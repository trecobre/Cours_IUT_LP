package com.example.taquin;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import com.example.taquin.Adaptateur.ImageAdaptateur;

public class GameActivity extends AppCompatActivity implements View.OnClickListener {
    int id;
    Map<Integer, Integer> board;
    int valLigne;
    int posNeutre;
    ImageView img;
    int chunk;
    int move;
    int idImg;

    private enum Direction{
        HAUT,
        BAS,
        GAUCHE,
        DROITE
    }

    @Override
    public void onCreate(Bundle bundle){

        super.onCreate(bundle);
        setContentView(R.layout.activity_game);

        move = 0;

        Intent intent = getIntent();
        img = new ImageView(this);
        idImg = intent.getIntExtra("id",0);
        img.setImageResource(intent.getIntExtra("id",0));
        chunk = intent.getIntExtra("chunk", 0);
        Bitmap[] imageChunks = splitImage1(img, chunk);

        GridView gv = findViewById(R.id.gridview);
        setGridView(imageChunks, chunk);
        gv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

            }
        });
        LinearLayout layout = findViewById(R.id.mainLayout);
        Context ctx = this;
        OnSwipeTouchListener OSTL = new OnSwipeTouchListener(ctx) {
            public void onSwipeTop() {
                switchPlace(Direction.HAUT);
            }
            public void onSwipeRight() {
                switchPlace(Direction.DROITE);
            }
            public void onSwipeLeft() {
                switchPlace(Direction.GAUCHE);
            }
            public void onSwipeBottom() {
                switchPlace(Direction.BAS);
            }
        };
        layout.setOnTouchListener(OSTL);
        gv.setOnTouchListener(OSTL);
    }

    private void setGridView(Bitmap[] imageChunks, int chunk){
        GridView gv = findViewById(R.id.gridview);
        gv.setAdapter(new ImageAdaptateur(this, imageChunks));
        gv.setNumColumns(chunk);
    }

    private void switchPlace(Direction direction){
        int val = board.get(posNeutre);
        int val2 = -1;
        int newPos = -1;
        if(direction == Direction.GAUCHE){
            for (int i = 0; i<board.size(); i++) {
                if(board.get(i)==val+1){
                    val2 = board.get(i);
                    newPos = i;
                }
            }
        }
        if(direction == Direction.DROITE){
            for (int i = 0; i<board.size(); i++) {
                if(board.get(i)==val-1){
                    val2 = board.get(i);
                    newPos = i;
                }
            }
        }
        if(direction == Direction.BAS){
            for (int i = 0; i<board.size(); i++) {
                if(board.get(i)==val-valLigne){
                    val2 = board.get(i);
                    newPos =i;
                }
            }
        }
        if(direction == Direction.HAUT){
            for (int i = 0; i<board.size(); i++) {
                if(board.get(i)==val+valLigne){
                    val2 = board.get(i);
                    newPos = i;
                }
            }
        }
        if(val2 > -1 && newPos > -1){
            board.replace(posNeutre, val2);
            board.replace(newPos, val);
            System.out.println(board);
            Bitmap[] imageChunk = splitImageByMap(img, chunk);
            setGridView(imageChunk, chunk);
            move++;
        }
        victoire();
    }

    private void victoire(){
        boolean win = true;
        for(int i=0; i<board.size(); i++){
            win = win && board.get(i)==i;
        }
        if(win){
            TextView tv = findViewById(R.id.textView7);
            tv.setText(R.string.win);

            Intent intent = new Intent();
            intent.setClass(this, WinActivity.class);
            intent.putExtra("move", move);
            intent.putExtra("level", idImg);
            intent.putExtra("scale", chunk);
            startActivity(intent);
        }
    }

    @Override
    public void onClick(View v) {

    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {

    }

    @NonNull
    private Bitmap[] splitImage(ImageView image, int chunkNumbers) {
        int cn = (int) Math.pow(chunkNumbers, 2);

        Bitmap[] splited = new Bitmap[cn];
        ArrayList<Integer> pos = new ArrayList<>();
        board = new HashMap<>(cn);

        Bitmap bitmap = ((BitmapDrawable)image.getDrawable()).getBitmap();
        Bitmap scaledBitmap = Bitmap.createScaledBitmap(bitmap, bitmap.getWidth(), bitmap.getHeight(), true);

        int row = chunkNumbers;
        int col = chunkNumbers;
        valLigne = chunkNumbers;


        int height = bitmap.getHeight() / row;
        int width = bitmap.getWidth() / col;

        int posY = 0;
        Bitmap bp;
        for(int x = 0; x < row; x++) {
            int posX = 0;
            for(int y = 0; y < col; y++) {
                int posRand = -1;
                do{
                    posRand = (int) (Math.random()*cn);
                }
                while(pos.contains(posRand));
                if((y+1)*(x+1)<cn){
                    bp = Bitmap.createBitmap(scaledBitmap, posX, posY, width, height);
                }
                else {
                    bp = null;
                    posNeutre = (x*row)+y;
                }
                pos.add(posRand);
                splited[posRand] = bp;
                board.put((x*row)+y, posRand);

                posX += width;
            }
            posY += height;
        }

        return splited;
    }

    @NonNull
    private Bitmap[] splitImage1(ImageView image, int chunkNumbers) {
        int cn = (int) Math.pow(chunkNumbers, 2);

        Bitmap[] splited = new Bitmap[cn];
        ArrayList<Integer> pos = new ArrayList<>();
        board = new HashMap<>(cn);

        Bitmap bitmap = ((BitmapDrawable)image.getDrawable()).getBitmap();
        Bitmap scaledBitmap = Bitmap.createScaledBitmap(bitmap, bitmap.getWidth(), bitmap.getHeight(), true);

        int row = chunkNumbers;
        int col = chunkNumbers;
        valLigne = chunkNumbers;


        int height = bitmap.getHeight() / row;
        int width = bitmap.getWidth() / col;

        int posY = 0;
        Bitmap bp;
        for(int x = 0; x < row; x++) {
            int posX = 0;
            for(int y = 0; y < col; y++) {
                int posRand = -1;
                do{
                    posRand = (x*row)+y;
                }
                while(pos.contains(posRand));
                if((y+1)*(x+1)<cn){
                    bp = Bitmap.createBitmap(scaledBitmap, posX, posY, width, height);
                }
                else {
                    bp = null;
                    posNeutre = (x*row)+y;
                }
                pos.add(posRand);
                splited[posRand] = bp;
                board.put((x*row)+y, posRand);

                posX += width;
            }
            posY += height;
        }

        return splited;
    }

    @NonNull
    private Bitmap[] splitImageByMap(ImageView image, int chunkNumbers) {
        int cn = (int) Math.pow(chunkNumbers, 2);

        Bitmap[] splited = new Bitmap[cn];
        ArrayList<Integer> pos = new ArrayList<>();

        Bitmap bitmap = ((BitmapDrawable)image.getDrawable()).getBitmap();
        Bitmap scaledBitmap = Bitmap.createScaledBitmap(bitmap, bitmap.getWidth(), bitmap.getHeight(), true);

        int row = chunkNumbers;
        int col = chunkNumbers;
        valLigne = chunkNumbers;


        int height = bitmap.getHeight() / row;
        int width = bitmap.getWidth() / col;

        int posY = 0;
        Bitmap bp;
        for(int x = 0; x < row; x++) {
            int posX = 0;
            for(int y = 0; y < col; y++) {
                if((y+1)*(x+1)<cn){
                    bp = Bitmap.createBitmap(scaledBitmap, posX, posY, width, height);
                }
                else {
                    bp = null;
                }
                splited[board.get((x*row)+y)] = bp;
                posX += width;
            }
            posY += height;
        }

        return splited;
    }
}
