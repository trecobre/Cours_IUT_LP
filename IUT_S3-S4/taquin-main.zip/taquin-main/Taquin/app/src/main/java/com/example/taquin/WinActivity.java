package com.example.taquin;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.TabStopSpan;
import android.util.Pair;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.io.StringWriter;
import java.io.UnsupportedEncodingException;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

public class WinActivity extends AppCompatActivity implements View.OnClickListener {
    int move;
    int idImg;
    int scale;
    String path;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_win);
        Intent intent = getIntent();
        move = intent.getIntExtra("move", 0);
        idImg = intent.getIntExtra("level", 0);
        scale = intent.getIntExtra("scale", 0);
        setWinView();
        Button button = findViewById(R.id.buttonValidate);
        button.setOnClickListener((View.OnClickListener) this);
    }

    private void setWinView(){
        LinearLayout linearLayout = findViewById(R.id.linearLayout);
        linearLayout.removeAllViews();
        String jsonString = "";
        path = getFilesDir() + "/" +
                "score.json";
        File file = new File(path);
        if(!file.exists()){
            try {
                file.createNewFile();
            } catch (IOException e) {
                System.out.println("66 : " + e.getMessage());
            }
        }
        else{
            jsonString = getScoreString();
        }
        try {
            if(!jsonString.isEmpty()){
                JSONObject jsonObject = new JSONObject(jsonString);
                JSONArray jsonArray = new JSONArray();
                jsonArray.put(jsonObject.get("score"));
                ArrayList<Pair<Integer, JSONObject>> array = new ArrayList<>();
                try {
                    for (int i=0; i<jsonArray.getJSONArray(0).length(); i++) {
                        JSONObject info = jsonArray.getJSONArray(0).getJSONObject(i);
                        Pair<Integer, JSONObject> pair = new Pair<>(Integer.parseInt(info.get("move").toString()), info);
                        array.add(pair);
                    }
                } catch (JSONException e) {
                    JSONObject info = jsonArray.getJSONObject(0);
                    Pair<Integer, JSONObject> pair = new Pair<>(Integer.parseInt(info.get("move").toString()), info);
                    array.add(pair);
                } catch (NumberFormatException e) {
                    e.printStackTrace();
                }
                ArrayList<Pair<Integer, JSONObject>> sortedArray = new ArrayList<>();
                for (Pair<Integer, JSONObject> pair : array) {
                    if(sortedArray.size()<1){
                        sortedArray.add(pair);
                    }
                    else{
                        int index=0;
                        boolean test = false;
                        int a=0;
                        for (Pair<Integer, JSONObject> paired : sortedArray) {
                            if(pair.first < paired.first){
                                a = index;
                                test = true;
                            }
                            if(!test) index++;
                        }
                        if(!test){
                            sortedArray.add(pair);
                        }
                        else{
                            sortedArray.add(a, pair);
                        }
                    }
                }
                String level = getResources().getResourceEntryName(idImg);

                System.out.println(level);
                int rank = 1;
                for (Pair<Integer, JSONObject> pair : sortedArray) {
                    JSONObject info = pair.second;
                    if(info.get("level").equals(level) && info.get("scale").equals(scale)){
                        TextView tv = new TextView(
                                this);
                        String text = rank + "\t\t\t";
                        rank++;
                        text += info.get("name") + "\t\t\t\t" + info.get("move");
                        tv.setText(text);
                        linearLayout.addView(tv);
                    }
                }
            }
        } catch (JSONException e) {
            System.out.println("107 : "+ e.getMessage());
        }
    }

    private String getScoreString() {
        try{
            InputStream is = this.openFileInput("score.json");
            Writer writer = new StringWriter();
            char[] buffer = new char[1024];
            try {
                Reader reader = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8));
                int n;
                while ((n = reader.read(buffer)) != -1) {
                    System.out.println(n);
                    writer.write(buffer, 0, n);
                }
            } catch (UnsupportedEncodingException e) {
                System.out.println("127 : " + e.getMessage());
            } catch (IOException e) {
                System.out.println("129 : " + e.getMessage());
            }
            String jsonString = writer.toString();
            return jsonString;
        } catch (FileNotFoundException e) {
            System.out.println("134 : " + e.getMessage());
            return "";
        }
    }

    @Override
    public void onClick(View v) {
        String jsonString = "";
        jsonString = getScoreString();
        try {
            JSONObject jObject;
            JSONObject jsonObject = new JSONObject();
            EditText edtx = findViewById(R.id.editTextTextPersonName);
            jsonObject.put("name", edtx.getText().toString());
            jsonObject.put("level", getResources().getResourceEntryName(idImg));
            jsonObject.put("scale", scale);
            jsonObject.put("move", move);
            JSONObject updatedJObject;
            OutputStreamWriter outputStreamWriter = new OutputStreamWriter(this.openFileOutput("score.json", Context.MODE_PRIVATE));
            if(jsonString.isEmpty()){
                jsonString = "{\"score\":[" +  jsonObject.toString() + "]}";
            }
            else{
                if(jsonString.length()>12){
                    String val = jsonString.substring(10);
                    jsonString = "{\"score\":[" + val.substring(0, val.length()-2) + "," + jsonObject.toString() + "]}";
                }
                else{
                    jsonString = "{\"score\":[" + jsonString + "," + jsonObject.toString() + "]}";
                }

            }
            outputStreamWriter.write(jsonString);
            outputStreamWriter.close();
            setWinView();
        } catch (JSONException | IOException e) {
            System.out.println("166 : " + e.getMessage()   );
        }
    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {

    }
}