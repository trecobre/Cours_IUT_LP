package com.example.taquin;

import java.util.ArrayList;

import android.content.Context;
import android.graphics.Bitmap;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;

//The adapter class associated with the ChunkedImageActivity class
public abstract class Adaptateur extends BaseAdapter{
    public static class ImageAdaptateur extends BaseAdapter {

        private Context mContext;
        private Bitmap[] imageChunks;
        private int imageWidth, imageHeight;


        //constructor
        public ImageAdaptateur(Context c, Bitmap[] images){
            mContext = c;
            imageChunks = images;

            imageWidth = (int) (650/Math.sqrt(imageChunks.length));
            imageHeight = (int) (650/Math.sqrt(imageChunks.length));
        }

        @Override
        public int getCount() {
            return imageChunks.length;
        }

        @Override
        public Object getItem(int position) {
            return imageChunks[position];
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            ImageView image;
            if(convertView == null){
                image = new ImageView(mContext);
                image.setLayoutParams(new GridView.LayoutParams(imageWidth , imageHeight));
                image.setPadding(2, 2, 2, 2);
            }else{
                image = (ImageView) convertView;
            }
            image.setImageBitmap(imageChunks[position]);
            return image;
        }
    }

    public static class CustomAdapter extends BaseAdapter {
        private int[] imageNames;
        private int[] imagesPhoto;
        private Context context;
        private LayoutInflater layoutInflater;

        public CustomAdapter(int[] imageNames, int[] imagesPhoto, Context context) {
            this.imageNames = imageNames;
            this.imagesPhoto = imagesPhoto;
            this.context = context;
            this.layoutInflater = (LayoutInflater) context.getSystemService(context.LAYOUT_INFLATER_SERVICE);
        }

        @Override
        public int getCount() {
            return imagesPhoto.length;
        }

        @Override
        public Object getItem(int i) {
            return null;
        }

        @Override
        public long getItemId(int i) {
            return 0;
        }

        @Override
        public View getView(int i, View view, ViewGroup viewGroup) {

            if(view == null){
                view = layoutInflater.inflate(R.layout.row_items, viewGroup, false);

            }

            TextView tvName = view.findViewById(R.id.tvName);
            ImageView imageView = view.findViewById(R.id.imageView);
            tvName.setText(imageNames[i]);
            imageView.setImageResource(imagesPhoto[i]);
            return view;
        }
    }
}
