package com.example.taquin;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.GridView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import com.example.taquin.Adaptateur.CustomAdapter;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    GridView gridView;

    int[] names = {R.string.img_bridge, R.string.img_canyon, R.string.img_dance, R.string.img_elephant, R.string.img_flower, R.string.img_house, R.string.img_lava, R.string.img_planet, R.string.img_road, R.string.img_rock};
    int[] images = {R.drawable.bridge,R.drawable.canyon,R.drawable.dance,R.drawable.elephant,R.drawable.flower,R.drawable.house,R.drawable.lava,R.drawable.planet,R.drawable.road,R.drawable.rock };
    private SeekBar seekBar;
    int[] dimension = {3, 4, 5, 6, 8, 10, 12, 15};
    View prec;
    int precI;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        gridView = findViewById(R.id.gridView);

        CustomAdapter customAdapter = new CustomAdapter(names, images, this);

        gridView.setAdapter(customAdapter);
        prec = gridView;
        precI = -1;
        Button button = findViewById(R.id.button);
        button.setOnClickListener(this);
        button.setVisibility(View.INVISIBLE);


        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                prec.setForeground(null);
                if(precI==i){
                    prec = gridView;
                    button.setVisibility(View.INVISIBLE);
                    precI=-1;
                }
                else{
                    view.setForeground(getResources().getDrawable(R.drawable.background_border));
                    prec = view;
                    button.setVisibility(View.VISIBLE);
                    precI = i;
                }

            }
        });

        this.seekBar = (SeekBar) findViewById(R.id.seekBar2);
        this.seekBar.setMax(dimension.length-1);
        TextView tvSeek = findViewById(R.id.textView4);
        tvSeek.setText( dimension[this.seekBar.getProgress()]+"x"+dimension[this.seekBar.getProgress()]);
        this.seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            int progress = 0;
            @Override
            public void onProgressChanged(SeekBar seekBar, int progressValue, boolean fromUser) {
                progress = progressValue;
                tvSeek.setText(dimension[progress]+"x"+dimension[progress]);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
    }

    @Override
    public void onClick(View v) {
        SeekBar sb = findViewById(R.id.seekBar2);
        Intent intent = new Intent();
        intent.setClass(this, GameActivity.class);
        intent.putExtra("id", images[precI]);
        intent.putExtra("chunk", dimension[sb.getProgress()]);
        startActivity(intent);
    }


}