#Librairies internes (Crée par nous dans le dossier classes/)
from classes.Image import Image
from classes.knn import knn
from classes.matrice_conv import matrice

#Librairies d'image
from skimage import io;
from matplotlib import image

# Librairies de temps
import time
from datetime import datetime
from dateutil import tz

# Librairies utilitaires
from array import typecodes
import os


start = time.time()
pathy = "Images Test/"

# Ouverture des fichiers en écriture des fichiers de logs 
f = open("journal.log", "w")
m = open("matrice.txt", "w")

FRA = tz.gettz('Europe/Paris')
date = datetime.now(tz=FRA)
f.write("----- Test OCR effectué le {}/{}/{} à {}:{}:{} -----\n\n".format(date.day, date.month, date.year, date.hour, date.minute, date.second))
m.write("----- Test OCR effectué le {}/{}/{} à {}:{}:{} -----\n\n".format(date.day, date.month, date.year, date.hour, date.minute, date.second))

fichier = os.listdir(pathy)
fichier.sort()

col = ["-", "+", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9"]
li = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10"]

vrai = 0
faux = 0

mat = matrice(11, 13)

mat.definirPremiereLigne(li)
mat.definirPremiereColonne(col)

# Compare une à une les images avec le reste du jeu de données
for nom_fichier in fichier:
    img1 = Image.init(pathy+nom_fichier)
    n_fichier = nom_fichier.split(".")[0]
    neurone = knn(img1, n_fichier)
    # Parcours de toutes les images du jeu de données
    for nom_fichier2 in os.listdir(pathy):
        img2 = Image.init(pathy+nom_fichier2)
        distance = neurone.voisin(img2, nom_fichier2.split("_")[0], nom_fichier == nom_fichier2) # Filtre sur les distances par rapport au voisinage
        f.write("Distance : "+nom_fichier + " - " + nom_fichier2 + "\t:\t{}".format(distance))
        f.write('\n')
    f.write('\n')
    
    # Execution de KNN
    proche = neurone.plusProches()
    mat.definirValeur(col.index(n_fichier.split("_")[0])+1, li.index(n_fichier.split("_")[1])+1, proche)
    if proche==n_fichier.split("_")[0]:
        vrai+=1
    else:
        faux+=1
    texte = "Image "+n_fichier+" reconnue telle que "+str(proche)+". \n\t" + str(vrai) + " reconnaissance(s) correcte(s).\n\t" + str(faux) + "reconnaissance(s) fausse(s).\n"
    f.write(texte)
    f.write("\n")
    print(texte)

tdr = (vrai/(vrai+faux))*100

# Retranscription dans les fichers logs
m.write(mat.to_string())
m.write("\nTaux de reconnaissance : {}%.".format(tdr))
m.close

end = time.time()
elapsed = end - start

minute = int(elapsed/60)
seconde = int(elapsed%60)

print("\n--------Résultat--------  \n\tNombre de reconnaissance(s) correcte(s) : {}\n\tNombre de reconnaissance(s) incorrecte(s) : {}\n\tTaux de reconnaissance : {}%\n\tTemps d'execution : {}min, {}sec\n\n".format(vrai, faux, tdr, minute,seconde))
f.write("\n--------Résultat--------  \n\tNombre de reconnaissance(s) correcte(s) : {}\n\tNombre de reconnaissance(s) incorrecte(s) : {}\n\tTaux de reconnaissance : {}%\n\tTemps d'execution : {}min, {}sec\n\n".format(vrai, faux, tdr, minute,seconde))

f.close()