from cgi import print_exception
from subprocess import list2cmdline
from array import *


class matrice:
    tab=[]

    def __init__(self, nb_rows, nb_cols):
        tab = []
        for i in range(nb_rows):
            col = [" "]*nb_cols
            tab.append(col)
        self.tab = tab

    def definirValeur(self, row: int, col:int, val):
        self.tab[col][row] = val

    def definirPremiereLigne(self, vals):
        for i in range(10):
            self.definirValeur(0, i+1, vals[i])


    def definirPremiereColonne(self, vals):
        for i in range(12):
            self.definirValeur(i+1, 0, vals[i])
    
    # Formattage de la matrice
    def to_string(self):
        versEcran = ""
        for i in range(11):
            for j in range(13):
                val = str(self.tab[i][j])
                versEcran += "   "+val
                if val == "10":
                    versEcran += "  "
                else:
                    versEcran += "   "    
                if j==0:
                    versEcran+="|"
            if i == 0:
                versEcran += "\n"
                for i in range(((3+3+1)*13)+2):
                    versEcran += "—"
                versEcran += "\n"
            else:
                versEcran += "\n"
        return versEcran
    