from skimage import io;
from skimage.transform import rescale,resize
import numpy as np

class Image(np.ndarray):
    name=""
    def __init__(self) -> None:
        super().__init__()

    # Conversion en binaire
    def clarifier(img) -> np.ndarray:
        new_img = []
        for i in range(25):
            line = []
            for j in range(25):
                val = (img[i][j][0] + img[i][j][1] + img[i][j][2])/3
                if val<=0.91:
                    line.append(0)
                else:
                    line.append(1)
            new_img.append(line)
        to_return = np.asarray(new_img)
        return to_return

    def init(path) :
        img = io.imread(path)
        img_r = resize(img, (25,25))

        return Image.clarifier(img_r)

    def conversionMatricielle(array):
        mat = np.matrix(array)
        return mat
        
