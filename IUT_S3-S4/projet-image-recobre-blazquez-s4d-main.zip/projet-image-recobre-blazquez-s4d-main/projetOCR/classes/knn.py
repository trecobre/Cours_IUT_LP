import numpy as np
from classes.Image import Image

class knn:

    image = Image.init("Images Test/-_1.png")
    name = ""
    dist = {(str, float)}

    def __init__(self,image, name):
        self.image = image
        self.name = name
        self.dist.clear()
 
    #Distance euclidienne
    def distance(l1,l2):
        d = 0.0
        for i in range(25):
            d += (l1[i] - l2[i])**2
        return np.sqrt(d);    

    # Compare les distances par rapport aux lignes puis elle ajoute les distances si l'image ne se compare pas elle même.
    def voisin(self,img2, categorie, same:bool):
        distance = 0
        for i in range(25):
            distance += knn.distance(self.image[i], img2[i])
        if not same:
            self.dist.add((categorie, distance))
        return distance

    # Compare les voisins selon leurs distance en n'en choisissant 5 pour k = 5 
    def plusProches(self):
        ppv = [(" ", 300)]*5
        for i in self.dist:
            if ppv[4][1] > i[1]:
                ppv[4] = i
                if ppv[3][1] > i[1]:
                    ppv[4] = ppv[3]
                    ppv[3] = i
                    if ppv[2][1] > i[1]:
                        ppv[3] = ppv[2]
                        ppv[2] = i
                        if ppv[1][1] > i[1]:
                            ppv[2] = ppv[1]
                            ppv[1] = i
                            if ppv[0][1] > i[1]:
                                ppv[1] = ppv[0]
                                ppv[0] = i
        appartenance = ""
        max = 0
        for i in ppv:
            max_temp = 0
            for j in ppv:
                if i[0] == j[0]:
                    max_temp+=1
            if max < max_temp:
                appartenance = i[0]
                max = max_temp
        return appartenance
