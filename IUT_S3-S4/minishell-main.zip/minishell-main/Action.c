#include "Action.h"
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include "Shell.h"
#include "StringVector.h"


char* output;
char* param;


void do_help(struct Shell *this, const struct StringVector *args)
{
    output = "tapez exit pour arrêter\n";
    write(STDOUT_FILENO, output, strlen(output));
}

void do_system(struct Shell *this, const struct StringVector *args){
    system(getenv("SHELL"));
}

void do_exit(struct Shell *this, const struct StringVector *args){
    this->running = false;
}

void do_cd(struct Shell *this, const struct StringVector *args){
    param = malloc(255);
    if(string_vector_size(args)>1){
        strcpy(param, string_vector_get(args, 1));
        if(strcmp(param,"..")==0){
            chdir("..");
        }
        else{
            if(chdir(param) != 0){
                output = "Aucun dossier de ce nom n'a été trouvé.\n";
                write(STDOUT_FILENO, output, strlen(output));
            }
        }
    }
    else{
        chdir(getenv("HOME"));
    }
    free(param);
}

void do_execute(struct Shell *this, const struct StringVector *args){
    char * cmd = malloc(string_vector_size(args)*100);
    strjoinarray(cmd, args, 0,string_vector_size(args), " ");
    int trycmd = system(cmd);
    free(cmd);
    if(trycmd==-1){
        output = "commande inconnue\n";
        write(STDOUT_FILENO, output, strlen(output));
    }
}

static struct{
    const char *name;
    Action action;
} 
actions[] = {
{ .name = "exit",.action = do_exit},
{ .name = "cd",.action = do_cd},
{ .name = "help",.action = do_help},
{ .name = "?", .action = do_help},
{ .name = "!",.action = do_system},
{ .name = NULL,.action = do_execute}
};

Action get_action(char * name)
{
    int i = 0;
    while (actions[i].name != NULL
        && strcmp(actions[i].name, name) != 0) {
        i++;
    }
    return actions[i].action;
}

void apply_action(char *name, struct Shell *s, const struct StringVector *args) {
    Action act = get_action(name);
    act(s, args);
}
