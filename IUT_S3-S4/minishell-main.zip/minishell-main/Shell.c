#include "Shell.h"
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "StringVector.h"
#include "Action.h"

char output[255];
struct StringVector command;
void shell_init(struct Shell *s){
    s->buffer = malloc(255);
    s->buffer_size = 0;
    s->line_number = 1;
    s->running = false;
}

void shell_run(struct Shell *s){
    s->running = true;
    //system("/bin/bash");
    while(s->running){
        shell_read_line(s);
        if(s->buffer_size > 1){
            shell_execute_line(s);
        }
    }
}

void reset_buffer(struct Shell *s){
    free(s->buffer);
    s->buffer = malloc(255);
}

void shell_free(struct Shell *s){
    free(s->buffer);
}

void shell_read_line(struct Shell *s){
    sprintf(output, "<[%d]> MiniShell - Recobre > ", s->line_number);
    write(STDOUT_FILENO, output, strlen(output));
    reset_buffer(s);
    s->buffer_size = read(STDIN_FILENO, s->buffer, 100);
    ++(s->line_number);
}

void shell_execute_line(struct Shell *s){
    command = split_line(s->buffer);
    char* cmd_line = malloc(s->buffer_size);
    strcpy(cmd_line, string_vector_get(&command, 0));
    apply_action(cmd_line, s, &command);
    string_vector_free(&command);
    free(cmd_line);
}
