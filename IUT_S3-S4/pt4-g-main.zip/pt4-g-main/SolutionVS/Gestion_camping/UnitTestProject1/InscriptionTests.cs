﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Gestion_camping.Resources;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gestion_camping.Resources.Tests
{
    [TestClass()]
    public class InscriptionTests
    {
        [TestMethod()]
        public void InscriptionTest()
        {
            Utilisateur utilisateur = new Utilisateur();
            utilisateur.login = "test99";
            utilisateur.nomUtilisateur = "test";
            utilisateur.password = "testLog3*";
            utilisateur.prenomUtilisateur = "99";
            utilisateur.telephoneUtilisateur = "0123456789";
            Utils.Inscription(utilisateur);
            Assert.AreEqual(utilisateur, utilisateur);
        }

        [TestMethod()]
        public void buttonConfirm_ClickTest()
        {
            
            Assert.Fail();
        }
    }
}