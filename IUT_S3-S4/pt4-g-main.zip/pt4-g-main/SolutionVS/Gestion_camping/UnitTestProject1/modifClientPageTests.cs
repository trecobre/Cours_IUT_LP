﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Gestion_camping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gestion_camping.Tests
{
    [TestClass()]
    public class modifClientPageTests
    {
        [TestMethod()]
        public void modifClientPageTest()
        {
            Assert.Fail();
        }
    }
}