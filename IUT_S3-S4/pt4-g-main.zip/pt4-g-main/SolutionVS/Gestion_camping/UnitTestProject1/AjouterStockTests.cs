﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Gestion_camping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gestion_camping.Tests
{
    [TestClass()]
    public class AjouterStockTests
    {
        readonly BD_PT4_S4D_E1Entities1 entities = new BD_PT4_S4D_E1Entities1();

        [TestMethod()]
        public void AjouterStockTest()
        {
            AjouterStock ajoutStock = new AjouterStock();
            Stock stock = new Stock();
            stock.prixProduit = 99;
            stock.datePeremption = DateTime.Now;
            stock.quantiteProduit = 50;
            entities.Stock.Add(stock);
            Stock newStock = entities.Stock.First(x => x.prixProduit == stock.prixProduit);
            Assert.IsTrue(newStock.prixProduit == stock.prixProduit);
        }

        [TestMethod()]
        public void getDataTest()
        {
            Assert.Fail();
        }
    }
}