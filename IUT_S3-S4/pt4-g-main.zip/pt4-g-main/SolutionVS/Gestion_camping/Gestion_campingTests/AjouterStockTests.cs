﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Gestion_camping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gestion_camping.Tests
{
    [TestClass()]
    public class AjouterStockTests
    {
        [TestMethod()]
        public void AjouterStockTest()
        {
            Assert.Fail();
        }

        [TestMethod()]
        public void getDataTest()
        {
            Assert.Fail();
        }
    }
}