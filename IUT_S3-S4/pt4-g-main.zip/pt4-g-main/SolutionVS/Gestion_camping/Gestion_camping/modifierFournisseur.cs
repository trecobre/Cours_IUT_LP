﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using Microsoft.Extensions.Logging;

namespace Gestion_camping
{
    public partial class modifierFournisseur : Form
    {
        ILogger _logger;
        BD_PT4_S4D_E1Entities1 entities = Program.bdEntities;
        public modifierFournisseur(Fournisseur fournisseur)
        {
        }

        public modifierFournisseur(ILogger logger)
        {
            _logger = logger;
            InitializeComponent();
            fillPanel();
        }

        void fillPanel()
        {
            listBox.Items.Clear();
            listBox.Items.Add("-- Ajouter --");
            Fournisseur[] fournisseur = entities.Fournisseur.ToArray();
            listBox.Items.AddRange(fournisseur);
        }

        private void suppFournisseurButton_Click(object sender, EventArgs e)
        {
            if (listBox.SelectedItem != null)
            {
                if (!(listBox.SelectedItem.ToString()== "-- Ajouter --"))
                {
                    Fournisseur fournisseur = (Fournisseur)listBox.SelectedItem;
                    entities.Fournisseur.Remove(entities.Fournisseur.First(f => f.FournisseurID == fournisseur.FournisseurID));
                    entities.SaveChanges();
                    _logger.LogInformation($"Suppresion fournisseur. Nom: {fournisseur.nomFournisseur}, tel: {fournisseur.telephoneFournisseur}");
                    fillPanel();
                }
            }
        }

        private void ModifButton_Click(object sender, EventArgs e)
        {
            if (listBox.SelectedItem != null)
            {
                bool updatable = true;
                if (textBox_NomProduit.Text == String.Empty)
                {
                    updatable = false;
                    label_Nom_Produit.ForeColor = Color.Red;
                }
                else
                {
                    label_Nom_Produit.ForeColor = Color.Black;
                }

                string patern = @"\(?\d{3}\)?-? *\d{3}-? *-?\d{4}";
                Regex rxPhone = new Regex(patern, RegexOptions.Compiled | RegexOptions.IgnoreCase);
                if (!(telephoneTextBox.Text.Length > 0 && rxPhone.IsMatch(telephoneTextBox.Text)))
                {
                    updatable = false;
                    label_Telephone.ForeColor = Color.Red;
                }
                else
                {
                    label_Telephone.ForeColor = Color.Black;
                }

                if (updatable)
                {
                    if ((String)listBox.SelectedItem == "-- Ajouter --")
                    {
                        Fournisseur fournisseur = getData();
                        entities.Fournisseur.Add(fournisseur);
                        _logger.LogInformation($"Ajout fournisseur. Nom: {fournisseur.nomFournisseur}, tel: {fournisseur.telephoneFournisseur}");
                    }
                    else
                    {
                        Fournisseur fournisseur = getData();
                        entities.Fournisseur.First(f => f.FournisseurID == fournisseur.FournisseurID).changetochanged(fournisseur);
                        _logger.LogInformation($"Update fournisseur. Nom: {fournisseur.nomFournisseur}({fournisseur.FournisseurID}), tel: {fournisseur.telephoneFournisseur}");
                    }
                    entities.SaveChanges();
                    fillPanel();
                }
            }
        }

        public Fournisseur getData()
        {
            Fournisseur fournisseur = new Fournisseur();
            fournisseur.nomFournisseur = textBox_NomProduit.Text;
            fournisseur.telephoneFournisseur=telephoneTextBox.Text;
            return fournisseur;
        }

        private void listBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBox.SelectedItem != null)
            {
                if (listBox.SelectedItem.ToString() == "-- Ajouter --")
                {

                }
                else
                {
                    Fournisseur fournisseur = (Fournisseur)listBox.SelectedItem;
                    textBox_NomProduit.Text = fournisseur.nomFournisseur;
                    telephoneTextBox.Text = fournisseur.telephoneFournisseur;
                    _logger.LogInformation($"Selection fournisseur. Nom: {fournisseur.nomFournisseur}, tel: {fournisseur.telephoneFournisseur}");
                }

            }
        }
    }
}