﻿namespace Gestion_camping
{
    partial class AjoutStock
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.CloselButton = new System.Windows.Forms.Button();
            this.label_Fournisseur = new System.Windows.Forms.Label();
            this.label_Nom_Produit = new System.Windows.Forms.Label();
            this.numericUpDown_Quantite = new System.Windows.Forms.NumericUpDown();
            this.addButton = new System.Windows.Forms.Button();
            this.richTextBox_Description = new System.Windows.Forms.RichTextBox();
            this.label_Description = new System.Windows.Forms.Label();
            this.DateLabel = new System.Windows.Forms.Label();
            this.label_Quantite = new System.Windows.Forms.Label();
            this.listBox_Produits = new System.Windows.Forms.ListBox();
            this.peremptionDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.textBox_Fournisseur = new System.Windows.Forms.TextBox();
            this.textBox_NomProduit = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.perissableCheckBox = new System.Windows.Forms.CheckBox();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_Quantite)).BeginInit();
            this.SuspendLayout();
            // 
            // CloselButton
            // 
            this.CloselButton.DialogResult = System.Windows.Forms.DialogResult.Abort;
            this.CloselButton.Location = new System.Drawing.Point(122, 201);
            this.CloselButton.Name = "CloselButton";
            this.CloselButton.Size = new System.Drawing.Size(75, 23);
            this.CloselButton.TabIndex = 29;
            this.CloselButton.Text = "Fermer";
            this.CloselButton.UseVisualStyleBackColor = true;
            // 
            // label_Fournisseur
            // 
            this.label_Fournisseur.AutoSize = true;
            this.label_Fournisseur.Location = new System.Drawing.Point(150, 131);
            this.label_Fournisseur.Name = "label_Fournisseur";
            this.label_Fournisseur.Size = new System.Drawing.Size(61, 13);
            this.label_Fournisseur.TabIndex = 27;
            this.label_Fournisseur.Text = "Fournisseur";
            // 
            // label_Nom_Produit
            // 
            this.label_Nom_Produit.AutoSize = true;
            this.label_Nom_Produit.Location = new System.Drawing.Point(150, 20);
            this.label_Nom_Produit.Name = "label_Nom_Produit";
            this.label_Nom_Produit.Size = new System.Drawing.Size(29, 13);
            this.label_Nom_Produit.TabIndex = 26;
            this.label_Nom_Produit.Text = "Nom";
            // 
            // numericUpDown_Quantite
            // 
            this.numericUpDown_Quantite.Location = new System.Drawing.Point(216, 47);
            this.numericUpDown_Quantite.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.numericUpDown_Quantite.Name = "numericUpDown_Quantite";
            this.numericUpDown_Quantite.Size = new System.Drawing.Size(120, 20);
            this.numericUpDown_Quantite.TabIndex = 23;
            // 
            // addButton
            // 
            this.addButton.Location = new System.Drawing.Point(12, 201);
            this.addButton.Name = "addButton";
            this.addButton.Size = new System.Drawing.Size(82, 23);
            this.addButton.TabIndex = 22;
            this.addButton.Text = "Ajouter stock";
            this.addButton.UseVisualStyleBackColor = true;
            this.addButton.Click += new System.EventHandler(this.addButton_Click);
            // 
            // richTextBox_Description
            // 
            this.richTextBox_Description.BackColor = System.Drawing.SystemColors.Window;
            this.richTextBox_Description.Location = new System.Drawing.Point(216, 166);
            this.richTextBox_Description.Name = "richTextBox_Description";
            this.richTextBox_Description.ReadOnly = true;
            this.richTextBox_Description.Size = new System.Drawing.Size(179, 68);
            this.richTextBox_Description.TabIndex = 21;
            this.richTextBox_Description.Text = "";
            // 
            // label_Description
            // 
            this.label_Description.AutoSize = true;
            this.label_Description.Location = new System.Drawing.Point(150, 166);
            this.label_Description.Name = "label_Description";
            this.label_Description.Size = new System.Drawing.Size(60, 13);
            this.label_Description.TabIndex = 20;
            this.label_Description.Text = "Description";
            // 
            // DateLabel
            // 
            this.DateLabel.AutoSize = true;
            this.DateLabel.Location = new System.Drawing.Point(150, 82);
            this.DateLabel.Name = "DateLabel";
            this.DateLabel.Size = new System.Drawing.Size(56, 13);
            this.DateLabel.TabIndex = 19;
            this.DateLabel.Text = "Date limite";
            // 
            // label_Quantite
            // 
            this.label_Quantite.AutoSize = true;
            this.label_Quantite.Location = new System.Drawing.Point(150, 51);
            this.label_Quantite.Name = "label_Quantite";
            this.label_Quantite.Size = new System.Drawing.Size(47, 13);
            this.label_Quantite.TabIndex = 18;
            this.label_Quantite.Text = "Quantité";
            // 
            // listBox_Produits
            // 
            this.listBox_Produits.BackColor = System.Drawing.SystemColors.Window;
            this.listBox_Produits.FormattingEnabled = true;
            this.listBox_Produits.Location = new System.Drawing.Point(12, 12);
            this.listBox_Produits.Name = "listBox_Produits";
            this.listBox_Produits.Size = new System.Drawing.Size(120, 173);
            this.listBox_Produits.TabIndex = 17;
            this.listBox_Produits.SelectedIndexChanged += new System.EventHandler(this.listBox_Produits_SelectedIndexChanged);
            // 
            // peremptionDateTimePicker
            // 
            this.peremptionDateTimePicker.Location = new System.Drawing.Point(216, 78);
            this.peremptionDateTimePicker.Name = "peremptionDateTimePicker";
            this.peremptionDateTimePicker.Size = new System.Drawing.Size(200, 20);
            this.peremptionDateTimePicker.TabIndex = 31;
            // 
            // textBox_Fournisseur
            // 
            this.textBox_Fournisseur.BackColor = System.Drawing.SystemColors.Window;
            this.textBox_Fournisseur.Location = new System.Drawing.Point(216, 128);
            this.textBox_Fournisseur.Name = "textBox_Fournisseur";
            this.textBox_Fournisseur.ReadOnly = true;
            this.textBox_Fournisseur.Size = new System.Drawing.Size(193, 20);
            this.textBox_Fournisseur.TabIndex = 28;
            // 
            // textBox_NomProduit
            // 
            this.textBox_NomProduit.BackColor = System.Drawing.SystemColors.Window;
            this.textBox_NomProduit.Location = new System.Drawing.Point(216, 17);
            this.textBox_NomProduit.Name = "textBox_NomProduit";
            this.textBox_NomProduit.ReadOnly = true;
            this.textBox_NomProduit.Size = new System.Drawing.Size(120, 20);
            this.textBox_NomProduit.TabIndex = 25;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(150, 103);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(80, 13);
            this.label1.TabIndex = 32;
            this.label1.Text = "Non perissable ";
            // 
            // perissableCheckBox
            // 
            this.perissableCheckBox.AutoSize = true;
            this.perissableCheckBox.Location = new System.Drawing.Point(238, 103);
            this.perissableCheckBox.Name = "perissableCheckBox";
            this.perissableCheckBox.Size = new System.Drawing.Size(15, 14);
            this.perissableCheckBox.TabIndex = 33;
            this.perissableCheckBox.UseVisualStyleBackColor = true;
            // 
            // AjouterStock
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(421, 254);
            this.Controls.Add(this.perissableCheckBox);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.peremptionDateTimePicker);
            this.Controls.Add(this.CloselButton);
            this.Controls.Add(this.textBox_Fournisseur);
            this.Controls.Add(this.label_Fournisseur);
            this.Controls.Add(this.label_Nom_Produit);
            this.Controls.Add(this.textBox_NomProduit);
            this.Controls.Add(this.numericUpDown_Quantite);
            this.Controls.Add(this.addButton);
            this.Controls.Add(this.richTextBox_Description);
            this.Controls.Add(this.label_Description);
            this.Controls.Add(this.DateLabel);
            this.Controls.Add(this.label_Quantite);
            this.Controls.Add(this.listBox_Produits);
            this.Name = "AjouterStock";
            this.Text = "AjouterStock";
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_Quantite)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button CloselButton;
        private System.Windows.Forms.Label label_Fournisseur;
        private System.Windows.Forms.Label label_Nom_Produit;
        private System.Windows.Forms.NumericUpDown numericUpDown_Quantite;
        private System.Windows.Forms.Button addButton;
        private System.Windows.Forms.RichTextBox richTextBox_Description;
        private System.Windows.Forms.Label label_Description;
        private System.Windows.Forms.Label DateLabel;
        private System.Windows.Forms.Label label_Quantite;
        private System.Windows.Forms.ListBox listBox_Produits;
        private System.Windows.Forms.DateTimePicker peremptionDateTimePicker;
        private System.Windows.Forms.TextBox textBox_Fournisseur;
        private System.Windows.Forms.TextBox textBox_NomProduit;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.CheckBox perissableCheckBox;
    }
}