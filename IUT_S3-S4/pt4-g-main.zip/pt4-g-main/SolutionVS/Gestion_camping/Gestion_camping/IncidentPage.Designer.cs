﻿namespace Gestion_camping
{
    partial class IncidentPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any Resources being used.
        /// </summary>
        /// <param name="disposing">true if managed Resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.IncidentPanel = new System.Windows.Forms.Panel();
            this.labelAstuce = new System.Windows.Forms.Label();
            this.flowLayoutPanelInc = new System.Windows.Forms.FlowLayoutPanel();
            this.IncidentLabel = new System.Windows.Forms.Label();
            this.panelInc = new System.Windows.Forms.Panel();
            this.buttonPrio = new System.Windows.Forms.Button();
            this.buttonFin = new System.Windows.Forms.Button();
            this.labelStatut = new System.Windows.Forms.Label();
            this.labelFin = new System.Windows.Forms.Label();
            this.labelDebut = new System.Windows.Forms.Label();
            this.labelEmplacement = new System.Windows.Forms.Label();
            this.labelDescription = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.IncidentPanel.SuspendLayout();
            this.panelInc.SuspendLayout();
            this.SuspendLayout();
            // 
            // IncidentPanel
            // 
            this.IncidentPanel.BackColor = System.Drawing.Color.Transparent;
            this.IncidentPanel.Controls.Add(this.labelAstuce);
            this.IncidentPanel.Controls.Add(this.flowLayoutPanelInc);
            this.IncidentPanel.Controls.Add(this.button1);
            this.IncidentPanel.Controls.Add(this.IncidentLabel);
            this.IncidentPanel.Location = new System.Drawing.Point(12, 12);
            this.IncidentPanel.Name = "IncidentPanel";
            this.IncidentPanel.Size = new System.Drawing.Size(730, 460);
            this.IncidentPanel.TabIndex = 25;
            // 
            // labelAstuce
            // 
            this.labelAstuce.AutoSize = true;
            this.labelAstuce.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelAstuce.Location = new System.Drawing.Point(315, 434);
            this.labelAstuce.Name = "labelAstuce";
            this.labelAstuce.Size = new System.Drawing.Size(413, 16);
            this.labelAstuce.TabIndex = 27;
            this.labelAstuce.Text = "Astuce : Cliquez sur une réservation pour la modifier ou voir la facture";
            // 
            // flowLayoutPanelInc
            // 
            this.flowLayoutPanelInc.AutoScroll = true;
            this.flowLayoutPanelInc.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.flowLayoutPanelInc.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.flowLayoutPanelInc.Location = new System.Drawing.Point(21, 49);
            this.flowLayoutPanelInc.Name = "flowLayoutPanelInc";
            this.flowLayoutPanelInc.Size = new System.Drawing.Size(671, 382);
            this.flowLayoutPanelInc.TabIndex = 26;
            this.flowLayoutPanelInc.WrapContents = false;
            // 
            // IncidentLabel
            // 
            this.IncidentLabel.AutoSize = true;
            this.IncidentLabel.Location = new System.Drawing.Point(18, 13);
            this.IncidentLabel.Name = "IncidentLabel";
            this.IncidentLabel.Size = new System.Drawing.Size(69, 13);
            this.IncidentLabel.TabIndex = 0;
            this.IncidentLabel.Text = "Réservations";
            // 
            // panelInc
            // 
            this.panelInc.BackColor = System.Drawing.Color.Chartreuse;
            this.panelInc.Controls.Add(this.buttonPrio);
            this.panelInc.Controls.Add(this.buttonFin);
            this.panelInc.Controls.Add(this.labelStatut);
            this.panelInc.Controls.Add(this.labelFin);
            this.panelInc.Controls.Add(this.labelDebut);
            this.panelInc.Controls.Add(this.labelEmplacement);
            this.panelInc.Controls.Add(this.labelDescription);
            this.panelInc.Location = new System.Drawing.Point(776, 189);
            this.panelInc.Name = "panelInc";
            this.panelInc.Size = new System.Drawing.Size(613, 96);
            this.panelInc.TabIndex = 26;
            this.panelInc.Click += new System.EventHandler(this.modifie);
            // 
            // buttonPrio
            // 
            this.buttonPrio.Location = new System.Drawing.Point(420, 50);
            this.buttonPrio.Name = "buttonPrio";
            this.buttonPrio.Size = new System.Drawing.Size(179, 23);
            this.buttonPrio.TabIndex = 36;
            this.buttonPrio.Text = "Supprimer l\'incident";
            this.buttonPrio.UseVisualStyleBackColor = true;
            this.buttonPrio.Click += new System.EventHandler(this.buttonSupprimer_Click);
            // 
            // buttonFin
            // 
            this.buttonFin.Location = new System.Drawing.Point(420, 21);
            this.buttonFin.Name = "buttonFin";
            this.buttonFin.Size = new System.Drawing.Size(179, 23);
            this.buttonFin.TabIndex = 35;
            this.buttonFin.Text = "Mettre fin à l\'incident ";
            this.buttonFin.UseVisualStyleBackColor = true;
            this.buttonFin.Click += new System.EventHandler(this.buttonFin_Click);
            // 
            // labelStatut
            // 
            this.labelStatut.AutoSize = true;
            this.labelStatut.BackColor = System.Drawing.Color.Transparent;
            this.labelStatut.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelStatut.ForeColor = System.Drawing.SystemColors.ControlText;
            this.labelStatut.Location = new System.Drawing.Point(315, 50);
            this.labelStatut.MaximumSize = new System.Drawing.Size(105, 36);
            this.labelStatut.Name = "labelStatut";
            this.labelStatut.Padding = new System.Windows.Forms.Padding(10);
            this.labelStatut.Size = new System.Drawing.Size(58, 36);
            this.labelStatut.TabIndex = 34;
            this.labelStatut.Text = "lapel";
            this.labelStatut.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.labelStatut.Click += new System.EventHandler(this.modifie);
            // 
            // labelFin
            // 
            this.labelFin.AutoSize = true;
            this.labelFin.BackColor = System.Drawing.Color.Transparent;
            this.labelFin.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelFin.ForeColor = System.Drawing.SystemColors.ControlText;
            this.labelFin.Location = new System.Drawing.Point(210, 50);
            this.labelFin.MaximumSize = new System.Drawing.Size(105, 36);
            this.labelFin.Name = "labelFin";
            this.labelFin.Padding = new System.Windows.Forms.Padding(10);
            this.labelFin.Size = new System.Drawing.Size(58, 36);
            this.labelFin.TabIndex = 33;
            this.labelFin.Text = "lapel";
            this.labelFin.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.labelFin.Click += new System.EventHandler(this.modifie);
            // 
            // labelDebut
            // 
            this.labelDebut.AutoSize = true;
            this.labelDebut.BackColor = System.Drawing.Color.Transparent;
            this.labelDebut.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelDebut.ForeColor = System.Drawing.SystemColors.ControlText;
            this.labelDebut.Location = new System.Drawing.Point(105, 50);
            this.labelDebut.MaximumSize = new System.Drawing.Size(105, 36);
            this.labelDebut.Name = "labelDebut";
            this.labelDebut.Padding = new System.Windows.Forms.Padding(10);
            this.labelDebut.Size = new System.Drawing.Size(58, 36);
            this.labelDebut.TabIndex = 32;
            this.labelDebut.Text = "lapel";
            this.labelDebut.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.labelDebut.Click += new System.EventHandler(this.modifie);
            // 
            // labelEmplacement
            // 
            this.labelEmplacement.AutoSize = true;
            this.labelEmplacement.BackColor = System.Drawing.Color.Transparent;
            this.labelEmplacement.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelEmplacement.ForeColor = System.Drawing.SystemColors.ControlText;
            this.labelEmplacement.Location = new System.Drawing.Point(0, 50);
            this.labelEmplacement.MaximumSize = new System.Drawing.Size(105, 36);
            this.labelEmplacement.Name = "labelEmplacement";
            this.labelEmplacement.Padding = new System.Windows.Forms.Padding(10);
            this.labelEmplacement.Size = new System.Drawing.Size(58, 36);
            this.labelEmplacement.TabIndex = 31;
            this.labelEmplacement.Text = "lapel";
            this.labelEmplacement.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.labelEmplacement.Click += new System.EventHandler(this.modifie);
            // 
            // labelDescription
            // 
            this.labelDescription.AutoSize = true;
            this.labelDescription.BackColor = System.Drawing.Color.Transparent;
            this.labelDescription.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelDescription.ForeColor = System.Drawing.SystemColors.ControlText;
            this.labelDescription.Location = new System.Drawing.Point(0, 9);
            this.labelDescription.MaximumSize = new System.Drawing.Size(305, 36);
            this.labelDescription.Name = "labelDescription";
            this.labelDescription.Padding = new System.Windows.Forms.Padding(10);
            this.labelDescription.Size = new System.Drawing.Size(58, 36);
            this.labelDescription.TabIndex = 27;
            this.labelDescription.Text = "lapel";
            this.labelDescription.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.labelDescription.Click += new System.EventHandler(this.modifie);
            // 
            // button1
            // 
            this.button1.BackgroundImage = global::Gestion_camping.Properties.Resources.icons8_plus_96;
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button1.Location = new System.Drawing.Point(652, 3);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(40, 40);
            this.button1.TabIndex = 2;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // IncidentPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1486, 635);
            this.Controls.Add(this.IncidentPanel);
            this.Controls.Add(this.panelInc);
            this.Name = "IncidentPage";
            this.Text = "IncidentPage";
            this.IncidentPanel.ResumeLayout(false);
            this.IncidentPanel.PerformLayout();
            this.panelInc.ResumeLayout(false);
            this.panelInc.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel IncidentPanel;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label IncidentLabel;
        private System.Windows.Forms.Panel panelInc;
        private System.Windows.Forms.Label labelDescription;
        private System.Windows.Forms.Label labelFin;
        private System.Windows.Forms.Label labelDebut;
        private System.Windows.Forms.Label labelEmplacement;
        private System.Windows.Forms.Button buttonPrio;
        private System.Windows.Forms.Button buttonFin;
        private System.Windows.Forms.Label labelStatut;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanelInc;
        private System.Windows.Forms.Label labelAstuce;
    }
}