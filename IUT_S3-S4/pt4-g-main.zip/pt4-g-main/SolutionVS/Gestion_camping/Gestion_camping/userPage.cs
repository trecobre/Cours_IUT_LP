﻿using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;
using System.Windows.Navigation;

namespace Gestion_camping
{
    public partial class userPage : Form, IPanel
    {
        /* This is the constructor of the userPage class. It is used to initialize the form and to add
        the content panel to the form. */
        public userPage(bool admin, Utilisateur user, ILogger logger)
        {
            InitializeComponent();
            initChartEmplacement();
            initChartProduit();
            initChartClient();
            Panel content = this.boardPanel;
            this.Controls.Clear();
        }

        public void initChartEmplacement()
        {
            IDictionary<Emplacement, int> emplacements = new Dictionary<Emplacement, int>();
            Emplacement[] empl = Program.bdEntities.Emplacement.ToArray();
            int max = 0;
            foreach (var emplacement in empl)
            {
                emplacements.Add(emplacement, Program.bdEntities.Reservation.Where(r => r.emplacementID == emplacement.EmplacementID).Count());
            }
            var sortedDict = (from entry in emplacements orderby entry.Value descending select entry).ToArray();
            if(sortedDict.Length > 10)
            {
                max = 10;
            }
            else
            {
                max = sortedDict.Length;
            }

            this.chart1.Series.Clear();
            Series series = this.chart1.Series.Add("Emplacement");
            series.Palette = ChartColorPalette.SeaGreen;
            series.Label = "#VALX";
            series.CustomProperties = "DrawSideBySide=True, LabelStyle=Bottom";
            for (int i = 0; i < max; i++)
            {
                series.Points.AddXY(sortedDict[i].Key.intitule, sortedDict[i].Value);
            }
        }

        public void initChartProduit()
        {
            int max = 0;
            IDictionary<Produit, int> produits = new Dictionary<Produit, int>();
            Produit[] prd = Program.bdEntities.Produit.ToArray();
            foreach (var produit in prd)
            {
                produits.Add(produit, Program.bdEntities.Produit.Where(p => p.ProduitID == produit.ProduitID).FirstOrDefault().Vente.Sum(q => q.quantiteVente));
            }
            var sortedDict = (from entry in produits orderby entry.Value descending select entry).ToArray();

            if (sortedDict.Length > 10)
            {
                max = 10;
            }
            else
            {
                max = sortedDict.Length;
            }

            this.chart2.Series.Clear();

            Series series = this.chart2.Series.Add("Produits");
            series.Palette = ChartColorPalette.SeaGreen;
            series.Label = "#VALX\n#VALY";
            series.CustomProperties = "DrawSideBySide=True, LabelStyle=Bottom";
            for (int i = 0; i < max; i++)
            {
                series.Points.AddXY(sortedDict[i].Key.nomProduit, sortedDict[i].Value);
            }
        }
        public void initChartClient()
        {
            int max = 0;
            IDictionary<Client, int> clients = new Dictionary<Client, int>();
            Client[] clt = Program.bdEntities.Client.ToArray();
            foreach (var client in clt)
            {
                clients.Add(client, Program.bdEntities.Client.Where(c=>c.ClientID==client.ClientID).FirstOrDefault().nombreReservationClient);
            }
            var sortedDict = (from entry in clients orderby entry.Value descending select entry).ToArray();

            if (sortedDict.Length > 10)
            {
                max = 10;
            }
            else
            {
                max = sortedDict.Length;
            }

            this.chart4.Series.Clear();
            Series series = this.chart4.Series.Add("Client");
            series.Palette = ChartColorPalette.SeaGreen;
            series.Label = "#VALX";
            series.CustomProperties = "DrawSideBySide=True, LabelStyle=Bottom";
            for (int i = 0; i < max; i++)
            {
                series.Points.AddXY(sortedDict[i].Key.nomClient + " " + sortedDict[i].Key.prenomClient.ToUpper().First() + ".", sortedDict[i].Value);
            }
        }

        public void formClose()
        {
            Program.running = true;
            this.Close();
        }

        /// <summary>
        /// Returns the panel that contains the board
        /// </summary>
        /// <returns>
        /// The panel that is being returned is the boardPanel.
        /// </returns>
        public Panel GetPanel()
        {
            return this.boardPanel;
        }

        private void userPage_Load(object sender, EventArgs e)
        {
        }

        private void boardPanel_SizeChanged(object sender, EventArgs e)
        {
            Size size = new Size(((Panel)sender).Width, ((Panel)sender).Height/3);
            chart1.Size = size;
            chart2.Size = size;
            chart4.Size = size;

            Color color = Color.WhiteSmoke;
            chart1.BackSecondaryColor = color;
            chart2.BackSecondaryColor = color;
            chart4.BackSecondaryColor = color;

            chart1.Location = new Point(0, 0);
            chart2.Location = new Point(0, size.Height);
            chart4.Location = new Point(0, size.Height*2);
        }
    }
}
