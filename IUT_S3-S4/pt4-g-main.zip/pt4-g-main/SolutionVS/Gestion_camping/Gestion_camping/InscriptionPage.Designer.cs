﻿
using System;
using System.Runtime.InteropServices;

namespace Gestion_camping.Resources
{
    partial class Inscription
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        [DllImport("Gdi32.dll", EntryPoint = "CreateRoundRectRgn")]
        private static extern IntPtr CreateRoundRectRgn(int nLeftRect, int nTopRect, int nRightRect, int nBottomRect, int nWidthEllipse, int nHeightEllipse);

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.loginTB = new System.Windows.Forms.TextBox();
            this.lLogin = new System.Windows.Forms.Label();
            this.lPass = new System.Windows.Forms.Label();
            this.mdpTB = new System.Windows.Forms.TextBox();
            this.lNom = new System.Windows.Forms.Label();
            this.nomTB = new System.Windows.Forms.TextBox();
            this.lPrenom = new System.Windows.Forms.Label();
            this.prenomTB = new System.Windows.Forms.TextBox();
            this.lPassConf = new System.Windows.Forms.Label();
            this.mdpcTB = new System.Windows.Forms.TextBox();
            this.lPhone = new System.Windows.Forms.Label();
            this.phoneTB = new System.Windows.Forms.TextBox();
            this.buttonCancel = new System.Windows.Forms.Button();
            this.buttonConfirm = new System.Windows.Forms.Button();
            this.panelLog = new System.Windows.Forms.Panel();
            this.panelTel = new System.Windows.Forms.Panel();
            this.panelMdp = new System.Windows.Forms.Panel();
            this.panelConf = new System.Windows.Forms.Panel();
            this.panelNom = new System.Windows.Forms.Panel();
            this.panelPren = new System.Windows.Forms.Panel();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.panelLog.SuspendLayout();
            this.panelTel.SuspendLayout();
            this.panelMdp.SuspendLayout();
            this.panelConf.SuspendLayout();
            this.panelNom.SuspendLayout();
            this.panelPren.SuspendLayout();
            this.SuspendLayout();
            // 
            // loginTB
            // 
            this.loginTB.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.loginTB.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.loginTB.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.loginTB.Location = new System.Drawing.Point(25, 19);
            this.loginTB.Name = "loginTB";
            this.loginTB.Size = new System.Drawing.Size(250, 24);
            this.loginTB.TabIndex = 0;
            this.loginTB.Enter += new System.EventHandler(this.loginTB_Enter);
            this.loginTB.Leave += new System.EventHandler(this.loginTB_Leave);
            // 
            // lLogin
            // 
            this.lLogin.BackColor = System.Drawing.SystemColors.Window;
            this.lLogin.Enabled = false;
            this.lLogin.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lLogin.Location = new System.Drawing.Point(100, 9);
            this.lLogin.Name = "lLogin";
            this.lLogin.Size = new System.Drawing.Size(100, 31);
            this.lLogin.TabIndex = 0;
            this.lLogin.Text = "Login";
            this.lLogin.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lPass
            // 
            this.lPass.BackColor = System.Drawing.SystemColors.Window;
            this.lPass.Enabled = false;
            this.lPass.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lPass.Location = new System.Drawing.Point(50, 9);
            this.lPass.Name = "lPass";
            this.lPass.Size = new System.Drawing.Size(200, 31);
            this.lPass.TabIndex = 0;
            this.lPass.Text = "Mot de passe";
            this.lPass.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // mdpTB
            // 
            this.mdpTB.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.mdpTB.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.mdpTB.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mdpTB.Location = new System.Drawing.Point(25, 19);
            this.mdpTB.Name = "mdpTB";
            this.mdpTB.PasswordChar = '•';
            this.mdpTB.Size = new System.Drawing.Size(250, 24);
            this.mdpTB.TabIndex = 0;
            this.mdpTB.UseSystemPasswordChar = true;
            this.mdpTB.Enter += new System.EventHandler(this.mdpTB_Enter);
            this.mdpTB.Leave += new System.EventHandler(this.mdpTB_Leave);
            // 
            // lNom
            // 
            this.lNom.BackColor = System.Drawing.SystemColors.Window;
            this.lNom.Enabled = false;
            this.lNom.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lNom.Location = new System.Drawing.Point(100, 9);
            this.lNom.Name = "lNom";
            this.lNom.Size = new System.Drawing.Size(100, 31);
            this.lNom.TabIndex = 0;
            this.lNom.Text = "Nom";
            this.lNom.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // nomTB
            // 
            this.nomTB.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.nomTB.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.nomTB.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nomTB.Location = new System.Drawing.Point(25, 19);
            this.nomTB.Name = "nomTB";
            this.nomTB.Size = new System.Drawing.Size(250, 24);
            this.nomTB.TabIndex = 0;
            this.nomTB.Enter += new System.EventHandler(this.nomTB_Enter);
            this.nomTB.Leave += new System.EventHandler(this.nomTB_Leave);
            // 
            // lPrenom
            // 
            this.lPrenom.BackColor = System.Drawing.SystemColors.Window;
            this.lPrenom.Enabled = false;
            this.lPrenom.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lPrenom.Location = new System.Drawing.Point(75, 9);
            this.lPrenom.Name = "lPrenom";
            this.lPrenom.Size = new System.Drawing.Size(150, 31);
            this.lPrenom.TabIndex = 0;
            this.lPrenom.Text = "Prénom";
            this.lPrenom.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // prenomTB
            // 
            this.prenomTB.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.prenomTB.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.prenomTB.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.prenomTB.Location = new System.Drawing.Point(25, 19);
            this.prenomTB.Name = "prenomTB";
            this.prenomTB.Size = new System.Drawing.Size(250, 24);
            this.prenomTB.TabIndex = 0;
            this.prenomTB.Enter += new System.EventHandler(this.prenomTB_Enter);
            this.prenomTB.Leave += new System.EventHandler(this.prenomTB_Leave);
            // 
            // lPassConf
            // 
            this.lPassConf.BackColor = System.Drawing.SystemColors.Window;
            this.lPassConf.Enabled = false;
            this.lPassConf.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lPassConf.Location = new System.Drawing.Point(50, 9);
            this.lPassConf.Name = "lPassConf";
            this.lPassConf.Size = new System.Drawing.Size(200, 31);
            this.lPassConf.TabIndex = 0;
            this.lPassConf.Text = "Confirmation";
            this.lPassConf.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // mdpcTB
            // 
            this.mdpcTB.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.mdpcTB.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.mdpcTB.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mdpcTB.Location = new System.Drawing.Point(25, 19);
            this.mdpcTB.Name = "mdpcTB";
            this.mdpcTB.PasswordChar = '•';
            this.mdpcTB.Size = new System.Drawing.Size(250, 24);
            this.mdpcTB.TabIndex = 0;
            this.mdpcTB.UseSystemPasswordChar = true;
            this.mdpcTB.Enter += new System.EventHandler(this.mdpcTB_Enter);
            this.mdpcTB.Leave += new System.EventHandler(this.mdpcTB_Leave);
            // 
            // lPhone
            // 
            this.lPhone.BackColor = System.Drawing.SystemColors.Window;
            this.lPhone.Enabled = false;
            this.lPhone.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lPhone.Location = new System.Drawing.Point(75, 9);
            this.lPhone.Name = "lPhone";
            this.lPhone.Size = new System.Drawing.Size(150, 31);
            this.lPhone.TabIndex = 0;
            this.lPhone.Text = "Téléphone";
            this.lPhone.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // phoneTB
            // 
            this.phoneTB.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.phoneTB.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.phoneTB.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.phoneTB.Location = new System.Drawing.Point(25, 19);
            this.phoneTB.Name = "phoneTB";
            this.phoneTB.Size = new System.Drawing.Size(250, 24);
            this.phoneTB.TabIndex = 0;
            this.phoneTB.Enter += new System.EventHandler(this.PhoneTB_Enter);
            this.phoneTB.Leave += new System.EventHandler(this.PhoneTB_Leave);
            // 
            // buttonCancel
            // 
            this.buttonCancel.BackColor = System.Drawing.Color.Red;
            this.buttonCancel.FlatAppearance.BorderSize = 0;
            this.buttonCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonCancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonCancel.ForeColor = System.Drawing.SystemColors.Window;
            this.buttonCancel.Location = new System.Drawing.Point(475, 350);
            this.buttonCancel.Name = "buttonCancel";
            this.buttonCancel.Size = new System.Drawing.Size(125, 30);
            this.buttonCancel.TabIndex = 0;
            this.buttonCancel.Text = "Annuler";
            this.buttonCancel.UseVisualStyleBackColor = false;
            // 
            // buttonConfirm
            // 
            this.buttonConfirm.BackColor = System.Drawing.Color.DarkGreen;
            this.buttonConfirm.FlatAppearance.BorderSize = 0;
            this.buttonConfirm.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonConfirm.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonConfirm.ForeColor = System.Drawing.SystemColors.Window;
            this.buttonConfirm.Location = new System.Drawing.Point(600, 350);
            this.buttonConfirm.Name = "buttonConfirm";
            this.buttonConfirm.Size = new System.Drawing.Size(125, 30);
            this.buttonConfirm.TabIndex = 0;
            this.buttonConfirm.Text = "Confirmer";
            this.buttonConfirm.UseVisualStyleBackColor = false;
            this.buttonConfirm.Click += new System.EventHandler(this.buttonConfirm_Click);
            // 
            // panelLog
            // 
            this.panelLog.BackColor = System.Drawing.SystemColors.Window;
            this.panelLog.Controls.Add(this.lLogin);
            this.panelLog.Controls.Add(this.loginTB);
            this.panelLog.Location = new System.Drawing.Point(75, 28);
            this.panelLog.Name = "panelLog";
            this.panelLog.Padding = new System.Windows.Forms.Padding(25, 5, 25, 5);
            this.panelLog.Size = new System.Drawing.Size(300, 48);
            this.panelLog.TabIndex = 0;
            this.panelLog.Click += new System.EventHandler(this.panelTel_Click);
            // 
            // panelTel
            // 
            this.panelTel.BackColor = System.Drawing.SystemColors.Window;
            this.panelTel.Controls.Add(this.lPhone);
            this.panelTel.Controls.Add(this.phoneTB);
            this.panelTel.Location = new System.Drawing.Point(425, 28);
            this.panelTel.Name = "panelTel";
            this.panelTel.Padding = new System.Windows.Forms.Padding(25, 5, 25, 5);
            this.panelTel.Size = new System.Drawing.Size(300, 48);
            this.panelTel.TabIndex = 0;
            // 
            // panelMdp
            // 
            this.panelMdp.BackColor = System.Drawing.SystemColors.Window;
            this.panelMdp.Controls.Add(this.lPass);
            this.panelMdp.Controls.Add(this.mdpTB);
            this.panelMdp.Location = new System.Drawing.Point(75, 106);
            this.panelMdp.Name = "panelMdp";
            this.panelMdp.Padding = new System.Windows.Forms.Padding(25, 5, 25, 5);
            this.panelMdp.Size = new System.Drawing.Size(300, 48);
            this.panelMdp.TabIndex = 0;
            // 
            // panelConf
            // 
            this.panelConf.BackColor = System.Drawing.SystemColors.Window;
            this.panelConf.Controls.Add(this.lPassConf);
            this.panelConf.Controls.Add(this.mdpcTB);
            this.panelConf.Location = new System.Drawing.Point(425, 106);
            this.panelConf.Name = "panelConf";
            this.panelConf.Padding = new System.Windows.Forms.Padding(25, 5, 25, 5);
            this.panelConf.Size = new System.Drawing.Size(300, 48);
            this.panelConf.TabIndex = 0;
            // 
            // panelNom
            // 
            this.panelNom.BackColor = System.Drawing.SystemColors.Window;
            this.panelNom.Controls.Add(this.lNom);
            this.panelNom.Controls.Add(this.nomTB);
            this.panelNom.Location = new System.Drawing.Point(75, 184);
            this.panelNom.Name = "panelNom";
            this.panelNom.Padding = new System.Windows.Forms.Padding(25, 5, 25, 5);
            this.panelNom.Size = new System.Drawing.Size(300, 48);
            this.panelNom.TabIndex = 0;
            // 
            // panelPren
            // 
            this.panelPren.BackColor = System.Drawing.SystemColors.Window;
            this.panelPren.Controls.Add(this.lPrenom);
            this.panelPren.Controls.Add(this.prenomTB);
            this.panelPren.Location = new System.Drawing.Point(425, 184);
            this.panelPren.Name = "panelPren";
            this.panelPren.Padding = new System.Windows.Forms.Padding(25, 5, 25, 5);
            this.panelPren.Size = new System.Drawing.Size(300, 48);
            this.panelPren.TabIndex = 0;
            //
            // Region
            //
            this.buttonCancel.Region = System.Drawing.Region.FromHrgn(CreateRoundRectRgn(0, 0, this.buttonCancel.Width + 50, this.buttonCancel.Height, 20, 20));
            this.buttonConfirm.Region = System.Drawing.Region.FromHrgn(CreateRoundRectRgn(-50, 0, this.buttonConfirm.Width, this.buttonConfirm.Height, 20, 20));
            this.panelLog.Region = System.Drawing.Region.FromHrgn(CreateRoundRectRgn(0, 0, this.panelLog.Width, this.panelLog.Height, 40, 40));
            this.panelTel.Region = System.Drawing.Region.FromHrgn(CreateRoundRectRgn(0, 0, this.panelTel.Width, this.panelTel.Height, 40, 40));
            this.panelMdp.Region = System.Drawing.Region.FromHrgn(CreateRoundRectRgn(0, 0, this.panelMdp.Width, this.panelMdp.Height, 40, 40));
            this.panelConf.Region = System.Drawing.Region.FromHrgn(CreateRoundRectRgn(0, 0, this.panelConf.Width, this.panelConf.Height, 40, 40));
            this.panelNom.Region = System.Drawing.Region.FromHrgn(CreateRoundRectRgn(0, 0, this.panelNom.Width, this.panelNom.Height, 40, 40));
            this.panelPren.Region = System.Drawing.Region.FromHrgn(CreateRoundRectRgn(0, 0, this.panelPren.Width, this.panelPren.Height, 40, 40));
            // 
            // Inscription
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(784, 411);
            this.Controls.Add(this.panelPren);
            this.Controls.Add(this.panelNom);
            this.Controls.Add(this.panelConf);
            this.Controls.Add(this.panelMdp);
            this.Controls.Add(this.panelLog);
            this.Controls.Add(this.buttonConfirm);
            this.Controls.Add(this.buttonCancel);
            this.Controls.Add(this.panelTel);
            this.Name = "Inscription";
            this.Text = "Inscription";
            this.panelLog.ResumeLayout(false);
            this.panelLog.PerformLayout();
            this.panelTel.ResumeLayout(false);
            this.panelTel.PerformLayout();
            this.panelMdp.ResumeLayout(false);
            this.panelMdp.PerformLayout();
            this.panelConf.ResumeLayout(false);
            this.panelConf.PerformLayout();
            this.panelNom.ResumeLayout(false);
            this.panelNom.PerformLayout();
            this.panelPren.ResumeLayout(false);
            this.panelPren.PerformLayout();
            this.ResumeLayout(false);

        }
        #endregion

        private System.Windows.Forms.TextBox loginTB;
        private System.Windows.Forms.Label lLogin;
        private System.Windows.Forms.Label lPass;
        private System.Windows.Forms.TextBox mdpTB;
        private System.Windows.Forms.Label lNom;
        private System.Windows.Forms.TextBox nomTB;
        private System.Windows.Forms.Label lPrenom;
        private System.Windows.Forms.TextBox prenomTB;
        private System.Windows.Forms.Label lPassConf;
        private System.Windows.Forms.TextBox mdpcTB;
        private System.Windows.Forms.TextBox phoneTB;
        private System.Windows.Forms.Button buttonCancel;
        private System.Windows.Forms.Button buttonConfirm;
        private System.Windows.Forms.Label lPhone;
        private System.Windows.Forms.Panel panelLog;
        private System.Windows.Forms.Panel panelTel;
        private System.Windows.Forms.Panel panelMdp;
        private System.Windows.Forms.Panel panelConf;
        private System.Windows.Forms.Panel panelNom;
        private System.Windows.Forms.Panel panelPren;
        private System.Windows.Forms.Timer timer1;
    }
}