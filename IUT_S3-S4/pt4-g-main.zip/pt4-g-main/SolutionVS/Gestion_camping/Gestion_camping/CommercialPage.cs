﻿using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gestion_camping
{
    public partial class commercial : Form, IPanel
    {
        ILogger _logger;
        /* Initializing the form. */
        public commercial(ILogger logger)
        {
            _logger = logger;
            InitializeComponent();
            /*Panels panels = new Panels();
            this.Controls.Add(panels.getLeftSide());
            this.Controls.Add(panels.getRightSide());
            this.Controls.Add(panels.getNotifs());*/
            fillClient();
        }

        /// <summary>
        /// It fills the client list with the client's name, first name, mail and description.
        /// </summary>
        void fillClient()
        {
            _logger.LogInformation("Chargement factures");
            BD_PT4_S4D_E1Entities1 entities = new BD_PT4_S4D_E1Entities1();
            Client[] clients = entities.Client.ToArray();
            foreach (Client client in clients)
            {
                factureFlowLayoutPanel.Controls.Add(getPannelFacture("nom", client.nomClient, "prenom", client.prenomClient, "desc", client.mailClient));
            }
            _logger.LogInformation("Chargées factures");
        }


        /// <summary>
        /// It creates a new panel and adds it to the factureFlowLayoutPanel.
        /// </summary>
        /// <param name="sender">The object that raised the event.</param>
        /// <param name="EventArgs">The event arguments.</param>
        private void button1_Click(object sender, EventArgs e)
        {
            factureFlowLayoutPanel.Controls.Add(getPannelFacture());
        }

        /// <summary>
        /// Returns a Panel with three Labels and three TextBoxes
        /// </summary>
        /// <param name="descinfo1">the description of the first info</param>
        /// <param name="info1">the text to display in the first column</param>
        /// <param name="descinfo2">the description of the second info</param>
        /// <param name="info2">the text to display in the second column</param>
        /// <param name="descinfo3">the description of the third parameter</param>
        /// <param name="info3">the text to display in the third column</param>
        /// <returns>
        /// A Panel
        /// </returns>
        public Panel getPannelFacture(string descinfo1 = "nom", string info1 = "prenom", string descinfo2 = "desc", string info2 = "nom", string descinfo3 = "prenom", string info3 = "desc")
        {
            ListableObject lobj = new ListableObject();

            return lobj.getListablePanel(descinfo1, info1, descinfo2, info2, descinfo3, info3);
        }

        /// <summary>
        /// Returns the panel that is used to communicate with the user
        /// </summary>
        /// <returns>
        /// The panelComm object.
        /// </returns>
        public Panel GetPanel()
        {
            return this.panelComm;
        }
    }
}
