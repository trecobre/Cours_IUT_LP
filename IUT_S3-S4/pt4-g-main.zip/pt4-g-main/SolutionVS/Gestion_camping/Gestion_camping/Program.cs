﻿using Gestion_camping.Resources;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Configuration;
using System.Diagnostics;
using System.IO;

namespace Gestion_camping
{
    class Program
    {
        /// <summary>
        /// Point d'entrée principal de l'application.
        /// </summary>
        public static BD_PT4_S4D_E1Entities1 bdEntities = new BD_PT4_S4D_E1Entities1();
        public static bool running = false;
        public static string path = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + "/Camping/logs/";


        [STAThread]

        /// <summary>
        /// The function starts by creating a new instance of the ConnexionPage class. Then it loops
        /// until the user clicks the OK button on the dialog box. If the user clicks OK, the function
        /// creates a new instance of the Utilisateur class and passes the user's login and password to
        /// the connexionPage class. If the user clicks Cancel, the function returns. If the user clicks
        /// OK, the function runs the userPage class
        /// </summary>
        /// <returns>
        /// Nothing
        /// </returns>
        static void Main(string[] args)
        {
            IConfiguration configuration = new ConfigurationBuilder().AddInMemoryCollection(
            new Dictionary<string, string>
            {
                ["LogLevel:Default"] = "Debug",
                //["Console:LogLevel:Default"] = "Information"
            }).Build();

            ILoggerFactory loggerFactory = LoggerFactory.Create(config => {
                config.AddConfiguration(configuration);
                config.AddConsole();
                config.AddDebug();
            });
            string filename = "Logs-Campo.txt";
            System.IO.Directory.CreateDirectory(path);
            loggerFactory.AddFile(path + filename);
            ILogger _logger = loggerFactory.CreateLogger<Program>();
            _logger.LogInformation("---------------------------------------------------------------------------------------------------------------------------");
            _logger.LogInformation("Démarrage de l'application");
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            //InjectionDataBase idb = new InjectionDataBase();
            bool connexionRéussie = false;
            ConnexionPage connexion = new ConnexionPage();
            do
            {
                do
                {
                    if (connexion.ShowDialog() == DialogResult.OK)
                    {
                        Utilisateur user = connexion.getUser();
                        _logger.LogInformation("Tentative de connexion avec le login "+user.login);
                        _logger.LogInformation("Connexion réussite");
                        _logger.LogInformation(user.login + " est connecté(e)");
                        Application.Run(new Panels(connexion.admin, user, _logger));
                        connexionRéussie = true;
                        _logger.LogInformation("Déconnexion de " + user.login);

                    }
                    else
                    {
                        return;
                    }
                } while (!connexionRéussie);
            } while (running);
            _logger.LogInformation("Arret de l'application");
            _logger.LogInformation("---------------------------------------------------------------------------------------------------------------------------");
        }
    }
}