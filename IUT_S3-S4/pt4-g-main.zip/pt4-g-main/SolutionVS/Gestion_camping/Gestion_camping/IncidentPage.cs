﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using System.Diagnostics;
using static Gestion_camping.PDFGenerator;
using Microsoft.Extensions.Logging;

namespace Gestion_camping
{
    public partial class IncidentPage : Form, IPanel
    {
        static IncidentPage main;
        ILogger _logger;
        public IncidentPage(ILogger logger)
        {
            _logger = logger;
            main = this;
            InitializeComponent();
            this.displayInc();
        }

        private void displayInc()
        {
            _logger.LogInformation("Chargement incidents");
            List<Incident> Incidents = Program.bdEntities.Incident.OrderBy(r => r.status).ToList();
            this.panelInc.Location = new System.Drawing.Point(0, 0);
            foreach (Incident Incident in Incidents)
            {
                IncidentPage IncidentPage = new IncidentPage(1);
                flowLayoutPanelInc.Controls.Add(getPanelInc(Incident, IncidentPage));
            }
            _logger.LogInformation("Incidents chargés");
        }

        public IncidentPage(int a)
        {
            InitializeComponent();
        }

        public Panel GetPanel()
        {
            return this.IncidentPanel;
        }

        public Panel getPanelInc(Incident incident, IncidentPage rp)
        {
            rp.Tag = incident.IncidentID;
            DateTime dDebut = incident.dateDebut;
            rp.labelDebut.Text = dDebut.Day + "/" + dDebut.Month + "/" + dDebut.Year;
            if (incident.dateFin.HasValue)
            {
                DateTime dFin = (DateTime)incident.dateFin;
                rp.labelFin.Text = dFin.Day + "/" + dFin.Month + "/" + dFin.Year;
            }
            else
            {
                rp.labelFin.Text = "Pas Fini";
            }
            rp.labelEmplacement.Text = incident.Emplacement.intitule;
            rp.labelStatut.Text = incident.Status1.name;
            rp.labelDescription.Text = incident.description;
            return rp.panelInc;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            IncidentForm2 rf = new IncidentForm2();
            if(rf.ShowDialog() == DialogResult.OK)
            {
                Incident incident = rf.getData();
                Console.WriteLine(rf.getDetail());

                incident.rapportPDF = new IncidentPDF(incident, incident.dateDebut, rf.getDetail()).filename;
                Program.bdEntities.Incident.Add(incident);
                Program.bdEntities.SaveChanges();
                flowLayoutPanelInc.Controls.Clear();
                displayInc();
            }
        }

        private void buttonSupprimer_Click(object sender, EventArgs e)
        {
            int id = (int)this.Tag;
            Incident Inc = Program.bdEntities.Incident.First(r => r.IncidentID == id);
            Program.bdEntities.Incident.Remove(Inc);
            Program.bdEntities.SaveChanges();
            main._logger.LogInformation($"Suppresion incident. Descrciption: {Inc.description}, emplacementID: {Inc.emplacementID}, status: {Inc.status}");
            main.flowLayoutPanelInc.Controls.Clear();
            main.displayInc();
        }

        private void buttonFin_Click(object sender, EventArgs e)
        {
            int id = (int)this.Tag;
            Program.bdEntities.Incident.First(r => r.IncidentID == id).dateFin = DateTime.Now;
            Program.bdEntities.Incident.First(r => r.IncidentID == id).status = "F";
            Program.bdEntities.Incident.First(r => r.IncidentID == id).Status1 = Program.bdEntities.Status.First(s=>s.StatusID == "F");
            Program.bdEntities.SaveChanges();
            main._logger.LogInformation($"Fin incident id: {id}");
            main.flowLayoutPanelInc.Controls.Clear();
            main.displayInc();
        }

        private void modifie(object sender, EventArgs e)
        {
            int id = (int)this.Tag;
            IncidentForm rForm = new IncidentForm();
            DialogResult dialogResult = rForm.ShowDialog();
            if(dialogResult == DialogResult.Yes)
            {
                
                Incident res = Program.bdEntities.Incident.First(r => r.IncidentID == id);
                IncidentForm2 rf = new IncidentForm2(res);
                Incident oldIncident = rf.getData();
                if (rf.ShowDialog() == DialogResult.OK)
                {
                    Incident incident = rf.getData();
                    incident.emplacementID = incident.Emplacement.EmplacementID;
                    incident.status = incident.Status1.StatusID;
                    incident.rapportPDF = new IncidentPDF(incident, incident.dateDebut, rf.getDetail()).filename;
                    Program.bdEntities.Incident.First(r => r.IncidentID == id).setFromIncident(incident);
                    Program.bdEntities.SaveChanges();
                    main._logger.LogInformation($"Update incident. Descrciption: {oldIncident.description} -> {incident.description}, emplacementId: {oldIncident.emplacementID} -> {incident.emplacementID},  status: {oldIncident.status} -> {incident.status}, pdf: {oldIncident.rapportPDF} -> {incident.rapportPDF}");

                    main.flowLayoutPanelInc.Controls.Clear();
                    main.displayInc();
                    
                }
            }
            else if(dialogResult == DialogResult.No)
            {
                Incident res = Program.bdEntities.Incident.First(r => r.IncidentID == id);
                Process.Start(res.rapportPDF);
            }
            
        }
    }
}
