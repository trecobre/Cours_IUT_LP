﻿namespace Gestion_camping
{
    partial class FournisseurPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.fournisseurPagePanel = new System.Windows.Forms.Panel();
            this.fournisseurFlowLayoutPanel = new System.Windows.Forms.FlowLayoutPanel();
            this.ajoutFournisseurButton = new System.Windows.Forms.Button();
            this.fournisseurPagePanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // fournisseurPagePanel
            // 
            this.fournisseurPagePanel.Controls.Add(this.fournisseurFlowLayoutPanel);
            this.fournisseurPagePanel.Controls.Add(this.ajoutFournisseurButton);
            this.fournisseurPagePanel.Location = new System.Drawing.Point(17, 33);
            this.fournisseurPagePanel.Name = "fournisseurPagePanel";
            this.fournisseurPagePanel.Size = new System.Drawing.Size(766, 614);
            this.fournisseurPagePanel.TabIndex = 31;
            this.fournisseurPagePanel.SizeChanged += new System.EventHandler(this.FournisseurPagePanel_SizeChanged);
            // 
            // fournisseurFlowLayoutPanel
            // 
            this.fournisseurFlowLayoutPanel.AutoScroll = true;
            this.fournisseurFlowLayoutPanel.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.fournisseurFlowLayoutPanel.Location = new System.Drawing.Point(3, 3);
            this.fournisseurFlowLayoutPanel.Name = "fournisseurFlowLayoutPanel";
            this.fournisseurFlowLayoutPanel.Size = new System.Drawing.Size(760, 579);
            this.fournisseurFlowLayoutPanel.TabIndex = 25;
            this.fournisseurFlowLayoutPanel.WrapContents = false;
            // 
            // ajoutFournisseurButton
            // 
            this.ajoutFournisseurButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.ajoutFournisseurButton.Location = new System.Drawing.Point(3, 588);
            this.ajoutFournisseurButton.Name = "ajoutFournisseurButton";
            this.ajoutFournisseurButton.Size = new System.Drawing.Size(75, 23);
            this.ajoutFournisseurButton.TabIndex = 27;
            this.ajoutFournisseurButton.Text = "gerer";
            this.ajoutFournisseurButton.UseVisualStyleBackColor = true;
            this.ajoutFournisseurButton.Click += new System.EventHandler(this.ajoutFournisseurButton_Click);
            // 
            // FournisseurPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(810, 699);
            this.Controls.Add(this.fournisseurPagePanel);
            this.Name = "FournisseurPage";
            this.Text = "FournisseurPage";
            this.fournisseurPagePanel.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel fournisseurPagePanel;
        private System.Windows.Forms.FlowLayoutPanel fournisseurFlowLayoutPanel;
        private System.Windows.Forms.Button ajoutFournisseurButton;
    }
}