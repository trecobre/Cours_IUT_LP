﻿
namespace Gestion_camping
{
    partial class ListableObject
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ListablePanel = new System.Windows.Forms.Panel();
            this.Info3Label = new System.Windows.Forms.Label();
            this.descInfo3Label = new System.Windows.Forms.Label();
            this.Info2Label = new System.Windows.Forms.Label();
            this.descInfo2Label = new System.Windows.Forms.Label();
            this.Info1Label = new System.Windows.Forms.Label();
            this.descInfo1Label = new System.Windows.Forms.Label();
            this.pictureBox = new System.Windows.Forms.PictureBox();
            this.clientListablePanel = new System.Windows.Forms.Panel();
            this.clientEditButton = new System.Windows.Forms.Button();
            this.clientInfo3Label = new System.Windows.Forms.Label();
            this.clientDescInfo3Label = new System.Windows.Forms.Label();
            this.clientInfo2Label = new System.Windows.Forms.Label();
            this.clientDescInfo2Label = new System.Windows.Forms.Label();
            this.clientInfo1Label = new System.Windows.Forms.Label();
            this.clientDdescInfo1Label = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.stockListablePanel = new System.Windows.Forms.Panel();
            this.stockEditButton = new System.Windows.Forms.Button();
            this.stockInfo3Label = new System.Windows.Forms.Label();
            this.stockDescInfo3Label = new System.Windows.Forms.Label();
            this.stockInfo2Label = new System.Windows.Forms.Label();
            this.stockDescInfo2Label = new System.Windows.Forms.Label();
            this.stockInfo1Label = new System.Windows.Forms.Label();
            this.stockDescInfo1Label = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.FournisseurlistablePanel = new System.Windows.Forms.Panel();
            this.fournisseurButton = new System.Windows.Forms.Button();
            this.fournisseurQuantiteInfoLabel = new System.Windows.Forms.Label();
            this.fournisseurQuantiteLabel = new System.Windows.Forms.Label();
            this.fournisseurTelephoneInfoLabel = new System.Windows.Forms.Label();
            this.fournisseurTelephoneLabel = new System.Windows.Forms.Label();
            this.fournisseurNomInfoLabel = new System.Windows.Forms.Label();
            this.fournisseurNomLabel = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.ListablePanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox)).BeginInit();
            this.clientListablePanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.stockListablePanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.FournisseurlistablePanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.SuspendLayout();
            // 
            // ListablePanel
            // 
            this.ListablePanel.Controls.Add(this.Info3Label);
            this.ListablePanel.Controls.Add(this.descInfo3Label);
            this.ListablePanel.Controls.Add(this.Info2Label);
            this.ListablePanel.Controls.Add(this.descInfo2Label);
            this.ListablePanel.Controls.Add(this.Info1Label);
            this.ListablePanel.Controls.Add(this.descInfo1Label);
            this.ListablePanel.Controls.Add(this.pictureBox);
            this.ListablePanel.Location = new System.Drawing.Point(142, 115);
            this.ListablePanel.Name = "ListablePanel";
            this.ListablePanel.Size = new System.Drawing.Size(516, 67);
            this.ListablePanel.TabIndex = 28;
            // 
            // Info3Label
            // 
            this.Info3Label.AutoSize = true;
            this.Info3Label.Location = new System.Drawing.Point(389, 35);
            this.Info3Label.Name = "Info3Label";
            this.Info3Label.Size = new System.Drawing.Size(35, 13);
            this.Info3Label.TabIndex = 9;
            this.Info3Label.Text = "label1";
            // 
            // descInfo3Label
            // 
            this.descInfo3Label.AutoSize = true;
            this.descInfo3Label.Location = new System.Drawing.Point(389, 18);
            this.descInfo3Label.Name = "descInfo3Label";
            this.descInfo3Label.Size = new System.Drawing.Size(60, 13);
            this.descInfo3Label.TabIndex = 8;
            this.descInfo3Label.Text = "Description";
            // 
            // Info2Label
            // 
            this.Info2Label.AutoSize = true;
            this.Info2Label.Location = new System.Drawing.Point(241, 35);
            this.Info2Label.Name = "Info2Label";
            this.Info2Label.Size = new System.Drawing.Size(35, 13);
            this.Info2Label.TabIndex = 7;
            this.Info2Label.Text = "label1";
            // 
            // descInfo2Label
            // 
            this.descInfo2Label.AutoSize = true;
            this.descInfo2Label.Location = new System.Drawing.Point(241, 18);
            this.descInfo2Label.Name = "descInfo2Label";
            this.descInfo2Label.Size = new System.Drawing.Size(43, 13);
            this.descInfo2Label.TabIndex = 6;
            this.descInfo2Label.Text = "Prenom";
            // 
            // Info1Label
            // 
            this.Info1Label.AutoSize = true;
            this.Info1Label.Location = new System.Drawing.Point(88, 35);
            this.Info1Label.Name = "Info1Label";
            this.Info1Label.Size = new System.Drawing.Size(35, 13);
            this.Info1Label.TabIndex = 5;
            this.Info1Label.Text = "label1";
            // 
            // descInfo1Label
            // 
            this.descInfo1Label.AutoSize = true;
            this.descInfo1Label.Location = new System.Drawing.Point(88, 18);
            this.descInfo1Label.Name = "descInfo1Label";
            this.descInfo1Label.Size = new System.Drawing.Size(29, 13);
            this.descInfo1Label.TabIndex = 4;
            this.descInfo1Label.Text = "Nom";
            // 
            // pictureBox
            // 
            this.pictureBox.Dock = System.Windows.Forms.DockStyle.Left;
            this.pictureBox.Image = global::Gestion_camping.Properties.Resources.icons8_person_64;
            this.pictureBox.Location = new System.Drawing.Point(0, 0);
            this.pictureBox.Name = "pictureBox";
            this.pictureBox.Size = new System.Drawing.Size(64, 67);
            this.pictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox.TabIndex = 3;
            this.pictureBox.TabStop = false;
            // 
            // clientListablePanel
            // 
            this.clientListablePanel.Controls.Add(this.clientEditButton);
            this.clientListablePanel.Controls.Add(this.clientInfo3Label);
            this.clientListablePanel.Controls.Add(this.clientDescInfo3Label);
            this.clientListablePanel.Controls.Add(this.clientInfo2Label);
            this.clientListablePanel.Controls.Add(this.clientDescInfo2Label);
            this.clientListablePanel.Controls.Add(this.clientInfo1Label);
            this.clientListablePanel.Controls.Add(this.clientDdescInfo1Label);
            this.clientListablePanel.Controls.Add(this.pictureBox1);
            this.clientListablePanel.Location = new System.Drawing.Point(27, 28);
            this.clientListablePanel.Name = "clientListablePanel";
            this.clientListablePanel.Size = new System.Drawing.Size(622, 67);
            this.clientListablePanel.TabIndex = 30;
            // 
            // clientEditButton
            // 
            this.clientEditButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.clientEditButton.FlatAppearance.BorderSize = 0;
            this.clientEditButton.FlatAppearance.MouseDownBackColor = System.Drawing.Color.LightSeaGreen;
            this.clientEditButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.MediumAquamarine;
            this.clientEditButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.clientEditButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clientEditButton.Location = new System.Drawing.Point(522, 0);
            this.clientEditButton.Name = "clientEditButton";
            this.clientEditButton.Size = new System.Drawing.Size(100, 67);
            this.clientEditButton.TabIndex = 10;
            this.clientEditButton.Text = "Modifier";
            this.clientEditButton.UseVisualStyleBackColor = true;
            this.clientEditButton.Click += new System.EventHandler(this.clientEditButton_Click);
            // 
            // clientInfo3Label
            // 
            this.clientInfo3Label.AutoSize = true;
            this.clientInfo3Label.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clientInfo3Label.Location = new System.Drawing.Point(389, 37);
            this.clientInfo3Label.Name = "clientInfo3Label";
            this.clientInfo3Label.Size = new System.Drawing.Size(44, 16);
            this.clientInfo3Label.TabIndex = 9;
            this.clientInfo3Label.Text = "label1";
            // 
            // clientDescInfo3Label
            // 
            this.clientDescInfo3Label.AutoSize = true;
            this.clientDescInfo3Label.Location = new System.Drawing.Point(389, 8);
            this.clientDescInfo3Label.Name = "clientDescInfo3Label";
            this.clientDescInfo3Label.Size = new System.Drawing.Size(60, 13);
            this.clientDescInfo3Label.TabIndex = 8;
            this.clientDescInfo3Label.Text = "Description";
            // 
            // clientInfo2Label
            // 
            this.clientInfo2Label.AutoSize = true;
            this.clientInfo2Label.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clientInfo2Label.Location = new System.Drawing.Point(241, 37);
            this.clientInfo2Label.Name = "clientInfo2Label";
            this.clientInfo2Label.Size = new System.Drawing.Size(44, 16);
            this.clientInfo2Label.TabIndex = 7;
            this.clientInfo2Label.Text = "label1";
            // 
            // clientDescInfo2Label
            // 
            this.clientDescInfo2Label.AutoSize = true;
            this.clientDescInfo2Label.Location = new System.Drawing.Point(241, 8);
            this.clientDescInfo2Label.Name = "clientDescInfo2Label";
            this.clientDescInfo2Label.Size = new System.Drawing.Size(43, 13);
            this.clientDescInfo2Label.TabIndex = 6;
            this.clientDescInfo2Label.Text = "Prenom";
            // 
            // clientInfo1Label
            // 
            this.clientInfo1Label.AutoSize = true;
            this.clientInfo1Label.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clientInfo1Label.Location = new System.Drawing.Point(88, 37);
            this.clientInfo1Label.Name = "clientInfo1Label";
            this.clientInfo1Label.Size = new System.Drawing.Size(44, 16);
            this.clientInfo1Label.TabIndex = 5;
            this.clientInfo1Label.Text = "label1";
            // 
            // clientDdescInfo1Label
            // 
            this.clientDdescInfo1Label.AutoSize = true;
            this.clientDdescInfo1Label.Location = new System.Drawing.Point(88, 8);
            this.clientDdescInfo1Label.Name = "clientDdescInfo1Label";
            this.clientDdescInfo1Label.Size = new System.Drawing.Size(29, 13);
            this.clientDdescInfo1Label.TabIndex = 4;
            this.clientDdescInfo1Label.Text = "Nom";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Left;
            this.pictureBox1.Image = global::Gestion_camping.Properties.Resources.icons8_person_64;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(64, 67);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 3;
            this.pictureBox1.TabStop = false;
            // 
            // stockListablePanel
            // 
            this.stockListablePanel.Controls.Add(this.stockEditButton);
            this.stockListablePanel.Controls.Add(this.stockInfo3Label);
            this.stockListablePanel.Controls.Add(this.stockDescInfo3Label);
            this.stockListablePanel.Controls.Add(this.stockInfo2Label);
            this.stockListablePanel.Controls.Add(this.stockDescInfo2Label);
            this.stockListablePanel.Controls.Add(this.stockInfo1Label);
            this.stockListablePanel.Controls.Add(this.stockDescInfo1Label);
            this.stockListablePanel.Controls.Add(this.pictureBox2);
            this.stockListablePanel.Location = new System.Drawing.Point(36, 214);
            this.stockListablePanel.Name = "stockListablePanel";
            this.stockListablePanel.Size = new System.Drawing.Size(622, 67);
            this.stockListablePanel.TabIndex = 31;
            // 
            // stockEditButton
            // 
            this.stockEditButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.stockEditButton.FlatAppearance.BorderSize = 0;
            this.stockEditButton.FlatAppearance.MouseDownBackColor = System.Drawing.Color.LightSeaGreen;
            this.stockEditButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.MediumAquamarine;
            this.stockEditButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.stockEditButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.stockEditButton.Location = new System.Drawing.Point(522, 0);
            this.stockEditButton.Name = "stockEditButton";
            this.stockEditButton.Size = new System.Drawing.Size(100, 67);
            this.stockEditButton.TabIndex = 10;
            this.stockEditButton.Text = "Vendre";
            this.stockEditButton.UseVisualStyleBackColor = true;
            this.stockEditButton.Click += new System.EventHandler(this.stockEditButton_Click);
            // 
            // stockInfo3Label
            // 
            this.stockInfo3Label.AutoSize = true;
            this.stockInfo3Label.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.stockInfo3Label.Location = new System.Drawing.Point(389, 38);
            this.stockInfo3Label.Name = "stockInfo3Label";
            this.stockInfo3Label.Size = new System.Drawing.Size(44, 16);
            this.stockInfo3Label.TabIndex = 9;
            this.stockInfo3Label.Text = "label1";
            // 
            // stockDescInfo3Label
            // 
            this.stockDescInfo3Label.AutoSize = true;
            this.stockDescInfo3Label.Location = new System.Drawing.Point(389, 7);
            this.stockDescInfo3Label.Name = "stockDescInfo3Label";
            this.stockDescInfo3Label.Size = new System.Drawing.Size(24, 13);
            this.stockDescInfo3Label.TabIndex = 8;
            this.stockDescInfo3Label.Text = "Prix";
            // 
            // stockInfo2Label
            // 
            this.stockInfo2Label.AutoSize = true;
            this.stockInfo2Label.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.stockInfo2Label.Location = new System.Drawing.Point(241, 38);
            this.stockInfo2Label.Name = "stockInfo2Label";
            this.stockInfo2Label.Size = new System.Drawing.Size(44, 16);
            this.stockInfo2Label.TabIndex = 7;
            this.stockInfo2Label.Text = "label1";
            // 
            // stockDescInfo2Label
            // 
            this.stockDescInfo2Label.AutoSize = true;
            this.stockDescInfo2Label.Location = new System.Drawing.Point(241, 7);
            this.stockDescInfo2Label.Name = "stockDescInfo2Label";
            this.stockDescInfo2Label.Size = new System.Drawing.Size(47, 13);
            this.stockDescInfo2Label.TabIndex = 6;
            this.stockDescInfo2Label.Text = "Quantité";
            // 
            // stockInfo1Label
            // 
            this.stockInfo1Label.AutoSize = true;
            this.stockInfo1Label.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.stockInfo1Label.Location = new System.Drawing.Point(88, 38);
            this.stockInfo1Label.Name = "stockInfo1Label";
            this.stockInfo1Label.Size = new System.Drawing.Size(44, 16);
            this.stockInfo1Label.TabIndex = 5;
            this.stockInfo1Label.Text = "label1";
            // 
            // stockDescInfo1Label
            // 
            this.stockDescInfo1Label.AutoSize = true;
            this.stockDescInfo1Label.Location = new System.Drawing.Point(88, 7);
            this.stockDescInfo1Label.Name = "stockDescInfo1Label";
            this.stockDescInfo1Label.Size = new System.Drawing.Size(29, 13);
            this.stockDescInfo1Label.TabIndex = 4;
            this.stockDescInfo1Label.Text = "Nom";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Dock = System.Windows.Forms.DockStyle.Left;
            this.pictureBox2.Image = global::Gestion_camping.Properties.Resources.icons8_person_64;
            this.pictureBox2.Location = new System.Drawing.Point(0, 0);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(64, 67);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 3;
            this.pictureBox2.TabStop = false;
            // 
            // FournisseurlistablePanel
            // 
            this.FournisseurlistablePanel.Controls.Add(this.fournisseurButton);
            this.FournisseurlistablePanel.Controls.Add(this.fournisseurQuantiteInfoLabel);
            this.FournisseurlistablePanel.Controls.Add(this.fournisseurQuantiteLabel);
            this.FournisseurlistablePanel.Controls.Add(this.fournisseurTelephoneInfoLabel);
            this.FournisseurlistablePanel.Controls.Add(this.fournisseurTelephoneLabel);
            this.FournisseurlistablePanel.Controls.Add(this.fournisseurNomInfoLabel);
            this.FournisseurlistablePanel.Controls.Add(this.fournisseurNomLabel);
            this.FournisseurlistablePanel.Controls.Add(this.pictureBox3);
            this.FournisseurlistablePanel.Location = new System.Drawing.Point(36, 309);
            this.FournisseurlistablePanel.Name = "FournisseurlistablePanel";
            this.FournisseurlistablePanel.Size = new System.Drawing.Size(622, 67);
            this.FournisseurlistablePanel.TabIndex = 32;
            // 
            // fournisseurButton
            // 
            this.fournisseurButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.fournisseurButton.FlatAppearance.BorderSize = 0;
            this.fournisseurButton.FlatAppearance.MouseDownBackColor = System.Drawing.Color.LightSeaGreen;
            this.fournisseurButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.MediumAquamarine;
            this.fournisseurButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.fournisseurButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fournisseurButton.Location = new System.Drawing.Point(522, 0);
            this.fournisseurButton.Name = "fournisseurButton";
            this.fournisseurButton.Size = new System.Drawing.Size(100, 67);
            this.fournisseurButton.TabIndex = 10;
            this.fournisseurButton.Text = "Afficher les détails";
            this.fournisseurButton.UseVisualStyleBackColor = true;
            this.fournisseurButton.Click += new System.EventHandler(this.fournisseurButton_Click);
            // 
            // fournisseurQuantiteInfoLabel
            // 
            this.fournisseurQuantiteInfoLabel.AutoSize = true;
            this.fournisseurQuantiteInfoLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fournisseurQuantiteInfoLabel.Location = new System.Drawing.Point(389, 38);
            this.fournisseurQuantiteInfoLabel.Name = "fournisseurQuantiteInfoLabel";
            this.fournisseurQuantiteInfoLabel.Size = new System.Drawing.Size(44, 16);
            this.fournisseurQuantiteInfoLabel.TabIndex = 9;
            this.fournisseurQuantiteInfoLabel.Text = "label1";
            // 
            // fournisseurQuantiteLabel
            // 
            this.fournisseurQuantiteLabel.AutoSize = true;
            this.fournisseurQuantiteLabel.Location = new System.Drawing.Point(389, 7);
            this.fournisseurQuantiteLabel.Name = "fournisseurQuantiteLabel";
            this.fournisseurQuantiteLabel.Size = new System.Drawing.Size(114, 13);
            this.fournisseurQuantiteLabel.TabIndex = 8;
            this.fournisseurQuantiteLabel.Text = "quantité produit fournis";
            // 
            // fournisseurTelephoneInfoLabel
            // 
            this.fournisseurTelephoneInfoLabel.AutoSize = true;
            this.fournisseurTelephoneInfoLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fournisseurTelephoneInfoLabel.Location = new System.Drawing.Point(241, 38);
            this.fournisseurTelephoneInfoLabel.Name = "fournisseurTelephoneInfoLabel";
            this.fournisseurTelephoneInfoLabel.Size = new System.Drawing.Size(44, 16);
            this.fournisseurTelephoneInfoLabel.TabIndex = 7;
            this.fournisseurTelephoneInfoLabel.Text = "label1";
            // 
            // fournisseurTelephoneLabel
            // 
            this.fournisseurTelephoneLabel.AutoSize = true;
            this.fournisseurTelephoneLabel.Location = new System.Drawing.Point(241, 7);
            this.fournisseurTelephoneLabel.Name = "fournisseurTelephoneLabel";
            this.fournisseurTelephoneLabel.Size = new System.Drawing.Size(58, 13);
            this.fournisseurTelephoneLabel.TabIndex = 6;
            this.fournisseurTelephoneLabel.Text = "Téléphone";
            // 
            // fournisseurNomInfoLabel
            // 
            this.fournisseurNomInfoLabel.AutoSize = true;
            this.fournisseurNomInfoLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fournisseurNomInfoLabel.Location = new System.Drawing.Point(88, 38);
            this.fournisseurNomInfoLabel.Name = "fournisseurNomInfoLabel";
            this.fournisseurNomInfoLabel.Size = new System.Drawing.Size(44, 16);
            this.fournisseurNomInfoLabel.TabIndex = 5;
            this.fournisseurNomInfoLabel.Text = "label1";
            // 
            // fournisseurNomLabel
            // 
            this.fournisseurNomLabel.AutoSize = true;
            this.fournisseurNomLabel.Location = new System.Drawing.Point(88, 7);
            this.fournisseurNomLabel.Name = "fournisseurNomLabel";
            this.fournisseurNomLabel.Size = new System.Drawing.Size(29, 13);
            this.fournisseurNomLabel.TabIndex = 4;
            this.fournisseurNomLabel.Text = "Nom";
            // 
            // pictureBox3
            // 
            this.pictureBox3.Dock = System.Windows.Forms.DockStyle.Left;
            this.pictureBox3.Image = global::Gestion_camping.Properties.Resources.icons8_person_64;
            this.pictureBox3.Location = new System.Drawing.Point(0, 0);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(64, 67);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 3;
            this.pictureBox3.TabStop = false;
            // 
            // ListableObject
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.FournisseurlistablePanel);
            this.Controls.Add(this.stockListablePanel);
            this.Controls.Add(this.clientListablePanel);
            this.Controls.Add(this.ListablePanel);
            this.Name = "ListableObject";
            this.Text = "Form3";
            this.ListablePanel.ResumeLayout(false);
            this.ListablePanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox)).EndInit();
            this.clientListablePanel.ResumeLayout(false);
            this.clientListablePanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.stockListablePanel.ResumeLayout(false);
            this.stockListablePanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.FournisseurlistablePanel.ResumeLayout(false);
            this.FournisseurlistablePanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel ListablePanel;
        private System.Windows.Forms.Label Info3Label;
        private System.Windows.Forms.Label descInfo3Label;
        private System.Windows.Forms.Label Info2Label;
        private System.Windows.Forms.Label descInfo2Label;
        private System.Windows.Forms.Label Info1Label;
        private System.Windows.Forms.Label descInfo1Label;
        private System.Windows.Forms.PictureBox pictureBox;
        private System.Windows.Forms.Panel clientListablePanel;
        private System.Windows.Forms.Button clientEditButton;
        private System.Windows.Forms.Label clientInfo3Label;
        private System.Windows.Forms.Label clientDescInfo3Label;
        private System.Windows.Forms.Label clientInfo2Label;
        private System.Windows.Forms.Label clientDescInfo2Label;
        private System.Windows.Forms.Label clientInfo1Label;
        private System.Windows.Forms.Label clientDdescInfo1Label;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel stockListablePanel;
        private System.Windows.Forms.Button stockEditButton;
        private System.Windows.Forms.Label stockInfo3Label;
        private System.Windows.Forms.Label stockDescInfo3Label;
        private System.Windows.Forms.Label stockInfo2Label;
        private System.Windows.Forms.Label stockDescInfo2Label;
        private System.Windows.Forms.Label stockInfo1Label;
        private System.Windows.Forms.Label stockDescInfo1Label;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Panel FournisseurlistablePanel;
        private System.Windows.Forms.Label fournisseurQuantiteInfoLabel;
        private System.Windows.Forms.Label fournisseurQuantiteLabel;
        private System.Windows.Forms.Label fournisseurTelephoneInfoLabel;
        private System.Windows.Forms.Label fournisseurTelephoneLabel;
        private System.Windows.Forms.Label fournisseurNomInfoLabel;
        private System.Windows.Forms.Label fournisseurNomLabel;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Button fournisseurButton;
    }
}