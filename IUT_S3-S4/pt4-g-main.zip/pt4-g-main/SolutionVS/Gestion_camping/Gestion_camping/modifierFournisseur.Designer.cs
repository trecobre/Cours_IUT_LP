﻿namespace Gestion_camping
{
    partial class modifierFournisseur
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.suppFournisseurButton = new System.Windows.Forms.Button();
            this.CloselButton = new System.Windows.Forms.Button();
            this.label_Nom_Produit = new System.Windows.Forms.Label();
            this.textBox_NomProduit = new System.Windows.Forms.TextBox();
            this.ModifButton = new System.Windows.Forms.Button();
            this.label_Telephone = new System.Windows.Forms.Label();
            this.listBox = new System.Windows.Forms.ListBox();
            this.telephoneTextBox = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // suppFournisseurButton
            // 
            this.suppFournisseurButton.Location = new System.Drawing.Point(12, 12);
            this.suppFournisseurButton.Name = "suppFournisseurButton";
            this.suppFournisseurButton.Size = new System.Drawing.Size(120, 22);
            this.suppFournisseurButton.TabIndex = 32;
            this.suppFournisseurButton.Text = "supprimer fournisseur";
            this.suppFournisseurButton.UseVisualStyleBackColor = true;
            this.suppFournisseurButton.Click += new System.EventHandler(this.suppFournisseurButton_Click);
            // 
            // CloselButton
            // 
            this.CloselButton.DialogResult = System.Windows.Forms.DialogResult.Abort;
            this.CloselButton.Location = new System.Drawing.Point(270, 112);
            this.CloselButton.Name = "CloselButton";
            this.CloselButton.Size = new System.Drawing.Size(75, 23);
            this.CloselButton.TabIndex = 30;
            this.CloselButton.Text = "Fermer";
            this.CloselButton.UseVisualStyleBackColor = true;
            // 
            // label_Nom_Produit
            // 
            this.label_Nom_Produit.AutoSize = true;
            this.label_Nom_Produit.Location = new System.Drawing.Point(150, 32);
            this.label_Nom_Produit.Name = "label_Nom_Produit";
            this.label_Nom_Produit.Size = new System.Drawing.Size(29, 13);
            this.label_Nom_Produit.TabIndex = 27;
            this.label_Nom_Produit.Text = "Nom";
            // 
            // textBox_NomProduit
            // 
            this.textBox_NomProduit.Location = new System.Drawing.Point(216, 29);
            this.textBox_NomProduit.Name = "textBox_NomProduit";
            this.textBox_NomProduit.Size = new System.Drawing.Size(120, 20);
            this.textBox_NomProduit.TabIndex = 26;
            // 
            // ModifButton
            // 
            this.ModifButton.Location = new System.Drawing.Point(147, 112);
            this.ModifButton.Name = "ModifButton";
            this.ModifButton.Size = new System.Drawing.Size(114, 23);
            this.ModifButton.TabIndex = 23;
            this.ModifButton.Text = "ajouter Fournisseur";
            this.ModifButton.UseVisualStyleBackColor = true;
            this.ModifButton.Click += new System.EventHandler(this.ModifButton_Click);
            // 
            // label_Telephone
            // 
            this.label_Telephone.AutoSize = true;
            this.label_Telephone.Location = new System.Drawing.Point(150, 62);
            this.label_Telephone.Name = "label_Telephone";
            this.label_Telephone.Size = new System.Drawing.Size(58, 13);
            this.label_Telephone.TabIndex = 20;
            this.label_Telephone.Text = "Telephone";
            // 
            // listBox
            // 
            this.listBox.FormattingEnabled = true;
            this.listBox.Location = new System.Drawing.Point(12, 40);
            this.listBox.Name = "listBox";
            this.listBox.Size = new System.Drawing.Size(120, 95);
            this.listBox.TabIndex = 18;
            this.listBox.SelectedIndexChanged += new System.EventHandler(this.listBox_SelectedIndexChanged);
            // 
            // telephoneTextBox
            // 
            this.telephoneTextBox.Location = new System.Drawing.Point(216, 62);
            this.telephoneTextBox.Name = "telephoneTextBox";
            this.telephoneTextBox.Size = new System.Drawing.Size(120, 20);
            this.telephoneTextBox.TabIndex = 33;
            // 
            // modifierFournisseur
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(377, 147);
            this.Controls.Add(this.telephoneTextBox);
            this.Controls.Add(this.suppFournisseurButton);
            this.Controls.Add(this.CloselButton);
            this.Controls.Add(this.label_Nom_Produit);
            this.Controls.Add(this.textBox_NomProduit);
            this.Controls.Add(this.ModifButton);
            this.Controls.Add(this.label_Telephone);
            this.Controls.Add(this.listBox);
            this.Name = "modifierFournisseur";
            this.Text = "modifierFournisseur";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button suppFournisseurButton;
        private System.Windows.Forms.Button CloselButton;
        private System.Windows.Forms.Label label_Nom_Produit;
        private System.Windows.Forms.TextBox textBox_NomProduit;
        private System.Windows.Forms.Button ModifButton;
        private System.Windows.Forms.Label label_Telephone;
        private System.Windows.Forms.ListBox listBox;
        private System.Windows.Forms.TextBox telephoneTextBox;
    }
}