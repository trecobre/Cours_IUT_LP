﻿namespace Gestion_camping
{
    partial class IncidentForm2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dateTimeDebut = new System.Windows.Forms.DateTimePicker();
            this.comboBoxEmplacement = new System.Windows.Forms.ComboBox();
            this.labelDate = new System.Windows.Forms.Label();
            this.labelEmplacement = new System.Windows.Forms.Label();
            this.buttonValider = new System.Windows.Forms.Button();
            this.buttonAnnuler = new System.Windows.Forms.Button();
            this.comboBoxTypeInc = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.textBoxDetail = new System.Windows.Forms.TextBox();
            this.labelDetails = new System.Windows.Forms.Label();
            this.compteur = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // dateTimeDebut
            // 
            this.dateTimeDebut.Location = new System.Drawing.Point(224, 27);
            this.dateTimeDebut.Name = "dateTimeDebut";
            this.dateTimeDebut.Size = new System.Drawing.Size(200, 20);
            this.dateTimeDebut.TabIndex = 3;
            // 
            // comboBoxEmplacement
            // 
            this.comboBoxEmplacement.FormattingEnabled = true;
            this.comboBoxEmplacement.Location = new System.Drawing.Point(298, 55);
            this.comboBoxEmplacement.Name = "comboBoxEmplacement";
            this.comboBoxEmplacement.Size = new System.Drawing.Size(126, 21);
            this.comboBoxEmplacement.TabIndex = 7;
            // 
            // labelDate
            // 
            this.labelDate.AutoSize = true;
            this.labelDate.Location = new System.Drawing.Point(291, 9);
            this.labelDate.Name = "labelDate";
            this.labelDate.Size = new System.Drawing.Size(75, 13);
            this.labelDate.TabIndex = 8;
            this.labelDate.Text = "Date de début";
            // 
            // labelEmplacement
            // 
            this.labelEmplacement.AutoSize = true;
            this.labelEmplacement.Location = new System.Drawing.Point(221, 58);
            this.labelEmplacement.Name = "labelEmplacement";
            this.labelEmplacement.Size = new System.Drawing.Size(77, 13);
            this.labelEmplacement.TabIndex = 11;
            this.labelEmplacement.Text = "Emplacement :";
            // 
            // buttonValider
            // 
            this.buttonValider.Location = new System.Drawing.Point(327, 288);
            this.buttonValider.Name = "buttonValider";
            this.buttonValider.Size = new System.Drawing.Size(97, 23);
            this.buttonValider.TabIndex = 12;
            this.buttonValider.Text = "Valider";
            this.buttonValider.UseVisualStyleBackColor = true;
            this.buttonValider.Click += new System.EventHandler(this.buttonValider_Click);
            // 
            // buttonAnnuler
            // 
            this.buttonAnnuler.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.buttonAnnuler.Location = new System.Drawing.Point(224, 288);
            this.buttonAnnuler.Name = "buttonAnnuler";
            this.buttonAnnuler.Size = new System.Drawing.Size(97, 23);
            this.buttonAnnuler.TabIndex = 13;
            this.buttonAnnuler.Text = "Annuler";
            this.buttonAnnuler.UseVisualStyleBackColor = true;
            // 
            // comboBoxTypeInc
            // 
            this.comboBoxTypeInc.FormattingEnabled = true;
            this.comboBoxTypeInc.Location = new System.Drawing.Point(12, 27);
            this.comboBoxTypeInc.Name = "comboBoxTypeInc";
            this.comboBoxTypeInc.Size = new System.Drawing.Size(180, 21);
            this.comboBoxTypeInc.TabIndex = 6;
            this.comboBoxTypeInc.Text = "Incident";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(71, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(79, 13);
            this.label1.TabIndex = 14;
            this.label1.Text = "Type d\'incident";
            // 
            // textBoxDetail
            // 
            this.textBoxDetail.Location = new System.Drawing.Point(12, 82);
            this.textBoxDetail.Multiline = true;
            this.textBoxDetail.Name = "textBoxDetail";
            this.textBoxDetail.Size = new System.Drawing.Size(412, 177);
            this.textBoxDetail.TabIndex = 15;
            this.textBoxDetail.TextChanged += new System.EventHandler(this.textBoxDetail_TextChanged);
            // 
            // labelDetails
            // 
            this.labelDetails.AutoSize = true;
            this.labelDetails.Location = new System.Drawing.Point(12, 66);
            this.labelDetails.Name = "labelDetails";
            this.labelDetails.Size = new System.Drawing.Size(93, 13);
            this.labelDetails.TabIndex = 16;
            this.labelDetails.Text = "Détail de l\'incident";
            // 
            // compteur
            // 
            this.compteur.AutoSize = true;
            this.compteur.Location = new System.Drawing.Point(389, 262);
            this.compteur.Name = "compteur";
            this.compteur.Size = new System.Drawing.Size(31, 13);
            this.compteur.TabIndex = 17;
            this.compteur.Text = "3500";
            // 
            // IncidentForm2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(439, 323);
            this.Controls.Add(this.compteur);
            this.Controls.Add(this.labelDetails);
            this.Controls.Add(this.textBoxDetail);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.buttonAnnuler);
            this.Controls.Add(this.buttonValider);
            this.Controls.Add(this.labelEmplacement);
            this.Controls.Add(this.labelDate);
            this.Controls.Add(this.comboBoxEmplacement);
            this.Controls.Add(this.comboBoxTypeInc);
            this.Controls.Add(this.dateTimeDebut);
            this.Name = "IncidentForm2";
            this.Text = "IncidentForm2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.DateTimePicker dateTimeDebut;
        private System.Windows.Forms.ComboBox comboBoxEmplacement;
        private System.Windows.Forms.Label labelDate;
        private System.Windows.Forms.Label labelEmplacement;
        private System.Windows.Forms.Button buttonValider;
        private System.Windows.Forms.Button buttonAnnuler;
        private System.Windows.Forms.ComboBox comboBoxTypeInc;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBoxDetail;
        private System.Windows.Forms.Label labelDetails;
        private System.Windows.Forms.Label compteur;
    }
}