﻿using System.Collections.Generic;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Configuration;
using System.Diagnostics;
using System.IO;
using System;

namespace Gestion_camping
{
    internal class Logging
    {
        public TraceListener s_listener;
        public ILogger<Program> logger;
        public IConfiguration Configuration { get; }

        public Logging(IConfiguration configuration)
        {
            Configuration = configuration;
            var writer = File.CreateText("logfileMrCampo.txt");

            s_listener = new TextWriterTraceListener(writer.BaseStream);
            ILoggerFactory loggerFactory = LoggerFactory.Create(config => {
                config.AddConfiguration(Configuration);
                config.AddConsole();
                config.AddTraceSource(new SourceSwitch("TraceSourceLog", SourceLevels.Verbose.ToString()), s_listener);
                config.AddDebug();
            });
            logger = loggerFactory.CreateLogger<Program>();

            logger.LogDebug("Debug from logger");
            //s_listener.Close();
        }
    }
}

//logger.LogInformation("Logging information.");
//logger.LogCritical("Logging critical information.");
//logger.LogDebug("Logging debug information.");
//logger.LogError("Logging error information.");
//logger.LogTrace("Logging trace");
//logger.LogWarning("Logging warning.");