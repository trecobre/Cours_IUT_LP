﻿
namespace Gestion_camping
{
    partial class affichageFournisseur
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.telephoneTextBox = new System.Windows.Forms.TextBox();
            this.closeButton = new System.Windows.Forms.Button();
            this.label_Nom_Produit = new System.Windows.Forms.Label();
            this.textBox_NomProduit = new System.Windows.Forms.TextBox();
            this.label_Telephone = new System.Windows.Forms.Label();
            this.listBox = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // telephoneTextBox
            // 
            this.telephoneTextBox.BackColor = System.Drawing.SystemColors.Window;
            this.telephoneTextBox.Location = new System.Drawing.Point(215, 45);
            this.telephoneTextBox.Name = "telephoneTextBox";
            this.telephoneTextBox.ReadOnly = true;
            this.telephoneTextBox.Size = new System.Drawing.Size(120, 20);
            this.telephoneTextBox.TabIndex = 39;
            // 
            // closeButton
            // 
            this.closeButton.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.closeButton.Location = new System.Drawing.Point(178, 87);
            this.closeButton.Name = "closeButton";
            this.closeButton.Size = new System.Drawing.Size(120, 22);
            this.closeButton.TabIndex = 38;
            this.closeButton.Text = "Fermer";
            this.closeButton.UseVisualStyleBackColor = true;
            // 
            // label_Nom_Produit
            // 
            this.label_Nom_Produit.AutoSize = true;
            this.label_Nom_Produit.Location = new System.Drawing.Point(149, 15);
            this.label_Nom_Produit.Name = "label_Nom_Produit";
            this.label_Nom_Produit.Size = new System.Drawing.Size(29, 13);
            this.label_Nom_Produit.TabIndex = 37;
            this.label_Nom_Produit.Text = "Nom";
            // 
            // textBox_NomProduit
            // 
            this.textBox_NomProduit.BackColor = System.Drawing.SystemColors.Window;
            this.textBox_NomProduit.Location = new System.Drawing.Point(215, 12);
            this.textBox_NomProduit.Name = "textBox_NomProduit";
            this.textBox_NomProduit.ReadOnly = true;
            this.textBox_NomProduit.Size = new System.Drawing.Size(120, 20);
            this.textBox_NomProduit.TabIndex = 36;
            // 
            // label_Telephone
            // 
            this.label_Telephone.AutoSize = true;
            this.label_Telephone.Location = new System.Drawing.Point(149, 45);
            this.label_Telephone.Name = "label_Telephone";
            this.label_Telephone.Size = new System.Drawing.Size(58, 13);
            this.label_Telephone.TabIndex = 35;
            this.label_Telephone.Text = "Telephone";
            // 
            // listBox
            // 
            this.listBox.FormattingEnabled = true;
            this.listBox.Location = new System.Drawing.Point(11, 12);
            this.listBox.Name = "listBox";
            this.listBox.Size = new System.Drawing.Size(120, 95);
            this.listBox.TabIndex = 34;
            // 
            // affichageFournisseur
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(349, 131);
            this.Controls.Add(this.telephoneTextBox);
            this.Controls.Add(this.closeButton);
            this.Controls.Add(this.label_Nom_Produit);
            this.Controls.Add(this.textBox_NomProduit);
            this.Controls.Add(this.label_Telephone);
            this.Controls.Add(this.listBox);
            this.Name = "affichageFournisseur";
            this.Text = "affichageFournisseur";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox telephoneTextBox;
        private System.Windows.Forms.Button closeButton;
        private System.Windows.Forms.Label label_Nom_Produit;
        private System.Windows.Forms.TextBox textBox_NomProduit;
        private System.Windows.Forms.Label label_Telephone;
        private System.Windows.Forms.ListBox listBox;
    }
}