﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gestion_camping
{
    public partial class affichageFournisseur : Form
    {
        public affichageFournisseur(Fournisseur fournisseur)
        {
            InitializeComponent();
            fillPanel(fournisseur);
        }

        private void fillPanel(Fournisseur fournisseur)
        {
            textBox_NomProduit.Text = fournisseur.nomFournisseur;
            telephoneTextBox.Text = fournisseur.telephoneFournisseur;
            fillList(fournisseur);
        }

        private void fillList(Fournisseur fournisseur)
        {
            Produit[] produits = Program.bdEntities.Produit.Where(p => p.fournisseurId == fournisseur.FournisseurID).ToArray();
            listBox.Items.AddRange(produits);
        }
    }
}
