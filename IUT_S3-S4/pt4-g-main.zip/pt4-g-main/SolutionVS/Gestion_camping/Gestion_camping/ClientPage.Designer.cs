﻿namespace Gestion_camping
{
    partial class ClientPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ClientPagePanel = new System.Windows.Forms.Panel();
            this.clientFlowLayoutPanel = new System.Windows.Forms.FlowLayoutPanel();
            this.ajoutClientButton = new System.Windows.Forms.Button();
            this.ClientPagePanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // ClientPagePanel
            // 
            this.ClientPagePanel.Controls.Add(this.clientFlowLayoutPanel);
            this.ClientPagePanel.Controls.Add(this.ajoutClientButton);
            this.ClientPagePanel.Location = new System.Drawing.Point(17, 13);
            this.ClientPagePanel.Name = "ClientPagePanel";
            this.ClientPagePanel.Size = new System.Drawing.Size(766, 614);
            this.ClientPagePanel.TabIndex = 30;
            this.ClientPagePanel.SizeChanged += new System.EventHandler(this.ClientPagePanel_SizeChanged);
            // 
            // clientFlowLayoutPanel
            // 
            this.clientFlowLayoutPanel.AutoScroll = true;
            this.clientFlowLayoutPanel.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.clientFlowLayoutPanel.Location = new System.Drawing.Point(3, 3);
            this.clientFlowLayoutPanel.Name = "clientFlowLayoutPanel";
            this.clientFlowLayoutPanel.Size = new System.Drawing.Size(760, 579);
            this.clientFlowLayoutPanel.TabIndex = 25;
            this.clientFlowLayoutPanel.WrapContents = false;
            // 
            // ajoutClientButton
            // 
            this.ajoutClientButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.ajoutClientButton.Location = new System.Drawing.Point(346, 588);
            this.ajoutClientButton.Name = "ajoutClientButton";
            this.ajoutClientButton.Size = new System.Drawing.Size(75, 23);
            this.ajoutClientButton.TabIndex = 27;
            this.ajoutClientButton.Text = "Ajouter";
            this.ajoutClientButton.UseVisualStyleBackColor = true;
            this.ajoutClientButton.Click += new System.EventHandler(this.modificationButton_Click);
            // 
            // ClientPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(851, 745);
            this.Controls.Add(this.ClientPagePanel);
            this.Name = "ClientPage";
            this.Text = "ClientPage";
            this.ClientPagePanel.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel ClientPagePanel;
        private System.Windows.Forms.FlowLayoutPanel clientFlowLayoutPanel;
        private System.Windows.Forms.Button ajoutClientButton;
    }
}