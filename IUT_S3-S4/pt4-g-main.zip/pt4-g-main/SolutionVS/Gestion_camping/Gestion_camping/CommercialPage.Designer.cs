﻿namespace Gestion_camping
{
    partial class commercial
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.factureFlowLayoutPanel = new System.Windows.Forms.FlowLayoutPanel();
            this.clientPageLabel = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.panelComm = new System.Windows.Forms.Panel();
            this.panelComm.SuspendLayout();
            this.SuspendLayout();
            // 
            // factureFlowLayoutPanel
            // 
            this.factureFlowLayoutPanel.AutoScroll = true;
            this.factureFlowLayoutPanel.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.factureFlowLayoutPanel.Location = new System.Drawing.Point(113, 3);
            this.factureFlowLayoutPanel.Name = "factureFlowLayoutPanel";
            this.factureFlowLayoutPanel.Size = new System.Drawing.Size(492, 665);
            this.factureFlowLayoutPanel.TabIndex = 25;
            this.factureFlowLayoutPanel.WrapContents = false;
            // 
            // clientPageLabel
            // 
            this.clientPageLabel.Location = new System.Drawing.Point(8, 16);
            this.clientPageLabel.Name = "clientPageLabel";
            this.clientPageLabel.Size = new System.Drawing.Size(35, 13);
            this.clientPageLabel.TabIndex = 0;
            this.clientPageLabel.Text = "clientFactureLabel";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(11, 421);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 27;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // panelComm
            // 
            this.panelComm.Controls.Add(this.factureFlowLayoutPanel);
            this.panelComm.Controls.Add(this.button1);
            this.panelComm.Controls.Add(this.clientPageLabel);
            this.panelComm.Location = new System.Drawing.Point(1, 1);
            this.panelComm.Name = "panelComm";
            this.panelComm.Size = new System.Drawing.Size(730, 589);
            this.panelComm.TabIndex = 28;
            // 
            // commercial
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(817, 518);
            this.Controls.Add(this.panelComm);
            this.Name = "commercial";
            this.Text = "commercial";
            this.panelComm.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.FlowLayoutPanel factureFlowLayoutPanel;
        private System.Windows.Forms.Label clientPageLabel;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Panel panelComm;
    }
}