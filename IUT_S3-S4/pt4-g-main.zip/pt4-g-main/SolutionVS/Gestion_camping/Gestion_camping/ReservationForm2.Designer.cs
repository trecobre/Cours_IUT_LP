﻿namespace Gestion_camping
{
    partial class ReservationForm2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.dateTimeDebut = new System.Windows.Forms.DateTimePicker();
            this.comboBoxClient = new System.Windows.Forms.ComboBox();
            this.comboBoxEmplacement = new System.Windows.Forms.ComboBox();
            this.labelDate = new System.Windows.Forms.Label();
            this.labelDuree = new System.Windows.Forms.Label();
            this.numericUpDownDuree = new System.Windows.Forms.NumericUpDown();
            this.labelEmplacement = new System.Windows.Forms.Label();
            this.buttonValider = new System.Windows.Forms.Button();
            this.buttonAnnuler = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownDuree)).BeginInit();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(12, 53);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(180, 23);
            this.button1.TabIndex = 2;
            this.button1.Text = "Nouveau client";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // dateTimeDebut
            // 
            this.dateTimeDebut.Location = new System.Drawing.Point(224, 27);
            this.dateTimeDebut.Name = "dateTimeDebut";
            this.dateTimeDebut.Size = new System.Drawing.Size(200, 20);
            this.dateTimeDebut.TabIndex = 3;
            // 
            // comboBoxClient
            // 
            this.comboBoxClient.FormattingEnabled = true;
            this.comboBoxClient.Location = new System.Drawing.Point(12, 26);
            this.comboBoxClient.Name = "comboBoxClient";
            this.comboBoxClient.Size = new System.Drawing.Size(180, 21);
            this.comboBoxClient.TabIndex = 6;
            this.comboBoxClient.Text = "Client";
            // 
            // comboBoxEmplacement
            // 
            this.comboBoxEmplacement.FormattingEnabled = true;
            this.comboBoxEmplacement.Location = new System.Drawing.Point(89, 96);
            this.comboBoxEmplacement.Name = "comboBoxEmplacement";
            this.comboBoxEmplacement.Size = new System.Drawing.Size(103, 21);
            this.comboBoxEmplacement.TabIndex = 7;
            // 
            // labelDate
            // 
            this.labelDate.AutoSize = true;
            this.labelDate.Location = new System.Drawing.Point(291, 9);
            this.labelDate.Name = "labelDate";
            this.labelDate.Size = new System.Drawing.Size(75, 13);
            this.labelDate.TabIndex = 8;
            this.labelDate.Text = "Date de début";
            // 
            // labelDuree
            // 
            this.labelDuree.AutoSize = true;
            this.labelDuree.Location = new System.Drawing.Point(221, 58);
            this.labelDuree.Name = "labelDuree";
            this.labelDuree.Size = new System.Drawing.Size(175, 13);
            this.labelDuree.TabIndex = 9;
            this.labelDuree.Text = "Durée :                                     jours";
            // 
            // numericUpDownDuree
            // 
            this.numericUpDownDuree.Location = new System.Drawing.Point(263, 56);
            this.numericUpDownDuree.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.numericUpDownDuree.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDownDuree.Name = "numericUpDownDuree";
            this.numericUpDownDuree.Size = new System.Drawing.Size(103, 20);
            this.numericUpDownDuree.TabIndex = 10;
            this.numericUpDownDuree.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // labelEmplacement
            // 
            this.labelEmplacement.AutoSize = true;
            this.labelEmplacement.Location = new System.Drawing.Point(12, 99);
            this.labelEmplacement.Name = "labelEmplacement";
            this.labelEmplacement.Size = new System.Drawing.Size(77, 13);
            this.labelEmplacement.TabIndex = 11;
            this.labelEmplacement.Text = "Emplacement :";
            // 
            // buttonValider
            // 
            this.buttonValider.Location = new System.Drawing.Point(327, 96);
            this.buttonValider.Name = "buttonValider";
            this.buttonValider.Size = new System.Drawing.Size(97, 23);
            this.buttonValider.TabIndex = 12;
            this.buttonValider.Text = "Valider";
            this.buttonValider.UseVisualStyleBackColor = true;
            this.buttonValider.Click += new System.EventHandler(this.buttonValider_Click);
            // 
            // buttonAnnuler
            // 
            this.buttonAnnuler.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.buttonAnnuler.Location = new System.Drawing.Point(224, 96);
            this.buttonAnnuler.Name = "buttonAnnuler";
            this.buttonAnnuler.Size = new System.Drawing.Size(97, 23);
            this.buttonAnnuler.TabIndex = 13;
            this.buttonAnnuler.Text = "Annuler";
            this.buttonAnnuler.UseVisualStyleBackColor = true;
            // 
            // ReservationForm2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(442, 146);
            this.Controls.Add(this.buttonAnnuler);
            this.Controls.Add(this.buttonValider);
            this.Controls.Add(this.labelEmplacement);
            this.Controls.Add(this.numericUpDownDuree);
            this.Controls.Add(this.labelDuree);
            this.Controls.Add(this.labelDate);
            this.Controls.Add(this.comboBoxEmplacement);
            this.Controls.Add(this.comboBoxClient);
            this.Controls.Add(this.dateTimeDebut);
            this.Controls.Add(this.button1);
            this.Name = "ReservationForm2";
            this.Text = "ReservationForm2";
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownDuree)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.DateTimePicker dateTimeDebut;
        private System.Windows.Forms.ComboBox comboBoxClient;
        private System.Windows.Forms.ComboBox comboBoxEmplacement;
        private System.Windows.Forms.Label labelDate;
        private System.Windows.Forms.Label labelDuree;
        private System.Windows.Forms.NumericUpDown numericUpDownDuree;
        private System.Windows.Forms.Label labelEmplacement;
        private System.Windows.Forms.Button buttonValider;
        private System.Windows.Forms.Button buttonAnnuler;
    }
}