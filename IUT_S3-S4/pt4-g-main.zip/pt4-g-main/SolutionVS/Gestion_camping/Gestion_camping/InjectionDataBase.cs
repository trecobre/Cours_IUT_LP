﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Gestion_camping.PDFGenerator;

namespace Gestion_camping
{

    internal class InjectionDataBase
    {
        static DateTime RandomDay()
        {
            Random gen = new Random();
            DateTime start = new DateTime(DateTime.Now.Year - 2, 1, 1);
            int range = (DateTime.Today.AddYears(2) - start).Days;
            return start.AddDays(gen.Next(range));
        }
        public InjectionDataBase()
        {
            Program.bdEntities.Facture.RemoveRange(Program.bdEntities.Facture);
            Program.bdEntities.Client.RemoveRange(Program.bdEntities.Client);
            Program.bdEntities.Fournisseur.RemoveRange(Program.bdEntities.Fournisseur);
            Program.bdEntities.Produit.RemoveRange(Program.bdEntities.Produit);
            Program.bdEntities.Zone.RemoveRange(Program.bdEntities.Zone);
            Program.bdEntities.Emplacement.RemoveRange(Program.bdEntities.Emplacement);
            Program.bdEntities.Incident.RemoveRange(Program.bdEntities.Incident);//TODO
            Program.bdEntities.Achat.RemoveRange(Program.bdEntities.Achat);
            Program.bdEntities.Stock.RemoveRange(Program.bdEntities.Stock);
            Program.bdEntities.Vente.RemoveRange(Program.bdEntities.Vente);
            Program.bdEntities.Reservation.RemoveRange(Program.bdEntities.Reservation);
            Program.bdEntities.SaveChanges();
            var PrenC = new StreamReader("C:/Users/trecobre/Documents/Nouveau dossier/nat2020.csv");
            var NomC = new StreamReader("C:/Users/trecobre/Documents/Nouveau dossier/Nat2008.csv");
            var ProdC = new StreamReader("C:/Users/trecobre/Documents/Nouveau dossier/produits.csv");
            List<string> prenoms = new List<string>();
            var line = PrenC.ReadLine();
            while (!PrenC.EndOfStream)
            {
                line = PrenC.ReadLine();
                var values = line.Split(';');
                for(int i = 0; i < int.Parse(values[1]); i++)
                {
                    prenoms.Add(values[0].Trim());
                }
            }
            Console.WriteLine(prenoms.Count);
            List<string> noms = new List<string>();
            while (!NomC.EndOfStream)
            {
                line = NomC.ReadLine();
                var values = line.Split(',');
                noms.Add(values[0].Trim());
            }
            Random rdm = new Random();
            for (int i = 0; i <= 30; i++)
            {
                TextInfo ti = new CultureInfo("fr-FR").TextInfo;
                string prenRand = ti.ToTitleCase(prenoms[rdm.Next(prenoms.Count())].ToLower());
                string nomRand = ti.ToTitleCase(noms[rdm.Next(noms.Count())].ToLower());
                int digit = (rdm.Next(2) + 6);
                string phone = "0" + digit + "" + rdm.Next(10000000, 99999999);
                string mail = prenRand.ToLower() + "." + nomRand.ToLower() + "@gmail.com";
                Client client = new Client();
                client.nomClient = nomRand;
                client.prenomClient = prenRand;
                client.telephoneClient = phone;
                client.mailClient = mail;
                client.ClientID = i;
                Program.bdEntities.Client.Add(client);
            }
            List<string> produits = new List<string>();
            List<string> store = new List<string>();
            while (!ProdC.EndOfStream)
            {
                line = ProdC.ReadLine();
                var values = line.Split(',');
                string nomP = values[1].Trim();
                if (nomP.Contains("\""))
                {
                    nomP.Remove(nomP.IndexOf('"'));
                }
                produits.Add(nomP);
                nomP = values[2].Trim();
                if (nomP.Contains("\""))
                {
                    nomP.Remove(nomP.IndexOf('"'));
                }
                store.Add(nomP);
            }
            store = store.Where(r => r != "").ToList();
            for (int i = 0; i <= 10; i++)
            {
                string nomF = store[rdm.Next(store.Count())];
                int digit = (rdm.Next(1, 9));
                string phone = "0" + digit + "" + rdm.Next(10000000, 99999999);
                Fournisseur fournisseur = new Fournisseur();
                fournisseur.nomFournisseur = nomF;
                fournisseur.telephoneFournisseur = phone;
                fournisseur.FournisseurID = i;
                Program.bdEntities.Fournisseur.Add(fournisseur);
            }
            Program.bdEntities.SaveChanges();
            for (int i = 0; i <= 25; i++)
            {
                string nomP = produits[rdm.Next(produits.Count() - 1)];
                Produit prod = new Produit();
                prod.nomProduit = nomP;
                prod.descriptionProduit = nomP;
                prod.prixProduit = Math.Truncate(100 * (rdm.NextDouble() * 5)) / 100;
                prod.fournisseurId = Program.bdEntities.Fournisseur.ToArray()[rdm.Next(Program.bdEntities.Fournisseur.Count() - 1)].FournisseurID;
                prod.ProduitID = i;
                Program.bdEntities.Produit.Add(prod);
                Program.bdEntities.SaveChanges();
                int nb = rdm.Next(5);

                for (int j = 0; j < nb; j++)
                {
                    Stock stock = new Stock();
                    stock.quantiteProduit = rdm.Next(100);
                    stock.dateAjout = DateTime.Now.AddDays(-rdm.Next(100));
                    stock.datePeremption = stock.dateAjout.AddDays(rdm.Next(200));
                    Produit produit = Program.bdEntities.Produit.Where(p => p.nomProduit.Equals(prod.nomProduit)).First();
                    stock.Produit = produit;
                    stock.produitID = produit.ProduitID;
                    stock.StockID = i * nb + j;
                    Achat achat = new Achat();
                    achat.fournisseurID = (int)prod.fournisseurId;
                    achat.quantiteAchat = stock.quantiteProduit;
                    achat.dateAchat = stock.dateAjout.AddDays(-rdm.Next(10));
                    achat.Produit = prod;
                    achat.produitID = prod.ProduitID;
                    produit.Achat.Add(achat);
                    produit.Stock.Add(stock);
                    Program.bdEntities.Achat.Add(achat);
                    Program.bdEntities.Stock.Add(stock);
                }
            }

            foreach (char i in "ABCDEFG")
            {
                int nb = rdm.Next(6, 12);
                Zone zone = new Zone();
                zone.zoneName = "" + i;
                zone.nbEmplacement = nb;
                int index = "ABCDEFG".IndexOf(i);
                zone.ZoneID = index;
                Program.bdEntities.Zone.Add(zone);
                Program.bdEntities.SaveChanges();
                for (int j = 0; j < nb; j++)
                {
                    Emplacement emplacement = new Emplacement();
                    emplacement.Zone = zone;
                    emplacement.zoneID = zone.ZoneID;
                    emplacement.numeroEmplacement = j;
                    emplacement.intitule = i + "" + j;
                    emplacement.distanceRuisseau = rdm.Next(200);
                    emplacement.eau = rdm.Next(2) == 1;
                    emplacement.electricite = rdm.Next(2) == 1;
                    emplacement.ombre = rdm.Next(2) == 1;
                    emplacement.EmplacementID = index * nb + j;
                    Program.bdEntities.Emplacement.Add(emplacement);
                }
            }
            Program.bdEntities.SaveChanges();
            for (int i = 0; i <= 35; i++)
            {
                Reservation reservation = new Reservation();
                int indexC = rdm.Next(Program.bdEntities.Client.Count() - 1);
                reservation.Client = (Client)Program.bdEntities.Client.ToArray().GetValue(indexC);
                reservation.clientID = reservation.Client.ClientID;
                ((Client)Program.bdEntities.Client.ToArray().GetValue(indexC)).nombreReservationClient += 1;
                int duree = rdm.Next(100);
                DateTime debut = RandomDay();
                DateTime fin = debut.AddDays(duree);
                if(debut > DateTime.Now)
                {
                    reservation.etat = 1;
                }
                else if(fin < DateTime.Now){
                    reservation.etat = 2;
                }
                else
                {
                    reservation.etat = 0;
                }
                reservation.dateDebut = debut;
                reservation.dateFin = fin;
                reservation.Emplacement = Program.bdEntities.Emplacement.ToArray().ElementAt(rdm.Next(Program.bdEntities.Emplacement.Count() - 1));
                reservation.emplacementID = reservation.Emplacement.EmplacementID;
                Program.bdEntities.Reservation.Add(reservation);
                Program.bdEntities.SaveChanges();
                int interv = rdm.Next(-100, 100);
                FacturePDF fPDF = new FacturePDF(reservation.Client, reservation.dateDebut);
            }
            for (int i = 0; i < 30; i++)
            {
                Vente vente = new Vente();
                Produit produit = new Produit();
                DateTime date = RandomDay();
                Produit[] prods = { };
                while(prods.Length == 0)
                {
                    date = RandomDay();
                    prods = Program.bdEntities.Produit.Where(p => p.Stock.Where(s => s.dateAjout < date && s.datePeremption > date).Count() > 1).ToArray();
                }
                vente.Produit = prods[rdm.Next(prods.Length)];
                vente.produitID = vente.Produit.ProduitID;
                vente.dateVente = date;
                vente.quantiteVente = rdm.Next(10);
                vente.prix = (decimal)(vente.quantiteVente * vente.Produit.prixProduit);
                Program.bdEntities.Stock.Where(s => s.dateAjout < date && s.datePeremption > date && s.produitID==vente.produitID).OrderBy(s => s.dateAjout).FirstOrDefault().quantiteProduit -= vente.quantiteVente;
                vente.Produit.Vente.Add(vente);
                Program.bdEntities.Vente.Add(vente);
            }
            Program.bdEntities.SaveChanges();
        }
    }
}
