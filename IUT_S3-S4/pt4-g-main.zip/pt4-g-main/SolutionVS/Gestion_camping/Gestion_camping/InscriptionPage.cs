﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using System.Security.Cryptography;

namespace Gestion_camping.Resources
{
    public partial class Inscription : Form
    {
        private MD5 saltForHash;
        private Label focusLabel;
        private Label focusedLabel;
        private TextBox focusTB;
        private int counter = 0;
        private bool stopC = false;
        private bool agrandir = false;
        private int baseX;
        private int baseX2;
        private enum EtatMDP
        {
            DIF = -1,
            OK = 0,
            MIN = 1,
            MAX = 2,
            MAJ = 3,
            MINUS = 4,
            NUM = 5,
            SPEC = 6
        }

        public Inscription()
        {
            InitializeComponent();
            this.InitializeTimer();
            saltForHash = MD5.Create();
            focusedLabel =  new Label();
            focusLabel = new Label();
            focusTB = new TextBox();
        }
        private void InitializeTimer()
        {
            this.timer1.Interval = 1; //1.5 seconds
            timer1.Enabled = false;
            this.timer1.Tick += new EventHandler(TimerEventProcessor);
        }

        private void TimerEventProcessor(object sender, EventArgs e)
        {
            if (counter <= 21)
            {
                
                float taille;
                Single police;
                if(agrandir)
                {
                    taille = (float)(9.75 + ((float)counter / 10) * 5);
                    police = taille;
                    focusedLabel.Font = new Font("Microsoft Sans Serif", taille, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
                    focusedLabel.Location = new System.Drawing.Point(baseX2, 9);
                    focusedLabel.TextAlign = System.Drawing.ContentAlignment.TopCenter;
                }
                
                taille = (float)(20.25 - ((float)counter / 10) * 5);
                police = taille;
                focusLabel.Font = new Font("Microsoft Sans Serif", taille, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
                focusLabel.Location = new System.Drawing.Point(25, 0);
                focusedLabel.TextAlign = System.Drawing.ContentAlignment.TopLeft;
                
                counter++;
            }
            else
            {
                stopC = true;
            }
        }

        private EtatMDP GetEtat(string pass, string passConf)
        {
            Regex rxNum = new Regex(@"(?=.*\d)", RegexOptions.Compiled | RegexOptions.IgnoreCase);
            Regex rxSpec = new Regex(@"(?=.*[@#$%*!/+_\-%])", RegexOptions.Compiled | RegexOptions.IgnoreCase);

            MatchCollection matchNum = rxNum.Matches(pass);
            MatchCollection matchSpec = rxSpec.Matches(pass);

            if(pass.Length < 5) return EtatMDP.MIN;
            if(pass.Length >= 64) return EtatMDP.MAX;
            if(!pass.Any(char.IsUpper)) return EtatMDP.MAJ;
            if(!pass.Any(char.IsLower)) return EtatMDP.MINUS;
            if(matchNum.Count <= 0) return EtatMDP.NUM;
            if(matchSpec.Count <= 0) return EtatMDP.SPEC;
            if(!pass.Equals(passConf)) return EtatMDP.DIF;
            return EtatMDP.OK;
        }

        public void buttonConfirm_Click(object sender, EventArgs e)
        {
            string message = "Votre compte a été crée avec succès !";
            MessageBoxIcon icon = MessageBoxIcon.Warning;
            
            string nom = nomTB.Text;
            string prenom = prenomTB.Text;
            string login = loginTB.Text;
            string password = mdpTB.Text;
            string passConfirm = mdpcTB.Text;
            string telephone = phoneTB.Text;

            EtatMDP etat = GetEtat(password, passConfirm);

            if (etat == EtatMDP.OK)
            {
                if (nom.Length > 0) 
                { 
                    if(prenom.Length > 0)
                    {
                        Utilisateur[] utilisateurs = Program.bdEntities.Utilisateur.ToArray();
                        bool sameLogin = false;
                        foreach (Utilisateur user in utilisateurs)
                        {
                            if (user.login.Equals(login))
                            {
                                sameLogin = true;
                            }
                        }
                        if (login.Length > 0 && !sameLogin)
                        {
                            string patern = @"\(?\d{3}\)?-? *\d{3}-? *-?\d{4}";
                            Regex rxPhone = new Regex(patern, RegexOptions.Compiled | RegexOptions.IgnoreCase);
                            if (telephone.Length > 0 && rxPhone.IsMatch(telephone))
                            {
                                //Hashage password
                                var salting = saltForHash.ComputeHash(new UTF8Encoding().GetBytes(password));
                                string hash = BitConverter.ToString(salting).Replace("-", string.Empty);
                                
                                Utilisateur utilisateur = new Utilisateur();
                                utilisateur.login = login;
                                utilisateur.nomUtilisateur = nom;
                                utilisateur.password = hash;
                                utilisateur.prenomUtilisateur = prenom;
                                utilisateur.telephoneUtilisateur = telephone;

                                Utils.Inscription(utilisateur);
                            }
                            else
                            {
                                message = "Vous devez renseignez votre numéro de téléphone valide.";
                            }
                        }
                        else
                        {
                            message = "Vous devez renseignez votre identifiant.";
                        }
                    }
                    else
                    {
                        message = "Vous devez renseignez votre prénom.";
                    }
                }
                else
                {
                    message = "Vous devez renseignez votre nom.";
                }
            }
            else
            {
                icon = MessageBoxIcon.Error;
                switch (etat)
                {
                    case EtatMDP.DIF: 
                        message = "Les mots de passe renseignés ne sont pas identiques."; 
                        break;
                    case EtatMDP.MAJ: 
                        message = "Le mot de passe renseigné doit contenir au moins une majuscule.";
                        break;
                    case EtatMDP.MINUS: 
                        message = "Le mot de passe renseigné doit contenir au moins une minuscule.";
                        break;
                    case EtatMDP.MAX:
                        message = "Les mots de passe renseignés ne sont pas identiques."; 
                        break;
                    case EtatMDP.MIN: 
                        message = "Les mots de passe renseignés ne sont pas identiques.";
                        break;
                    case EtatMDP.NUM: 
                        message = "Le mot de passe renseigné doit contenir au moins un chiffe."; 
                        break;
                    case EtatMDP.SPEC: 
                        message = "Le mot de passe renseigné doit contenir au moins un caractère spécial parmi la liste suivante : \"@ # $ % * ! / + _ - %\"."; 
                        break;
                }
            }
            if (message.Contains("crée avec succès")) icon = MessageBoxIcon.Information;
            MessageBox.Show(message, "Erreur formulaire", MessageBoxButtons.OK, icon);
        }
        #region config log
        private void panelLog_Click(object sender, EventArgs e)
        {
            loginTB.Focus();
        }
        private void loginTB_Enter(object sender, EventArgs e)
        {
            TbEnter(loginTB, lLogin);
        }
        private void loginTB_Leave(object sender, EventArgs e)
        {
            TbLeave(loginTB, lLogin);
        }
        #endregion
        #region config phone
        private void panelTel_Click(object sender, EventArgs e)
        {
            phoneTB.Focus();
        }
        private void PhoneTB_Enter(object sender, EventArgs e)
        {
            TbEnter(phoneTB, lPhone);
        }
        private void PhoneTB_Leave(object sender, EventArgs e)
        {
            TbLeave(phoneTB, lPhone);
        }
        #endregion
        #region config mdp
        private void panelMdp_Click(object sender, EventArgs e)
        {
            mdpTB.Focus();
        }
        private void mdpTB_Enter(object sender, EventArgs e)
        {
            TbEnter(mdpTB, lPass);
        }
        private void mdpTB_Leave(object sender, EventArgs e)
        {
            TbLeave(mdpTB, lPass);
        }
        #endregion
        #region config mdpc
        private void panelConf_Click(object sender, EventArgs e)
        {
            mdpcTB.Focus();
        }
        private void mdpcTB_Enter(object sender, EventArgs e)
        {
            TbEnter(mdpcTB, lPassConf);
        }
        private void mdpcTB_Leave(object sender, EventArgs e)
        {
            TbLeave(mdpcTB, lPassConf);
        }
        #endregion
        #region config nom
        private void panelNom_Click(object sender, EventArgs e)
        {
            nomTB.Focus();
        }
        private void nomTB_Enter(object sender, EventArgs e)
        {
            TbEnter(nomTB, lNom);
        }
        private void nomTB_Leave(object sender, EventArgs e)
        {
            TbLeave(nomTB, lNom);
        }
        #endregion
        #region config prenom
        private void panelPren_Click(object sender, EventArgs e)
        {
            prenomTB.Focus();
        }

        private void prenomTB_Enter(object sender, EventArgs e)
        {
            TbEnter(prenomTB, lPrenom);
        }

        private void prenomTB_Leave(object sender, EventArgs e)
        {
            TbLeave(prenomTB, lPrenom);
        }

        #endregion

        /// <summary>
        /// This function is called when the user presses the Enter key
        /// </summary>
        /// <param name="TextBox">The TextBox that is being focused.</param>
        /// <param name="Label">The label that is being focused on.</param>
        private void TbEnter(TextBox tb, Label lb)
        {
            TbLeave(focusTB, focusedLabel);
            counter = 0;
            focusLabel = lb;
            baseX2 = baseX;
            baseX = lb.Location.X;
            stopC = false;
            timer1.Start();
            while (!stopC)
            {
                Application.DoEvents();
            }
            focusTB = tb;
            focusedLabel = lb;
            tb.BringToFront();
        }

        /// <summary>
        /// When the textbox loses focus, if the textbox is empty, then the label is brought to the
        /// front
        /// </summary>
        /// <param name="TextBox">The TextBox that is being modified.</param>
        /// <param name="Label">The label that will be shown when the textbox is empty.</param>
        
        private void TbLeave(TextBox tb, Label lb)
        {
            agrandir = tb.Text.Length <= 0;
            if(agrandir) lb.BringToFront();
        }

        
    }
}
