﻿namespace Gestion_camping
{
    partial class ModifierStock
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.listBox_Stock = new System.Windows.Forms.ListBox();
            this.label_Quantite = new System.Windows.Forms.Label();
            this.label_Prix = new System.Windows.Forms.Label();
            this.label_Description = new System.Windows.Forms.Label();
            this.richTextBox_Description = new System.Windows.Forms.RichTextBox();
            this.ModifButton = new System.Windows.Forms.Button();
            this.numericUpDown_Quantite = new System.Windows.Forms.NumericUpDown();
            this.textBox_NomProduit = new System.Windows.Forms.TextBox();
            this.label_Nom_Produit = new System.Windows.Forms.Label();
            this.label_Fournisseur = new System.Windows.Forms.Label();
            this.CloselButton = new System.Windows.Forms.Button();
            this.resteLabel = new System.Windows.Forms.Label();
            this.suppStockButton = new System.Windows.Forms.Button();
            this.textBox_Fournisseur = new System.Windows.Forms.TextBox();
            this.prixTextBox = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_Quantite)).BeginInit();
            this.SuspendLayout();
            // 
            // listBox_Stock
            // 
            this.listBox_Stock.FormattingEnabled = true;
            this.listBox_Stock.Location = new System.Drawing.Point(12, 34);
            this.listBox_Stock.Name = "listBox_Stock";
            this.listBox_Stock.Size = new System.Drawing.Size(120, 173);
            this.listBox_Stock.TabIndex = 0;
            this.listBox_Stock.SelectedIndexChanged += new System.EventHandler(this.listBox_Produits_SelectedIndexChanged);
            // 
            // label_Quantite
            // 
            this.label_Quantite.AutoSize = true;
            this.label_Quantite.Location = new System.Drawing.Point(150, 57);
            this.label_Quantite.Name = "label_Quantite";
            this.label_Quantite.Size = new System.Drawing.Size(47, 13);
            this.label_Quantite.TabIndex = 2;
            this.label_Quantite.Text = "Quantité";
            // 
            // label_Prix
            // 
            this.label_Prix.AutoSize = true;
            this.label_Prix.Location = new System.Drawing.Point(150, 104);
            this.label_Prix.Name = "label_Prix";
            this.label_Prix.Size = new System.Drawing.Size(24, 13);
            this.label_Prix.TabIndex = 4;
            this.label_Prix.Text = "Prix";
            // 
            // label_Description
            // 
            this.label_Description.AutoSize = true;
            this.label_Description.Location = new System.Drawing.Point(150, 172);
            this.label_Description.Name = "label_Description";
            this.label_Description.Size = new System.Drawing.Size(60, 13);
            this.label_Description.TabIndex = 6;
            this.label_Description.Text = "Description";
            // 
            // richTextBox_Description
            // 
            this.richTextBox_Description.BackColor = System.Drawing.SystemColors.Window;
            this.richTextBox_Description.Location = new System.Drawing.Point(216, 172);
            this.richTextBox_Description.Name = "richTextBox_Description";
            this.richTextBox_Description.ReadOnly = true;
            this.richTextBox_Description.Size = new System.Drawing.Size(179, 68);
            this.richTextBox_Description.TabIndex = 7;
            this.richTextBox_Description.Text = "";
            // 
            // ModifButton
            // 
            this.ModifButton.Location = new System.Drawing.Point(12, 218);
            this.ModifButton.Name = "ModifButton";
            this.ModifButton.Size = new System.Drawing.Size(82, 23);
            this.ModifButton.TabIndex = 8;
            this.ModifButton.Text = "Modifier stock";
            this.ModifButton.UseVisualStyleBackColor = true;
            this.ModifButton.Click += new System.EventHandler(this.modifButton_Click);
            // 
            // numericUpDown_Quantite
            // 
            this.numericUpDown_Quantite.Location = new System.Drawing.Point(216, 55);
            this.numericUpDown_Quantite.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.numericUpDown_Quantite.Name = "numericUpDown_Quantite";
            this.numericUpDown_Quantite.Size = new System.Drawing.Size(120, 20);
            this.numericUpDown_Quantite.TabIndex = 9;
            this.numericUpDown_Quantite.ValueChanged += new System.EventHandler(this.numericUpDown_Quantite_ValueChanged);
            // 
            // textBox_NomProduit
            // 
            this.textBox_NomProduit.BackColor = System.Drawing.SystemColors.Window;
            this.textBox_NomProduit.Location = new System.Drawing.Point(216, 23);
            this.textBox_NomProduit.Name = "textBox_NomProduit";
            this.textBox_NomProduit.ReadOnly = true;
            this.textBox_NomProduit.Size = new System.Drawing.Size(120, 20);
            this.textBox_NomProduit.TabIndex = 11;
            // 
            // label_Nom_Produit
            // 
            this.label_Nom_Produit.AutoSize = true;
            this.label_Nom_Produit.Location = new System.Drawing.Point(150, 26);
            this.label_Nom_Produit.Name = "label_Nom_Produit";
            this.label_Nom_Produit.Size = new System.Drawing.Size(29, 13);
            this.label_Nom_Produit.TabIndex = 12;
            this.label_Nom_Produit.Text = "Nom";
            // 
            // label_Fournisseur
            // 
            this.label_Fournisseur.AutoSize = true;
            this.label_Fournisseur.Location = new System.Drawing.Point(150, 138);
            this.label_Fournisseur.Name = "label_Fournisseur";
            this.label_Fournisseur.Size = new System.Drawing.Size(61, 13);
            this.label_Fournisseur.TabIndex = 13;
            this.label_Fournisseur.Text = "Fournisseur";
            // 
            // CloselButton
            // 
            this.CloselButton.DialogResult = System.Windows.Forms.DialogResult.Abort;
            this.CloselButton.Location = new System.Drawing.Point(122, 218);
            this.CloselButton.Name = "CloselButton";
            this.CloselButton.Size = new System.Drawing.Size(75, 23);
            this.CloselButton.TabIndex = 15;
            this.CloselButton.Text = "Fermer";
            this.CloselButton.UseVisualStyleBackColor = true;
            // 
            // resteLabel
            // 
            this.resteLabel.AutoSize = true;
            this.resteLabel.Location = new System.Drawing.Point(221, 77);
            this.resteLabel.Name = "resteLabel";
            this.resteLabel.Size = new System.Drawing.Size(10, 13);
            this.resteLabel.TabIndex = 16;
            this.resteLabel.Text = ".";
            // 
            // suppStockButton
            // 
            this.suppStockButton.Location = new System.Drawing.Point(12, 6);
            this.suppStockButton.Name = "suppStockButton";
            this.suppStockButton.Size = new System.Drawing.Size(120, 22);
            this.suppStockButton.TabIndex = 17;
            this.suppStockButton.Text = "supprimer stock";
            this.suppStockButton.UseVisualStyleBackColor = true;
            this.suppStockButton.Click += new System.EventHandler(this.suppStockButton_Click);
            // 
            // textBox_Fournisseur
            // 
            this.textBox_Fournisseur.BackColor = System.Drawing.SystemColors.Window;
            this.textBox_Fournisseur.Location = new System.Drawing.Point(216, 135);
            this.textBox_Fournisseur.Name = "textBox_Fournisseur";
            this.textBox_Fournisseur.ReadOnly = true;
            this.textBox_Fournisseur.Size = new System.Drawing.Size(118, 20);
            this.textBox_Fournisseur.TabIndex = 30;
            // 
            // prixTextBox
            // 
            this.prixTextBox.BackColor = System.Drawing.SystemColors.Window;
            this.prixTextBox.Location = new System.Drawing.Point(216, 101);
            this.prixTextBox.Name = "prixTextBox";
            this.prixTextBox.ReadOnly = true;
            this.prixTextBox.Size = new System.Drawing.Size(118, 20);
            this.prixTextBox.TabIndex = 31;
            // 
            // ModifierStock
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(404, 264);
            this.Controls.Add(this.prixTextBox);
            this.Controls.Add(this.textBox_Fournisseur);
            this.Controls.Add(this.suppStockButton);
            this.Controls.Add(this.resteLabel);
            this.Controls.Add(this.CloselButton);
            this.Controls.Add(this.label_Fournisseur);
            this.Controls.Add(this.label_Nom_Produit);
            this.Controls.Add(this.textBox_NomProduit);
            this.Controls.Add(this.numericUpDown_Quantite);
            this.Controls.Add(this.ModifButton);
            this.Controls.Add(this.richTextBox_Description);
            this.Controls.Add(this.label_Description);
            this.Controls.Add(this.label_Prix);
            this.Controls.Add(this.label_Quantite);
            this.Controls.Add(this.listBox_Stock);
            this.Name = "ModifierStock";
            this.Text = "Ajout Produits/Stock";
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_Quantite)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox listBox_Stock;
        private System.Windows.Forms.Label label_Quantite;
        private System.Windows.Forms.Label label_Prix;
        private System.Windows.Forms.Label label_Description;
        private System.Windows.Forms.RichTextBox richTextBox_Description;
        private System.Windows.Forms.Button ModifButton;
        private System.Windows.Forms.NumericUpDown numericUpDown_Quantite;
        private System.Windows.Forms.TextBox textBox_NomProduit;
        private System.Windows.Forms.Label label_Nom_Produit;
        private System.Windows.Forms.Label label_Fournisseur;
        private System.Windows.Forms.Button CloselButton;
        private System.Windows.Forms.Label resteLabel;
        private System.Windows.Forms.Button suppStockButton;
        private System.Windows.Forms.TextBox textBox_Fournisseur;
        private System.Windows.Forms.TextBox prixTextBox;
    }
}