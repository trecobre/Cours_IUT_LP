﻿namespace Gestion_camping
{
    partial class GestionProduit
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.suppProduitButton = new System.Windows.Forms.Button();
            this.CloselButton = new System.Windows.Forms.Button();
            this.label_Fournisseur = new System.Windows.Forms.Label();
            this.label_Nom_Produit = new System.Windows.Forms.Label();
            this.textBox_NomProduit = new System.Windows.Forms.TextBox();
            this.numericUpDown_Prix = new System.Windows.Forms.NumericUpDown();
            this.ajoutModifProduitButton = new System.Windows.Forms.Button();
            this.richTextBox_Description = new System.Windows.Forms.RichTextBox();
            this.label_Description = new System.Windows.Forms.Label();
            this.label_Prix = new System.Windows.Forms.Label();
            this.listBox_Produit = new System.Windows.Forms.ListBox();
            this.fournisseurComboBox = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_Prix)).BeginInit();
            this.SuspendLayout();
            // 
            // suppProduitButton
            // 
            this.suppProduitButton.Location = new System.Drawing.Point(12, 12);
            this.suppProduitButton.Name = "suppProduitButton";
            this.suppProduitButton.Size = new System.Drawing.Size(120, 22);
            this.suppProduitButton.TabIndex = 32;
            this.suppProduitButton.Text = "supprimer produit";
            this.suppProduitButton.UseVisualStyleBackColor = true;
            this.suppProduitButton.Click += new System.EventHandler(this.suppStockButton_Click);
            // 
            // CloselButton
            // 
            this.CloselButton.DialogResult = System.Windows.Forms.DialogResult.Abort;
            this.CloselButton.Location = new System.Drawing.Point(122, 189);
            this.CloselButton.Name = "CloselButton";
            this.CloselButton.Size = new System.Drawing.Size(75, 23);
            this.CloselButton.TabIndex = 30;
            this.CloselButton.Text = "Fermer";
            this.CloselButton.UseVisualStyleBackColor = true;
            // 
            // label_Fournisseur
            // 
            this.label_Fournisseur.AutoSize = true;
            this.label_Fournisseur.Location = new System.Drawing.Point(150, 93);
            this.label_Fournisseur.Name = "label_Fournisseur";
            this.label_Fournisseur.Size = new System.Drawing.Size(61, 13);
            this.label_Fournisseur.TabIndex = 28;
            this.label_Fournisseur.Text = "Fournisseur";
            // 
            // label_Nom_Produit
            // 
            this.label_Nom_Produit.AutoSize = true;
            this.label_Nom_Produit.Location = new System.Drawing.Point(150, 26);
            this.label_Nom_Produit.Name = "label_Nom_Produit";
            this.label_Nom_Produit.Size = new System.Drawing.Size(65, 13);
            this.label_Nom_Produit.TabIndex = 27;
            this.label_Nom_Produit.Text = "Nom Produit";
            // 
            // textBox_NomProduit
            // 
            this.textBox_NomProduit.Location = new System.Drawing.Point(216, 23);
            this.textBox_NomProduit.Name = "textBox_NomProduit";
            this.textBox_NomProduit.Size = new System.Drawing.Size(120, 20);
            this.textBox_NomProduit.TabIndex = 26;
            // 
            // numericUpDown_Prix
            // 
            this.numericUpDown_Prix.DecimalPlaces = 2;
            this.numericUpDown_Prix.Location = new System.Drawing.Point(216, 57);
            this.numericUpDown_Prix.Name = "numericUpDown_Prix";
            this.numericUpDown_Prix.Size = new System.Drawing.Size(120, 20);
            this.numericUpDown_Prix.TabIndex = 25;
            // 
            // ajoutModifProduitButton
            // 
            this.ajoutModifProduitButton.Location = new System.Drawing.Point(12, 189);
            this.ajoutModifProduitButton.Name = "ajoutModifProduitButton";
            this.ajoutModifProduitButton.Size = new System.Drawing.Size(82, 23);
            this.ajoutModifProduitButton.TabIndex = 23;
            this.ajoutModifProduitButton.Text = "Ajout produit";
            this.ajoutModifProduitButton.UseVisualStyleBackColor = true;
            this.ajoutModifProduitButton.Click += new System.EventHandler(this.ajoutModifProduitButton_Click);
            // 
            // richTextBox_Description
            // 
            this.richTextBox_Description.Location = new System.Drawing.Point(216, 123);
            this.richTextBox_Description.Name = "richTextBox_Description";
            this.richTextBox_Description.Size = new System.Drawing.Size(179, 89);
            this.richTextBox_Description.TabIndex = 22;
            this.richTextBox_Description.Text = "";
            // 
            // label_Description
            // 
            this.label_Description.AutoSize = true;
            this.label_Description.Location = new System.Drawing.Point(150, 123);
            this.label_Description.Name = "label_Description";
            this.label_Description.Size = new System.Drawing.Size(60, 13);
            this.label_Description.TabIndex = 21;
            this.label_Description.Text = "Description";
            // 
            // label_Prix
            // 
            this.label_Prix.AutoSize = true;
            this.label_Prix.Location = new System.Drawing.Point(150, 59);
            this.label_Prix.Name = "label_Prix";
            this.label_Prix.Size = new System.Drawing.Size(24, 13);
            this.label_Prix.TabIndex = 20;
            this.label_Prix.Text = "Prix";
            // 
            // listBox_Produit
            // 
            this.listBox_Produit.FormattingEnabled = true;
            this.listBox_Produit.Location = new System.Drawing.Point(12, 40);
            this.listBox_Produit.Name = "listBox_Produit";
            this.listBox_Produit.Size = new System.Drawing.Size(120, 134);
            this.listBox_Produit.TabIndex = 18;
            this.listBox_Produit.SelectedIndexChanged += new System.EventHandler(this.listBox_Produit_SelectedIndexChanged);
            // 
            // fournisseurComboBox
            // 
            this.fournisseurComboBox.FormattingEnabled = true;
            this.fournisseurComboBox.Location = new System.Drawing.Point(216, 90);
            this.fournisseurComboBox.Name = "fournisseurComboBox";
            this.fournisseurComboBox.Size = new System.Drawing.Size(145, 21);
            this.fournisseurComboBox.TabIndex = 33;
            // 
            // GestionProduit
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(412, 233);
            this.Controls.Add(this.fournisseurComboBox);
            this.Controls.Add(this.suppProduitButton);
            this.Controls.Add(this.CloselButton);
            this.Controls.Add(this.label_Fournisseur);
            this.Controls.Add(this.label_Nom_Produit);
            this.Controls.Add(this.textBox_NomProduit);
            this.Controls.Add(this.numericUpDown_Prix);
            this.Controls.Add(this.ajoutModifProduitButton);
            this.Controls.Add(this.richTextBox_Description);
            this.Controls.Add(this.label_Description);
            this.Controls.Add(this.label_Prix);
            this.Controls.Add(this.listBox_Produit);
            this.Name = "GestionProduit";
            this.Text = "AjoutProduit";
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_Prix)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button suppProduitButton;
        private System.Windows.Forms.Button CloselButton;
        private System.Windows.Forms.Label label_Fournisseur;
        private System.Windows.Forms.Label label_Nom_Produit;
        private System.Windows.Forms.TextBox textBox_NomProduit;
        private System.Windows.Forms.NumericUpDown numericUpDown_Prix;
        private System.Windows.Forms.Button ajoutModifProduitButton;
        private System.Windows.Forms.RichTextBox richTextBox_Description;
        private System.Windows.Forms.Label label_Description;
        private System.Windows.Forms.Label label_Prix;
        private System.Windows.Forms.ListBox listBox_Produit;
        private System.Windows.Forms.ComboBox fournisseurComboBox;
    }
}