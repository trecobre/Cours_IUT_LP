﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Security.Cryptography;


namespace Gestion_camping
{
    public partial class ConnexionPage : Form
    {
        private MD5 saltForHash;
        public bool admin = false;
        Bitmap mdpVisible = Gestion_camping.Properties.Resources.open_eye_icon;
        Bitmap mdpNonVisible = Gestion_camping.Properties.Resources.close_eye_logo;
        bool étatMdp = false;
        bool vide = true;
        Utilisateur user;
        public ConnexionPage()
        {
            StartPosition = FormStartPosition.CenterScreen;
            InitializeComponent();
            saltForHash = MD5.Create();
        }

        #region TextsBoxs
        /// <summary>
        /// Méthode permettant de gérer la textBox du login du menu connexion lorsque l'utilisateur tape des informations
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void loginTextBox_Enter(object sender, EventArgs e)
        {
            if (loginTextBox.Text == "Login")
            {
                loginTextBox.ForeColor = Color.Black;
                loginTextBox.Text = "";
            }
        }

        /// <summary>
        /// Méthode permettant de gérer la textBox du login du menu connexion
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void loginTextBox_Leave(object sender, EventArgs e)
        {
            if (loginTextBox.Text.Length == 0)
            {
                loginTextBox.ForeColor = Color.Gray;
                loginTextBox.Text = "Login";
            }
        }

        /// <summary>
        /// Méthode permettant de gérer la textBox du mot de passe du menu connexion lorsque l'utilisateur tape des informations
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void passTextBox_Enter(object sender, EventArgs e)
        {
            if (passTextBox.Text == "Mot de passe" && vide)
            {
                passTextBox.ForeColor = Color.Black;
                passTextBox.Text = "";
                passTextBox.UseSystemPasswordChar = !étatMdp;
                vide = false;
            }
        }
        /// <summary>
        /// Méthode permettant de gérer la textBox du login du menu connexion
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void passTextBox_Leave(object sender, EventArgs e)
        {
            if (passTextBox.Text.Length == 0)
            {
                passTextBox.ForeColor = Color.Gray;
                passTextBox.Text = "Mot de passe";
                passTextBox.UseSystemPasswordChar = false;
                vide = true;
            }
        }
        #endregion

        #region Buttons
        
        /// <summary>
        /// Connect to the database
        /// </summary>
        /// <param name="sender">The object that raised the event.</param>
        /// <param name="EventArgs">The event arguments.</param>
        private void connexionButton_Click(object sender, EventArgs e)
        {
            connect();
        }

        #endregion

        /// <summary>
        /// When the user clicks the "Voir le mot de passe" button, the password text box is toggled
        /// between showing the password and hiding it
        /// </summary>
        /// <param name="sender">The object that raised the event.</param>
        /// <param name="EventArgs">The event arguments.</param>
        private void voirMdp_CheckedChanged(object sender, EventArgs e)
        {
            étatMdp = !étatMdp;
            if (étatMdp)
            {
                voirMdp.BackgroundImage = mdpVisible;
                if (!vide) passTextBox.UseSystemPasswordChar = false;

            }
            else
            {
                voirMdp.BackgroundImage = mdpNonVisible;
                if (!vide) passTextBox.UseSystemPasswordChar = true;
            }
        }

        /// <summary>
        /// It connects the user to the database.
        /// </summary>
        private void connect()
        {
            string login = loginTextBox.Text;
            string mdp = passTextBox.Text;
            var salting = saltForHash.ComputeHash(new UTF8Encoding().GetBytes(mdp));
            string hash = BitConverter.ToString(salting).Replace("-", string.Empty);
            bool connect = false;
            try
            {
                Utilisateur user = Utils.Connexion(login);
                if (user.login.Equals(login) && user.password.Equals(hash))
                {
                    connect = true;
                    this.user = user;
                    admin = user.admin;
                    //break;
                }
            } catch (Exception ex) { }

            if (connect)
            {
                this.DialogResult = DialogResult.OK;
            }
            else
            {
                MessageBox.Show("Combinaison login/mdp invalide !");
            }
        }

        /// <summary>
        /// When the mouse hovers over the connexion button, the button's background color changes to
        /// forest green
        /// </summary>
        /// <param name="sender">The object that raised the event.</param>
        /// <param name="EventArgs">The event arguments.</param>
        private void connexionButton_MouseHover(object sender, EventArgs e)
        {
            connexionButton.BackColor = Color.ForestGreen;
        }

        private void ConnexionPage_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(e.KeyChar == (char)Keys.Enter)
            {
                connect();
            }
        }

        /// <summary>
        /// The buttonQuit_Enter event handler changes the color of the buttonQuit control to red and
        /// changes the image of the buttonQuit control to a cross
        /// </summary>
        /// <param name="sender">The object that raised the event.</param>
        /// <param name="EventArgs">The event arguments.</param>
        private void buttonQuit_Enter(object sender, EventArgs e)
        {
            Color color = ColorTranslator.FromHtml("#F44336");
            buttonQuit.BackColor = color;
            buttonQuit.BackgroundImage = global::Gestion_camping.Properties.Resources.icons8_effacer_96_1_;
        }

        /// <summary>
        /// This function is called when the mouse leaves the buttonQuit. 
        /// 
        /// The function changes the buttonQuit's background image to the original image
        /// </summary>
        /// <param name="sender">The object that raised the event.</param>
        /// <param name="EventArgs">The event arguments.</param>
        private void buttonQuit_Leave(object sender, EventArgs e)
        {
            buttonQuit.BackColor = Color.Transparent;
            buttonQuit.BackgroundImage = global::Gestion_camping.Properties.Resources.icons8_effacer_96;
        }

        /// <summary>
        /// This function is called when the user clicks the Quit button.
        /// </summary>
        /// <param name="sender">The object that raised the event.</param>
        /// <param name="EventArgs">The event arguments.</param>
        private void buttonQuit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        /// <summary>
        /// Returns the user object
        /// </summary>
        /// <returns>
        /// The user object.
        /// </returns>
        public Utilisateur getUser()
        {
            return user;
        }
    }
}
