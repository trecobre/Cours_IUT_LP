﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gestion_camping
{
    public class Utils
    {
        #region utilisateur

        static public void Inscription(Utilisateur utilisateur)
        {
            Program.bdEntities.Utilisateur.Add(utilisateur);
            Program.bdEntities.SaveChanges();
        }

        static public Utilisateur Connexion(string login)
        {
            Utilisateur user = Program.bdEntities.Utilisateur.First(u => u.login == login);
            return user;
        }

        static public void SuppresionUtilisateur(int id)
        {
            Utilisateur user = Program.bdEntities.Utilisateur.First(u => u.UtilisateurID == id);
            Program.bdEntities.Utilisateur.Remove(user);
            Program.bdEntities.SaveChanges();
        }

        #endregion

        #region client

        static public void modifierAjouterClient(Client client)
        {
            Program.bdEntities.Client.Add(client);
            Program.bdEntities.SaveChanges();
        }

        static public Client getClient(int id)
        {
            Client client = new Client();
            client = Program.bdEntities.Client.First(c => c.ClientID == id);
            return client;
        }

        #endregion

        #region listable
        static public void editListableObject(Client client, Client toChange)
        {
            Client cl = Program.bdEntities.Client.First(c => c.ClientID == client.ClientID);
            cl.changetochanged(toChange);
            //tochange.nomClient=edit.nom
            Program.bdEntities.SaveChanges();
        }
        #endregion

        #region Reservation

        static public void ajouterReservation(Reservation reservation)
        {
            Program.bdEntities.Reservation.Add(reservation);
            Program.bdEntities.SaveChanges();
        }

        static public void supprimerReservation(Reservation res)
        {
            Program.bdEntities.Reservation.Remove(res);
            Program.bdEntities.SaveChanges();
        }

        static public void finReservation(int id)
        {
            Program.bdEntities.Reservation.First(r => r.ReservationID == id).dateFin = DateTime.Now;
            Program.bdEntities.Reservation.First(r => r.ReservationID == id).etat = 2;
            Program.bdEntities.SaveChanges();
        }

        static public Reservation reservationGet(int id)
        {
            Reservation res = Program.bdEntities.Reservation.First(r => r.ReservationID == id);
            return res;
        }

        static public void modifierReservation(int id, Reservation reservation)
        {
            Program.bdEntities.Reservation.First(r => r.ReservationID == id).setFromReservation(reservation);
            Program.bdEntities.SaveChanges();
        }

        #endregion
    }
}
