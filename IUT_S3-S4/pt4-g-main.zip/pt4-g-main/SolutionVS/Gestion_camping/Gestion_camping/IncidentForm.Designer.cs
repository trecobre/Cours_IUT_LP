﻿namespace Gestion_camping
{
    partial class IncidentForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonInc = new System.Windows.Forms.Button();
            this.buttonRap = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // buttonInc
            // 
            this.buttonInc.DialogResult = System.Windows.Forms.DialogResult.Yes;
            this.buttonInc.Location = new System.Drawing.Point(12, 14);
            this.buttonInc.Name = "buttonInc";
            this.buttonInc.Size = new System.Drawing.Size(140, 23);
            this.buttonInc.TabIndex = 0;
            this.buttonInc.Text = "Modifier l\'incident";
            this.buttonInc.UseVisualStyleBackColor = true;
            // 
            // buttonRap
            // 
            this.buttonRap.DialogResult = System.Windows.Forms.DialogResult.No;
            this.buttonRap.Location = new System.Drawing.Point(168, 14);
            this.buttonRap.Name = "buttonRap";
            this.buttonRap.Size = new System.Drawing.Size(137, 23);
            this.buttonRap.TabIndex = 1;
            this.buttonRap.Text = "Consulter le rapport";
            this.buttonRap.UseVisualStyleBackColor = true;
            // 
            // IncidentForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClientSize = new System.Drawing.Size(320, 49);
            this.Controls.Add(this.buttonRap);
            this.Controls.Add(this.buttonInc);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "IncidentForm";
            this.Text = "IncidentForm";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button buttonInc;
        private System.Windows.Forms.Button buttonRap;
    }
}