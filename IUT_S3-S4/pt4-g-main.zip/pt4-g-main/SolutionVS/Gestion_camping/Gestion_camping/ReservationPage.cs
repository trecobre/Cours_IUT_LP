﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using System.Diagnostics;
using static Gestion_camping.PDFGenerator;
using Microsoft.Extensions.Logging;
using System.Drawing;

namespace Gestion_camping
{
    public partial class ReservationPage : Form, IPanel
    {
        static ReservationPage main;
        static ILogger _logger;
        List<Reservation> reservations;
        List<Panel> panelsRes;
        public ReservationPage(ILogger logger)
        {
            _logger = logger;
            main = this;
            reservations = Program.bdEntities.Reservation.OrderBy(r => r.etat).ToList();
            panelsRes = new List<Panel>();
            InitializeComponent();
            this.displayRes();
            changeSize(ReservationPanel);
            flowLayoutPanelRes.Controls.AddRange(panelsRes.ToArray());
        }

        /// <summary>
        /// Display all the reservations in the database
        /// </summary>
        private void displayRes()
        {
            _logger.LogInformation("Chargement reservations");
            List<Reservation> reservations = Program.bdEntities.Reservation.OrderBy(r => r.etat).ToList();
            this.panelRes.Location = new System.Drawing.Point(0, 0);
            List<Panel> panels = new List<Panel>();
            foreach (Reservation reservation in reservations)
            {
                ReservationPage reservationPage = new ReservationPage(1);
                panels.Add(getPanelRes(reservation, reservationPage));
            }
            Console.WriteLine(panelRes.Location);
            Console.WriteLine(panelRes.Size);
            flowLayoutPanelRes.Controls.AddRange(panels.ToArray());
            _logger.LogInformation("Reservations chargées");
        }

        /* This is the constructor of the class. It is called when the object is created. */
        public ReservationPage(int a)
        {
            InitializeComponent();
        }

        /// <summary>
        /// Returns the panel that contains the reservation information
        /// </summary>
        /// <returns>
        /// The ReservationPanel object.
        /// </returns>
        public Panel GetPanel()
        {
            return this.ReservationPanel;
        }

        /// <summary>
        /// This function returns a panel that contains the information of a reservation
        /// </summary>
        /// <param name="Reservation">The reservation object that is being displayed.</param>
        /// <param name="ReservationPage">The ReservationPage object that is being displayed.</param>
        /// <returns>
        /// A panel.
        /// </returns>
        public Panel getPanelRes(Reservation reservation, ReservationPage rp)
        {
            rp.Tag = reservation.ReservationID;
            DateTime dDebut = reservation.dateDebut;
            rp.labelDebut.Text = dDebut.Day + "/" + dDebut.Month + "/" + dDebut.Year;
            DateTime dFin = reservation.dateFin;
            rp.labelFin.Text = dFin.Day + "/" + dFin.Month + "/" + dFin.Year;
            rp.labelEmplacement.Text = reservation.Emplacement.intitule;
            rp.labelStatut.Text = reservation.getEtat();
            rp.labelClient.Text = reservation.Client.nomClient + " " + reservation.Client.prenomClient;
            rp.labelNumClient.Text = reservation.Client.telephoneClient.ToString();
            return rp.panelRes;
        }

        /// <summary>
        /// This function creates a new Reservation object and adds it to the database
        /// </summary>
        /// <param name="sender">The object that raised the event.</param>
        /// <param name="EventArgs">The type of event that is being handled.</param>
        private void button1_Click(object sender, EventArgs e)
        {
            ReservationForm2 rf = new ReservationForm2();
            if(rf.ShowDialog() == DialogResult.OK)
            {
                Reservation reservation = rf.getData();
                if(reservation.dateDebut > DateTime.Now)
                {
                    reservation.etat = 1;
                }
                else if(reservation.dateFin < DateTime.Now)
                {
                    reservation.etat = 2;
                }
                else
                {
                    reservation.etat = 0;
                }
                Utils.ajouterReservation(reservation);
                flowLayoutPanelRes.Controls.Clear();
                FacturePDF facture = new FacturePDF(reservation.Client, reservation.dateDebut);
                _logger.LogInformation($"Ajout reservation. dateDebut: {reservation.dateDebut}, dateFin: {reservation.dateFin}, emplacement: {reservation.Emplacement}, clientID: {reservation.clientID}, etat: {reservation.etat}");
                main.displayRes();
            }
        }

        /// <summary>
        /// This function is called when the user clicks the "Supprimer" button
        /// </summary>
        /// <param name="sender">The object that raised the event.</param>
        /// <param name="EventArgs">The event arguments.</param>
        private void buttonSupprimer_Click(object sender, EventArgs e)
        {
            int id = (int)this.Tag;
            Reservation res = Program.bdEntities.Reservation.First(r => r.ReservationID == id);
            Utils.supprimerReservation(res);
            _logger.LogInformation($"Suppresion reservation. dateDebut: {res.dateDebut}, dateFin: {res.dateFin}, emplacement: {res.Emplacement}, clientID: {res.clientID}, etat: {res.etat}");
            main.flowLayoutPanelRes.Controls.Clear();
            main.displayRes();
        }

        /// <summary>
        /// This function is called when the user clicks the "Fin" button. 
        /// It takes the id of the reservation and sets the dateFin to the current date. 
        /// It then saves the changes to the database and refreshes the display
        /// </summary>
        /// <param name="sender">The object that raised the event.</param>
        /// <param name="EventArgs">The event arguments.</param>
        private void buttonFin_Click(object sender, EventArgs e)
        {
            int id = (int)this.Tag;
            Utils.finReservation(id);
            _logger.LogInformation($"Fin reservation idReservation: {id}");
            main.flowLayoutPanelRes.Controls.Clear();
            main.displayRes();
        }

        /// <summary>
        /// Modify a reservation
        /// </summary>
        /// <param name="sender">The object that raised the event.</param>
        /// <param name="EventArgs">The event arguments.</param>
        private void modifie(object sender, EventArgs e)
        {
            int id = (int)this.Tag;
            ReservationForm rForm = new ReservationForm();
            DialogResult dialogResult = rForm.ShowDialog();
            if(dialogResult == DialogResult.Yes)
            {
                
                Reservation res = Program.bdEntities.Reservation.First(r => r.ReservationID == id);
                ReservationForm2 rf = new ReservationForm2(res);
                Reservation oldRes = rf.getData();
                if (rf.ShowDialog() == DialogResult.OK)
                {
                    Reservation reservation = rf.getData();
                    reservation.emplacementID = reservation.Emplacement.EmplacementID;
                    reservation.clientID = reservation.Client.ClientID;
                    Utils.modifierReservation(id, reservation);
                    _logger.LogInformation($"Update reservation. dateDebut: {oldRes.dateDebut} -> {reservation.dateDebut}, dateFin: {oldRes.dateFin} -> {reservation.dateFin},  emplacement: {oldRes.emplacementID} -> {reservation.emplacementID}, clientId: {oldRes.clientID} -> {reservation.clientID}, etat: {oldRes.etat} -> {reservation.etat}");
                    main.flowLayoutPanelRes.Controls.Clear();
                    main.displayRes();
                    
                }
            }
            else if(dialogResult == DialogResult.No)
            {
                try
                {
                    Reservation res = Program.bdEntities.Reservation.First(r => r.ReservationID == id);
                    Facture facture = Program.bdEntities.Facture.First(r => r.clientID == res.clientID);
                    _logger.LogInformation("Génération PDF");
                    Process.Start(facture.pdf);
                    _logger.LogInformation("PDF géneré");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Facture non disponible pour cette réservation.");
                }
                
            }

        }

        

        private void ReservationPanel_SizeChanged(object sender, EventArgs e)
        {
            Panel panel = (Panel)sender;
            changeSize(panel);
        }

        private void changeSize(Panel panel)
        {
            flowLayoutPanelRes.Visible = false;
            flowLayoutPanelRes.Size = new System.Drawing.Size(panel.Width, panel.Height - button1.Height - labelAstuce.Height);
            foreach (Panel p in panelsRes)
            {
                if(flowLayoutPanelRes.Width > 2 * panelRes.Width + 50)
                {
                    p.Width = (flowLayoutPanelRes.Width /2)-50;
                }
                else
                {
                    p.Size = new System.Drawing.Size(flowLayoutPanelRes.Width - 25, p.Height);
                    labelDebut.Location = new System.Drawing.Point(p.Width/6, labelDebut.Bottom);
                    labelFin.Location = new System.Drawing.Point(p.Width/3, labelFin.Bottom);
                }
                p.BackColor = Color.FromArgb(150, Color.WhiteSmoke);
            }
            flowLayoutPanelRes.Visible = true;
        }

        private void flowLayoutPanelRes_Scroll(object sender, ScrollEventArgs e)
        {
            flowLayoutPanelRes.Visible=false;
            flowLayoutPanelRes.Refresh();
            foreach (Panel p in panelsRes)
            {
                p.Visible=false;
                p.Refresh();
                p.Visible = true;
            }
            flowLayoutPanelRes.Visible = true;
        }
    }
}
