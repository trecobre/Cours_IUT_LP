﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gestion_camping
{
    public partial class ReservationForm2 : Form
    {
        /* It initializes the form. */
        public ReservationForm2()
        {
            InitializeComponent();
            this.comboBoxClient.Items.AddRange(Program.bdEntities.Client.ToArray());
            this.comboBoxEmplacement.Items.AddRange(Program.bdEntities.Emplacement.ToArray());
        }

        /* A constructor that takes a Reservation object as a parameter. */
        public ReservationForm2(Reservation reservation)
        {
            InitializeComponent();
            this.comboBoxClient.Items.AddRange(Program.bdEntities.Client.ToArray());
            this.comboBoxEmplacement.Items.AddRange(Program.bdEntities.Emplacement.ToArray());
            this.comboBoxClient.SelectedItem = reservation.Client;
            this.comboBoxEmplacement.SelectedItem = reservation.Emplacement;
            this.dateTimeDebut.Value = reservation.dateDebut;
            this.numericUpDownDuree.Value = reservation.dateFin.Subtract(reservation.dateDebut).Days;
        }

        /// <summary>
        /// It returns a Reservation object with the data from the form.
        /// </summary>
        /// <returns>
        /// A Reservation object.
        /// </returns>
        public Reservation getData()
        {
            Reservation reservation = new Reservation();
            reservation.Client = (Client)this.comboBoxClient.SelectedItem;
            reservation.dateDebut = this.dateTimeDebut.Value;
            reservation.dateFin = this.dateTimeDebut.Value.AddDays((double)this.numericUpDownDuree.Value);
            reservation.Emplacement = (Emplacement) this.comboBoxEmplacement.SelectedItem;
            return reservation;
        }

        private void buttonValider_Click(object sender, EventArgs e)
        {
            Reservation reservation = this.getData();
            if (reservation.Client != null && reservation.Emplacement != null)
            {
                DialogResult = DialogResult.OK;
            }
            else
            {
                MessageBox.Show("Veuillez rentrer toutes les informations nécessaires.");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            modifClientPage edit = new modifClientPage();
            if (edit.ShowDialog() == DialogResult.OK)
            {
                Client client = new Client();
                client = edit.getData();
                Utils.modifierAjouterClient(client);
                this.comboBoxClient.Items.Clear();
                this.comboBoxClient.Items.AddRange(Program.bdEntities.Client.ToArray());
                this.comboBoxClient.SelectedItem = client;
            }
        }
    }
}
