﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace Gestion_camping
{
    public partial class modifClientPage : Form
    {
        public modifClientPage()
        {
            InitializeComponent();
        }

        /* A constructor. It is used to initialize the form. */
        public modifClientPage(Client client)
        {
            InitializeComponent();
            nomClientTextBox.Text = client.nomClient;
            prenomClientTextBox.Text = client.prenomClient;
            emailClientTextBox.Text = client.mailClient;
            telephoneTextBox.Text = client.telephoneClient;
        }

        /// <summary>
        /// The function accepts a string and returns a boolean. 
        /// 
        /// The function checks if the string is a valid email address. 
        /// 
        /// The function returns true if the string is a valid email address, otherwise it returns
        /// false. 
        /// 
        /// The function uses the System.Text.RegularExpressions.Regex class to check if the string is a
        /// valid email address.
        /// 
        /// The function uses the System.Text.RegularExpressions.Regex.IsMatch method to check if the
        /// string
        /// </summary>
        /// <param name="sender">The object that raised the event.</param>
        /// <param name="EventArgs">The event arguments.</param>
        private void AcceptButton_Click(object sender, EventArgs e)
        {
            bool valide = true;

            if (!(nomClientTextBox.Text.Length > 0 && nomClientTextBox.Text.Length < 30))
            {
                nomLabel.ForeColor = Color.Red;
                valide = false;
            }
            else
            {
                nomLabel.ForeColor = Color.Black;
            }

            if (!(prenomClientTextBox.Text.Length > 0 && prenomClientTextBox.Text.Length < 25))
            {
                prenomLabel.ForeColor = Color.Red;
                valide = false;
            }
            else
            {
                prenomLabel.ForeColor = Color.Black;
            }

            if (!IsValidEmail(emailClientTextBox.Text))
            {
                emailLabel.ForeColor = Color.Red;
                valide = false;
            }
            else
            {
                emailLabel.ForeColor = Color.Black;
            }

            string patern = @"\(?\d{3}\)?-? *\d{3}-? *-?\d{4}";
            Regex rxPhone = new Regex(patern, RegexOptions.Compiled | RegexOptions.IgnoreCase);
            if (!(telephoneTextBox.Text.Length > 0 && rxPhone.IsMatch(telephoneTextBox.Text)))
            {
                telephoneLabel.ForeColor = Color.Red;
                valide = false;
            }
            else
            {
                telephoneLabel.ForeColor = Color.Black;
            }

            if (valide)
            {
                this.DialogResult = DialogResult.OK;
            }
        }

        /// <summary>
        /// It checks if the email is valid or not.
        /// </summary>
        /// <param name="email">The email address to validate.</param>
        /// <returns>
        /// A boolean value.
        /// </returns>
        public static bool IsValidEmail(string email)
        {
            try
            {
                var addr = new System.Net.Mail.MailAddress(email);
                return addr.Address == email;
            }
            catch
            {
                return false;
            }
        }

        /// <summary>
        /// It gets the data from the form and returns it as a Client object.
        /// </summary>
        /// <returns>
        /// The client object.
        /// </returns>
        public Client getData()
        {
            Client client = new Client();
            client.nomClient = nomClientTextBox.Text;
            client.prenomClient = prenomClientTextBox.Text;
            client.mailClient = emailClientTextBox.Text;
            client.telephoneClient = telephoneTextBox.Text;
            return client;
        }
    }
}
