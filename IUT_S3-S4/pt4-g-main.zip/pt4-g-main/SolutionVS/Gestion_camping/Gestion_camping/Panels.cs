﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gestion_camping
{
    public partial class Panels : Form, IPanel
    {
        public bool admin;
        Panel actualPannel;
        Utilisateur mainUser;
        public ILogger _logger;
        Graphics gAccueil;
        Graphics gReservation;
        Graphics gClient;
        Graphics gFournisseur;
        Graphics gStock;
        Graphics gIncident;
        Graphics gLogs;
        Size size;
        Graphics currentGraphic;
        Label currentLab;
        PictureBox currentPB;
        string currentTag;

        public GraphicsPath RoundedRect(Rectangle bounds, int radius)
        {
            int diameter = radius * 2;
            Size size = new Size(diameter, diameter);
            Rectangle arc = new Rectangle(bounds.Location, size);
            GraphicsPath path = new GraphicsPath();

            if (radius == 0)
            {
                path.AddRectangle(bounds);
                return path;
            }

            // top left arc  
            path.AddArc(arc, 180, 90);

            // top right arc  
            arc.X = bounds.Right - diameter;
            path.AddArc(arc, 270, 90);

            // bottom right arc  
            arc.Y = bounds.Bottom - diameter;
            path.AddArc(arc, 0, 90);

            // bottom left arc 
            arc.X = bounds.Left;
            path.AddArc(arc, 90, 90);

            path.CloseFigure();
            return path;
        }
        public void FillRoundedRectangle(Graphics graphics, Brush brush, Rectangle bounds, int cornerRadius)
        {
            if (graphics == null)
                throw new ArgumentNullException("graphics");
            if (brush == null)
                throw new ArgumentNullException("brush");

            using (GraphicsPath path = RoundedRect(bounds, cornerRadius))
            {
                graphics.FillPath(brush, path);
            }
        }


        public Panels(bool admin, Utilisateur user, ILogger logger)
        {
            InitializeComponent();
            ListableObject lo = new ListableObject(logger);
            mainUser = user;
            this.profileNameLabel.Text = user.nomUtilisateur + " " + user.prenomUtilisateur;
            _logger = logger;
            _logger.LogInformation(user.login+ " est connecté(e).");
            this.admin = admin;
            gAccueil = accueilPanel.CreateGraphics();
            gReservation = panelReservation.CreateGraphics();
            gClient = clientPanel.CreateGraphics();
            gFournisseur = fournisseurPanel.CreateGraphics();
            gStock= stockPanel.CreateGraphics();
            gLogs = logPanel.CreateGraphics();
            gIncident = incidentPanel.CreateGraphics();
            currentGraphic = gAccueil;
            currentLab = accueilLabel;
            currentPB = accueilPictureBox;
            currentTag = accueilPanel.Tag.ToString();
            Color color = Color.WhiteSmoke;
            colorChange(accueilPanel, color);
            colorChange(panelReservation, color);
            colorChange(clientPanel, color);
            colorChange(fournisseurPanel, color);
            colorChange(stockPanel, color);
            colorChange(incidentPanel, color);
            colorChange(logPanel, color);
            if (!admin)
            {
                logPanel.Visible = false;
            }
            changeTab("Accueil", new userPage(admin, mainUser,_logger));
        }

        public void SetContentPanel(Panel contentP)
        {
            this.contentPanel.Controls.Clear();
            contentP.Location = new Point(0, 0);
            this.contentPanel.Controls.Add(contentP);
        }

        public Panel GetPanel()
        {
            return this.panelLayout;
        }

        private void clearCurrent()
        {
            colorChange(currentLab.Parent, Color.WhiteSmoke);
            currentLab = null;
            currentGraphic = null;
            currentPB = null;

        }

        private void accueilPanel_Click(object sender, EventArgs e)
        {
            currentTag = accueilPanel.Tag.ToString();
            clearCurrent();
            Color color = Color.LightSeaGreen;
            currentGraphic = gAccueil;
            currentLab = accueilLabel;
            currentPB = accueilPictureBox;
            colorChange((Control)sender, color);
            changeTab("Accueil", new userPage(admin, mainUser, _logger));
        }

        private void clientPanel_Click(object sender, EventArgs e)
        {
            currentTag = clientPanel.Tag.ToString();
            clearCurrent();
            Color color = Color.LightSeaGreen;
            currentLab = clientLabel;
            currentPB = clientPictureBox;
            currentGraphic = gClient;
            colorChange((Control)sender, color);
            _logger.LogInformation("Chargement de la page Client");
            changeTab("Client", new ClientPage(_logger));
        }

        private void fournisseurPanel_Click(object sender, EventArgs e)
        {
            currentTag = fournisseurPanel.Tag.ToString();
            clearCurrent();
            _logger.LogInformation("Chargement de la page Fournisseur");
            Color color = Color.LightSeaGreen;
            currentGraphic = gFournisseur;
            currentLab = fournisseurLabel;
            currentPB = fournisseurPictureBox;
            colorChange((Control)sender, color);
            changeTab("Fournisseur", new FournisseurPage(_logger));
        }

        private void stockPanel_Click(object sender, EventArgs e)
        {
            currentTag = stockPanel.Tag.ToString();

            clearCurrent();
            Color color = Color.LightSeaGreen;
            currentGraphic = gStock;
            currentLab = stockLabel;
            currentPB = stockPictureBox;
            colorChange((Control)sender, color);
            _logger.LogInformation("Chargement de la page Stock");
            changeTab("Gestion des Stocks", new ProduitPage(_logger));
        }

        private void incidentPanel_Click(object sender, EventArgs e)
        {
            currentTag = incidentPanel.Tag.ToString();

            clearCurrent();
            Color color = Color.LightSeaGreen;
            currentGraphic = gIncident;
            currentLab = incidentLabel;
            currentPB = incidentsPictureBox;
            colorChange((Control)sender, color);
            _logger.LogInformation("Chargement de la page Incidents");
            changeTab("Gestion des incidents", new IncidentPage(_logger));
        }
        private void logPanel_Click(object sender, EventArgs e)
        {
            currentTag = logPanel.Tag.ToString();
            Color color = Color.LightSeaGreen;
            colorChange((Control)sender, color);
            _logger.LogInformation("Chargement de la page Incidents");
            DateTime dateTime = DateTime.Now;
            string nameFile = "Logs-Campo-"+dateTime.Year + "" + dateTime.Month.ToString("d2")+""+dateTime.Day.ToString("d2") +".txt";
            Process.Start(Program.path + nameFile);
        }

        private void panelReservation_Click(object sender, EventArgs e)
        {
            currentTag = panelReservation.Tag.ToString();
            clearCurrent();
            Color color = Color.LightSeaGreen;
            currentGraphic = gReservation;
            currentLab = labelReservation;
            currentPB = reservationPictureBox;
            colorChange((Control)sender, color);

            _logger.LogInformation("Chargement de la page Réservations");
            changeTab("Réservations", new ReservationPage(_logger));

        }

        private void deconnectionButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void changeTab(string name, Form form)
        {
            this.Text = name;
            Panel panel = ((IPanel)form).GetPanel();
            actualPannel = panel;
            this.SetContentPanel(panel);
            actualPannel.Size = contentPanel.Size;
            actualPannel.Location = new System.Drawing.Point(0, 0);
        }
        
        private void colorChange(Control widget, Color color)
        {
            if(!isCurrentButton(widget))
            {
                switch (widget.Tag.ToString())
                {
                    case "Accueil":
                        accueilLabel.BackColor = color;
                        accueilPictureBox.BackColor = color;
                        changeColorPanel(gAccueil, color, size, 15);
                        break;
                    case "Reservation":
                        reservationPictureBox.BackColor = color;
                        labelReservation.BackColor = color;
                        changeColorPanel(gReservation, color, size, 15);
                        break;
                    case "Stock":
                        stockLabel.BackColor = color;
                        stockPictureBox.BackColor = color;
                        changeColorPanel(gStock, color, size, 15);
                        break;
                    case "Fournisseur":
                        fournisseurLabel.BackColor = color;
                        fournisseurPictureBox.BackColor = color;
                        changeColorPanel(gFournisseur, color, size, 15);
                        break;
                    case "Clients":
                        clientLabel.BackColor = color;
                        clientPictureBox.BackColor = color;
                        changeColorPanel(gClient, color, size, 15);
                        break;
                    case "Incident":
                        incidentLabel.BackColor = color;
                        incidentsPictureBox.BackColor = color;
                        changeColorPanel(gIncident, color, size, 15);
                        break;
                    case "Logs":
                        logLabel.BackColor = color;
                        logPictureBox.BackColor = color;
                        changeColorPanel(gLogs, color, size, 15);
                        break;
                }
            }
            
        }

        private bool isCurrentButton(Control widget)
        {
            if (widget.Tag.ToString().Equals(currentTag))
            {

                changeColorPanel(currentGraphic, Color.LightSeaGreen, size, 15);
                currentLab.BackColor = Color.LightSeaGreen;
                currentPB.BackColor = Color.LightSeaGreen;
                return true;
            }
            return false;
        }

        #region hover
        private void Button_MouseEnter(object sender, EventArgs e)
        {
            Color color = Color.MediumAquamarine;
            var widget = (Control)sender;
            colorChange(widget, color);
        }

        private void Button_MouseLeave(object sender, EventArgs e)
        {
            Color color = Color.WhiteSmoke;
            var widget = (Control)sender;
            colorChange(widget, color);
        }
        #endregion
        private void Panels_Paint(object sender, PaintEventArgs e)
        {
        }

        private void changeColorPanel(Graphics graphics, Color color, Size size, int round)
        {
            try
            {
                graphics.SmoothingMode = SmoothingMode.HighQuality;
                Rectangle gradientRectangle = new Rectangle(0, 0, size.Width, size.Height);
                SolidBrush b = new SolidBrush(color);
                graphics.SmoothingMode = SmoothingMode.HighQuality;
                FillRoundedRectangle(graphics, b, gradientRectangle, round);
            }
            catch (System.NullReferenceException ex)
            {

            }
        }

        private void Panels_Configs(object sender, EventArgs e)
        {
            panelLayout.Size = ClientSize;

            menuPanel.Size = new Size(ClientSize.Width / 5, ClientSize.Height);
            menuPanel.Location = new System.Drawing.Point(0, 0);

            profilPanel.Size = new Size(ClientSize.Width / 5, ClientSize.Height);
            profilPanel.Location = new System.Drawing.Point(4 * ClientSize.Width / 5, 0);

            contentPanel.Size = new Size(3 * (ClientSize.Width / 5), ClientSize.Height);
            contentPanel.Location = new System.Drawing.Point(ClientSize.Width / 5, 0);

            actualPannel.Size = contentPanel.Size;
            actualPannel.Location = new System.Drawing.Point(0, 0);

            panelButtons.Size = new Size(245 * menuPanel.Width / 265, 410 * menuPanel.Height / 650);
            panelButtons.Location = new System.Drawing.Point(menuPanel.Width / 2 - panelButtons.Width / 2, menuPanel.Height / 2 - panelButtons.Height / 2);

            size = new Size(panelButtons.Width - 10, 40);

            accueilPanel.Size = size;
            panelReservation.Size = size;
            clientPanel.Size = size;
            fournisseurPanel.Size = size;
            stockPanel.Size = size;
            incidentPanel.Size = size;
            logPanel.Size = size;

            accueilPanel.Location = new Point(0, 0);
            panelReservation.Location = new Point(0, 2 * panelButtons.Height / 14);
            clientPanel.Location = new Point(0, 4 * panelButtons.Height / 14);
            fournisseurPanel.Location = new Point(0, 6 * panelButtons.Height / 14);
            stockPanel.Location = new Point(0, 8 * panelButtons.Height / 14);
            incidentPanel.Location = new Point(0, 10 * panelButtons.Height / 14);
            logPanel.Location = new Point(0, 12 * panelButtons.Height / 14);

            gAccueil = accueilPanel.CreateGraphics();
            gReservation = panelReservation.CreateGraphics();
            gClient = clientPanel.CreateGraphics();
            gFournisseur = fournisseurPanel.CreateGraphics();
            gStock = stockPanel.CreateGraphics();
            gIncident = incidentPanel.CreateGraphics();
            gLogs = logPanel.CreateGraphics();

            currentGraphic = currentLab.Parent.CreateGraphics();


            Color color = Color.WhiteSmoke;
            colorChange(accueilPanel, color);
            colorChange(panelReservation, color);
            colorChange(clientPanel, color);
            colorChange(fournisseurPanel, color);
            colorChange(stockPanel, color);
            colorChange(incidentPanel, color);
            colorChange(logPanel, color);

            accueilLabel.Location = new System.Drawing.Point(accueilPanel.Width / 2 - accueilLabel.Width / 2, accueilPanel.Height / 2 - accueilLabel.Height / 2);
            labelReservation.Location = new System.Drawing.Point(panelReservation.Width / 2 - labelReservation.Width / 2, panelReservation.Height / 2 - labelReservation.Height / 2);
            clientLabel.Location = new System.Drawing.Point(clientPanel.Width / 2 - clientLabel.Width / 2, clientPanel.Height / 2 - clientLabel.Height / 2);
            fournisseurLabel.Location = new System.Drawing.Point(fournisseurPanel.Width / 2 - fournisseurLabel.Width / 2, fournisseurPanel.Height / 2 - fournisseurLabel.Height / 2);
            stockLabel.Location = new System.Drawing.Point(stockPanel.Width / 2 - stockLabel.Width / 2, stockPanel.Height / 2 - stockLabel.Height / 2);
            incidentLabel.Location = new System.Drawing.Point(incidentPanel.Width / 2 - incidentLabel.Width / 2, incidentPanel.Height / 2 - incidentLabel.Height / 2);
            logLabel.Location = new System.Drawing.Point(logPanel.Width / 2 - logLabel.Width / 2, logPanel.Height / 2 - logLabel.Height / 2);

            profileGroupBox.Size = new Size(profilPanel.Width, profileGroupBox.Height);
            profilePictureBox.Location = new Point(0, profileGroupBox.Height/2 - profilePictureBox.Height/2);
            profileNameLabel.Location = new Point(profilePictureBox.Width + 10, profilePictureBox.Location.Y);
            profileRoleLabel.Location = new Point(profilePictureBox.Width + 10, profilePictureBox.Location.Y + profilePictureBox.Height - profileRoleLabel.Height);
            deconnectionButton.BackColor = Color.FromArgb(150, color);

            monthCalendar.Location = new Point(profilPanel.Width / 2 - monthCalendar.Width / 2, profilPanel.Height / 2 - monthCalendar.Height / 2);
            Console.WriteLine(monthCalendar.Location);

        }
    }
}
