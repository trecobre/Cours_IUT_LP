﻿using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gestion_camping
{
    public partial class ClientPage : Form, IPanel
    {
        ILogger _logger;
        Client[] clients;
        Panel[] panels;

        public string nomClient { get; private set; }
        public string prenomClient { get; private set; }
        public string mailClient { get; private set; }
        public string telephoneClient { get; private set; }

        public ClientPage(ILogger logger)
        {
            _logger = logger;
            clients = Program.bdEntities.Client.OrderBy(c => c.nomClient).ToArray();
            panels = new Panel[clients.Length];
            InitializeComponent();
            fillClient();
            changeSize(ClientPagePanel);
        }

        /// <summary>
        /// This function fills the clientFlowLayoutPanel with the clientListablePanel for each client
        /// in the database
        /// </summary>
        void fillClient()
        {
            int count = 0;
            foreach (Client client in clients)
            {
                panels[count] = getClientListablePanel(client);
                count++;
            }
            clientFlowLayoutPanel.Controls.AddRange(panels);
        }

        /// <summary>
        /// Returns a Panel that can be used to display a Client in a ListableObject
        /// </summary>
        /// <param name="Client">The client object that you want to display.</param>
        /// <returns>
        /// A panel.
        /// </returns>
        public Panel getClientListablePanel(Client client)
        {
            ListableObject lobj = new ListableObject();

            return lobj.getClientListablePanel(client);
        }

        /// <summary>
        /// Returns the panel that is currently being displayed on the client
        /// </summary>
        /// <returns>
        /// The panel that is being returned is the ClientPagePanel.
        /// </returns>
        public Panel GetPanel()
        {
            return ClientPagePanel;
        }

        /// <summary>
        /// This function is called when the user clicks the "Modify" button. 
        /// It creates a modifClientPage object and displays it. 
        /// If the user clicks OK, it gets the data from the modifClientPage object and creates a new
        /// Client object. 
        /// It then adds the new Client object to the database and saves the changes. 
        /// Finally, it adds the new Client object to the clientFlowLayoutPanel
        /// </summary>
        /// <param name="sender">The object that raised the event.</param>
        /// <param name="EventArgs">The event arguments.</param>
        private void modificationButton_Click(object sender, EventArgs e)
        {
            modifClientPage edit = new modifClientPage();
            Client clientOld = edit.getData();
            if (edit.ShowDialog() == DialogResult.OK)
            {
                Client client = new Client();
                client = edit.getData();
                if(Program.bdEntities.Client.Where(c => c.nomClient == client.nomClient && c.prenomClient == client.prenomClient && c.mailClient == client.mailClient && c.telephoneClient == client.telephoneClient).Count() == 0)
                {
                    Utils.modifierAjouterClient(client);
                    clientFlowLayoutPanel.Controls.Add(getClientListablePanel(client));
                }
                else
                {
                    MessageBox.Show("Ce client existe déjà !");
                }
                
            }
        }

        private void ClientPagePanel_SizeChanged(object sender, EventArgs e)
        {
            Panel panel = (Panel)sender;
            changeSize(panel);
        }

        private void changeSize(Panel panel)
        {
            clientFlowLayoutPanel.Size = new System.Drawing.Size(panel.Width, panel.Height - ajoutClientButton.Height-25);
            foreach (Panel p in panels)
            {
                p.Size = new System.Drawing.Size(clientFlowLayoutPanel.Width - 25, p.Height);
                p.BackColor = Color.FromArgb(150, Color.WhiteSmoke);
            }
        }

        public void changetochanged(Client client) {
            this.nomClient = client.nomClient;
            this.prenomClient = client.prenomClient;
            this.mailClient = client.mailClient;
            this.telephoneClient = client.telephoneClient;
        }
    }
}
