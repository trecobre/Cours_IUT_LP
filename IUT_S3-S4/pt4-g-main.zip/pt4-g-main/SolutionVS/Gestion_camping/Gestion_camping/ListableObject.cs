﻿using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gestion_camping
{
    public partial class ListableObject : Form
    {
        static ILogger _logger;
        BD_PT4_S4D_E1Entities1 entities = Program.bdEntities;


        public ListableObject(ILogger logger=null)
        {
            
            _logger = logger;
        }

        public ListableObject()
        {
            InitializeComponent();
        }

        public Panel getListablePanel(string descinfo1 = "nom", string info1 = "nom", string descinfo2 = "prenom", string info2 = "prenom", string descinfo3 = "desc", string info3 = "desc")
        {
            descInfo1Label.Text = descinfo1;
            Info1Label.Text = info1;
            descInfo2Label.Text = descinfo2;
            Info2Label.Text = info2;
            descInfo3Label.Text = descinfo3;
            Info3Label.Text = info3;
            return this.ListablePanel;
        }

        public Panel getClientListablePanel(Client client)
        {
            Client theClient = client;
            clientInfo1Label.Text = theClient.nomClient;
            clientInfo2Label.Text = theClient.prenomClient;
            clientInfo3Label.Text = theClient.mailClient;
            this.clientEditButton.Tag = theClient;
            return this.clientListablePanel;
        }

        private void clientEditButton_Click(object sender, EventArgs e)
        {
            Client client = (Client)((Button)sender).Tag;
            modifClientPage edit = new modifClientPage(client);
            Client clientOld = edit.getData();
            if (edit.ShowDialog() == DialogResult.OK)
            {
                Client toChanged = edit.getData();
                //entities.Client.First(c => c.ClientID == client.ClientID).changetochanged(toChanged);
                Utils.editListableObject(clientOld, client);
                _logger.LogInformation($"Update Client Nom: {clientOld.nomClient} -> {client.nomClient}, Prenom: {clientOld.prenomClient} -> {client.prenomClient}, mail: {clientOld.mailClient} -> {client.mailClient}, tel: {clientOld.telephoneClient} -> {client.telephoneClient}");

                entities.SaveChanges();
                changeClientValues(entities.Client.First(c => c.ClientID == client.ClientID));
            }
        }

        private void changeClientValues(Client client)
        {
            clientInfo1Label.Text = client.nomClient;
            clientInfo2Label.Text = client.prenomClient;
            clientInfo3Label.Text = client.mailClient;
            clientEditButton.Tag = client;
        }

        /// ///////////////////////////////////////////////////////////////////////////////////////////

        public Panel getStockListablePanel(Produit produit)
        {
            fillProduitLabels(produit);

            return this.stockListablePanel;
        }

        private void fillProduitLabels(Produit produit)
        {
            Stock[] stocks = entities.Stock.Where(s => produit.ProduitID == s.produitID).Where(s => s.datePeremption > DateTime.Now).OrderBy(s => s.datePeremption).ToArray();
            Stock[] stock2 = entities.Stock.Where(s => produit.ProduitID == s.produitID).Where(s => s.datePeremption == null).ToArray();
            stocks = stocks.Concat(stock2).ToArray();

            string quantity = "indisponible";
            if (stocks != null && stocks.Length > 0)
            {
                quantity = stocks.Sum(s => s.quantiteProduit).ToString();
            }
            String price = produit.prixProduit.ToString();

            stockInfo1Label.Text = produit.nomProduit;
            stockInfo2Label.Text = quantity;
            stockInfo3Label.Text = price;
            (Stock[], Produit) toButton = (stocks, produit);
            this.stockEditButton.Tag = toButton;
        }

        private void stockEditButton_Click(object sender, EventArgs e)
        {
            (Stock[], Produit produit) tuple = ((Stock[], Produit))stockEditButton.Tag;
            ModifierStock edit = new ModifierStock(tuple, _logger);
            edit.ShowDialog();
            fillProduitLabels(entities.Produit.Where(p => tuple.produit.ProduitID == p.ProduitID).First());
        }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        public Panel getFournisseurListablePanel(Fournisseur fournisseur)
        {
            fillFournisseurValues(fournisseur);
            fournisseurButton.Tag = fournisseur;
            return FournisseurlistablePanel;
        }

        private void fournisseurButton_Click(object sender, EventArgs e)
        {
            Fournisseur fournisseur = (Fournisseur)fournisseurButton.Tag;
            affichageFournisseur edit = new affichageFournisseur(fournisseur);
            edit.ShowDialog();
        }

        private void fillFournisseurValues(Fournisseur fournisseur)
        {
            fournisseurNomInfoLabel.Text = fournisseur.nomFournisseur;
            fournisseurTelephoneInfoLabel.Text = fournisseur.telephoneFournisseur;
            fournisseurQuantiteInfoLabel.Text = entities.Produit.Where(p => p.fournisseurId == fournisseur.FournisseurID).Count().ToString();
        }
    }
}
