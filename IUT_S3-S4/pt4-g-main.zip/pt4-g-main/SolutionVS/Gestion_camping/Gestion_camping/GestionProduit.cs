﻿using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Gestion_camping
{
    public partial class GestionProduit : Form
    {
        private string ajout = " -- Ajout -- ";
        private ILogger _logger;
        BD_PT4_S4D_E1Entities1 entities = Program.bdEntities;

        public GestionProduit(ILogger logger)
        {
            _logger = logger;
            InitializeComponent();
            fillList();
            fillComboBox();
        }

        void fillList()
        {
            listBox_Produit.Items.Clear();
            listBox_Produit.Items.Add(ajout);//string
            Produit[] produits = entities.Produit.ToArray();
            listBox_Produit.Items.AddRange(produits);
            listBox_Produit.SelectedIndex =0;
        }

        private void fillComboBox()
        {
            Fournisseur[] fournisseurs = entities.Fournisseur.ToArray();
            fournisseurComboBox.Items.AddRange(fournisseurs);
        }

        private Produit getDataProduit()
        {
            Produit produit = new Produit();
            produit.nomProduit = textBox_NomProduit.Text;
            produit.prixProduit = (double)numericUpDown_Prix.Value;
            produit.descriptionProduit = richTextBox_Description.Text;
            Fournisseur fournisseur = (Fournisseur)fournisseurComboBox.SelectedItem;
            produit.fournisseurId = fournisseur.FournisseurID;
            return produit;
        }

        private void suppStockButton_Click(object sender, EventArgs e)
        {
            if (listBox_Produit.SelectedItem != null)
            {
                Produit produit = listBox_Produit.SelectedItem as Produit;
                entities.Produit.Remove(entities.Produit.First(p => p.ProduitID == produit.ProduitID));
                entities.Stock.RemoveRange(entities.Stock.Where(s => s.produitID == produit.ProduitID));
                entities.Achat.RemoveRange(entities.Achat.Where(s => s.produitID == produit.ProduitID));
                entities.Vente.RemoveRange(entities.Vente.Where(s => s.produitID== produit.ProduitID));
                entities.SaveChanges();

                //reset values to 0
                listBox_Produit.SelectedItem = null;
                textBox_NomProduit.Text=String.Empty;
                richTextBox_Description.Text=String.Empty;
                numericUpDown_Prix.Value = 0;
                _logger.LogInformation($"Suppresion du produit {produit.nomProduit}({produit.ProduitID})");
                fillList();
            }
        }

        private void ajoutModifProduitButton_Click(object sender, EventArgs e)
        {
            bool updatable = true;
            if (textBox_NomProduit.Text == null || textBox_NomProduit.Text ==string.Empty)
            {
                updatable = false;
                label_Nom_Produit.ForeColor = Color.Red;
            }
            else
            {
                label_Nom_Produit.ForeColor = Color.Black;
            }

            if (fournisseurComboBox.SelectedItem == null)
            {
                updatable = false;
                label_Fournisseur.ForeColor = Color.Red;
            }
            else
            {
                label_Fournisseur.ForeColor = Color.Black;
            }

            if (updatable)
            {
                if (!(listBox_Produit.SelectedItem.ToString() == ajout ))//modif
                {
                    
                    
                        Produit toChanged = getDataProduit();
                        Produit produit = (Produit)listBox_Produit.SelectedItem;
                        entities.Produit.First(p => p.ProduitID == produit.ProduitID).changetochanged(toChanged);

                        _logger.LogInformation($"modification produit : {produit.nomProduit}");
                        listBox_Produit.ForeColor = Color.Black;
                    
                    
                }

                else
                {
                    if(entities.Produit.Where(p=>p.nomProduit.Trim()== textBox_NomProduit.Text.Trim()).ToArray().Length == 0)
                    {
                        Produit produit = getDataProduit();
                        entities.Produit.Add(produit);
    
                        _logger.LogInformation($"Ajout produit : {produit.nomProduit}");
                        listBox_Produit.ForeColor = Color.Black;
                    }
                    else
                    {
                        listBox_Produit.ForeColor = Color.Red;
                    }
                    
                }
                entities.SaveChanges();
                fillList();
            }
        }

        private void listBox_Produit_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBox_Produit.SelectedItem != null)
            {
                if (listBox_Produit.SelectedItem.ToString() != ajout) {
                    ajoutModifProduitButton.Text = "Modifier";
                    Produit produit = listBox_Produit.SelectedItem as Produit;
                    textBox_NomProduit.Text = produit.nomProduit.Trim();
                    numericUpDown_Prix.Value = (decimal)produit.prixProduit;
                    richTextBox_Description.Text = produit.descriptionProduit;
                    if (produit.fournisseurId != null) { fournisseurComboBox.SelectedItem = entities.Fournisseur.First(f => f.FournisseurID == produit.fournisseurId); }
                }
                else
                {
                    ajoutModifProduitButton.Text = "Ajouter";
                    fournisseurComboBox.SelectedItem = null;
                }
            }
        }
    }
}
