﻿namespace Gestion_camping
{
    partial class ProduitPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.produitPagePanel = new System.Windows.Forms.Panel();
            this.gestionProduitButton = new System.Windows.Forms.Button();
            this.produitFlowLayoutPanel = new System.Windows.Forms.FlowLayoutPanel();
            this.btn_ajouter_stock = new System.Windows.Forms.Button();
            this.produitPagePanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // produitPagePanel
            // 
            this.produitPagePanel.Controls.Add(this.gestionProduitButton);
            this.produitPagePanel.Controls.Add(this.produitFlowLayoutPanel);
            this.produitPagePanel.Controls.Add(this.btn_ajouter_stock);
            this.produitPagePanel.Location = new System.Drawing.Point(36, 2);
            this.produitPagePanel.Name = "produitPagePanel";
            this.produitPagePanel.Size = new System.Drawing.Size(730, 589);
            this.produitPagePanel.TabIndex = 29;
            this.produitPagePanel.SizeChanged += new System.EventHandler(this.produitPagePanel_SizeChanged);
            // 
            // gestionProduitButton
            // 
            this.gestionProduitButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.gestionProduitButton.Location = new System.Drawing.Point(0, 563);
            this.gestionProduitButton.Name = "gestionProduitButton";
            this.gestionProduitButton.Size = new System.Drawing.Size(89, 23);
            this.gestionProduitButton.TabIndex = 28;
            this.gestionProduitButton.Text = "Gérer produit";
            this.gestionProduitButton.UseVisualStyleBackColor = true;
            this.gestionProduitButton.Click += new System.EventHandler(this.gestionProduitButton_Click);
            // 
            // produitFlowLayoutPanel
            // 
            this.produitFlowLayoutPanel.AutoScroll = true;
            this.produitFlowLayoutPanel.Location = new System.Drawing.Point(0, 6);
            this.produitFlowLayoutPanel.Name = "produitFlowLayoutPanel";
            this.produitFlowLayoutPanel.Size = new System.Drawing.Size(716, 551);
            this.produitFlowLayoutPanel.TabIndex = 25;
            // 
            // btn_ajouter_stock
            // 
            this.btn_ajouter_stock.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btn_ajouter_stock.Location = new System.Drawing.Point(128, 563);
            this.btn_ajouter_stock.Name = "btn_ajouter_stock";
            this.btn_ajouter_stock.Size = new System.Drawing.Size(75, 23);
            this.btn_ajouter_stock.TabIndex = 27;
            this.btn_ajouter_stock.Text = "Ajout stock";
            this.btn_ajouter_stock.UseVisualStyleBackColor = true;
            this.btn_ajouter_stock.Click += new System.EventHandler(this.btn_ajouter_stock_Click);
            // 
            // ProduitPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(844, 604);
            this.Controls.Add(this.produitPagePanel);
            this.Name = "ProduitPage";
            this.Text = "StockPage";
            this.produitPagePanel.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel produitPagePanel;
        private System.Windows.Forms.FlowLayoutPanel produitFlowLayoutPanel;
        private System.Windows.Forms.Button btn_ajouter_stock;
        private System.Windows.Forms.Button gestionProduitButton;
    }
}