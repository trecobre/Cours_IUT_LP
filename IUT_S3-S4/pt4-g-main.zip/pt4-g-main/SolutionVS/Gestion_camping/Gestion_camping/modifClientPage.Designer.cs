﻿namespace Gestion_camping
{
    partial class modifClientPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.CancelButton = new System.Windows.Forms.Button();
            this.AcceptButton = new System.Windows.Forms.Button();
            this.telephoneTextBox = new System.Windows.Forms.TextBox();
            this.telephoneLabel = new System.Windows.Forms.Label();
            this.emailClientTextBox = new System.Windows.Forms.TextBox();
            this.emailLabel = new System.Windows.Forms.Label();
            this.prenomClientTextBox = new System.Windows.Forms.TextBox();
            this.prenomLabel = new System.Windows.Forms.Label();
            this.nomClientTextBox = new System.Windows.Forms.TextBox();
            this.nomLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // CancelButton
            // 
            this.CancelButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.CancelButton.Location = new System.Drawing.Point(150, 188);
            this.CancelButton.Name = "CancelButton";
            this.CancelButton.Size = new System.Drawing.Size(75, 23);
            this.CancelButton.TabIndex = 19;
            this.CancelButton.Text = "Annuler";
            this.CancelButton.UseVisualStyleBackColor = true;
            // 
            // AcceptButton
            // 
            this.AcceptButton.Location = new System.Drawing.Point(33, 188);
            this.AcceptButton.Name = "AcceptButton";
            this.AcceptButton.Size = new System.Drawing.Size(75, 23);
            this.AcceptButton.TabIndex = 18;
            this.AcceptButton.Text = "Accept";
            this.AcceptButton.UseVisualStyleBackColor = true;
            this.AcceptButton.Click += new System.EventHandler(this.AcceptButton_Click);
            // 
            // telephoneTextBox
            // 
            this.telephoneTextBox.Location = new System.Drawing.Point(104, 136);
            this.telephoneTextBox.Name = "telephoneTextBox";
            this.telephoneTextBox.Size = new System.Drawing.Size(100, 20);
            this.telephoneTextBox.TabIndex = 17;
            // 
            // telephoneLabel
            // 
            this.telephoneLabel.AutoSize = true;
            this.telephoneLabel.Location = new System.Drawing.Point(30, 139);
            this.telephoneLabel.Name = "telephoneLabel";
            this.telephoneLabel.Size = new System.Drawing.Size(58, 13);
            this.telephoneLabel.TabIndex = 16;
            this.telephoneLabel.Text = "Telephone";
            // 
            // emailClientTextBox
            // 
            this.emailClientTextBox.Location = new System.Drawing.Point(104, 99);
            this.emailClientTextBox.Name = "emailClientTextBox";
            this.emailClientTextBox.Size = new System.Drawing.Size(180, 20);
            this.emailClientTextBox.TabIndex = 15;
            // 
            // emailLabel
            // 
            this.emailLabel.AutoSize = true;
            this.emailLabel.Location = new System.Drawing.Point(30, 102);
            this.emailLabel.Name = "emailLabel";
            this.emailLabel.Size = new System.Drawing.Size(32, 13);
            this.emailLabel.TabIndex = 14;
            this.emailLabel.Text = "Email";
            // 
            // prenomClientTextBox
            // 
            this.prenomClientTextBox.Location = new System.Drawing.Point(104, 64);
            this.prenomClientTextBox.Name = "prenomClientTextBox";
            this.prenomClientTextBox.Size = new System.Drawing.Size(100, 20);
            this.prenomClientTextBox.TabIndex = 13;
            // 
            // prenomLabel
            // 
            this.prenomLabel.AutoSize = true;
            this.prenomLabel.Location = new System.Drawing.Point(30, 67);
            this.prenomLabel.Name = "prenomLabel";
            this.prenomLabel.Size = new System.Drawing.Size(43, 13);
            this.prenomLabel.TabIndex = 12;
            this.prenomLabel.Text = "Prenom";
            // 
            // nomClientTextBox
            // 
            this.nomClientTextBox.Location = new System.Drawing.Point(104, 29);
            this.nomClientTextBox.Name = "nomClientTextBox";
            this.nomClientTextBox.Size = new System.Drawing.Size(100, 20);
            this.nomClientTextBox.TabIndex = 11;
            // 
            // nomLabel
            // 
            this.nomLabel.AutoSize = true;
            this.nomLabel.Location = new System.Drawing.Point(30, 32);
            this.nomLabel.Name = "nomLabel";
            this.nomLabel.Size = new System.Drawing.Size(32, 13);
            this.nomLabel.TabIndex = 10;
            this.nomLabel.Text = "Nom ";
            // 
            // modifClientPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(300, 253);
            this.Controls.Add(this.CancelButton);
            this.Controls.Add(this.AcceptButton);
            this.Controls.Add(this.telephoneTextBox);
            this.Controls.Add(this.telephoneLabel);
            this.Controls.Add(this.emailClientTextBox);
            this.Controls.Add(this.emailLabel);
            this.Controls.Add(this.prenomClientTextBox);
            this.Controls.Add(this.prenomLabel);
            this.Controls.Add(this.nomClientTextBox);
            this.Controls.Add(this.nomLabel);
            this.Name = "modifClientPage";
            this.Text = "modifClientPage";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button CancelButton;
        private System.Windows.Forms.Button AcceptButton;
        private System.Windows.Forms.TextBox telephoneTextBox;
        private System.Windows.Forms.Label telephoneLabel;
        private System.Windows.Forms.TextBox emailClientTextBox;
        private System.Windows.Forms.Label emailLabel;
        private System.Windows.Forms.TextBox prenomClientTextBox;
        private System.Windows.Forms.Label prenomLabel;
        private System.Windows.Forms.TextBox nomClientTextBox;
        private System.Windows.Forms.Label nomLabel;
    }
}