﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gestion_camping
{
    public partial class IncidentForm2 : Form
    {
        String[] typeInc = { "Panne d'éléctricité", "Panne d'eau", "Dégradation matérielle", "Incendie", "Matériel en panne", "Condition météo", "Client", "Autre" };
        public IncidentForm2()
        {
            InitializeComponent();
            this.comboBoxTypeInc.Items.AddRange(typeInc);
            this.comboBoxEmplacement.Items.AddRange(Program.bdEntities.Emplacement.ToArray());
        }

        public IncidentForm2(Incident Incident)
        {
            InitializeComponent();
            this.comboBoxTypeInc.Items.AddRange(typeInc);
            this.comboBoxEmplacement.Items.AddRange(Program.bdEntities.Emplacement.ToArray());
            this.comboBoxTypeInc.SelectedItem = Incident.description;
            this.comboBoxEmplacement.SelectedItem = Incident.Emplacement;
            this.dateTimeDebut.Value = Incident.dateDebut;
        }

        public String getDetail()
        {
            return this.textBoxDetail.Text;
        }

        public Incident getData()
        {
            Incident incident = new Incident();
            incident.Status1 = Program.bdEntities.Status.First(s => s.StatusID == "EC");
            incident.dateDebut = dateTimeDebut.Value;
            incident.dateCreation = DateTime.Now;
            incident.description = comboBoxTypeInc.SelectedItem.ToString();
            incident.Emplacement = (Emplacement)comboBoxEmplacement.SelectedItem;
            return incident;
        }

        private void buttonValider_Click(object sender, EventArgs e)
        { 
            Incident incident = this.getData();
            if (incident.Emplacement != null && incident.description != null)
            {
                if(getDetail().Length <= 3500)
                {
                    DialogResult = DialogResult.OK;
                }
                else
                {
                    MessageBox.Show("Le descriptif de l'incident doit contenir moins de 3500 caractères (espaces compris)");
                }
            }
            else
            {
                MessageBox.Show("Veuillez rentrer toutes les informations nécessaires.");
            }
        }

        private void textBoxDetail_TextChanged(object sender, EventArgs e)
        {
            compteur.Text = "" + (3500 - textBoxDetail.Text.Length);
        }
    }
}
