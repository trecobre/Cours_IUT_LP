﻿using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gestion_camping
{
    public partial class FournisseurPage : Form, IPanel
    {
        Fournisseur[] fournisseurs;
        Panel[] panels;
        ILogger _logger;

        public FournisseurPage(ILogger logger)
        {
            _logger = logger;
            fournisseurs = Program.bdEntities.Fournisseur.OrderBy(c => c.nomFournisseur).ToArray();
            panels = new Panel[fournisseurs.Length];
            InitializeComponent();
            fillPanel();
        }

        void fillPanel()
        {
            _logger.LogInformation("Chargement Fournisseur");
            fournisseurFlowLayoutPanel.Controls.Clear();
            int count = 0;
            foreach (Fournisseur fournisseur in fournisseurs)
            {
                panels[count] = getFournisseurListablePanel(fournisseur);
                count++;
            }
            _logger.LogInformation("Fournisseur chargé");
            fournisseurFlowLayoutPanel.Controls.AddRange(panels);
        }

        public Panel getFournisseurListablePanel(Fournisseur fournisseur)
        {
            ListableObject lobj = new ListableObject();

            return lobj.getFournisseurListablePanel(fournisseur);
        }

        private void ajoutFournisseurButton_Click(object sender, EventArgs e)
        {
            
            modifierFournisseur edit = new modifierFournisseur(_logger);
            edit.ShowDialog();
            fillPanel();
            
        }

        public Panel GetPanel()
        {
            return fournisseurPagePanel;
        }

        private void FournisseurPagePanel_SizeChanged(object sender, EventArgs e)
        {
            Panel panel = (Panel)sender;
            changeSize(panel);
        }

        private void changeSize(Panel panel)
        {

            fournisseurFlowLayoutPanel.Size = new System.Drawing.Size(panel.Width, panel.Height - ajoutFournisseurButton.Height - 25);
            foreach (Panel p in panels)
            {
                p.Size = new System.Drawing.Size(fournisseurFlowLayoutPanel.Width - 25, p.Height);
                p.BackColor = Color.FromArgb(150, Color.WhiteSmoke);
            }
        }
    }
}