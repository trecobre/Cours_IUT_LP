﻿
using System;
using System.Runtime.InteropServices;

namespace Gestion_camping
{
    partial class ConnexionPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        [DllImport("Gdi32.dll", EntryPoint = "CreateRoundRectRgn")]
        private static extern IntPtr CreateRoundRectRgn(int nLeftRect, int nTopRect, int nRightRect, int nBottomRect, int nWidthEllipse, int nHeightEllipse);

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ConnexionPage));
            this.loginTextBox = new System.Windows.Forms.TextBox();
            this.passTextBox = new System.Windows.Forms.TextBox();
            this.connexionButton = new System.Windows.Forms.Button();
            this.voirMdp = new System.Windows.Forms.CheckBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.buttonQuit = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // loginTextBox
            // 
            this.loginTextBox.BackColor = System.Drawing.SystemColors.Window;
            this.loginTextBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.loginTextBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.loginTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.loginTextBox.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.loginTextBox.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.loginTextBox.Location = new System.Drawing.Point(15, 8);
            this.loginTextBox.Margin = new System.Windows.Forms.Padding(0);
            this.loginTextBox.Name = "loginTextBox";
            this.loginTextBox.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.loginTextBox.Size = new System.Drawing.Size(230, 24);
            this.loginTextBox.TabIndex = 1;
            this.loginTextBox.Text = "Login";
            this.loginTextBox.Enter += new System.EventHandler(this.loginTextBox_Enter);
            this.loginTextBox.Leave += new System.EventHandler(this.loginTextBox_Leave);
            this.loginTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ConnexionPage_KeyPress);
            // 
            // passTextBox
            // 
            this.passTextBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.passTextBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.passTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.passTextBox.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.passTextBox.Location = new System.Drawing.Point(15, 8);
            this.passTextBox.Name = "passTextBox";
            this.passTextBox.Size = new System.Drawing.Size(230, 24);
            this.passTextBox.TabIndex = 2;
            this.passTextBox.Text = "Mot de passe";
            this.passTextBox.Enter += new System.EventHandler(this.passTextBox_Enter);
            this.passTextBox.Leave += new System.EventHandler(this.passTextBox_Leave);
            this.passTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ConnexionPage_KeyPress);
            // 
            // connexionButton
            // 
            this.connexionButton.BackColor = System.Drawing.Color.DarkGreen;
            this.connexionButton.Cursor = System.Windows.Forms.Cursors.Default;
            this.connexionButton.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.connexionButton.FlatAppearance.BorderSize = 0;
            this.connexionButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.connexionButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.connexionButton.ForeColor = System.Drawing.SystemColors.Window;
            this.connexionButton.Location = new System.Drawing.Point(175, 214);
            this.connexionButton.Name = "connexionButton";
            this.connexionButton.Size = new System.Drawing.Size(150, 40);
            this.connexionButton.TabIndex = 4;
            this.connexionButton.Text = "Connexion";
            this.connexionButton.UseVisualStyleBackColor = false;
            this.connexionButton.Click += new System.EventHandler(this.connexionButton_Click);
            this.connexionButton.MouseHover += new System.EventHandler(this.connexionButton_MouseHover);
            // 
            // voirMdp
            // 
            this.voirMdp.Appearance = System.Windows.Forms.Appearance.Button;
            this.voirMdp.BackColor = System.Drawing.Color.Transparent;
            this.voirMdp.BackgroundImage = global::Gestion_camping.Properties.Resources.close_eye_logo;
            this.voirMdp.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.voirMdp.FlatAppearance.BorderSize = 0;
            this.voirMdp.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
            this.voirMdp.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.voirMdp.Location = new System.Drawing.Point(390, 154);
            this.voirMdp.Name = "voirMdp";
            this.voirMdp.Size = new System.Drawing.Size(31, 31);
            this.voirMdp.TabIndex = 3;
            this.voirMdp.UseVisualStyleBackColor = false;
            this.voirMdp.CheckedChanged += new System.EventHandler(this.voirMdp_CheckedChanged);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.Window;
            this.panel1.Controls.Add(this.passTextBox);
            this.panel1.Location = new System.Drawing.Point(120, 148);
            this.panel1.Name = "panel1";
            this.panel1.Padding = new System.Windows.Forms.Padding(15, 8, 15, 8);
            this.panel1.Size = new System.Drawing.Size(260, 40);
            this.panel1.TabIndex = 5;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.Window;
            this.panel2.Controls.Add(this.loginTextBox);
            this.panel2.Location = new System.Drawing.Point(120, 86);
            this.panel2.Name = "panel2";
            this.panel2.Padding = new System.Windows.Forms.Padding(15, 8, 15, 8);
            this.panel2.Size = new System.Drawing.Size(260, 40);
            this.panel2.TabIndex = 5;
            // 
            // buttonQuit
            // 
            this.buttonQuit.BackColor = System.Drawing.Color.Transparent;
            this.buttonQuit.BackgroundImage = global::Gestion_camping.Properties.Resources.icons8_effacer_96;
            this.buttonQuit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.buttonQuit.FlatAppearance.BorderSize = 0;
            this.buttonQuit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonQuit.Location = new System.Drawing.Point(433, 0);
            this.buttonQuit.Name = "buttonQuit";
            this.buttonQuit.Size = new System.Drawing.Size(50, 25);
            this.buttonQuit.TabIndex = 6;
            this.buttonQuit.UseVisualStyleBackColor = false;
            this.buttonQuit.Click += new System.EventHandler(this.buttonQuit_Click);
            this.buttonQuit.MouseEnter += new System.EventHandler(this.buttonQuit_Enter);
            this.buttonQuit.MouseLeave += new System.EventHandler(this.buttonQuit_Leave);
            //             
            // Region             
            //
            this.panel1.Region = System.Drawing.Region.FromHrgn(CreateRoundRectRgn(0, 0, this.panel1.Width, this.panel1.Height, 40, 40));
            this.panel2.Region = System.Drawing.Region.FromHrgn(CreateRoundRectRgn(0, 0, this.panel2.Width, this.panel2.Height, 40, 40));
            this.connexionButton.Region = System.Drawing.Region.FromHrgn(CreateRoundRectRgn(0, 0, this.connexionButton.Width, this.connexionButton.Height, 40, 40));
            // 
            // ConnexionPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(484, 330);
            this.Controls.Add(this.buttonQuit);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.voirMdp);
            this.Controls.Add(this.connexionButton);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "ConnexionPage";
            this.Text = "Connexion";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox loginTextBox;
        private System.Windows.Forms.TextBox passTextBox;
        private System.Windows.Forms.Button connexionButton;
        private System.Windows.Forms.CheckBox voirMdp;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button buttonQuit;
    }
}