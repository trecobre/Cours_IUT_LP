﻿using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gestion_camping
{
    public partial class ProduitPage : Form, IPanel
    {
        Produit[] Produits;
        ILogger _logger;
        Panel[] panels;
        public ProduitPage(ILogger logger)
        {
            _logger = logger;
            Produits = Program.bdEntities.Produit.OrderBy(c => c.nomProduit).ToArray();
            panels = new Panel[Produits.Length];
            InitializeComponent();
            fillStock();
        }

        void fillStock()
        {
            int count = 0;
            foreach (Produit Produit in Produits)
            {
                panels[count] = getPannelStock(Produit);
                count++;
            }
            produitFlowLayoutPanel.Controls.AddRange(panels);
        }

        public Panel getPannelStock(Produit produit)
        {
            ListableObject lobj = new ListableObject();

            return lobj.getStockListablePanel(produit);
        }

        public Panel GetPanel()
        {
            return this.produitPagePanel;
        }

        private void btn_ajouter_stock_Click(object sender, EventArgs e)
        {
            AjoutStock edit = new AjoutStock(_logger);
            edit.ShowDialog();
            fillStock();
        }

        private void gestionProduitButton_Click(object sender, EventArgs e)
        {
            GestionProduit edit = new GestionProduit(_logger);
            edit.ShowDialog();
            produitFlowLayoutPanel.Controls.Clear();
            fillStock();
        }
        private void produitPagePanel_SizeChanged(object sender, EventArgs e)
        {
            Panel panel = (Panel)sender;
            changeSize(panel);
        }

        private void changeSize(Panel panel)
        {
            produitFlowLayoutPanel.Size = new System.Drawing.Size(panel.Width, panel.Height - btn_ajouter_stock.Height - 20);
            Console.WriteLine(produitFlowLayoutPanel.Size.ToString());
            foreach (Panel p in panels)
            {
                p.Size = new System.Drawing.Size(produitFlowLayoutPanel.Width - 25, p.Height);
                p.BackColor = Color.FromArgb(150, Color.WhiteSmoke);
            }
        }
    }
}
