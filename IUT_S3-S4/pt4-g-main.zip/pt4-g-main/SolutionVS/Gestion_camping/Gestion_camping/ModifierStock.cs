﻿using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gestion_camping
{
    public partial class ModifierStock : Form
    {
        ILogger _logger;
        BD_PT4_S4D_E1Entities1 entities = Program.bdEntities;

        private Produit theProduit;

        public Produit getTheProduit()
        {
            return theProduit;
        }

        public ModifierStock((Stock[], Produit produit) tuple, ILogger logger)
        {
            _logger = logger;
            InitializeComponent();
            theProduit = tuple.produit;
            fillPanel(tuple);
        }

        void fillPanel((Stock[] stocks, Produit produit) tuple)
        {            
            textBox_NomProduit.Text = tuple.produit.nomProduit;
            prixTextBox.Text = tuple.produit.prixProduit.ToString()+" €";
            if (tuple.produit.descriptionProduit != null){ richTextBox_Description.Text = tuple.produit.descriptionProduit; }
            textBox_Fournisseur.Text = entities.Fournisseur.First(f => f.FournisseurID == tuple.produit.fournisseurId).nomFournisseur;
            fillList();
            resteLabel.Text = string.Empty;
        }

        void fillList()
        {
            listBox_Stock.Items.Clear();

            Stock[] stocks = entities.Stock.Where(s => theProduit.ProduitID == s.produitID).Where(s => s.datePeremption > DateTime.Now).OrderBy(s => s.datePeremption).ToArray();
            Stock[] stock2 = entities.Stock.Where(s => theProduit.ProduitID == s.produitID).Where(s => s.datePeremption == null).ToArray();
            stocks = stocks.Concat(stock2).ToArray();

            foreach (Stock stock in stocks)
            {
                listBox_Stock.Items.Add(stock);
            }
        }

        private void listBox_Produits_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBox_Stock.SelectedItem != null) {
                Stock stock = (Stock)listBox_Stock.SelectedItem;
                numericUpDown_Quantite.Maximum = stock.quantiteProduit;
            }
            
        }

        public Stock getDataStock()
        {
            Stock stock = new Stock();
            stock.Produit = ((Stock)(listBox_Stock.SelectedItem)).Produit;
            stock.quantiteProduit = (int)numericUpDown_Quantite.Value;
            return stock;

        }

        private void modifButton_Click(object sender, EventArgs e)
        {
            Stock stock;
            if (listBox_Stock.SelectedItem != null) 
            {
                stock = (Stock)listBox_Stock.SelectedItem;
                if (numericUpDown_Quantite.Value == numericUpDown_Quantite.Maximum)
                {
                    _logger.LogInformation($"Vente -> Stock vide. produit: {stock.Produit.nomProduit}, quantite: {stock.quantiteProduit}, prix: {stock.Produit.prixProduit}");
                    entities.Stock.Remove(entities.Stock.First(s => s.StockID == stock.StockID));

                }
                else
                {
                    Stock toChanged = getDataStock();
                    _logger.LogInformation($"Vente Stock. produit: {stock.Produit.nomProduit}, quantiteVendus: {stock.quantiteProduit - toChanged.quantiteProduit}, quantiteRestante: {toChanged.quantiteProduit}, prix: {stock.Produit.prixProduit}");
                    entities.Stock.First(s => s.StockID == stock.StockID).changetochanged(toChanged);
                }

                if(numericUpDown_Quantite.Value > 0)
                {
                    Vente vente = getDataVente();
                    entities.Vente.Add(vente);
                    _logger.LogInformation($"Ajout vente. produit: {vente.Produit.nomProduit}, quantite: {vente.quantiteVente}, prix: {vente.prix}");
                    fillList();
                    entities.SaveChanges();
                }
                
            }
        }

        private Vente getDataVente()
        {
            Vente vente = new Vente();
            vente.dateVente = DateTime.Now;
            vente.produitID = theProduit.ProduitID;
            vente.quantiteVente = (int)numericUpDown_Quantite.Value;
            decimal prix = (decimal)theProduit.prixProduit * numericUpDown_Quantite.Value;
            vente.prix = prix;
            return vente;
        }

        private void numericUpDown_Quantite_ValueChanged(object sender, EventArgs e)
        {
            if (listBox_Stock.SelectedItem != null)
            {
                Stock stock=(Stock)listBox_Stock.SelectedItem;
                int quantite = stock.quantiteProduit - (int)numericUpDown_Quantite.Value;
                resteLabel.Text = ("reste = "+quantite);
            }
            else
            {
                resteLabel.Text = String.Empty;
            }
        }

        private void suppStockButton_Click(object sender, EventArgs e)
        {
            if (listBox_Stock.SelectedItem != null)
            {
                Stock stock = (Stock)listBox_Stock.SelectedItem;
                entities.Stock.Remove(entities.Stock.First(s => s.StockID == stock.StockID));
                entities.SaveChanges();
                _logger.LogInformation($"Suppresion stock {stock.StockID}, quantite: {stock.quantiteProduit}, produitID: {stock.produitID}, dateAjout: {stock.dateAjout}, datePeremption: {stock.datePeremption}");
                fillList();
            }
        }
    }
}
