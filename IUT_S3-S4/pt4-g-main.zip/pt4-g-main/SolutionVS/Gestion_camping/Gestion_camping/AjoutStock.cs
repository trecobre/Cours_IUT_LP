﻿using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gestion_camping
{
    public partial class AjoutStock : Form
    {
        private ILogger _logger;
        Produit selectProduits;
        int? idFournisseur;
        public AjoutStock(ILogger logger)
        {
            _logger = logger;
            InitializeComponent();
            Produit[] produits = Program.bdEntities.Produit.OrderBy(p=>p.nomProduit).ToArray();
            foreach(Produit produit in produits)
            {
                listBox_Produits.Items.Add(produit);
            }
        }

        /// <summary>
        /// When the user selects a product from the listbox, the program will display the product's
        /// name, price, quantity and description
        /// </summary>
        /// <param name="sender">The object that raised the event.</param>
        /// <param name="EventArgs">The event arguments.</param>
        private void listBox_Produits_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBox_Produits.SelectedItem != null)
            {
                selectProduits = listBox_Produits.SelectedItem as Produit;
                textBox_NomProduit.Text = selectProduits.nomProduit;
                richTextBox_Description.Text = selectProduits.descriptionProduit;
                if (selectProduits.fournisseurId.HasValue)
                {
                    Fournisseur fournisseur = Program.bdEntities.Fournisseur.Where(f => f.FournisseurID == (int)selectProduits.fournisseurId).First();
                    textBox_Fournisseur.Text = fournisseur.nomFournisseur;
                    idFournisseur = fournisseur.FournisseurID;
                }
            }
        }

        private void addButton_Click(object sender, EventArgs e)
        {
            bool updatable = true;

            if (numericUpDown_Quantite.Value <= 0)
            {
                updatable = false;
                label_Quantite.ForeColor = Color.Red;
            }else
            {
                label_Quantite.ForeColor = Color.Black;
            }

            if (!perissableCheckBox.Checked)
            {
                if (peremptionDateTimePicker.Value <= DateTime.Now)
                {
                    updatable = false;
                    DateLabel.ForeColor = Color.Red;
                }
                else
                {
                    DateLabel.ForeColor = Color.Black;
                }
            }
            else
            {
                DateLabel.ForeColor = Color.Black;
            }

            if (listBox_Produits.SelectedItem == null)
            {
                updatable=false;
                listBox_Produits.ForeColor = Color.Red;
            }else
            {
                listBox_Produits.ForeColor= Color.Black;
            }

            if (updatable)
            {
                Stock stock = tostock();
                if (idFournisseur.HasValue)
                {
                    Achat achat = new Achat();
                    achat.fournisseurID = (int)idFournisseur;
                    achat.produitID = stock.produitID;
                    achat.quantiteAchat = stock.quantiteProduit;
                    Program.bdEntities.Achat.Add(achat);
                    Program.bdEntities.Produit.Where(p => p.ProduitID == stock.produitID).First().Achat.Add(achat);
                }

                Program.bdEntities.Stock.Add(stock);
                Program.bdEntities.SaveChanges();

                textBox_NomProduit.Text = String.Empty;
                listBox_Produits.SelectedItem = null;
                numericUpDown_Quantite.Value = 0;
                peremptionDateTimePicker.Value = DateTime.Now;   
            }
        }

        private Stock tostock()
        {
            Produit produit = (Produit)listBox_Produits.SelectedItem;
            Stock stock = new Stock();
            if (!perissableCheckBox.Checked)
            {
                stock.datePeremption = peremptionDateTimePicker.Value;
            }
            stock.quantiteProduit = (int)numericUpDown_Quantite.Value;
            stock.produitID = produit.ProduitID;
            _logger.LogInformation($"Ajout stock de {produit.nomProduit}");
            _logger.LogInformation($"QuantiteProduit: {stock.StockID}, datePeremption: {stock.datePeremption}");

            return stock;
        }
    }
}
