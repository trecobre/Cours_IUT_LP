﻿namespace Gestion_camping
{
    partial class ReservationForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonRes = new System.Windows.Forms.Button();
            this.buttonFac = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // buttonRes
            // 
            this.buttonRes.BackColor = System.Drawing.Color.DarkCyan;
            this.buttonRes.DialogResult = System.Windows.Forms.DialogResult.Yes;
            this.buttonRes.FlatAppearance.BorderSize = 0;
            this.buttonRes.FlatAppearance.MouseDownBackColor = System.Drawing.Color.LightSeaGreen;
            this.buttonRes.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Aquamarine;
            this.buttonRes.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonRes.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonRes.Location = new System.Drawing.Point(0, 0);
            this.buttonRes.Name = "buttonRes";
            this.buttonRes.Size = new System.Drawing.Size(200, 80);
            this.buttonRes.TabIndex = 0;
            this.buttonRes.Text = "Modifier la reservation";
            this.buttonRes.UseVisualStyleBackColor = false;
            // 
            // buttonFac
            // 
            this.buttonFac.BackColor = System.Drawing.Color.DarkCyan;
            this.buttonFac.DialogResult = System.Windows.Forms.DialogResult.No;
            this.buttonFac.FlatAppearance.BorderSize = 0;
            this.buttonFac.FlatAppearance.MouseDownBackColor = System.Drawing.Color.LightSeaGreen;
            this.buttonFac.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Aquamarine;
            this.buttonFac.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonFac.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonFac.Location = new System.Drawing.Point(200, 0);
            this.buttonFac.Name = "buttonFac";
            this.buttonFac.Size = new System.Drawing.Size(200, 80);
            this.buttonFac.TabIndex = 1;
            this.buttonFac.Text = "Consulter la facture";
            this.buttonFac.UseVisualStyleBackColor = false;
            // 
            // ReservationForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClientSize = new System.Drawing.Size(400, 80);
            this.Controls.Add(this.buttonFac);
            this.Controls.Add(this.buttonRes);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "ReservationForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "ReservationForm";
            this.Shown += new System.EventHandler(this.ReservationForm_Shown);
            this.MouseCaptureChanged += new System.EventHandler(this.ReservationForm_MouseCaptureChanged);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button buttonRes;
        private System.Windows.Forms.Button buttonFac;
    }
}