﻿namespace Gestion_camping
{
    partial class Panels
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panelLayout = new System.Windows.Forms.Panel();
            this.contentPanel = new System.Windows.Forms.Panel();
            this.menuPanel = new System.Windows.Forms.Panel();
            this.panelButtons = new System.Windows.Forms.Panel();
            this.accueilPanel = new System.Windows.Forms.Panel();
            this.accueilPictureBox = new System.Windows.Forms.PictureBox();
            this.accueilLabel = new System.Windows.Forms.Label();
            this.logPanel = new System.Windows.Forms.Panel();
            this.logPictureBox = new System.Windows.Forms.PictureBox();
            this.logLabel = new System.Windows.Forms.Label();
            this.fournisseurPanel = new System.Windows.Forms.Panel();
            this.fournisseurPictureBox = new System.Windows.Forms.PictureBox();
            this.fournisseurLabel = new System.Windows.Forms.Label();
            this.panelReservation = new System.Windows.Forms.Panel();
            this.reservationPictureBox = new System.Windows.Forms.PictureBox();
            this.labelReservation = new System.Windows.Forms.Label();
            this.stockPanel = new System.Windows.Forms.Panel();
            this.stockPictureBox = new System.Windows.Forms.PictureBox();
            this.stockLabel = new System.Windows.Forms.Label();
            this.incidentPanel = new System.Windows.Forms.Panel();
            this.incidentsPictureBox = new System.Windows.Forms.PictureBox();
            this.incidentLabel = new System.Windows.Forms.Label();
            this.clientPanel = new System.Windows.Forms.Panel();
            this.clientPictureBox = new System.Windows.Forms.PictureBox();
            this.clientLabel = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.profilPanel = new System.Windows.Forms.Panel();
            this.profileGroupBox = new System.Windows.Forms.GroupBox();
            this.profileRoleLabel = new System.Windows.Forms.Label();
            this.profileNameLabel = new System.Windows.Forms.Label();
            this.profilePictureBox = new System.Windows.Forms.PictureBox();
            this.monthCalendar = new System.Windows.Forms.MonthCalendar();
            this.deconnectionButton = new System.Windows.Forms.Button();
            this.profileLabel = new System.Windows.Forms.Label();
            this.panelLayout.SuspendLayout();
            this.menuPanel.SuspendLayout();
            this.panelButtons.SuspendLayout();
            this.accueilPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.accueilPictureBox)).BeginInit();
            this.logPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.logPictureBox)).BeginInit();
            this.fournisseurPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fournisseurPictureBox)).BeginInit();
            this.panelReservation.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.reservationPictureBox)).BeginInit();
            this.stockPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.stockPictureBox)).BeginInit();
            this.incidentPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.incidentsPictureBox)).BeginInit();
            this.clientPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.clientPictureBox)).BeginInit();
            this.profilPanel.SuspendLayout();
            this.profileGroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.profilePictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // panelLayout
            // 
            this.panelLayout.BackColor = System.Drawing.Color.Transparent;
            this.panelLayout.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panelLayout.Controls.Add(this.contentPanel);
            this.panelLayout.Controls.Add(this.menuPanel);
            this.panelLayout.Controls.Add(this.profilPanel);
            this.panelLayout.Location = new System.Drawing.Point(0, 0);
            this.panelLayout.Name = "panelLayout";
            this.panelLayout.Size = new System.Drawing.Size(1269, 665);
            this.panelLayout.TabIndex = 35;
            // 
            // contentPanel
            // 
            this.contentPanel.BackColor = System.Drawing.Color.Transparent;
            this.contentPanel.Location = new System.Drawing.Point(266, 7);
            this.contentPanel.Name = "contentPanel";
            this.contentPanel.Size = new System.Drawing.Size(730, 642);
            this.contentPanel.TabIndex = 34;
            // 
            // menuPanel
            // 
            this.menuPanel.BackColor = System.Drawing.Color.Transparent;
            this.menuPanel.Controls.Add(this.panelButtons);
            this.menuPanel.Controls.Add(this.label6);
            this.menuPanel.Location = new System.Drawing.Point(0, 0);
            this.menuPanel.Margin = new System.Windows.Forms.Padding(0);
            this.menuPanel.Name = "menuPanel";
            this.menuPanel.Size = new System.Drawing.Size(263, 649);
            this.menuPanel.TabIndex = 28;
            // 
            // panelButtons
            // 
            this.panelButtons.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panelButtons.Controls.Add(this.accueilPanel);
            this.panelButtons.Controls.Add(this.logPanel);
            this.panelButtons.Controls.Add(this.fournisseurPanel);
            this.panelButtons.Controls.Add(this.panelReservation);
            this.panelButtons.Controls.Add(this.stockPanel);
            this.panelButtons.Controls.Add(this.incidentPanel);
            this.panelButtons.Controls.Add(this.clientPanel);
            this.panelButtons.Location = new System.Drawing.Point(27, 123);
            this.panelButtons.Margin = new System.Windows.Forms.Padding(0);
            this.panelButtons.Name = "panelButtons";
            this.panelButtons.Size = new System.Drawing.Size(210, 453);
            this.panelButtons.TabIndex = 19;
            // 
            // accueilPanel
            // 
            this.accueilPanel.BackColor = System.Drawing.Color.Transparent;
            this.accueilPanel.Controls.Add(this.accueilPictureBox);
            this.accueilPanel.Controls.Add(this.accueilLabel);
            this.accueilPanel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.accueilPanel.ForeColor = System.Drawing.SystemColors.ControlText;
            this.accueilPanel.Location = new System.Drawing.Point(0, 0);
            this.accueilPanel.Margin = new System.Windows.Forms.Padding(0);
            this.accueilPanel.Name = "accueilPanel";
            this.accueilPanel.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.accueilPanel.Size = new System.Drawing.Size(200, 40);
            this.accueilPanel.TabIndex = 15;
            this.accueilPanel.Tag = "Accueil";
            this.accueilPanel.Click += new System.EventHandler(this.accueilPanel_Click);
            this.accueilPanel.MouseEnter += new System.EventHandler(this.Button_MouseEnter);
            this.accueilPanel.MouseLeave += new System.EventHandler(this.Button_MouseLeave);
            // 
            // accueilPictureBox
            // 
            this.accueilPictureBox.BackColor = System.Drawing.Color.WhiteSmoke;
            this.accueilPictureBox.Image = global::Gestion_camping.Properties.Resources.icons8_accueil_96;
            this.accueilPictureBox.Location = new System.Drawing.Point(5, 5);
            this.accueilPictureBox.Name = "accueilPictureBox";
            this.accueilPictureBox.Size = new System.Drawing.Size(30, 30);
            this.accueilPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.accueilPictureBox.TabIndex = 1;
            this.accueilPictureBox.TabStop = false;
            this.accueilPictureBox.Tag = "Accueil";
            this.accueilPictureBox.Click += new System.EventHandler(this.accueilPanel_Click);
            this.accueilPictureBox.MouseEnter += new System.EventHandler(this.Button_MouseEnter);
            this.accueilPictureBox.MouseLeave += new System.EventHandler(this.Button_MouseLeave);
            // 
            // accueilLabel
            // 
            this.accueilLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.accueilLabel.AutoSize = true;
            this.accueilLabel.BackColor = System.Drawing.Color.WhiteSmoke;
            this.accueilLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.accueilLabel.Location = new System.Drawing.Point(123, 7);
            this.accueilLabel.Name = "accueilLabel";
            this.accueilLabel.Size = new System.Drawing.Size(73, 24);
            this.accueilLabel.TabIndex = 0;
            this.accueilLabel.Tag = "Accueil";
            this.accueilLabel.Text = "Accueil";
            this.accueilLabel.Click += new System.EventHandler(this.accueilPanel_Click);
            this.accueilLabel.MouseEnter += new System.EventHandler(this.Button_MouseEnter);
            this.accueilLabel.MouseLeave += new System.EventHandler(this.Button_MouseLeave);
            // 
            // logPanel
            // 
            this.logPanel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.logPanel.BackColor = System.Drawing.Color.Transparent;
            this.logPanel.Controls.Add(this.logPictureBox);
            this.logPanel.Controls.Add(this.logLabel);
            this.logPanel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.logPanel.Location = new System.Drawing.Point(0, 413);
            this.logPanel.Margin = new System.Windows.Forms.Padding(0);
            this.logPanel.Name = "logPanel";
            this.logPanel.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.logPanel.Size = new System.Drawing.Size(200, 40);
            this.logPanel.TabIndex = 20;
            this.logPanel.Tag = "Logs";
            this.logPanel.Click += new System.EventHandler(this.logPanel_Click);
            this.logPanel.MouseEnter += new System.EventHandler(this.Button_MouseEnter);
            this.logPanel.MouseLeave += new System.EventHandler(this.Button_MouseLeave);
            // 
            // logPictureBox
            // 
            this.logPictureBox.BackColor = System.Drawing.Color.WhiteSmoke;
            this.logPictureBox.Image = global::Gestion_camping.Properties.Resources.icons8_semaine_de_la_chronologie_96;
            this.logPictureBox.Location = new System.Drawing.Point(5, 5);
            this.logPictureBox.Name = "logPictureBox";
            this.logPictureBox.Size = new System.Drawing.Size(30, 30);
            this.logPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.logPictureBox.TabIndex = 1;
            this.logPictureBox.TabStop = false;
            this.logPictureBox.Tag = "Logs";
            this.logPictureBox.Click += new System.EventHandler(this.logPanel_Click);
            this.logPictureBox.MouseEnter += new System.EventHandler(this.Button_MouseEnter);
            this.logPictureBox.MouseLeave += new System.EventHandler(this.Button_MouseLeave);
            // 
            // logLabel
            // 
            this.logLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.logLabel.AutoSize = true;
            this.logLabel.BackColor = System.Drawing.Color.WhiteSmoke;
            this.logLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.logLabel.Location = new System.Drawing.Point(76, 16);
            this.logLabel.Name = "logLabel";
            this.logLabel.Size = new System.Drawing.Size(51, 24);
            this.logLabel.TabIndex = 0;
            this.logLabel.Tag = "Logs";
            this.logLabel.Text = "Logs";
            this.logLabel.Click += new System.EventHandler(this.logPanel_Click);
            this.logLabel.MouseEnter += new System.EventHandler(this.Button_MouseEnter);
            this.logLabel.MouseLeave += new System.EventHandler(this.Button_MouseLeave);
            // 
            // fournisseurPanel
            // 
            this.fournisseurPanel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.fournisseurPanel.BackColor = System.Drawing.Color.Transparent;
            this.fournisseurPanel.Controls.Add(this.fournisseurPictureBox);
            this.fournisseurPanel.Controls.Add(this.fournisseurLabel);
            this.fournisseurPanel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.fournisseurPanel.Location = new System.Drawing.Point(0, 207);
            this.fournisseurPanel.Margin = new System.Windows.Forms.Padding(0);
            this.fournisseurPanel.Name = "fournisseurPanel";
            this.fournisseurPanel.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.fournisseurPanel.Size = new System.Drawing.Size(200, 40);
            this.fournisseurPanel.TabIndex = 11;
            this.fournisseurPanel.Tag = "Fournisseur";
            this.fournisseurPanel.Click += new System.EventHandler(this.fournisseurPanel_Click);
            this.fournisseurPanel.MouseEnter += new System.EventHandler(this.Button_MouseEnter);
            this.fournisseurPanel.MouseLeave += new System.EventHandler(this.Button_MouseLeave);
            // 
            // fournisseurPictureBox
            // 
            this.fournisseurPictureBox.BackColor = System.Drawing.Color.WhiteSmoke;
            this.fournisseurPictureBox.Image = global::Gestion_camping.Properties.Resources.icons8_camion_conteneur_96;
            this.fournisseurPictureBox.Location = new System.Drawing.Point(5, 5);
            this.fournisseurPictureBox.Name = "fournisseurPictureBox";
            this.fournisseurPictureBox.Size = new System.Drawing.Size(30, 30);
            this.fournisseurPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.fournisseurPictureBox.TabIndex = 1;
            this.fournisseurPictureBox.TabStop = false;
            this.fournisseurPictureBox.Tag = "Fournisseur";
            this.fournisseurPictureBox.Click += new System.EventHandler(this.fournisseurPanel_Click);
            this.fournisseurPictureBox.MouseEnter += new System.EventHandler(this.Button_MouseEnter);
            this.fournisseurPictureBox.MouseLeave += new System.EventHandler(this.Button_MouseLeave);
            // 
            // fournisseurLabel
            // 
            this.fournisseurLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.fournisseurLabel.AutoSize = true;
            this.fournisseurLabel.BackColor = System.Drawing.Color.WhiteSmoke;
            this.fournisseurLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fournisseurLabel.Location = new System.Drawing.Point(65, 12);
            this.fournisseurLabel.Name = "fournisseurLabel";
            this.fournisseurLabel.Size = new System.Drawing.Size(111, 24);
            this.fournisseurLabel.TabIndex = 0;
            this.fournisseurLabel.Tag = "Fournisseur";
            this.fournisseurLabel.Text = "Fournisseur";
            this.fournisseurLabel.Click += new System.EventHandler(this.fournisseurPanel_Click);
            this.fournisseurLabel.MouseEnter += new System.EventHandler(this.Button_MouseEnter);
            this.fournisseurLabel.MouseLeave += new System.EventHandler(this.Button_MouseLeave);
            // 
            // panelReservation
            // 
            this.panelReservation.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.panelReservation.BackColor = System.Drawing.Color.Transparent;
            this.panelReservation.Controls.Add(this.reservationPictureBox);
            this.panelReservation.Controls.Add(this.labelReservation);
            this.panelReservation.Cursor = System.Windows.Forms.Cursors.Hand;
            this.panelReservation.Location = new System.Drawing.Point(0, 68);
            this.panelReservation.Margin = new System.Windows.Forms.Padding(0);
            this.panelReservation.Name = "panelReservation";
            this.panelReservation.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.panelReservation.Size = new System.Drawing.Size(200, 40);
            this.panelReservation.TabIndex = 18;
            this.panelReservation.Tag = "Reservation";
            this.panelReservation.Click += new System.EventHandler(this.panelReservation_Click);
            this.panelReservation.MouseEnter += new System.EventHandler(this.Button_MouseEnter);
            this.panelReservation.MouseLeave += new System.EventHandler(this.Button_MouseLeave);
            // 
            // reservationPictureBox
            // 
            this.reservationPictureBox.BackColor = System.Drawing.Color.WhiteSmoke;
            this.reservationPictureBox.Image = global::Gestion_camping.Properties.Resources.icons8_réservation_90;
            this.reservationPictureBox.Location = new System.Drawing.Point(5, 5);
            this.reservationPictureBox.Name = "reservationPictureBox";
            this.reservationPictureBox.Size = new System.Drawing.Size(30, 30);
            this.reservationPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.reservationPictureBox.TabIndex = 1;
            this.reservationPictureBox.TabStop = false;
            this.reservationPictureBox.Tag = "Reservation";
            this.reservationPictureBox.Click += new System.EventHandler(this.panelReservation_Click);
            this.reservationPictureBox.MouseEnter += new System.EventHandler(this.Button_MouseEnter);
            this.reservationPictureBox.MouseLeave += new System.EventHandler(this.Button_MouseLeave);
            // 
            // labelReservation
            // 
            this.labelReservation.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.labelReservation.AutoSize = true;
            this.labelReservation.BackColor = System.Drawing.Color.WhiteSmoke;
            this.labelReservation.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelReservation.Location = new System.Drawing.Point(43, 12);
            this.labelReservation.Name = "labelReservation";
            this.labelReservation.Size = new System.Drawing.Size(118, 24);
            this.labelReservation.TabIndex = 0;
            this.labelReservation.Tag = "Reservation";
            this.labelReservation.Text = "Reservations";
            this.labelReservation.Click += new System.EventHandler(this.panelReservation_Click);
            this.labelReservation.MouseEnter += new System.EventHandler(this.Button_MouseEnter);
            this.labelReservation.MouseLeave += new System.EventHandler(this.Button_MouseLeave);
            // 
            // stockPanel
            // 
            this.stockPanel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.stockPanel.BackColor = System.Drawing.Color.Transparent;
            this.stockPanel.Controls.Add(this.stockPictureBox);
            this.stockPanel.Controls.Add(this.stockLabel);
            this.stockPanel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.stockPanel.Location = new System.Drawing.Point(0, 280);
            this.stockPanel.Margin = new System.Windows.Forms.Padding(0);
            this.stockPanel.Name = "stockPanel";
            this.stockPanel.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.stockPanel.Size = new System.Drawing.Size(200, 40);
            this.stockPanel.TabIndex = 12;
            this.stockPanel.Tag = "Stock";
            this.stockPanel.Click += new System.EventHandler(this.stockPanel_Click);
            this.stockPanel.MouseEnter += new System.EventHandler(this.Button_MouseEnter);
            this.stockPanel.MouseLeave += new System.EventHandler(this.Button_MouseLeave);
            // 
            // stockPictureBox
            // 
            this.stockPictureBox.BackColor = System.Drawing.Color.WhiteSmoke;
            this.stockPictureBox.Image = global::Gestion_camping.Properties.Resources.icons8_garage_ouvert_96;
            this.stockPictureBox.Location = new System.Drawing.Point(5, 5);
            this.stockPictureBox.Name = "stockPictureBox";
            this.stockPictureBox.Size = new System.Drawing.Size(30, 30);
            this.stockPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.stockPictureBox.TabIndex = 2;
            this.stockPictureBox.TabStop = false;
            this.stockPictureBox.Tag = "Stock";
            this.stockPictureBox.Click += new System.EventHandler(this.stockPanel_Click);
            this.stockPictureBox.MouseEnter += new System.EventHandler(this.Button_MouseEnter);
            this.stockPictureBox.MouseLeave += new System.EventHandler(this.Button_MouseLeave);
            // 
            // stockLabel
            // 
            this.stockLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.stockLabel.AutoSize = true;
            this.stockLabel.BackColor = System.Drawing.Color.WhiteSmoke;
            this.stockLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.stockLabel.Location = new System.Drawing.Point(76, 16);
            this.stockLabel.Name = "stockLabel";
            this.stockLabel.Size = new System.Drawing.Size(56, 24);
            this.stockLabel.TabIndex = 0;
            this.stockLabel.Tag = "Stock";
            this.stockLabel.Text = "Stock";
            this.stockLabel.Click += new System.EventHandler(this.stockPanel_Click);
            this.stockLabel.MouseEnter += new System.EventHandler(this.Button_MouseEnter);
            this.stockLabel.MouseLeave += new System.EventHandler(this.Button_MouseLeave);
            // 
            // incidentPanel
            // 
            this.incidentPanel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.incidentPanel.BackColor = System.Drawing.Color.Transparent;
            this.incidentPanel.Controls.Add(this.incidentsPictureBox);
            this.incidentPanel.Controls.Add(this.incidentLabel);
            this.incidentPanel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.incidentPanel.Location = new System.Drawing.Point(0, 347);
            this.incidentPanel.Margin = new System.Windows.Forms.Padding(0);
            this.incidentPanel.Name = "incidentPanel";
            this.incidentPanel.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.incidentPanel.Size = new System.Drawing.Size(200, 40);
            this.incidentPanel.TabIndex = 13;
            this.incidentPanel.Tag = "Incident";
            this.incidentPanel.Click += new System.EventHandler(this.incidentPanel_Click);
            this.incidentPanel.MouseEnter += new System.EventHandler(this.Button_MouseEnter);
            this.incidentPanel.MouseLeave += new System.EventHandler(this.Button_MouseLeave);
            // 
            // incidentsPictureBox
            // 
            this.incidentsPictureBox.BackColor = System.Drawing.Color.WhiteSmoke;
            this.incidentsPictureBox.Image = global::Gestion_camping.Properties.Resources.icons8_erreur_96;
            this.incidentsPictureBox.Location = new System.Drawing.Point(5, 5);
            this.incidentsPictureBox.Name = "incidentsPictureBox";
            this.incidentsPictureBox.Size = new System.Drawing.Size(30, 30);
            this.incidentsPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.incidentsPictureBox.TabIndex = 1;
            this.incidentsPictureBox.TabStop = false;
            this.incidentsPictureBox.Tag = "Incident";
            this.incidentsPictureBox.Click += new System.EventHandler(this.incidentPanel_Click);
            this.incidentsPictureBox.MouseEnter += new System.EventHandler(this.Button_MouseEnter);
            this.incidentsPictureBox.MouseLeave += new System.EventHandler(this.Button_MouseLeave);
            // 
            // incidentLabel
            // 
            this.incidentLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.incidentLabel.AutoSize = true;
            this.incidentLabel.BackColor = System.Drawing.Color.WhiteSmoke;
            this.incidentLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.incidentLabel.Location = new System.Drawing.Point(76, 16);
            this.incidentLabel.Name = "incidentLabel";
            this.incidentLabel.Size = new System.Drawing.Size(85, 24);
            this.incidentLabel.TabIndex = 0;
            this.incidentLabel.Tag = "Incident";
            this.incidentLabel.Text = "Incidents";
            this.incidentLabel.Click += new System.EventHandler(this.incidentPanel_Click);
            this.incidentLabel.MouseEnter += new System.EventHandler(this.Button_MouseEnter);
            this.incidentLabel.MouseLeave += new System.EventHandler(this.Button_MouseLeave);
            // 
            // clientPanel
            // 
            this.clientPanel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.clientPanel.BackColor = System.Drawing.Color.Transparent;
            this.clientPanel.Controls.Add(this.clientPictureBox);
            this.clientPanel.Controls.Add(this.clientLabel);
            this.clientPanel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.clientPanel.Location = new System.Drawing.Point(0, 142);
            this.clientPanel.Margin = new System.Windows.Forms.Padding(0);
            this.clientPanel.Name = "clientPanel";
            this.clientPanel.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.clientPanel.Size = new System.Drawing.Size(200, 40);
            this.clientPanel.TabIndex = 10;
            this.clientPanel.Tag = "Clients";
            this.clientPanel.Click += new System.EventHandler(this.clientPanel_Click);
            this.clientPanel.MouseEnter += new System.EventHandler(this.Button_MouseEnter);
            this.clientPanel.MouseLeave += new System.EventHandler(this.Button_MouseLeave);
            // 
            // clientPictureBox
            // 
            this.clientPictureBox.BackColor = System.Drawing.Color.WhiteSmoke;
            this.clientPictureBox.Image = global::Gestion_camping.Properties.Resources.icons8_groupe_d_utilisateurs_homme_homme_96;
            this.clientPictureBox.Location = new System.Drawing.Point(5, 5);
            this.clientPictureBox.Name = "clientPictureBox";
            this.clientPictureBox.Size = new System.Drawing.Size(30, 30);
            this.clientPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.clientPictureBox.TabIndex = 1;
            this.clientPictureBox.TabStop = false;
            this.clientPictureBox.Tag = "Clients";
            this.clientPictureBox.Click += new System.EventHandler(this.clientPanel_Click);
            this.clientPictureBox.MouseEnter += new System.EventHandler(this.Button_MouseEnter);
            this.clientPictureBox.MouseLeave += new System.EventHandler(this.Button_MouseLeave);
            // 
            // clientLabel
            // 
            this.clientLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.clientLabel.AutoSize = true;
            this.clientLabel.BackColor = System.Drawing.Color.WhiteSmoke;
            this.clientLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clientLabel.Location = new System.Drawing.Point(69, 8);
            this.clientLabel.Name = "clientLabel";
            this.clientLabel.Size = new System.Drawing.Size(66, 24);
            this.clientLabel.TabIndex = 0;
            this.clientLabel.Tag = "Clients";
            this.clientLabel.Text = "Clients";
            this.clientLabel.Click += new System.EventHandler(this.clientPanel_Click);
            this.clientLabel.MouseEnter += new System.EventHandler(this.Button_MouseEnter);
            this.clientLabel.MouseLeave += new System.EventHandler(this.Button_MouseLeave);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Gabriola", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label6.Location = new System.Drawing.Point(0, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(261, 68);
            this.label6.TabIndex = 7;
            this.label6.Text = "LES FLOTS BLANCS";
            // 
            // profilPanel
            // 
            this.profilPanel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.profilPanel.BackColor = System.Drawing.Color.Transparent;
            this.profilPanel.Controls.Add(this.profileGroupBox);
            this.profilPanel.Controls.Add(this.monthCalendar);
            this.profilPanel.Controls.Add(this.deconnectionButton);
            this.profilPanel.Controls.Add(this.profileLabel);
            this.profilPanel.Location = new System.Drawing.Point(1007, 3);
            this.profilPanel.Name = "profilPanel";
            this.profilPanel.Size = new System.Drawing.Size(259, 650);
            this.profilPanel.TabIndex = 29;
            // 
            // profileGroupBox
            // 
            this.profileGroupBox.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.profileGroupBox.BackColor = System.Drawing.Color.Transparent;
            this.profileGroupBox.Controls.Add(this.profileRoleLabel);
            this.profileGroupBox.Controls.Add(this.profileNameLabel);
            this.profileGroupBox.Controls.Add(this.profilePictureBox);
            this.profileGroupBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.profileGroupBox.Location = new System.Drawing.Point(10, 38);
            this.profileGroupBox.Name = "profileGroupBox";
            this.profileGroupBox.Size = new System.Drawing.Size(246, 113);
            this.profileGroupBox.TabIndex = 0;
            this.profileGroupBox.TabStop = false;
            // 
            // profileRoleLabel
            // 
            this.profileRoleLabel.AutoSize = true;
            this.profileRoleLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.profileRoleLabel.Location = new System.Drawing.Point(98, 71);
            this.profileRoleLabel.Name = "profileRoleLabel";
            this.profileRoleLabel.Size = new System.Drawing.Size(33, 18);
            this.profileRoleLabel.TabIndex = 2;
            this.profileRoleLabel.Text = "rôle";
            // 
            // profileNameLabel
            // 
            this.profileNameLabel.AutoSize = true;
            this.profileNameLabel.BackColor = System.Drawing.Color.Transparent;
            this.profileNameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.profileNameLabel.Location = new System.Drawing.Point(97, 19);
            this.profileNameLabel.Name = "profileNameLabel";
            this.profileNameLabel.Size = new System.Drawing.Size(96, 20);
            this.profileNameLabel.TabIndex = 1;
            this.profileNameLabel.Text = "profile name";
            // 
            // profilePictureBox
            // 
            this.profilePictureBox.Image = global::Gestion_camping.Properties.Resources.icons8_person_64;
            this.profilePictureBox.Location = new System.Drawing.Point(6, 19);
            this.profilePictureBox.Name = "profilePictureBox";
            this.profilePictureBox.Size = new System.Drawing.Size(85, 70);
            this.profilePictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.profilePictureBox.TabIndex = 0;
            this.profilePictureBox.TabStop = false;
            // 
            // monthCalendar
            // 
            this.monthCalendar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.monthCalendar.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.monthCalendar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.monthCalendar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.monthCalendar.Location = new System.Drawing.Point(11, 166);
            this.monthCalendar.Name = "monthCalendar";
            this.monthCalendar.TabIndex = 1;
            this.monthCalendar.TitleBackColor = System.Drawing.Color.MediumAquamarine;
            this.monthCalendar.TrailingForeColor = System.Drawing.Color.MediumSeaGreen;
            // 
            // deconnectionButton
            // 
            this.deconnectionButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.deconnectionButton.BackColor = System.Drawing.Color.Transparent;
            this.deconnectionButton.FlatAppearance.BorderSize = 0;
            this.deconnectionButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.deconnectionButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.deconnectionButton.Image = global::Gestion_camping.Properties.Resources.icons8_sortie_96;
            this.deconnectionButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.deconnectionButton.Location = new System.Drawing.Point(23, 594);
            this.deconnectionButton.Name = "deconnectionButton";
            this.deconnectionButton.Size = new System.Drawing.Size(222, 52);
            this.deconnectionButton.TabIndex = 4;
            this.deconnectionButton.Text = "Déconnexion";
            this.deconnectionButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.deconnectionButton.UseVisualStyleBackColor = false;
            this.deconnectionButton.Click += new System.EventHandler(this.deconnectionButton_Click);
            // 
            // profileLabel
            // 
            this.profileLabel.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.profileLabel.AutoSize = true;
            this.profileLabel.Location = new System.Drawing.Point(8, 4);
            this.profileLabel.Name = "profileLabel";
            this.profileLabel.Size = new System.Drawing.Size(66, 13);
            this.profileLabel.TabIndex = 1;
            this.profileLabel.Text = "Mon compte";
            // 
            // Panels
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Gestion_camping.Properties.Resources._3188055;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1264, 661);
            this.Controls.Add(this.panelLayout);
            this.Name = "Panels";
            this.Text = "Panels";
            this.Load += new System.EventHandler(this.Panels_Configs);
            this.Shown += new System.EventHandler(this.Panels_Configs);
            this.ClientSizeChanged += new System.EventHandler(this.Panels_Configs);
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.Panels_Paint);
            this.Resize += new System.EventHandler(this.Panels_Configs);
            this.panelLayout.ResumeLayout(false);
            this.menuPanel.ResumeLayout(false);
            this.menuPanel.PerformLayout();
            this.panelButtons.ResumeLayout(false);
            this.accueilPanel.ResumeLayout(false);
            this.accueilPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.accueilPictureBox)).EndInit();
            this.logPanel.ResumeLayout(false);
            this.logPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.logPictureBox)).EndInit();
            this.fournisseurPanel.ResumeLayout(false);
            this.fournisseurPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fournisseurPictureBox)).EndInit();
            this.panelReservation.ResumeLayout(false);
            this.panelReservation.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.reservationPictureBox)).EndInit();
            this.stockPanel.ResumeLayout(false);
            this.stockPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.stockPictureBox)).EndInit();
            this.incidentPanel.ResumeLayout(false);
            this.incidentPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.incidentsPictureBox)).EndInit();
            this.clientPanel.ResumeLayout(false);
            this.clientPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.clientPictureBox)).EndInit();
            this.profilPanel.ResumeLayout(false);
            this.profilPanel.PerformLayout();
            this.profileGroupBox.ResumeLayout(false);
            this.profileGroupBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.profilePictureBox)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Label profileLabel;
        private System.Windows.Forms.Button deconnectionButton;
        private System.Windows.Forms.MonthCalendar monthCalendar;
        private System.Windows.Forms.GroupBox profileGroupBox;
        private System.Windows.Forms.Label profileRoleLabel;
        private System.Windows.Forms.Label profileNameLabel;
        private System.Windows.Forms.PictureBox profilePictureBox;
        private System.Windows.Forms.Panel profilPanel;
        private System.Windows.Forms.Panel incidentPanel;
        private System.Windows.Forms.PictureBox incidentsPictureBox;
        private System.Windows.Forms.Label incidentLabel;
        private System.Windows.Forms.Panel stockPanel;
        private System.Windows.Forms.PictureBox stockPictureBox;
        private System.Windows.Forms.Label stockLabel;
        private System.Windows.Forms.Panel clientPanel;
        private System.Windows.Forms.PictureBox clientPictureBox;
        private System.Windows.Forms.Label clientLabel;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel accueilPanel;
        private System.Windows.Forms.PictureBox accueilPictureBox;
        private System.Windows.Forms.Label accueilLabel;
        private System.Windows.Forms.Panel contentPanel;
        private System.Windows.Forms.Panel panelLayout;
        private System.Windows.Forms.Panel menuPanel;
        private System.Windows.Forms.Panel panelReservation;
        private System.Windows.Forms.PictureBox reservationPictureBox;
        private System.Windows.Forms.Label labelReservation;
        private System.Windows.Forms.Panel fournisseurPanel;
        private System.Windows.Forms.PictureBox fournisseurPictureBox;
        private System.Windows.Forms.Label fournisseurLabel;
        private System.Windows.Forms.Panel panelButtons;
        private System.Windows.Forms.Panel logPanel;
        private System.Windows.Forms.PictureBox logPictureBox;
        private System.Windows.Forms.Label logLabel;
    }
}