﻿using System;
using System.Collections.Generic;
using System.Data.Entity.Validation;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MigraDoc.DocumentObjectModel;
using MigraDoc.DocumentObjectModel.Fields;
using MigraDoc.DocumentObjectModel.Shapes;
using MigraDoc.DocumentObjectModel.Tables;
using MigraDoc.Rendering;

namespace Gestion_camping
{
    internal class PDFGenerator
    {
        public class FacturePDF
        {
            Document document;
            DateTime date;
            Client client;
            public string filename;
            double totalPrix;

            public FacturePDF(Client client, DateTime date)
            {
                this.client = client;
                this.date = date;
                document = new Document();
                infoDocument();
                styleDocument();
                fillDocument();
                saveDocument();
            }

            public void infoDocument()
            {
                
                document.Info.Title = "Facture du " + date.Day + "/" + date.Month + "/" + date.Year + ".";
                document.Info.Subject = "Facture du " + date.Day + "/" + date.Month + "/" + date.Year + " à l'intention de " + client.nomClient + " " + client.prenomClient;
                document.Info.Author = "M. Campo";
            }

            public void styleDocument()
            {
                Style style = document.Styles["Normal"];

                style.Font.Name = "Verdana";
                style = document.Styles[StyleNames.Header];
                style.ParagraphFormat.AddTabStop("16cm", TabAlignment.Right);
                style = document.Styles[StyleNames.Footer];
                style.ParagraphFormat.AddTabStop("8cm", TabAlignment.Center);
                style = document.Styles.AddStyle("Table", "Normal");
                style.Font.Name = "Arial";
                style.Font.Size = 11;
                style = document.Styles.AddStyle("Reference", "Normal");
                style.ParagraphFormat.SpaceBefore = "5mm";
                style.ParagraphFormat.SpaceAfter = "5mm";
                style.ParagraphFormat.TabStops.AddTabStop("16cm", TabAlignment.Right);
            }

            public void fillDocument()
            {
                Section section = document.AddSection();

                Paragraph paragraph = section.Headers.Primary.AddParagraph();

                paragraph.AddText("Facture du ");
                paragraph.AddDateField("dd.MM.yyyy");
                paragraph.AddText(" à l'attention de " + client.nomClient + " " + client.prenomClient + ".");
                paragraph.Format.Font.Size = 15;
                paragraph.Format.Alignment = ParagraphAlignment.Center;

                TextFrame addressFrame = section.AddTextFrame();
                addressFrame.Width = "7.cm";
                addressFrame.Height = "1.cm";
                addressFrame.Left = ShapePosition.Left;
                addressFrame.Top = "4.cm";
                addressFrame.RelativeVertical = RelativeVertical.Page;
                paragraph = addressFrame.AddParagraph("Les Flots Blancs\n001 rue du Camping\n63160 Billom");

                addressFrame = section.AddTextFrame();
                addressFrame.Top = "5.cm";

                paragraph = addressFrame.AddParagraph(""+client.nomClient+" "+client.prenomClient+"\n"+client.telephoneClient);
                paragraph.Format.Font.Name = "Arial";
                paragraph.Format.Font.Size = 11;
                paragraph.Format.SpaceAfter = 3;

                paragraph = section.AddParagraph();
                paragraph.Style = "Reference";
                paragraph.AddFormattedText("Facture", TextFormat.Bold);
                paragraph.AddTab();
                paragraph.AddText("Les Flots Blancs, ");
                paragraph.AddDateField("dd.MM.yyyy");

                Table table = section.AddTable();

                table.Style = "Table";
                table.Borders.Color = Color.FromRgb(0, 0, 0);
                table.Borders.Width = .25;
                table.Borders.Left.Width = .5;
                table.Borders.Right.Width = .5;
                table.Rows.LeftIndent = 0;
                Column column = table.AddColumn("4cm");
                column.Format.Alignment = ParagraphAlignment.Center;

                column = table.AddColumn("3.5cm");
                column.Format.Alignment = ParagraphAlignment.Right;
                column = table.AddColumn("2.5cm");
                column.Format.Alignment = ParagraphAlignment.Right;

                column = table.AddColumn("3cm");
                column.Format.Alignment = ParagraphAlignment.Right;
                column = table.AddColumn("3.5cm");
                column.Format.Alignment = ParagraphAlignment.Right;
                Row row = table.AddRow();
                row.HeadingFormat = true;
                row.Format.Alignment = ParagraphAlignment.Center;
                row.Format.Font.Bold = true;
                row.Shading.Color = Color.FromRgb(255,255,255);
                row.Cells[0].AddParagraph("Réservation");
                row.Cells[0].Format.Font.Bold = true;
                row.Cells[0].Format.Alignment = ParagraphAlignment.Left;
                row.Cells[0].VerticalAlignment = VerticalAlignment.Bottom;
                row.Cells[0].MergeDown = 1;
                row.Cells[1].AddParagraph("Détails");
                row.Cells[1].Format.Alignment = ParagraphAlignment.Left;
                row.Cells[1].MergeRight = 2;
                row.Cells[4].AddParagraph("Prix");
                row.Cells[4].Format.Alignment = ParagraphAlignment.Left;
                row.Cells[4].VerticalAlignment = VerticalAlignment.Bottom;
                row.Cells[4].MergeDown = 1;
                row = table.AddRow();
                row.HeadingFormat = true;
                row.Format.Alignment = ParagraphAlignment.Center;
                row.Format.Font.Bold = true;
                row.Shading.Color = Color.FromRgb(255, 255, 255);
                row.Cells[1].AddParagraph("Nombre de jour");
                row.Cells[1].Format.Alignment = ParagraphAlignment.Left;
                row.Cells[2].AddParagraph("Prix unité");
                row.Cells[2].Format.Alignment = ParagraphAlignment.Left;
                row.Cells[3].AddParagraph("Réduction");
                row.Cells[3].Format.Alignment = ParagraphAlignment.Left;

                int count = 3;
                totalPrix = 0.00;
                Reservation[] reservations = Program.bdEntities.Reservation.Where(r => r.dateDebut.Day == date.Day && r.dateDebut.Month == date.Month && r.dateDebut.Year == date.Year && r.clientID == client.ClientID).ToArray();
                foreach(Reservation res in reservations)
                {
                    count++;
                    double duree = (res.dateFin - res.dateDebut).TotalDays;
                    double prix = 13.99;
                    double total = (prix * duree);
                    totalPrix+=total;
                    row = table.AddRow();
                    row.Borders.Top.Width = 0;
                    row.Borders.Bottom.Width = 0;
                    row.HeadingFormat = false;
                    row.Format.Alignment = ParagraphAlignment.Center;
                    row.Format.Font.Bold = false;
                    row.Shading.Color = Color.FromRgb(255, 255, 255);
                    row.Cells[0].AddParagraph("Emplacement : " +res.Emplacement.intitule);
                    row.Cells[0].Format.Alignment = ParagraphAlignment.Left;
                    row.Cells[1].AddParagraph(""+duree+"j");
                    row.Cells[1].Format.Alignment = ParagraphAlignment.Left;
                    row.Cells[2].AddParagraph(""+prix+"€");
                    row.Cells[2].Format.Alignment = ParagraphAlignment.Left;
                    row.Cells[3].AddParagraph("");
                    row.Cells[3].Format.Alignment = ParagraphAlignment.Left;
                    row.Cells[4].AddParagraph("" + total + "€");
                    row.Cells[4].Format.Alignment = ParagraphAlignment.Left;
                }
                row = table.AddRow();
                row.Borders.Color = Color.FromRgb(255, 255, 255);
                row.Borders.Top.Color = Color.FromRgb(0, 0, 0);

                row.HeadingFormat = false;
                row.Format.Alignment = ParagraphAlignment.Center;
                row.Format.Font.Bold = true;
                row.Shading.Color = Color.FromRgb(255, 255, 255);
                row.Cells[2].Borders.Right.Color = Color.FromRgb(0, 0, 0);
                row.Cells[3].AddParagraph("Total");
                row.Cells[3].Format.Alignment = ParagraphAlignment.Left;
                row.Cells[3].Borders.Color = Color.FromRgb(0, 0, 0);
                row.Cells[4].AddParagraph("" + totalPrix + "€");
                row.Cells[4].Format.Alignment = ParagraphAlignment.Left;
                row.Cells[4].Borders.Color = Color.FromRgb(0, 0, 0);

                table.SetEdge(0, 0, 5, count, Edge.Box, BorderStyle.Single, .75, Color.Empty);
            }

            public void saveDocument()
            {
                PdfDocumentRenderer pdfRenderer = new PdfDocumentRenderer();

                pdfRenderer.Document = document;

                pdfRenderer.RenderDocument();

                filename = "Facture-" + date.Day + "-" + date.Month + "-" + date.Year + "_"+ client.nomClient+"-"+client.prenomClient+".pdf";
                string path = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + "/Camping/Factures/";
                System.IO.Directory.CreateDirectory(path);
                filename = path + filename;
                Facture facture = new Facture();
                facture.Client = client;
                facture.clientID = client.ClientID;
                facture.montant = totalPrix;
                facture.dateCreation = DateTime.Now;
                pdfRenderer.PdfDocument.Save(filename);
                facture.pdf = filename;
                facture.description = filename;
                Program.bdEntities.Facture.Add(facture);
                Program.bdEntities.SaveChanges();
                
            }
        }
        public class IncidentPDF
        {
            Document document;
            DateTime date;
            Incident incident;
            public string filename;
            String details;

            public IncidentPDF(Incident incident, DateTime date, String details)
            {
                this.incident = incident;
                this.date = date;
                this.details = details;
                document = new Document();
                infoDocument();
                styleDocument();
                fillDocument();
                saveDocument();
            }

            public void infoDocument()
            {

                document.Info.Title = "Rapport d'incident du " + date.Day + "/" + date.Month + "/" + date.Year + ".";
                document.Info.Subject = "Rapport d'incident du " + date.Day + "/" + date.Month + "/" + date.Year + ".";
                document.Info.Author = "M. Campo";
            }

            public void styleDocument()
            {
                Style style = document.Styles["Normal"];

                style.Font.Name = "Verdana";
                style.Font.Name = "Arial";
                style.Font.Size = 11;
            }

            public void fillDocument()
            {
                Section section = document.AddSection();

                Paragraph paragraph = section.Headers.Primary.AddParagraph();

                paragraph.AddText("Rapport d'incident du ");
                paragraph.AddDateField("dd.MM.yyyy");
                paragraph.AddText(".");
                paragraph.Format.Font.Size = 15;
                paragraph.Format.Alignment = ParagraphAlignment.Center;

                TextFrame addressFrame = section.AddTextFrame();
                addressFrame.Width = "16cm";
                addressFrame.Left = ShapePosition.Left;
                addressFrame.Top = "4.cm";
                addressFrame.RelativeVertical = RelativeVertical.Page;
                paragraph = addressFrame.AddParagraph(incident.description + " à l'emplacement " + incident.Emplacement);

                paragraph = addressFrame.AddParagraph("\n" + details);
                paragraph.Format.Alignment = ParagraphAlignment.Justify;
                paragraph.Format.Font.Name = "Arial";
                paragraph.Format.Font.Size = 11;
                paragraph.Format.SpaceAfter = 3;
            }

            public void saveDocument()
            {
                PdfDocumentRenderer pdfRenderer = new PdfDocumentRenderer();

                pdfRenderer.Document = document;

                pdfRenderer.RenderDocument();

                filename = "Rapport-incident_" + date.Day + "-" + date.Month + "-" + date.Year + "_" + incident.emplacementID + ".pdf";
                string path = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + "/Camping/Incident/";
                System.IO.Directory.CreateDirectory(path);
                filename = path + filename;
                pdfRenderer.PdfDocument.Save(filename);
            }
        }
    }
}
