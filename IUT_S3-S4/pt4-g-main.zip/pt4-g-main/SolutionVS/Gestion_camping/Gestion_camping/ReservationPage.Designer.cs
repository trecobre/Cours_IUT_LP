﻿namespace Gestion_camping
{
    partial class ReservationPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ReservationPanel = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.labelAstuce = new System.Windows.Forms.Label();
            this.flowLayoutPanelRes = new System.Windows.Forms.FlowLayoutPanel();
            this.button1 = new System.Windows.Forms.Button();
            this.panelRes = new System.Windows.Forms.Panel();
            this.buttonSupprimer = new System.Windows.Forms.Button();
            this.buttonFin = new System.Windows.Forms.Button();
            this.labelStatut = new System.Windows.Forms.Label();
            this.labelFin = new System.Windows.Forms.Label();
            this.labelDebut = new System.Windows.Forms.Label();
            this.labelEmplacement = new System.Windows.Forms.Label();
            this.labelNumClient = new System.Windows.Forms.Label();
            this.labelClient = new System.Windows.Forms.Label();
            this.ReservationPanel.SuspendLayout();
            this.panelRes.SuspendLayout();
            this.SuspendLayout();
            // 
            // ReservationPanel
            // 
            this.ReservationPanel.BackColor = System.Drawing.Color.Transparent;
            this.ReservationPanel.Controls.Add(this.button1);
            this.ReservationPanel.Controls.Add(this.labelAstuce);
            this.ReservationPanel.Controls.Add(this.flowLayoutPanelRes);
            this.ReservationPanel.Location = new System.Drawing.Point(29, 30);
            this.ReservationPanel.Name = "ReservationPanel";
            this.ReservationPanel.Size = new System.Drawing.Size(713, 459);
            this.ReservationPanel.TabIndex = 25;
            this.ReservationPanel.SizeChanged += new System.EventHandler(this.ReservationPanel_SizeChanged);
            // 
            // button1
            // 
            this.button1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.button1.BackgroundImage = global::Gestion_camping.Properties.Resources.icons8_plus_96;
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.LightSeaGreen;
            this.button1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.MediumAquamarine;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Location = new System.Drawing.Point(670, 3);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(40, 40);
            this.button1.TabIndex = 2;
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            this.flowLayoutPanelRes.Scroll += new System.Windows.Forms.ScrollEventHandler(this.flowLayoutPanelRes_Scroll);
            // 
            // labelAstuce
            // 
            this.labelAstuce.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.labelAstuce.AutoSize = true;
            this.labelAstuce.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelAstuce.Location = new System.Drawing.Point(185, 433);
            this.labelAstuce.Name = "labelAstuce";
            this.labelAstuce.Size = new System.Drawing.Size(494, 20);
            this.labelAstuce.TabIndex = 27;
            this.labelAstuce.Text = "Astuce : Cliquez sur une réservation pour la modifier ou voir la facture";
            // 
            // flowLayoutPanelRes
            // 
            this.flowLayoutPanelRes.AutoScroll = true;
            this.flowLayoutPanelRes.FlowDirection = System.Windows.Forms.FlowDirection.RightToLeft;
            this.flowLayoutPanelRes.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.flowLayoutPanelRes.Location = new System.Drawing.Point(0, 49);
            this.flowLayoutPanelRes.Name = "flowLayoutPanelRes";
            this.flowLayoutPanelRes.Size = new System.Drawing.Size(713, 382);
            this.flowLayoutPanelRes.TabIndex = 26;
            // 
            // panelRes
            // 
            this.panelRes.BackColor = System.Drawing.Color.WhiteSmoke;
            this.panelRes.Controls.Add(this.buttonSupprimer);
            this.panelRes.Controls.Add(this.buttonFin);
            this.panelRes.Controls.Add(this.labelStatut);
            this.panelRes.Controls.Add(this.labelFin);
            this.panelRes.Controls.Add(this.labelDebut);
            this.panelRes.Controls.Add(this.labelEmplacement);
            this.panelRes.Controls.Add(this.labelNumClient);
            this.panelRes.Controls.Add(this.labelClient);
            this.panelRes.Location = new System.Drawing.Point(776, 189);
            this.panelRes.Name = "panelRes";
            this.panelRes.Size = new System.Drawing.Size(499, 96);
            this.panelRes.TabIndex = 26;
            this.panelRes.Click += new System.EventHandler(this.modifie);
            // 
            // buttonSupprimer
            // 
            this.buttonSupprimer.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonSupprimer.Location = new System.Drawing.Point(330, 50);
            this.buttonSupprimer.Name = "buttonSupprimer";
            this.buttonSupprimer.Size = new System.Drawing.Size(154, 23);
            this.buttonSupprimer.TabIndex = 36;
            this.buttonSupprimer.Text = "Supprimer la réservation";
            this.buttonSupprimer.UseVisualStyleBackColor = true;
            this.buttonSupprimer.Click += new System.EventHandler(this.buttonSupprimer_Click);
            // 
            // buttonFin
            // 
            this.buttonFin.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonFin.Location = new System.Drawing.Point(330, 10);
            this.buttonFin.Name = "buttonFin";
            this.buttonFin.Size = new System.Drawing.Size(154, 23);
            this.buttonFin.TabIndex = 35;
            this.buttonFin.Text = "Mettre fin à la réservation";
            this.buttonFin.UseVisualStyleBackColor = true;
            this.buttonFin.Click += new System.EventHandler(this.buttonFin_Click);
            // 
            // labelStatut
            // 
            this.labelStatut.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.labelStatut.AutoSize = true;
            this.labelStatut.BackColor = System.Drawing.Color.Transparent;
            this.labelStatut.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelStatut.ForeColor = System.Drawing.SystemColors.ControlText;
            this.labelStatut.Location = new System.Drawing.Point(227, 50);
            this.labelStatut.MaximumSize = new System.Drawing.Size(105, 36);
            this.labelStatut.Name = "labelStatut";
            this.labelStatut.Padding = new System.Windows.Forms.Padding(10);
            this.labelStatut.Size = new System.Drawing.Size(97, 36);
            this.labelStatut.TabIndex = 34;
            this.labelStatut.Text = "EN COURS";
            this.labelStatut.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.labelStatut.Click += new System.EventHandler(this.modifie);
            // 
            // labelFin
            // 
            this.labelFin.AutoSize = true;
            this.labelFin.BackColor = System.Drawing.Color.Transparent;
            this.labelFin.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelFin.ForeColor = System.Drawing.SystemColors.ControlText;
            this.labelFin.Location = new System.Drawing.Point(130, 53);
            this.labelFin.MaximumSize = new System.Drawing.Size(105, 36);
            this.labelFin.Name = "labelFin";
            this.labelFin.Padding = new System.Windows.Forms.Padding(10);
            this.labelFin.Size = new System.Drawing.Size(91, 36);
            this.labelFin.TabIndex = 33;
            this.labelFin.Text = "01/01/2011";
            this.labelFin.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.labelFin.Click += new System.EventHandler(this.modifie);
            // 
            // labelDebut
            // 
            this.labelDebut.AutoSize = true;
            this.labelDebut.BackColor = System.Drawing.Color.Transparent;
            this.labelDebut.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelDebut.ForeColor = System.Drawing.SystemColors.ControlText;
            this.labelDebut.Location = new System.Drawing.Point(44, 53);
            this.labelDebut.MaximumSize = new System.Drawing.Size(105, 36);
            this.labelDebut.Name = "labelDebut";
            this.labelDebut.Padding = new System.Windows.Forms.Padding(10);
            this.labelDebut.Size = new System.Drawing.Size(91, 36);
            this.labelDebut.TabIndex = 32;
            this.labelDebut.Text = "01/01/2011";
            this.labelDebut.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.labelDebut.Click += new System.EventHandler(this.modifie);
            // 
            // labelEmplacement
            // 
            this.labelEmplacement.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.labelEmplacement.AutoSize = true;
            this.labelEmplacement.BackColor = System.Drawing.Color.Transparent;
            this.labelEmplacement.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelEmplacement.ForeColor = System.Drawing.SystemColors.ControlText;
            this.labelEmplacement.Location = new System.Drawing.Point(0, 50);
            this.labelEmplacement.MaximumSize = new System.Drawing.Size(105, 36);
            this.labelEmplacement.Name = "labelEmplacement";
            this.labelEmplacement.Padding = new System.Windows.Forms.Padding(10);
            this.labelEmplacement.Size = new System.Drawing.Size(50, 36);
            this.labelEmplacement.TabIndex = 31;
            this.labelEmplacement.Text = "A11";
            this.labelEmplacement.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.labelEmplacement.Click += new System.EventHandler(this.modifie);
            // 
            // labelNumClient
            // 
            this.labelNumClient.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.labelNumClient.AutoSize = true;
            this.labelNumClient.BackColor = System.Drawing.Color.Transparent;
            this.labelNumClient.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelNumClient.ForeColor = System.Drawing.SystemColors.ControlText;
            this.labelNumClient.Location = new System.Drawing.Point(227, 10);
            this.labelNumClient.MaximumSize = new System.Drawing.Size(105, 36);
            this.labelNumClient.Name = "labelNumClient";
            this.labelNumClient.Padding = new System.Windows.Forms.Padding(10);
            this.labelNumClient.Size = new System.Drawing.Size(97, 36);
            this.labelNumClient.TabIndex = 29;
            this.labelNumClient.Text = "0000000000";
            this.labelNumClient.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.labelNumClient.Click += new System.EventHandler(this.modifie);
            // 
            // labelClient
            // 
            this.labelClient.AutoSize = true;
            this.labelClient.BackColor = System.Drawing.Color.Transparent;
            this.labelClient.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelClient.ForeColor = System.Drawing.SystemColors.ControlText;
            this.labelClient.Location = new System.Drawing.Point(0, 9);
            this.labelClient.MaximumSize = new System.Drawing.Size(305, 36);
            this.labelClient.Name = "labelClient";
            this.labelClient.Padding = new System.Windows.Forms.Padding(10);
            this.labelClient.Size = new System.Drawing.Size(53, 36);
            this.labelClient.TabIndex = 27;
            this.labelClient.Text = "nom";
            this.labelClient.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.labelClient.Click += new System.EventHandler(this.modifie);
            // 
            // ReservationPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1486, 635);
            this.Controls.Add(this.ReservationPanel);
            this.Controls.Add(this.panelRes);
            this.Name = "ReservationPage";
            this.Text = "ReservationPage";
            this.ReservationPanel.ResumeLayout(false);
            this.ReservationPanel.PerformLayout();
            this.panelRes.ResumeLayout(false);
            this.panelRes.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel ReservationPanel;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Panel panelRes;
        private System.Windows.Forms.Label labelClient;
        private System.Windows.Forms.Label labelFin;
        private System.Windows.Forms.Label labelDebut;
        private System.Windows.Forms.Label labelEmplacement;
        private System.Windows.Forms.Label labelNumClient;
        private System.Windows.Forms.Button buttonSupprimer;
        private System.Windows.Forms.Button buttonFin;
        private System.Windows.Forms.Label labelStatut;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanelRes;
        private System.Windows.Forms.Label labelAstuce;
    }
}