﻿using Gestion_camping;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Gestion_camping.Resources;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Security.Cryptography;

namespace Gestion_camping.Resources.Tests
{
    [TestClass()]
    public class InscriptionTests
    {
        public Utilisateur utilisateur = new Utilisateur();
        MD5 saltForHash = MD5.Create();
        string login = "test99";

        [TestMethod()]
        public void T1_InscriptionTest()
        {
            var salting = saltForHash.ComputeHash(new UTF8Encoding().GetBytes("testLog3*"));
            string hash = BitConverter.ToString(salting).Replace("-", string.Empty);
            utilisateur.login = login;
            utilisateur.nomUtilisateur = "test";
            utilisateur.password = hash;
            utilisateur.prenomUtilisateur = "99";
            utilisateur.telephoneUtilisateur = "012345679";
            Utils.Inscription(utilisateur);
        }

        [TestMethod()]
        public void T2_ConnexionTest()
        {
            Utilisateur user = Utils.Connexion(login);
            Assert.AreEqual(user.login, login);
        }

        [TestMethod()]
        public void T3_SuppressionUtilisateur()
        {
            Utilisateur user = Utils.Connexion(login);
            Utils.SuppresionUtilisateur(user.UtilisateurID);
        }
    }
}