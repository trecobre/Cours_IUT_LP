﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Gestion_camping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Security.Cryptography;

namespace Gestion_camping.Tests
{
    [TestClass()]
    public class AjouterStockTests
    {
        [TestMethod()]
        public void AjouterStockTest()
        {
            
        }

        [TestMethod()]
        public void getDataTest()
        {
            //Assert.Fail();
        }
    }
}