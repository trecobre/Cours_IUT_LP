﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Gestion_camping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gestion_camping.Tests
{
    [TestClass()]
    public class ReservationTest
    {
        Client client = new Client();
        Reservation reservation = new Reservation();


        public void init()
        {
            client.mailClient = "test99@gmail.fr";
            client.telephoneClient = "0123456789";
            client.nomClient = "test";
            client.prenomClient = "199";
            Utils.modifierAjouterClient(client);
        }
        
        [TestMethod()]
        public void T1_ajouterReservationTest()
        {
            try
            {
                init();
                reservation.Client = client;
                reservation.dateDebut = DateTime.Now;
                reservation.dateFin = DateTime.MaxValue;
                Utils.ajouterReservation(reservation);
                Assert.IsTrue(true);
            } catch (Exception ex)
            {
                Assert.Fail(ex.Message);
            }
        }

        [TestMethod()]
        public void T2_getReservationTest()
        {
            Reservation res = Utils.reservationGet(reservation.ReservationID);
            Assert.Equals(res.Client.nomClient, reservation.Client.nomClient);
        }
    }
}