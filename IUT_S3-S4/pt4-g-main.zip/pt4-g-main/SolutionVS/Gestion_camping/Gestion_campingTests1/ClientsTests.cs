﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Gestion_camping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gestion_camping.Tests
{
    [TestClass()]
    public class ClientTests
    {
        [TestMethod()]
        public void T1_ajouterClientTest()
        {
            Client client = new Client();
            client.nomClient = "nomclient99";
            client.prenomClient = "prenomclient99";
            client.telephoneClient = "0123456789"; 
            
            if (T3_IsValidEmailTest("client99@gmail.com")) {
                client.mailClient = "client99@gmail.com" ;
            } else {
                Assert.Fail("Mail invalide");
            }
            try
            {
                Utils.modifierAjouterClient(client);
                Assert.IsTrue(true);
            } catch (Exception ex)
            {
                Assert.Fail(ex.Message);
            }
        }

        //public void T2_getClient()
        //{
        //    Utils.getClient()
        //}

        public void T2_modifierClientTest()
        {
            Client client = new Client();
            client.nomClient = "nomclient99";
            client.prenomClient = "prenomclient99";
            client.telephoneClient = "0123456789";

            if (T3_IsValidEmailTest("client99@gmail.com"))
            {
                client.mailClient = "client99@gmail.com";
            }
            else
            {
                Assert.Fail("Mail invalide");
            }
            try
            {
                Utils.modifierAjouterClient(client);
                Assert.IsTrue(true);
            }
            catch (Exception ex)
            {
                Assert.Fail(ex.Message);
            }
        }

        [TestMethod()]
        public bool T3_IsValidEmailTest(string email)
        {
            bool validMail = modifClientPage.IsValidEmail(email);
            Assert.IsTrue(validMail);
            Assert.IsFalse(modifClientPage.IsValidEmail("jeNeSuisPasUnMail.com"));
            return validMail;
        }
    }
}