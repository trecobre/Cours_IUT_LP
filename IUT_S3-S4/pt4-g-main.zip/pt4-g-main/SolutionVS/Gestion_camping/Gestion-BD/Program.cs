﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gestion_BD
{
    internal static class Program
    {
        /// <summary>
        /// Point d'entrée principal de l'application.
        /// </summary>
        [STAThread]
        public static BD_PT4_S4D_E1Entities bdEntities = new BD_PT4_S4D_E1Entities();

        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Program.bdEntities.Facture.RemoveRange(Program.bdEntities.Facture);
            Program.bdEntities.Client.RemoveRange(Program.bdEntities.Client);
            Program.bdEntities.Fournisseur.RemoveRange(Program.bdEntities.Fournisseur);
            Program.bdEntities.Produit.RemoveRange(Program.bdEntities.Produit);
            Program.bdEntities.Zone.RemoveRange(Program.bdEntities.Zone);
            Program.bdEntities.Emplacement.RemoveRange(Program.bdEntities.Emplacement);
            Program.bdEntities.Incident.RemoveRange(Program.bdEntities.Incident);//TODO
            Program.bdEntities.Achat.RemoveRange(Program.bdEntities.Achat);
            Program.bdEntities.Stock.RemoveRange(Program.bdEntities.Stock);
            Program.bdEntities.Vente.RemoveRange(Program.bdEntities.Vente);
            Program.bdEntities.Reservation.RemoveRange(Program.bdEntities.Reservation);
            Program.bdEntities.SaveChanges();
        }
    }
}
