let univers = [[new cellule(0,0)]]
let list_atome = [new cellule(0,0)]

let nb_atome = 5
let selection = 0
let score = 0
let fin = false
let debug = false
let coins = [false, false, false, false];

function init(){
    console.log("Pour activer le mode débug il faut cliquer dans cet ordre : \n - Le coin en haut à gauche \n - Le coin en haut à droite \n - Le coin en bas à gauche \n - Le coin en bas à droite \n - Bouton valider \nVoilà voilà ^^")
    document.body.style.backgroundColor = "#272822";
    document.body.style.fontFamily = "sans-serif"
    var tab= document.createElement("table");
    tab.style.borderCollapse = "collapse";
    tab.style.border = "solid 2px grey";
    tab.style.borderBottom = "solid darkslategrey";
    tab.style.borderRight = "solid darkslategrey";
    univers.pop();
    creerUnivers();
    placerAtome();
    univers.forEach(u_line => {
        var line = document.createElement("tr");
        u_line.forEach(cell => {
            line.appendChild(cell.dom);
        });
        tab.appendChild(line);
    });
    var elem = document.createElement("p");
    var titre = document.getElementById("titre");
    titre.style.textAlign = "center";
    titre.textContent = "TP Secret";
    titre.style.color = "white"

    var button = document.getElementById("validate");
    button.addEventListener("click", () => { 
        if(selection>=5){
            elem.style.color = "white"
            elem.textContent = "your score is " + score;
            fin = true;
            show_atome();
        }
        else if( coins[0] && coins[1] && coins[2] && coins[3]){
            
            titre.textContent = "Debug mode";
            show_atome();
        }
     }, false);
    button.style.padding = "10px";
    button.style.borderRadius = "20px";
    button.style.border = "none"
    button.style.backgroundColor = "grey"
    button.addEventListener("mouseenter", ()=> {
        button.style.backgroundColor = "darkgrey";
      }, false);
    button.addEventListener("mouseleave", ()=> {
        button.style.backgroundColor = "grey";
      }, false);
    
    var bouton = document.getElementById("bouton");
    bouton.style.display = "flex";
    bouton.style.flexDirection = "column"
    bouton.style.alignItems = "center";
    
    var jeu = document.getElementById("jeu");
    jeu.style.display = "flex";
    jeu.style.flexDirection = "column"
    jeu.style.alignItems = "center";
    jeu.appendChild(tab);
    jeu.appendChild(elem);
}

function show_atome(){
    for(i=1; i<9; i++){
        for(j=1; j<9; j++){
            if(univers[i][j].atome){
                var rond = document.createElement("div");
                rond.style.height = "50px";
                rond.style.width = "50px";
                rond.style.borderRadius = "50%";
                if(debug){
                    rond.style.backgroundColor = "#762B42";
                }
                else if(univers[i][j].etat == 1){
                    rond.style.backgroundColor = "green";
                }
                else{
                    rond.style.backgroundColor = "red";
                }
                if(univers[i][j].dom.hasChildNodes()){
                    univers[i][j].dom.removeChild(univers[i][j].dom.lastChild);
                }
                univers[i][j].dom.appendChild(rond);

            }
        }
    }
}

function changeWhite(element){
    if(!fin){
        if(element.etat == -1){
            var rond = document.createElement("div");
            rond.style.height = "50px";
            rond.style.width = "50px";
            rond.style.borderRadius = "50%";
            if(!element.atome){
                score -= 5
            }
            rond.style.backgroundColor = "orange";
            element.etat = 1;
            selection++;
            if(element.dom.hasChildNodes()){
                element.dom.removeChild(element.dom.lastChild);
            }
            element.dom.appendChild(rond);
        }
        else if(element.etat == 1){
            selection--;
            element.dom.removeChild(element.dom.lastChild);
            element.etat =-1;
        }
    }
}
function changeGrey(element){
    if(!fin){
        if(element.etat == -1){
            a = Math.random()*255;
            b = Math.random()*255;
            c = Math.random()*255;
            element.dom.style.backgroundColor = "rgb("+a+","+b+","+c+")";
            element.etat = 1;
            if(element.li == 0 || element.li == 9){
                rayon_x("v", element.co, element.li==0);
            }
            else{
                rayon_x("h", element.li, element.co==0);
            }
        }
    }
}      



function cellule(li, co) {
    this.li = li;
    this.co = co;
    this.etat = -1;
    this.atome = false;
    this.dom = document.createElement("td");
    this.grille = (li > 0) && (li < 9) && (co > 0) && (co < 9);

    this.dom.style.height = "50px";
    this.dom.style.width = "50px";
    this.dom.style.border = "solid 1px";

    this.initialiser=function() {
        var couleur = "";
        if (
            (this.li === 0 && this.co === 0) || 
            (this.li === 0 && this.co === 9) || 
            (this.li === 9 && this.co === 0) || 
            (this.li === 9 && this.co === 9)) 
        { // les 4 coins
            couleur = 'grey';
            this.dom.addEventListener("click", ()=> {
                if(this.li == 0 && this.co == 0){
                    coins[0] = !coins[0];
                }
                else if(this.li == 0 && this.co == 9 && coins[0]){
                    coins[1] = !coins[1];
                }
                else if(this.li == 9 && this.co == 0 && coins[1]){
                    coins[2] = !coins[2];
                }
                else if(this.li == 9 && this.co == 9 && coins[2]){
                    coins[3] = !coins[3];
                    debug=true;
                }
            }, false)
        } 
        else if (this.li === 0 || this.co === 0 || this.li === 9 || this.co === 9) { // les boutons latéraux ou les pions joué
            couleur = 'darkgrey';
            this.dom.addEventListener("click", () => { changeGrey(this); }, false);
            
        }
        else {
            couleur = "white";
            this.dom.addEventListener("click", () => { changeWhite(this); }, false);
            
        }
        this.dom.style.backgroundColor = couleur;
    };
    this.initialiser();
}

function rayon_x(direction, depart, origin){
    if(origin){
        check(1, 9, depart, direction);
    }
    else{
        check(9, 1, depart, direction);
    }
}

function check(min, max, depart,direction){
    let inc = 1;
    let run = true;
    if(min > max){
        inc = -1;
    }
    score-=1
    for(i=min; i!=max+inc; i+=inc){
        if(run){
            switch (direction){
                case 'v':
                    if(univers[i][depart].atome){
                        run = false;
                    }
                    else{
                        univers[i][depart].dom.style.backgroundColor = "blue";
                        for(j=0; j<5; j++){
                            diff_x = (list_atome[j].li - univers[i][depart].li);
                            diff_y = (list_atome[j].co - univers[i][depart].co);
                            if(diff_x==1 || diff_x ==-1){
                                if(diff_y== 1){
                                    return check(depart-1, 1, i, 'h')
                                }
                                else if (diff_y== -1){
                                    return check(depart+1, 8, i, 'h')
                                }
                            }
                        }
                    }
                    break;
                case 'h':
                    if(univers[depart][i].atome){
                        run = false;
                    }
                    else{
                        univers[depart][i].dom.style.backgroundColor = "blue";
                        for(j=0; j<5; j++){
                            diff_x = (list_atome[j].li - univers[depart][i].li);
                            diff_y = (list_atome[j].co - univers[depart][i].co);
                            if(diff_y==1 || diff_y ==-1){
                                if(diff_x== -1){
                                    return check(depart+1, 8, i, 'v')
                                }
                                else if (diff_x== 1){
                                    return check(depart-1, 1, i, 'v')
                                }
                            }
                        }
                    }
                    break;
            }
        }
    }
    return;
}

function creerUnivers() {
    var li, co, ligne;
    for (li = 0; li < 10; li += 1) {
        ligne = [];
        for (co = 0; co < 10; co += 1) {
            ligne.push(new cellule(li, co));
        }
        univers.push(ligne);
    }
}

function placerAtome(){
    list_atome.pop();
    for(i=0; i<nb_atome;i++){
        li = Math.trunc(Math.random()*7)+2;
        col = Math.trunc(Math.random()*7)+1;
        let cell = new cellule(li, col);
        cell.atome = true;
        can_atome = true
        for(m=0; m<i; m++){
            if(cell.co == list_atome[m].co && cell.li == list_atome[m].li){
                can_atome = false
            }
        }
        if(can_atome){
            list_atome.push(cell);
            for(k=li; k<=li; k++){
                for(j=col; j<=col; j++){
                    univers[k][j] = cell;
                }
            }
        }
        else{
            i--;
        }
    }
}