/*! jQuery v3.6.0 | (c) OpenJS Foundation and other contributors | jquery.org/license */
$(document).ready(function(){
    var start = false;
    var level = 1;
    var instruct = [];
    var setting_elem = true;
    var move = 0;
    var index = 0;

    function anim_fin(){
        for(let i = 0; i<6; i++){
            $('#green').animate({opacity: 0.2}, 100, function(){
                $('#red').animate({opacity: 0.2}, 100, function(){
                    $('#blue').animate({opacity: 0.2}, 100, function(){
                        $('#yellow').animate({opacity: 0.2}, 100).animate({opacity: 1}, 100)
                    }).animate({opacity: 1}, 100).animate({opacity: 1}, 100)
                }).animate({opacity: 1}, 100).animate({opacity: 1}, 100)
            }).animate({opacity: 1}, 100).animate({opacity: 1}, 200, function(){start = false;})
        }
    }



    function compare_tiles(id){
        if(id == instruct[move]){
            move++;
            if(move == level){
                move = 0;
                level+=1;
                $("#start").text("Niveau : " + level);
                random_tiles();
            }
        }
        else{
            level = 1;
            setting_elem = true;
            anim_fin();
            $("#start").attr('name', 'notStarted');
            $("#start").text("Perdu !\nCliquez pour réessayer");
        }
    }

    function set_audio(){
        var aud1 = document.getElementsByClassName("sound1").item(0);
        aud1.onended = function() {
            if(! setting_elem){
                compare_tiles(0);
            }
            else{
                display_tiles()
            }
        };
        var aud2 = document.getElementsByClassName("sound2").item(0);
        aud2.onended = function() {
            if(! setting_elem){
                compare_tiles(1);
            }
            else{
                display_tiles()
            }
        };
        var aud3 = document.getElementsByClassName("sound3").item(0);

        aud3.onended = function() {
            if(! setting_elem){
                compare_tiles(2);
            }else{
                display_tiles()
            }
        };
        var aud4 = document.getElementsByClassName("sound4").item(0);
        aud4.onended = function() {
            if(! setting_elem){
                compare_tiles(3);
            }
            else{
                display_tiles()
            }
        };
    }

    $(".tiles").mousedown(function(){
        if($(this).attr('name')=='notStarted'){
            $(this).attr('name', 'start');
            $(this).text("Niveau : " + level);
            start = true;
            max_anim = 0;
            set_audio();
            $(this).animate({opacity: 0.9}, 100).animate({opacity: 1}, 100).animate({opacity: 1}, 200, function(){
                random_tiles();
            });
        }
        else{
            if(start && !setting_elem && $(this).attr('name')!='start'){
                $(this).animate({opacity: 0.4}, 220);
            }
        }
    });

    $(".tiles").mouseup(function(){
        if(! setting_elem)
        {
            if($(this).attr('id')=='green'){
                $(this).animate({opacity: 1}, 220);
                document.getElementsByClassName("sound1").item(0).play();
            }
            if($(this).attr('id')=='red'){
                $(this).animate({opacity: 1}, 220);
                document.getElementsByClassName("sound2").item(0).play();
            }
            if($(this).attr('id')=='yellow'){
                $(this).animate({opacity: 1}, 220);
                document.getElementsByClassName("sound3").item(0).play();
            }
            if($(this).attr('id')=='blue'){
                $(this).animate({opacity: 1}, 220);
                document.getElementsByClassName("sound4").item(0).play();
            }
        }
    });

    function display_tiles(){
        if(index == level){
            setting_elem = false;
            index = 0
        }
        else{
            let val = instruct[index];
            if(val==0){
                $("audio.sound1")[0].play()
                $('#green').animate({opacity: 0.2}, 220, function(){
                    document.getElementsByClassName("sound1").item(0).play();
                }).animate({opacity: 1}, 220)
            }
            else if(val==1){
                $("audio.sound2")[0].play()
                $('#red').animate({opacity: 0.2}, 220, function(){
                    document.getElementsByClassName("sound2").item(0).play();
                }).animate({opacity: 1}, 220)
            }
            else if(val==2){
                $("audio.sound3")[0].play()
                $('#yellow').animate({opacity: 0.2}, 220, function(){
                    document.getElementsByClassName("sound3").item(0).play();
                }).animate({opacity: 1}, 220)
            }
            else{
                $("audio.sound4")[0].play()
                $('#blue').animate({opacity: 0.2}, 220, function(){
                    document.getElementsByClassName("sound4").item(0).play();
                }).animate({opacity: 1}, 220)
            }
            index+=1;
        }
    }

    function random_tiles(){
        setting_elem = true;
        instruct[level-1] = Math.floor(Math.random() * 4);
        display_tiles(level);
    }
});
