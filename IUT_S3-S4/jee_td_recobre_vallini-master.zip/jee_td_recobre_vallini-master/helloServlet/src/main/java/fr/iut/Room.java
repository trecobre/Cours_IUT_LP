package fr.iut;

public class Room {
    public String name;
    public int occupation;
    public int capacity;

    public Room(String name, int occupation, int capacity) {
        this.name = name;
        this.occupation = occupation;
        this.capacity = capacity;
    }

    public String getName() {
        return name;
    }

    public int getOccupation() {
        return occupation;
    }

    public int getCapacity() {
        return capacity;
    }
}
