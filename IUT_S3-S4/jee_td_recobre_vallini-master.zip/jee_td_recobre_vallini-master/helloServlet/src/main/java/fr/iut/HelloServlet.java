package fr.iut;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class HelloServlet extends HttpServlet {


    @Override
    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response)
            throws ServletException, IOException {
        PrintWriter out = response.getWriter();
        out.println( "<HTML>" );
        out.println( "<HEAD>");
        out.println( "<TITLE>cette page est FORTEMENT inspirée</TITLE>" );
        out.println( "</HEAD>" );
        out.println( "<BODY>" );
        out.println( "<H1>Hello world !</H1>" );
        out.println("<ul>");
        out.println("<li>la</li>");
        out.println("<li>personalisation</li>");
        out.println("<li>c'est</li>");
        out.println("<li>trop</li>");
        out.println("<li>fun</li>");
        out.println("</ul>");
        out.println( "</BODY>" );
        out.println( "</HTML>" );
        out.close();
    }
}
