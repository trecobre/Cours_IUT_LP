package fr.iut.rm.persistence.domain;

public enum EventType {
    IN,OUT
}
