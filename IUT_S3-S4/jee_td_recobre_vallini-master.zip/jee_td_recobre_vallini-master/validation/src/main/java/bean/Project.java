package bean;

public class Project {
    private String description;
    private String name;
    private String urlRepository;
    private Person teachers;
    private Person students;
    private Person customers;
    private Document mesDocuments;

    public Project(String description, String name, String urlRepository, Person teachers, Person students, Person customers, Document mesDocuments) {
        this.description = description;
        this.name = name;
        this.urlRepository = urlRepository;
        this.teachers = teachers;
        this.students = students;
        this.customers = customers;
        this.mesDocuments = mesDocuments;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUrlRepository() {
        return urlRepository;
    }

    public void setUrlRepository(String urlRepository) {
        this.urlRepository = urlRepository;
    }

    public Person getTeachers() {
        return teachers;
    }

    public void setTeachers(Person teachers) {
        this.teachers = teachers;
    }

    public Person getStudents() {
        return students;
    }

    public void setStudents(Person students) {
        this.students = students;
    }

    public Person getCustomers() {
        return customers;
    }

    public void setCustomers(Person customers) {
        this.customers = customers;
    }

    public Document getMesDocuments() {
        return mesDocuments;
    }

    public void setMesDocuments(Document mesDocuments) {
        this.mesDocuments = mesDocuments;
    }
}
