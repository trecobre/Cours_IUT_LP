package bean;

import java.util.Date;

public class Document {
    private String title;
    private String content;
    private Date creationDate;
    private Date lastModification;
    private Person creator;
    private Person lastModifier;

    public Document(String title, String content, Date creationDate, Date lastModification, Person creator, Person lastModifier) {
        this.title = title;
        this.content = content;
        this.creationDate = creationDate;
        this.lastModification = lastModification;
        this.creator = creator;
        this.lastModifier = lastModifier;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public Date getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(Date creationDate) {
        this.creationDate = creationDate;
    }

    public Date getLastModification() {
        return lastModification;
    }

    public void setLastModification(Date lastModification) {
        this.lastModification = lastModification;
    }

    public Person getCreator() {
        return creator;
    }

    public void setCreator(Person creator) {
        this.creator = creator;
    }

    public Person getLastModifier() {
        return lastModifier;
    }

    public void setLastModifier(Person lastModifier) {
        this.lastModifier = lastModifier;
    }


}
