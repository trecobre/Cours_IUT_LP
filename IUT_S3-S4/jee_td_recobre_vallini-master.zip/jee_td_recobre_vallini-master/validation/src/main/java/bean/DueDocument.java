package bean;

import java.util.Date;

public class DueDocument extends Document{
    private Date dueDate;

    public DueDocument(String title, String content, Date creationDate, Date lastModification, Person creator, Person lastModifier, Date dueDate) {
        super(title, content, creationDate, lastModification, creator, lastModifier);
        this.dueDate = dueDate;
    }

    public Date getDueDate() {
        return dueDate;
    }

    public void setDueDate(Date dueDate) {
        this.dueDate = dueDate;
    }
}
