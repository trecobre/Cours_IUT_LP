package validation;


import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class LoginValidator implements ConstraintValidator<Login, Object> {

    public void initialize(Login parameters){

    }

    public boolean isValid(Object object, ConstraintValidatorContext context){
        return true;
    }
}
