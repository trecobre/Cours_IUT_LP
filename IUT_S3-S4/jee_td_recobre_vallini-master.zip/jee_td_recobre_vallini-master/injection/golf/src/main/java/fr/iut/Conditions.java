package fr.iut;

/* Golf terrain conditions*/
public enum Conditions {
    GREEN,
    FAIRWAY,
    BUNKER
}
