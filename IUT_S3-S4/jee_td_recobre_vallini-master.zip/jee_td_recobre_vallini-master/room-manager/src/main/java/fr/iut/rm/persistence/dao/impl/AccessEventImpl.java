package fr.iut.rm.persistence.dao.impl;

import fr.iut.rm.persistence.dao.AccessEvent;

public class AccessEventImpl implements AccessEvent {
}
