package fr.iut.rm.persistence.dao;

public interface AccessEvent {//on fait quoi du coup ?
}
//ah mais j'ai la flemme de comprendre là tout de suite en soit