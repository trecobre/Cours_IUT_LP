/**
 * Contains all project classes.
 */
package fr.iut.rm.persistence.dao;