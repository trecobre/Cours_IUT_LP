package fr.iut.rm.control;

import com.google.inject.Inject;
import com.google.inject.persist.UnitOfWork;
import fr.iut.rm.persistence.dao.RoomDao;
import fr.iut.rm.persistence.domain.Room;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

/**
 * Created by cjohnen on 02/02/17.
 */
public class ControlRoom {
    /**
     * Logger
     */
    private static final Logger logger = LoggerFactory.getLogger(ControlRoom.class);

    /**
     * Unit of work is used to drive DB Connection
     */
    @Inject
    UnitOfWork unitOfWork;

    /**
     * Data Access Object for rooms
     */
    @Inject
    RoomDao roomDao;

     /*
     * * Displays all the rooms content in DB
     */
    public void showRooms() {
        unitOfWork.begin();

        List<Room> rooms = roomDao.findAll();
        if (rooms.isEmpty()) {
            System.out.println("No room");
        } else {
            System.out.println("Rooms :");
            System.out.println("--------");
            for (Room room : rooms) {
                System.out.println(String.format("   [%d], name '%s', description '%s'", room.getId(), room.getName(), room.getDescription()));
            }
        }

        unitOfWork.end();
    }

    private boolean canCreate(String name){
        Room rooms = roomDao.findByName(name); //un ptit message d'erreur pour que ce soit joli
        return !(rooms.getName().equals(name)); //ça marche?
    }

    /**
     * Creates a room in DB
     *
     * @param name the name of the room
     */
    public void createRoom(final String name) {
        unitOfWork.begin();

        // TODO check unicity


        Room room = new Room();
        room.setName(name);
        if(canCreate(name)){
            roomDao.saveOrUpdate(room);// réel
        }else{
            System.err.println("Chose another name than " + name + ". :)");
        }//
        unitOfWork.end();

    }


    public void deleteRoom(final String name){
        unitOfWork.begin();

        roomDao.removeRoom(name);

        unitOfWork.end();
    }

    public void createRoomWithDescription(final String name, final String description) {
        unitOfWork.begin();
        try{
            Room room = new Room();
            room.setDescription(description);
            room.setName(name);
            roomDao.saveOrUpdate(room);
        }
        catch (javax.persistence.PersistenceException e) {
            System.err.println("Description too long");
        }

        unitOfWork.end();
    }
}
