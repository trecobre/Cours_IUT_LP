/**
 * Provides the classes necessary to persist Room Manager data.
 */
package fr.iut.rm.persistence.domain;