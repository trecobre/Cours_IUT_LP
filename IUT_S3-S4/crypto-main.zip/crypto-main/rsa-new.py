"""
Code réalisé par Théo Recobre, Alexandre Malagnac et Angel Blazquez.
"""

import math
import random
import sympy as sp
import hashlib as hash
import sys


"""
Certificat
"""


# Constitution d'un certificat
class Certificat:
    signature = (0,0,0)
    nom = ""
    def __init__(self, nom:str, id:int, clePublique)-> None:
        self.nom = nom
        self.signature = chiffrage_avec_cle(id, clePriveeCA), chiffrage_avec_cle(clePublique[0], clePriveeCA), chiffrage_avec_cle(clePublique[1], clePriveeCA)


# Envoie une information de non retenu du message
def poubelle():
    print("A la poubelle le message !!\nVous ne m'aurez pas comme ça, vilains hackers !!")


"""
Empreintes
"""


# Génère l'empreinte d'un message et le renvoie en entier
def empreinte(message) :
    protocole = hash.sha512() 
    protocole.update(str(message).encode('utf-8'))
    emp = protocole.digest()
    return int.from_bytes(emp,sys.byteorder)


# Chiffre en message
def chiffrage_avec_cle(message,cle) :
    return RSA_chiffrement(message,cle[0],cle[1])


# Déchiffre un message
def dechiffrage_avec_cle(message,cle) :
    return RSA_dechiffrement(message,cle[0],cle[1])


"""
Chiffrement RSA
"""


# Chiffrement RSA
def RSA_chiffrement(valeur, cle:int, modulo:int):
    resultat = int(1)
    for i in range(cle):
        resultat = resultat*valeur
        resultat = resultat%modulo
    return resultat


# Déchiffrement RSA
def RSA_dechiffrement(valeur:int, cle:int, modulo:int):
    resultat = int(1)
    for i in range(cle):
        resultat = resultat*valeur
        resultat = resultat%modulo
    return resultat


# Fonction d'Euler
def euler(p:int, q:int):
    return (p-1)*(q-1)


# Fonction de Bézout
def bezout(a:int, b:int)->int:
    p = 1
    q = 0
    r = 0
    s = 1
    c = 0
    quotient = 0
    nouveau_r = 0
    nouveau_s = 0
    while (b != 0):
        c = a % b
        quotient = math.floor(a/b)
        a = b
        b = c
        nouveau_r = p - (quotient * r)
        nouveau_s = q - (quotient * s)
        p = r
        q = s
        r = nouveau_r
        s = nouveau_s
    return p


# Génère une clé privée
def cle_privee(phi:int):
    e = 2
    d = -1
    for e in range(2, phi):
        if math.gcd(e, phi)==1:
            d = bezout(e, phi)
            if d > 1:
                return d, e
    return -1, -1


# Génère les clés
def generer_cles():
    phi = -1
    p = 0
    q = 0
    primes = list(sp.primerange(10000))
    while phi == -1:
        p = primes[random.randint(0, len(primes)-1)]
        q = primes[random.randint(0, len(primes)-1)]
        phi = euler(p,q)
    cle = cle_privee(phi)
    d = cle[0]
    e = cle[1]
    n = p*q
    return (n, d, e)


# Informations de CA
CA = generer_cles()
nC = CA[0]
dC = CA[1]
eC = CA[2]
clepubliqueCA = (eC, nC)
clePriveeCA = (dC, nC)


# Envoie un certificat si possible
def certificat_autentificator(nom:str, id:int, message, empreinte, clePublique):
    message = dechiffrage_avec_cle(message, clePriveeCA)
    empreinteDechiffree = dechiffrage_avec_cle(empreinte, clePublique)
    messageEmpreinte = empreinte(message)%clePublique[1]
    if messageEmpreinte == empreinteDechiffree:
        return Certificat(nom, id, clePublique)
    print("Certificat non validé")
    poubelle()
    return None


# Gère la réception pour Bob
def reception_bob(certif:Certificat, message):
    cle = dechiffrage_avec_cle(certif.signature[1], clepubliqueCA), dechiffrage_avec_cle(certif.signature[2], clepubliqueCA)
    emetteur = certif.nom
    emetteur = dechiffrage_avec_cle(message[0], cle)
    empreinte = dechiffrage_avec_cle(message[1], cle)
    messageEmpreinte = empreinte(emetteur)%cle[1]

    if(messageEmpreinte == empreinte):
        print("Bob reçoit {} de la part de {}".format(emetteur, emetteur))
    else:
        print("{} ≠ {}".format(empreinte, messageEmpreinte))
        print("Empreinte non valide")
        poubelle()


"""
Fonction principale
"""
def main():
    # Informations d'Alice
    alice = generer_cles()
    nA = alice[0]
    dA = alice[1]
    eA = alice[2]
    clePubliqueAlice = (eA, nA)
    clePriveeAlice = (dA, nA)

    # Alice écrit son message
    messageAlice = int(input("Alice envoie à Bob : ")) # Saisie utilisateur
    while messageAlice >= nA:
        messageAlice = int(input("Alice envoie à Bob : ")) # Saisie utilisateur

    M = chiffrage_avec_cle(messageAlice, clepubliqueCA) # Message
    E = chiffrage_avec_cle(empreinte(messageAlice), clePriveeAlice) # Empreinte
    message = chiffrage_avec_cle(messageAlice, clePriveeAlice), E
    certificat = certificat_autentificator("Alice", 411331458, M, E, clePubliqueAlice)
    if certificat != None:
        reception_bob(certificat, message)

# On lance le programme
main()
