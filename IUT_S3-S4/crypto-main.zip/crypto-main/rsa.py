import math
import random
import sympy as sp
import hashlib as hash
import sys
import binascii 

class Certificat:
    signature = (0,0,0)
    name = ""
    def __init__(self, name:str, id:int, public_key)-> None:
        self.name = name
        self.signature = chiffrage_avec_cle(id, clePriveeCA), chiffrage_avec_cle(public_key[0], clePriveeCA), chiffrage_avec_cle(public_key[1], clePriveeCA)

def poubelle():
    print("A la poubelle le message !!\nVous m'aurez pas comme ça, vilains hackers !!")


# Gestion des empreintes


# Genere l'empreinte d'un message et renvoie en int
def empreinte(message) :
    protocole = hash.sha512() 
    protocole.update(str(message).encode('utf-8'))
    emp = protocole.digest()
    return int.from_bytes(emp,sys.byteorder)


def chiffrage_avec_cle(message,cle) :
    return RSA_chiffrement(message,cle[0],cle[1])


def dechiffrage_avec_cle(message,cle) :
    return RSA_dechiffrement(message,cle[0],cle[1])


def generation_chiffre_empreinte(message, cle) :
    emp = empreinte(message)
    msg = (chiffrage_avec_cle(message, cle)),(chiffrage_avec_cle(emp, cle))
    return msg


# RSA


def RSA_chiffrement(valeur, cle:int, modulo:int):
    resultat = int(1)
    for i in range(cle):
        resultat = resultat*valeur
        resultat = resultat%modulo
    return resultat


def RSA_dechiffrement(valeur:int, cle:int, modulo:int):
    resultat = int(1)
    for i in range(cle):
        resultat = resultat*valeur
        resultat = resultat%modulo
    return resultat


def euler(p:int, q:int):
    return (p-1)*(q-1)


def bezout(a:int, b:int)->int:
    p = 1
    q = 0
    r = 0
    s = 1
    c = 0
    quotient = 0
    nouveau_r = 0
    nouveau_s = 0
    while (b != 0):
        c = a % b
        quotient = math.floor(a/b)
        a = b
        b = c
        nouveau_r = p - (quotient * r)
        nouveau_s = q - (quotient * s)
        p = r
        q = s
        r = nouveau_r
        s = nouveau_s
    return p


def cle_privee(phi:int):
    e = 2
    d = -1
    for e in range(2, phi):
        if math.gcd(e, phi)==1:
            d = bezout(e, phi)
            if d > 1:
                return d, e
    return -1, -1


def genererCles():
    phi = -1
    p = 0
    q = 0
    primes = list(sp.primerange(10000))
    while phi == -1:
        p = primes[random.randint(0, len(primes)-1)]
        q = primes[random.randint(0, len(primes)-1)]
        phi = euler(p,q)
    key = cle_privee(phi)
    d = key[0]
    e = key[1]
    n = p*q
    return (n, d, e)

certif = genererCles()
nC = certif[0]
dC = certif[1]
eC = certif[2]
clepubliqueCA = (eC, nC)
clePriveeCA = (dC, nC)

def certificat_autentificator(name:str, id:int, message, emp, public_key):
    msg = dechiffrage_avec_cle(message, clePriveeCA)
    empr = dechiffrage_avec_cle(emp, public_key)
    msg_emp = empreinte(msg)%public_key[1]
    if msg_emp == empr:
        return Certificat(name, id, public_key)
    print("Certificat non validé.")
    poubelle()
    return None


def reception_bob(certif:Certificat, message):
    key = dechiffrage_avec_cle(certif.signature[1], clepubliqueCA), dechiffrage_avec_cle(certif.signature[2], clepubliqueCA)
    emetteur = certif.name
    msg = dechiffrage_avec_cle(message[0], key)
    emp = dechiffrage_avec_cle(message[1], key)
    msg_emp = empreinte(msg)%key[1]

    if(msg_emp == emp):
        print("Bob reçoit {} de la part de {}".format(msg, emetteur))
    else:
        print("{} ≠ {}".format(emp, msg_emp))
        print("Empreinte non valide")
        poubelle()



# fonction principale


def main():
    # informations d'Alice
    alice = genererCles()
    nA = alice[0]
    dA = alice[1]
    eA = alice[2]
    clePubliqueAlice = (eA, nA)
    clePriveeAlice = (dA, nA)
    # Alice écrit son message
    mAlice = int(input("Alice envoie à Bob : ")) # saisie utilisateur
    while mAlice >= nA:
        mAlice = int(input("Alice envoie à Bob : ")) # saisie utilisateur

    M = chiffrage_avec_cle(mAlice, clepubliqueCA)
    E = chiffrage_avec_cle(empreinte(mAlice), clePriveeAlice)
    message = chiffrage_avec_cle(mAlice, clePriveeAlice), E
    certif = certificat_autentificator("Alice", 411331458, M, E, clePubliqueAlice)
    if certif != None:
        reception_bob(certif, message)


# informations de CA



# On lance le programme

main()
