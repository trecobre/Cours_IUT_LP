<?php
echo "Il est ".date('H:i:s');