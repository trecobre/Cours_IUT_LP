<!DOCTYPE html>

<html lang="fr">
    <head>
        <meta charset="utf-8"/>
        <link rel="stylesheet" href="../global.css">
        <title>Table de multiplication</title>
    </head>
    <body>
        <h1>
            Table de multiplication
        </h1>
        <?php
        if(isset($_GET["col"])){
            $col = $_GET["col"];
        }
        else{
            $col = 0;
        }
        if(isset($_GET["row"])){
            $row = $_GET["row"];
        }
        else{
            $row = 0;
        }
            $afficheTab = "<div><table class=\"mini-tab\">";
            for ($i=1; $i < 10; $i++) {
                $afficheTab .= "<tr>";
                for($j=1; $j<10; $j++){
                    if($i==1){
                        $afficheTab .= "<th><b>$j</b></th>";
                    }
                    else if($j==1){
                        $afficheTab .= "<th><b>$i</b></th>";
                    }
                    else{
                        $cal = $i * $j;
                        if($i == $col || $j == $row){
                            $afficheTab .= "<td style=\"background-color:powderblue;\"><a href=\"tableMultiplication.php?col=$i&row=$j\">$cal</a></td>";
                        }
                        else{
                            $afficheTab .= "<td><a href=\"tableMultiplication.php?col=$i&row=$j\">$cal</a></td>";
                        }
                    }
                }
                $afficheTab .= "</tr>";
            }
            $afficheTab .= "</table></div>";
            echo($afficheTab);
           
        ?>
        <a id="go_back" href="http://127.0.0.1:8080/">Retourner au menu principal</a>
    </body>
</html>