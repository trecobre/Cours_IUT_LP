<!DOCTYPE html>

<html lang="fr">
    <head>
        <meta charset="utf-8"/>
        <link rel="stylesheet" href="../global.css">
        <title>Saison</title>
    </head>
    <body>
        <?php
        $data = "";
        $var = "";
        if(isset($_GET["serie"])){
            $var .= $_GET["serie"];
            
        }
        echo "<h1>$var</h1>";
        $dsn = "mysql:dbname=etu_trecobre;host=info-titania";
        $user = "trecobre";
        $password = "tEyr93VB";
        $pdo = new PDO($dsn, $user, $password);
        $data .= '<ul>';
        $sql = "SELECT series.title, series.poster, season.number, COUNT(*) AS nb_ep 
        FROM episode 
        INNER JOIN season ON season.id = episode.season_id 
        INNER JOIN series ON series.id = season.series_id 
        WHERE series.title ='$var' 
        GROUP BY season.number";
        $index = 0;
        $query = $pdo->query($sql);
        while ($row = $query->fetch()) {
            if($index==0) $data .= '<div class="series"><img src="data:image/jpeg;base64,'.base64_encode($row['poster']).'"/>';
            $data .= '<li>Saison '.$row['number'].' : '.$row['nb_ep'].'';
            $index++;
        }
        echo $data;
        ?>
        </br><a id="go_back" href="http://127.0.0.1:8080/">Retourner au menu principal</a>
    </body>
</html>