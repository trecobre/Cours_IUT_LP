<!DOCTYPE html>

<html lang="fr">
    <head>
        <meta charset="utf-8"/>
        <link rel="stylesheet" href="../global.css">
        <title>Formulaire</title>
    </head>
    <body>
        <h1>Recherchez une série</h1>
    <?php
        $data = "<div><form method=\"post\"><input type=\"text\" name=\"initiale\"> <input type=\"submit\" value=\"confirmer\" name=\"Confirmer\" \"></form></div>";
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
                if(isset($_POST["initiale"])){
                    $initiale = $_POST["initiale"];
                    header("Location: lectureBDD.php?val=$initiale");
                    exit;
                }
        }
        echo $data;
    ?>
    <a id="go_back" href="http://127.0.0.1:8080/">Retourner au menu principal</a>
    </body>
</html>