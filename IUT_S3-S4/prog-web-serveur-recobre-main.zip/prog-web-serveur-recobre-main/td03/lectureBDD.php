<!DOCTYPE html>

<html lang="fr">
    <head>
        <meta charset="utf-8"/>
        <link rel="stylesheet" href="../global.css">
        <title>Série</title>
    </head>
    <body>
    <?php
        $data = "";
        class Series {
            public $title;
            public $poster;
            function set_serie($row){
                $this->title = $row['title'];
                $this->poster = $row['poster'];
            }
            function get_serie($to_get){
                return $this->$to_get;
            }

        }
        $var = "";
        if(isset($_GET["val"])){
            $var = $_GET["val"];
        }
        if(isset($_GET["page"])){
            $page = $_GET["page"];
        }
        else{
            $page = 1;
        }
        $dsn = "mysql:dbname=etu_trecobre;host=info-titania";
        $user = "trecobre";
        $password = "tEyr93VB";
        $pdo = new PDO($dsn, $user, $password);
        
        $rech = $var ."%";

        $sql = "SELECT COUNT(*) AS cpt FROM `series` WHERE title LIKE ?";
        $query = $pdo->prepare($sql);
        $query->execute([$rech]); 
        while($row = $query->fetch()){
            $lenght = $row['cpt'];
        }
        $data .= "<div id=\"menu\"><a href=\"http://127.0.0.1:8080/td03/formulaireBDD.php\">Retourner au formulaire</a></br>";
        $data .= "<h1>liste des séries commençant par $var : </h1>";
        if($lenght>10){
            $data .= "<div><form id=\"nav\" method=\"post\"><input type=\"submit\" name=\"left\" value=\"<\"><p id=\"page\">page : $page</p><input type=\"submit\" name=\"right\" value=\">\"></form></div>";
            if ($_SERVER["REQUEST_METHOD"] == "POST") {
                foreach($_POST as $name => $content) {
                    if($name == "right" && $page*10 < $lenght) $page++;
                    if($name == "left" && $page > 1) $page--;
                header("Location: lectureBDD.php?val=$var&page=$page");
                }
            }
        }
        else{
            $data .= "<p id=\"page\">page : $page</p>";
        }
        $data .= "</div>";

        $limit = ($page-1)*10;
        $sql = "SELECT * FROM `series` WHERE title LIKE ? LIMIT 10 OFFSET $limit";
        $query = $pdo->prepare($sql);
        $query->execute([$rech]);

        $data .= "<div id=\"lecture\">";
        $data .= "<ul>";

        while ($row = $query->fetch()) {
            $serie = new Series();
            $serie->set_serie($row);
            $poste = $serie->get_serie("poster");
            $titre = $serie->get_serie("title");
            $data .= '<li><a href=saisonSerie.php?serie='.$titre.'><div class="series"><img src="data:image/jpeg;base64,'.base64_encode($poste).'"/><p>'.$titre.'</a>';
        }
        $data .= "</div>";
        echo $data;
    ?>
    <a id="go_back" href="http://127.0.0.1:8080/">Retourner au menu principal</a>
    </body>
</html>