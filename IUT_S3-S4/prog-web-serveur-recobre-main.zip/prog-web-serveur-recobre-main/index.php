<!DOCTYPE html>
<html lang="fr">
    <head>
        <meta charset="utf-8"/>
        <link rel="stylesheet" href="global.css">
        <title>Main</title>
    </head>
    <body>
        <?php
            session_start();
            if (isset($_SESSION['user'])){
                echo "<h1>Bonjour, ".$_SESSION['user']." !</h1>";
            }
            else {
                header("location: td05/connexion.php");
            }
            ?>
        <h2>Les TPs de prog web serveur : </h2>
        <ul>
            <li>
                <h3>TP 01</h3>
                <ul>
                    <li><a href="td01/date.php">Date</a></li>
                    <li><a href="td01/tableMultiplication.php">Table de multiplication</a></li>
                </ul>
            </li>
            <li>
                <h3>TP 02</h3>
                <ul>
                    <li><a href="td02/calculatrice.php">Calculatrice</a></li>
                    <li><a href="td02/calendrier.php">Calendrier</a></li>
                </ul>
            </li>
            <li>
                <h3>TP 03</h3>
                <ul>
                    <li><a href="td03/formulaireBDD.php">Base de donnée</a></li>
                </ul>
            </li>
            <li>
                <h3>TP 04</h3>
                <ul>
                    <li><a href="td04/inscriptionUtilisateur.php">Base de donnée - 2</a></li>
                </ul>
            </li>
            <li>
                <h3>TP 05</h3>
                <ul>
                    <li><a href="td05/Cookie.php">Cookies</a></li>
                    <li><a href="td05/morpion.php">Morpion</a></li>
                </ul>
            </li>
        </ul>
    </body>
    <footer>
        <?php
            echo "<form id=\"go_back\" method=\"post\">
            <input type=\"submit\" placeholder=\"Detruire\" name=\"disconnect\" value=\"Se déconnecter\"></form>";
            if ($_SERVER["REQUEST_METHOD"] == "POST") {
                if(isset($_POST['disconnect'])){
                    session_unset();
                    session_destroy();
                    header("location: td05/connexion.php");
                }
            }
        ?>
    </footer>
</html>