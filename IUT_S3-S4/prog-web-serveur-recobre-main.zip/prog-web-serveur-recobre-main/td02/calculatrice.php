<!DOCTYPE html>

<html lang="fr">
    <head>
        <meta charset="utf-8"/>
        <link rel="stylesheet" href="../global.css">
        <title>Calculatrice</title>
    </head>
    <body>
        <h1>
            Calculatrice
        </h1>
        <?php
        $afficher = "<div id=\"calc\"><form method=\"post\" ><input type=\"number\" name=\"n1\"><p> + </p><input type=\"number\" name=\"n2\"><p> = </p><input type=\"submit\" name=\"Calculer\"></form></div>";
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            if(empty($_POST["n1"]) || empty($_POST["n2"])){
                $afficher .= "<p>Veuillez compléter tout les champs</p>";
            }
            else{
                $calc = $_POST["n1"] + $_POST["n2"];
                $afficher .= $calc;
            }
        }
        echo($afficher);

        ?>
        </br>
        <a id="go_back" href="http://127.0.0.1:8080/">Retourner au menu principal</a>
    </body>
</html>