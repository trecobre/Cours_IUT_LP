<!DOCTYPE html>

<html lang="fr">
    <head>
        <meta charset="utf-8"/>
        <link rel="stylesheet" href="../global.css">
        <title>Calendrier</title>
    </head>
    <body>
        <h1>
            Calendrier
        </h1>
        <?php
        $tmpDate = date_create("now");
        if(isset($_GET['month']) and isset($_GET['year'])){
            $tmpDate = date_create("now");
            date_date_set($tmpDate, $_GET['year'], $_GET['month'], $_GET['day']);
        }
        $dateActuelle = date_format($tmpDate, "y-m-d");
        $mois = date_format($tmpDate, "m");
        $annee = date_format($tmpDate, "y");
        $jour = date_format($tmpDate, "d");
        $afficheTab = "<div><form id=\"nav\" method=\"post\" ><input type=\"submit\" name=\"prec\" value = \"Précedent\"><p>$jour - $mois - $annee</p><input type=\"submit\" name=\"next\" value=\"Suivant\"></form></div>";
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            if(isset($_POST['prec'])){
                $mois--;
                if($mois<1){
                    $annee--;
                    $mois = 12;
                }
                $jour = 01;
                header("location: calendrier.php?day=$jour&month=$mois&year=$annee");
            }
            if(isset($_POST['next'])){
                $mois++;
                if($mois>12){
                    $annee++;
                    $mois = 1;
                }
                $jour = 01;
                header("location: calendrier.php?day=$jour&month=$mois&year=$annee");
            }
        }
        $afficheTab .= "</br>";
        $afficheTab .= "<div><table class=\"mini-tab\">";
        $afficheTab .= "<th></th>";
        $nomJour = "";
        $jourt = date_format($tmpDate, "w");
        $jourt = $jourt - ($jour%7) +1 ;
        $j_limit = date("t", strtotime($dateActuelle));
        for($i=-1; $i<6; $i++){
            $nJour = date("D", mktime(0,0,0,0,$i,0));
            $nomJour .= "<th>$nJour</th>";
        }
        $afficheTab .= $nomJour;
        for ($i=-$jourt+2; $i < 32; $i+=0) {
            $semaine = date("W", mktime(0,0,0,$mois,$i,$annee));
            
            $afficheTab .= "<tr>";
            $afficheTab .= "<th>$semaine</th>";
            for($j=0; $j<7; $j++){
                $date = date("d", mktime(0,0,0,$mois,$i,$annee)) ;
                if($i<1 || $i>$j_limit){
                    $afficheTab .= "<td class=\"other_day\">$date</td>";
                }
                else if($i==$jour){
                    $afficheTab .= "<td id=\"main_day\" >$date</td>";
                }
                else{
                    $afficheTab .= "<td><a href=\"calendrier.php?day=$date&month=$mois&year=$annee\">$date</a></td>";
                }
                $i++;
            }
            $afficheTab .= "</tr>";
        }
        $afficheTab .= "</table></div>";
        echo($afficheTab);
        ?>
        </br>
        <a id="go_back" href="http://127.0.0.1:8080/">Retourner au menu principal</a>
    </body>
</html>