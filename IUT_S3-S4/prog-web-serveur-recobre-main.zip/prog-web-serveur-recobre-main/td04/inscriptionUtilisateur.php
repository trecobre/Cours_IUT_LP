<!DOCTYPE html>

<html lang="fr">
    <head>
        <meta charset="utf-8"/>
        <link rel="stylesheet" href="../global.css">
        <title>Inscription</title>
    </head>
    <body>
    <?php
        $data = "";
        if(isset($_GET['usr'])){
            $compte = $_GET['usr'];
            $data .= "<h1>Votre compte a été créé avec succès ! Bienvenue à vous, $compte !";
            $data .= "</br>";
            $data .= "<div><form method=\"post\"><input id=\"go_connex\" type=\"submit\" placeholder=\"Confirmer\" name=\"connexion\" value=\"Se connecter\"></form></div>";
            if ($_SERVER["REQUEST_METHOD"] == "POST") {
                header("location: http://127.0.0.1:8080/td05/connexion.php");
            }
        }
        else{
        $dsn = "mysql:dbname=etu_trecobre;host=info-titania";
        $user = "trecobre";
        $password = "tEyr93VB";
        $pdo = new PDO($dsn, $user, $password);

        $sql = "SELECT * FROM `country`";
        $query = $pdo->query($sql);

        
        $data .= "<div><form method=\"post\">
                    <p>Nom : <input type=\"text\" name= \"name\" placeholder=\"Nom\"></p>
                    <p>Mail : <input type=\"text\" name= \"email\" placeholder=\"votre.adresse@mail.com\"></p>
                    <p>Mot de passe : <input type=\"password\" name= \"mdp1\" placeholder=\"Mot de passe\"></p>
                    <p>Confirmer mot de passe : <input type=\"password\" name= \"mdp2\" placeholder=\"Mot de passe\"></p>
                    <p>Pays : <select name=\"country\" placeholder=\"Pays\">";
            $data .= "<option>Autre</option>";
            while ($row = $query->fetch()) {
            $nom = $row['name'];
            $data .= "<option>$nom</option>";
        }
        
        $data.= "</p>
                    <input type=\"submit\" placeholder=\"Confirmer\" name=\"Confirmer\" value=\"Confirmer\">"; //

        $data .= "</form></div>";
        $verif = true;
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $info = [];
            foreach($_POST as $name => $content){
                if($name == "country"){
                    if($content != "Autre"){
                        $sql = "SELECT * FROM `country`";
                        $query = $pdo->query($sql);
                        while($row = $query->fetch()){
                            if($row['name']==$content){
                                array_push($info, $row['id']);
                            }
                        }
                    }
                    else{
                        $content = NULL;
                    }
                }
                else if ($name == "mdp2"){
                    if($content != $info[2]){
                        $verif = false;
                        $data .= "<p class=\"error\">Les mots de passe ne correspondent pas.</p>";
                    }
                }
                elseif($name == "email"){
                    $sql = "SELECT COUNT(*) AS exist FROM `users` WHERE email = \"$content\"";
                    $query = $pdo->query($sql);
                    $res = $query->fetch();
                    if($res['exist']>0){
                        $verif = false;
                        $data .= "<p class=\"error\">L'adresse mail existe déjà !</p>";
                    }
                    else{
                        array_push($info, $content);
                    }
                }
                else if ($content!="Envoyer"){
                    array_push($info, $content);
                }
                
            }
            $date = date("Y-m-d H:i:s"); 
            if($verif){
                $sql = $pdo->prepare("INSERT INTO `users`(`name`, `email`, `password`, `register_date`, `admin`, `country_id`) VALUES (?, ?, ?, ?, ?, ?)");
                $sql->execute([$info[0],$info[1],$info[2],$date,0,$info[3]]);
                $data .= "";
                    header("location: http://127.0.0.1:8080/td04/inscriptionUtilisateur.php?usr=$info[0]");
            }
        }
    }
        echo $data;
    ?>
    <br>
    <a id="go_back" href="http://127.0.0.1:8080/">Retourner au menu principal</a>
    </body>
</html>