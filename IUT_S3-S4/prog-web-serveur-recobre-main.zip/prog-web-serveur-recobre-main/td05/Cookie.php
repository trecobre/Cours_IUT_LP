<!DOCTYPE html>

<html lang="fr">
    <head>
        <meta charset="utf-8"/>
        <link rel="stylesheet" href="../global.css">
        <title>Cookie</title>
    </head>
    <body>
    <?php
        $nbVisite;
        if (isset($_COOKIE['visite'])) { 
            $nbVisite = $_COOKIE['visite']+1;
        }
        else{
            $nbVisite = 0;
        }
        setcookie('visite', $nbVisite);
        $data = "<div id=\"cookie\"> tu es venu $nbVisite fois <div>";
        echo $data;
    ?>
    <br>
    <a id="go_back" href="http://127.0.0.1:8080/">Retourner au menu principal</a>
    </body>
</html>