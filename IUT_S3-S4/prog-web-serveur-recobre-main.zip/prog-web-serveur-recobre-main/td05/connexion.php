<!DOCTYPE html>

<html lang="fr">
    <head>
        <meta charset="utf-8"/>
        <link rel="stylesheet" href="../global.css">
        <title>Connexion</title>
    </head>
    <body>
    <?php
        session_start();
        $dsn = "mysql:dbname=etu_trecobre;host=info-titania";
        $user = "trecobre";
        $password = "tEyr93VB";
        $pdo = new PDO($dsn, $user, $password);
        $data = "";
        $data .= "<div id=\"connex_form\"><form method=\"post\">
        <p>User : <input type=\"text\" name= \"user\" placeholder=\"Nom\"></p>
        <p>Password : <input type=\"password\" name= \"pw\" placeholder=\"Password\"></p>
        <input type=\"submit\" placeholder=\"Confirmer\" name=\"Confirmer\" \"></form>";
        $data .= "</div>
        <p>Pas encore inscrit ? M'inscrire <a href=\"http://127.0.0.1:8080/td04/inscriptionUtilisateur.php\">ici</a>.</p>";

        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            if($_POST['user'] != ""){
                $donnee = [];
                foreach($_POST as $name => $content){
                    array_push($donnee, $content);
                }
                $sql = "SELECT COUNT(*) AS exist FROM `users` WHERE name = \"$donnee[0]\" and password = \"$donnee[1]\"";
                $query = $pdo->query($sql);
                $res = $query->fetch();
                if($res['exist']>0){
                    $_SESSION['user'] = $_POST['user'];
                    header("location: http://127.0.0.1:8080/");
                }else{
                    $data .= "<p class=\"error\">User or password wrong... Try anything else</p>";
                }
            }
        }
        echo $data;
    ?>
    <br>
    </body>
</html>

