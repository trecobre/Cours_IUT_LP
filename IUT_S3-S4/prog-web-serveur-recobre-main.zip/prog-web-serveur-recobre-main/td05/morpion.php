<!DOCTYPE html>

<html lang="fr">
    <head>
        <meta charset="utf-8"/>
        <link rel="stylesheet" href="../global.css">
        <title>Morpion</title>
    </head>
    <body>
    <?php
        function victoire(){
            $val = (($_SESSION['case0'] == $_SESSION['case1'])&& ($_SESSION['case0'] == $_SESSION['case2']) || 
                    ($_SESSION['case3'] == $_SESSION['case4'])&& ($_SESSION['case3'] == $_SESSION['case5']) ||
                    ($_SESSION['case6'] == $_SESSION['case7'])&& ($_SESSION['case6'] == $_SESSION['case8']) ||

                    ($_SESSION['case0'] == $_SESSION['case3'])&& ($_SESSION['case0'] == $_SESSION['case6']) ||
                    ($_SESSION['case1'] == $_SESSION['case4'])&& ($_SESSION['case1'] == $_SESSION['case7']) ||
                    ($_SESSION['case2'] == $_SESSION['case5'])&& ($_SESSION['case2'] == $_SESSION['case8']) ||

                    ($_SESSION['case0'] == $_SESSION['case4'])&& ($_SESSION['case0'] == $_SESSION['case8']) ||
                    ($_SESSION['case2'] == $_SESSION['case4'])&& ($_SESSION['case2'] == $_SESSION['case6']));
            return $val;
        }
        $data = "";
        session_start();
        
        if (isset($_SESSION['user'])) {
            if(isset($_COOKIE['partie'])){
                $afficheTab = "<div><table>";
                if(!isset($_GET['i'])){
                    $data .= "<h2>Joueur 1, à vous de jouer !</h2>";
                    setcookie('victoire', false);
                }
                if(!isset($_COOKIE['victoire'])){
                    for ($i=0; $i <3 ; $i++) {
                        $afficheTab .= "<tr>";
                        for($j=0; $j<3; $j++){
                            $index = (3*$i)+$j;
                            if(isset($_GET['i']) && $_GET['i'] == $index ){
                                if(isset($_COOKIE['joueur'])){
                                    $data .= "<h2>Joueur 2, à vous de jouer !</h2>";
                                    $_SESSION['case'.$index] = "O"; 
                                    setcookie('joueur', false); 
                                }else{
                                    $data .= "<h2>Joueur 1, à vous de jouer !</h2>";
                                    $_SESSION['case'.$index] = "X";
                                    setcookie('joueur', true);
                                }
                            }
                            $afficheTab .= "<th>".$_SESSION['case'.$index]."</th>";
                        }
                        $afficheTab .= "</tr>";
                    }
                    $afficheTab .= "</table></div>";
                    $data .= $afficheTab;
                }
                setcookie('victoire', victoire());
                if(isset($_COOKIE['victoire'])){
                    if(isset($_COOKIE['joueur'])){
                        $gagnant = "joueur2";
                    }else{
                        $gagnant = "joueur1";
                    }
                    $data.="<h1>Victoire de $gagnant !!!!!</h1>";
                }
                $data .= "<div id=\"reset\"><form method=\"post\">
                    <input type=\"submit\" placeholder=\"Detruire\" name=\"destroy\" value=\"Réinitialiser la partie\"></form></div>";
                    if ($_SERVER["REQUEST_METHOD"] == "POST") {
                        if(isset($_POST['destroy'])){
                            setcookie('partie',false);
                            setcookie('victoire', false);
                            header("location: morpion.php");
                        }
                    }
                }
            else{
                for($i=0; $i<10; $i++){
                    $_SESSION['case'.$i] = "<a href=\"morpion.php?i=$i\">jouer</a>";
                }
                setcookie('joueur', true);
                setcookie('partie',true);
                setcookie('victoire', false);
                header("location: morpion.php");
            }
        }
        echo $data;
    ?>
    <br>
    <a id = "go_back" href="http://127.0.0.1:8080/">Retourner au menu principal</a>
    </body>
</html>