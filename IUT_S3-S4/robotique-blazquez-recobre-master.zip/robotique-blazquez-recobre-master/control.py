from cmath import sqrt
from ctypes.wintypes import tagMSG
import math
from re import L
from turtle import pos
import numpy as np
import interpo as ipo

def sandbox(t):
    """
    python simulator.py -m sandbox

    Un premier bac à sable pour faire des expériences

    La fonction reçoit le temps écoulé depuis le début (t) et retourne une position cible
    pour les angles des 12 moteurs

    - Entrée: t, le temps (secondes écoulées depuis le début)
    - Sortie: un tableau contenant les 12 positions angulaires cibles (radian) pour les moteurs
    """

    # Par exemple, on envoie un mouvement sinusoidal
    targets = [0]*12
    nb_posture = 4
    duree_posture = 0.3
    posture = int((t/duree_posture) % nb_posture)
    rise = math.radians(15)
    forward = math.radians(30)

    if posture == 0 :
        targets[1] = rise
        targets[7] = rise
    if posture == 1 :
        targets[0] = -forward
        targets[6] = forward
    if posture == 2:
        targets[4] = rise
        targets[10] = rise
    if posture == 3 :
        targets[3] = forward
        targets[9] = -forward

    return targets

# Dimensions (mm)
l1, l2, l3 = 0.045, 0.065, 0.087 


def direct(alpha, beta, gamma):
    """
    python simulator.py -m direct

    Le robot est figé en l'air, on ne contrôle qu'une patte

    Reçoit en argument la cible (alpha, beta, gamma) des degrés de liberté de la patte, et produit
    la position (x, y, z) atteinte par le bout de la patte

    - Sliders: les angles des trois moteurs (alpha, beta, gamma)
    - Entrées: alpha, beta, gamma, la cible (radians) des moteurs
    - Sortie: un tableau contenant la position atteinte par le bout de la patte (en mètres)
    """

    """Prend en entrée les angles moteurs et produit la position atteinte"""
    xp = l1 + math.cos(beta)*l2 + math.cos(beta - gamma)*l3
    yp = math.sin(beta)*l2 + math.sin(beta - gamma)*l3
    
    x = math.cos(alpha)*xp
    y = math.sin(alpha)*xp
    z = yp
    print("x : {} - y : {} - z : {}".format(x, y, z))
    return x, y, z

def inverse(x, y, z):
    """
    python simulator.py -m inverse

    Le robot est figé en l'air, on ne contrôle qu'une patte

    Reçoit en argument une position cible (x, y, z) pour le bout de la patte, et produit les angles
    (alpha, beta, gamma) pour que la patte atteigne cet objectif

    - Sliders: la position cible x, y, z du bout de la patte
    - Entrée: x, y, z, une position cible dans le repère de la patte (mètres), provenant du slider
    - Sortie: un tableau contenant les 3 positions angulaires cibles (en radians)
    """
    l1, l2, l3 = 45, 65, 87

    #Conversion
    l1 = l1 * 10**-3
    l2 = l2 * 10**-3
    l3 = l3 * 10**-3

    A = math.atan2(y,x)
    lp = x - l1

    Bp = math.atan2(z,lp)

    d=math.sqrt(lp**2+z**2) 

    calculBorne = (d**2+l2**2-l3**2) / (2*l2*d)

    if(calculBorne > 1) :
        calculBorne = 1
    elif (calculBorne < -1) :
        calculBorne = -1
    
    Bs = math.acos(calculBorne)

    calculBorne = (l2**2+l3**2-d**2) / (2*l2*l3)

    if(calculBorne > 1) :
        calculBorne = 1
    elif (calculBorne < -1) :
        calculBorne = -1
    
    O = math.acos(calculBorne)

    B = Bp+Bs
    G = O - math.pi

    return [A, B, -G]

def draw(t):
    """
    python simulator.py -m draw

    Le robot est figé en l'air, on ne contrôle qu'une patte

    Le but est, à partir du temps donné, de suivre une trajectoire de triangle. Pour ce faire, on
    utilisera une interpolation linéaire entre trois points, et la fonction inverse précédente.

    - Entrée: t, le temps (secondes écoulées depuis le début)
    - Sortie: un tableau contenant les 3 positions angulaires cibles (en radians)
    """

    values_x = [ # Les valeurs à interpoler
        (0, 0),
        (1, 1),
        (2, 0.5),
        (3, 0)
    ]

    values_y = [ # Les valeurs à interpoler
        (0, 0),
        (1, 2),
        (2, -0.5),
        (3, 0)
    ]
    values_z = [ # Les valeurs à interpoler
        (0, 0),
        (1, 2),
        (2, 0.5),
        (3, 0)
    ]

    point = ipo.interpolate3d(values_x, values_y, values_z, t)

    return inverse(point[0], point[1], point[2])

def legs(leg1, leg2, leg3, leg4):
    """
    python simulator.py -m legs

    Le robot est figé en l'air, on contrôle toute les pattes

    - Sliders: les 12 coordonnées (x, y, z) du bout des 4 pattes
    - Entrée: des positions cibles (tuples (x, y, z)) pour le bout des 4 pattes
    - Sortie: un tableau contenant les 12 positions angulaires cibles (radian) pour les moteurs
    """
    ecart = math.pi / 4
    x = (np.cos(ecart) * leg1[0] - np.sin(ecart) * leg1[1])-0.04
    y = (np.cos(ecart) * leg1[0] + np.sin(ecart) * leg1[1])
    l1 = inverse(-x, -y, leg1[2])

    x = (np.cos(ecart) * leg2[0] - np.sin(-ecart) * leg2[1])-0.04
    y = (np.cos(ecart) * leg2[0] + np.sin(-ecart) * leg2[1])
    l2 = inverse(-x, y, leg2[2])

    x = (np.cos(ecart) * leg3[0] - np.sin(ecart) * leg3[1])-0.04
    y = (np.cos(ecart) * leg3[0] + np.sin(ecart) * leg3[1])
    l3 = inverse(x, y, leg3[2])

    x = (np.cos(ecart) * leg4[0] - np.sin(-ecart) * leg4[1])-0.04
    y = (np.cos(ecart) * leg4[0] + np.sin(-ecart) * leg4[1])
    l4 = inverse(x, -y, leg4[2])

    targets = [ l1[0],l1[1],l1[2],
                l2[0],l2[1],l2[2],
                l3[0],l3[1],l3[2],
                l4[0],l4[1],l4[2]]

    return targets


def walk(t, speed_x, speed_y, speed_rotation):
    """
    python simulator.py -m walk

    Le but est d'intégrer tout ce que nous avons vu ici pour faire marcher le robot

    - Sliders: speed_x, speed_y, speed_rotation, la vitesse cible du robot
    - Entrée: t, le temps (secondes écoulées depuis le début)
            speed_x, speed_y, et speed_rotation, vitesses cibles contrôlées par les sliders
    - Sortie: un tableau contenant les 12 positions angulaires cibles (radian) pour les moteurs
    """
    targets = [0]*12

    nb_posture = 4
    duree_posture = 0.1
    posture = int((t/duree_posture) % nb_posture)
    

    targets[11] = -0.150
    targets[10] = 0.140
    targets[9] = 0.150

    targets[8] = -0.150
    targets[7] = -0.140
    targets[6] =  0.150

    targets[5] = -0.150
    targets[4] = -0.140
    targets[3] = -0.150

    targets[2] = -0.150
    targets[1] = 0.140
    targets[0] = -0.150


    if posture == 1 :
        targets[11] = 0.055
        targets[10] = 0.2
        targets[9] = 0.05

        targets[8] = 0.055
        targets[7] = -0.2
        targets[6] =  0.05

        targets[5] = -0.150
        targets[4] = -0.140
        targets[3] = -0.150

        targets[2] = -0.150
        targets[1] = 0.140
        targets[0] = -0.150
    
    elif posture == 2 :

        targets[11] = -0.05
        targets[10] = 0.1
        targets[9] = 0.2

        targets[8] = -0.05
        targets[7] = -0.1
        targets[6] = 0.2

        targets[5] = 0.055
        targets[4] = -0.2
        targets[3] = -0.05

        targets[2] = 0.055
        targets[1] = 0.2
        targets[0] = -0.05

    elif posture == 3 :

        targets[11] = -0.150
        targets[10] = 0.140
        targets[9] =  0.150

        targets[8] = -0.150
        targets[7] = -0.140
        targets[6] = 0.150

        targets[5] = -0.05
        targets[4] = -0.1
        targets[3] = -0.2

        targets[2] = -0.05
        targets[1] = 0.1
        targets[0] = -0.2

    leg1 = [targets[0],targets[1],targets[2]]
    leg2 = [targets[3],targets[4],targets[5]]
    leg3 = [targets[6],targets[7],targets[8]]
    leg4 = [targets[9],targets[10],targets[11]]
    return legs(leg1,leg2,leg3,leg4)

if __name__ == "__main__":
    print("N'exécutez pas ce fichier, mais simulator.py")