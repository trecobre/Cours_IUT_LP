from re import I
import matplotlib.pyplot as pyplot
import numpy as np
from scipy import interpolate

def interpolate(values, t):
    to_return = 0
    xa = 0
    xb = 0
    ya = 0
    yb = 0
    if t >= 0:
        x = t % values[-1][0]
        get_next = False
        for val in values:
            if get_next:
                xb = val[0]
                yb = val[1]
                get_next = False
            if val[0] <= x:
                xa = val[0]
                ya = val[1]
                get_next = True
        a = (yb - ya)/(xb - xa)

        y = (a * x) + (ya- (a * xa))
        to_return += y 

    return to_return

def interpolate3d(values_x, values_y, values_z, t):
    x = interpolate(values_x, t)
    y = interpolate(values_y, t)
    z = interpolate(values_z, t)
    return (x, y, z)

values_x = [ # Les valeurs à interpoler
    (0, 0),
    (1.2, 6),
    (2, -3),
    (3.3, 4),
    (4.2, -2),
    (5, 0)
]

values_y = [ # Les valeurs à interpoler
    (0, 0),
    (1.2, 6),
    (2.5, -3),
    (3.3, 4),
    (4.2, 0.5),
    (5, 0)
]
values_z = [ # Les valeurs à interpoler
    (0, 0),
    (1.2, 0),
    (2.5, -3),
    (4.1, 4),
    (4.2, 0),
    (5, 0)
]


"""ts = np.linspace(-1, 6, 100)
vsx = [interpolate(values_x, t) for t in ts]
vsy = [interpolate(values_y, t) for t in ts]
vsz = [interpolate(values_z, t) for t in ts]


pyplot.plot(ts, vsx)
pyplot.plot(ts, vsy)
pyplot.plot(ts, vsz)
pyplot.show()"""
