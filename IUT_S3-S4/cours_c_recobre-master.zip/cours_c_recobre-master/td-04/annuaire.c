#include "annuaire.h"
#include "personne.h"
#include <stdlib.h>
#include <stdio.h>
#include <stddef.h>

struct Annuaire creer_base_annuaire(){
    struct Personne perso_defaut = perso_vide();
    struct Annuaire annuaire;
    annuaire.taille =20;
    annuaire.tableau = malloc(annuaire.taille *sizeof(struct Personne));
    for(int i = 0; i< annuaire.taille; i++){
        annuaire.tableau[i] = perso_defaut;
    }
    return annuaire;
}

int ajouter_personne(struct Annuaire *ptr_annuaire, const struct Personne *nouveau){
    int i = 1;
    while(vide(&(ptr_annuaire->tableau[i]))!=0){
        i++;
    }
    if(i>=ptr_annuaire->taille){
        ptr_annuaire->taille += 10;
        ptr_annuaire->tableau = realloc( ptr_annuaire->tableau, ptr_annuaire->taille * sizeof(struct Personne) ) ;
    }
    ptr_annuaire->tableau[i] = *nouveau;
    return EXIT_SUCCESS;
}

void afficher_annuaire(const struct Annuaire *ptr_annuaire){
    if(ptr_annuaire != NULL){
        int nb_afficher = 0;
        for(int i = 0; i< ptr_annuaire->taille; ++i){
            nb_afficher += afficher_personne(&(ptr_annuaire->tableau[i]));
        }
        if(nb_afficher == 0){
            printf("Annuaire vide. \n\n");
        }
    }
    else{
        printf("pas d'annuaire à afficher");
    }
}

void detruire_annuaire(struct Annuaire *ptr_annuaire ){
    //vider annuaire 
    ptr_annuaire->taille = 20;
    ptr_annuaire->tableau = realloc(ptr_annuaire->tableau, ptr_annuaire->taille *sizeof(struct Personne));
    for(int i = 0; i< ptr_annuaire->taille; i++){
        ptr_annuaire->tableau[i] = perso_vide();
    }
}