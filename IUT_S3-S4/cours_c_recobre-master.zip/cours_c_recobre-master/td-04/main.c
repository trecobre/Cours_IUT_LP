#include <stdlib.h>
#include <stdio.h>
#include "annuaire.h"
#include "personne.h"
#include "date.h"
#include "fichier.h"

int main (void){
    //struct Personne perso = perso_vide();

    struct Annuaire annuaire/* = creer_base_annuaire()*/;
    lire_fichier(&annuaire, "annuaire.txt");
    printf("done");
    /*int res = 0;
    while(res != 4){
        printf("Choisissez ce que vous souhaitez faire : \n1- consulter l'annuaire\n2- ajouter une personne à l'annuaire\n3- detruire l'annuaire\n4- Quitter\n\nVotre choix : ");
        scanf("%d", &res);
        switch (res)
        {
        case 1:
            afficher_annuaire(&annuaire);
            break;
        case 2:
            perso = demander_personne();
            ajouter_personne(&annuaire, &perso);
            break;
        case 3:
            detruire_annuaire(&annuaire);
            break;
        default:
            break;
        }
    }*/
    free(annuaire.tableau);
    return EXIT_SUCCESS;
}

