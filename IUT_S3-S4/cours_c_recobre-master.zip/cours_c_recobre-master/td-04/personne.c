#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "personne.h"
#include "date.h"

struct Personne demander_personne(){
    struct Personne personne;
    struct Date date_de_naissance;
    do{
        printf("Nom : ");
        scanf("%s", personne.nom);
    }while(strcmp(personne.nom, "-1")==0);

    do{
        printf("Prenom : ");
        scanf("%s", personne.prenom);
    }while (strcmp(personne.prenom, "-1")==0);
    

    do{
        printf("Mois de naissance : ");
        scanf("%d", &date_de_naissance.mois);
    }while (date_de_naissance.mois>12 || date_de_naissance.mois<1);


    do{
        printf("Jour de naissance : ");
        scanf("%d", &date_de_naissance.jour);
    }while (date_de_naissance.jour>31 || date_de_naissance.jour<1);

    printf("Annee de naissance : ");
    scanf("%d", &date_de_naissance.annee);

    personne.naissance = date_de_naissance;
    return personne;
}

struct Personne perso_vide(){
    struct Date naissance;
    naissance.jour = -1;
    naissance.mois = -1;
    naissance.annee = -1;
    
    struct Personne perso = {"-1", "-1", naissance};
    return perso;
}

int vide(const struct Personne *perso){
    int toReturn = strcmp(perso->nom, "-1") + strcmp(perso->prenom, "-1");
    return toReturn;
}

int afficher_personne(const struct Personne *personne){
    if(vide(personne) != 0){
        printf("Nom : %s\n", personne->nom);
        printf("Prenom : %s\n", personne->prenom);
        afficher_date(&(personne->naissance));
        printf("\n");
        return 1;
    }
    return 0;
}
