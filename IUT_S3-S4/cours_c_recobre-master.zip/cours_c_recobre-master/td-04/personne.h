#ifndef PERSONNE_H
#define PERSONNE_H

#include "date.h"

struct Personne {
    char nom[50];
    char prenom[50];
    struct Date naissance;
};

struct Personne demander_personne();
struct Personne perso_vide();
int vide(const struct Personne *perso);
int afficher_personne(const struct Personne *personne);

#endif
