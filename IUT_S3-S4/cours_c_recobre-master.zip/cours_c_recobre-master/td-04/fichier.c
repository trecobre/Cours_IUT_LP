
#include "personne.h"
#include "date.h"
#include "annuaire.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int lire_fichier(struct Annuaire *ptr_annuaire, const char * nomfic){
    FILE *file;
    file = fopen(nomfic, "r");
    char* ligne = NULL;
    char* nom;
    char tab_nom[50];
    char* prenom;
    char tab_prenom[50];
    int jour;
    int mois;
    int annee;
    char delim[3] = "--";
    int index = 0;
    size_t taille = 1;
    size_t line = getline(&ligne, &taille, file);
    while(line!=-1){
        line = getline(&ligne, &taille, file);
        nom = strtok(ligne, delim);
        prenom = strtok(NULL, delim);
        jour = atoi(strtok(NULL, delim));
        mois = atoi(strtok(NULL, delim));
        annee = atoi(strtok(NULL, delim));

        strcpy(tab_nom, nom);
        strcpy(tab_prenom, prenom);

        struct Date dnaissance = {jour, mois, annee};
        struct Personne perso = {
            .nom = tab_nom,
            .prenom = tab_prenom,
            .naissance = dnaissance
        };
        /*perso.nom = tab_nom;
        perso.prenom = tab_prenom;
        perso.naissance = dnaissance;*/
        
        afficher_personne(&perso);
        ptr_annuaire->tableau[index] = perso;
        ++index;
    }
    return 1;
}