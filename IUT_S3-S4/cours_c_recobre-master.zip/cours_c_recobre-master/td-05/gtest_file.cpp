
#include "file.h"
#include "cellule.h"
#include "personne.h"
#include "date.h"
#include <gtest/gtest.h>


TEST(FileTest, filePush){
    File_t *file = File_create();
    int lng = 0;
    for(int i=0; i<10; i++){
        File_push(file, &i, NULL, true);
        EXPECT_EQ(i+1, File_lenght(file));
        lng = i+1;
    }
    char a = 'a';
    char a2[15] = "aaaaaaaaaaaaaa";
    char* as = "aaaaa";
    File_push(file, &a, NULL, true);
    File_push(file, &a2, NULL, true);
    File_push(file, &as, NULL, true);
    EXPECT_EQ(lng+=3, File_lenght(file));
    
    struct Date naissance;
    naissance.jour = 25;
    naissance.mois = 11;
    naissance.annee = 2002;

    /*struct Personne perso;
    perso.nom = "recobre";
    perso.prenom = "theo";
    perso.naissance = naissance;*/
    File_push(file, &naissance, d_free, false);
    //File_push(file, &perso);
    EXPECT_EQ(lng+1, File_lenght(file));
    File_free(file);
}

TEST(FileTest, filePop){
    File_t *file = File_create();
    for(int i=0; i<10; i++){
        File_push(file, &i, NULL, true);
    }
    for(int i=10; i>0; i--){
        EXPECT_EQ(i, File_lenght(file));
        File_pop(file);
    }
    File_free(file);
}

TEST(FileTest, fileLenght){
    File_t *file = File_create();
    for(int i=0; i<100; i++){
        EXPECT_EQ(i, File_lenght(file));
        File_push(file, &i, NULL, true);
    }
    for(int i=File_lenght(file); i>0; i--){
        EXPECT_EQ(i, File_lenght(file));
        File_pop(file);
    }
    File_free(file);
}

TEST(FileTest, fileEmpty){
    File_t *file = File_create();
    EXPECT_EQ(true, File_empty(file));
    int nb = 1;
    File_push(file, &nb, NULL, true);
    EXPECT_EQ(false, File_empty(file));
    File_free(file);
}


int main(int argc, char **argv){
    ::testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}