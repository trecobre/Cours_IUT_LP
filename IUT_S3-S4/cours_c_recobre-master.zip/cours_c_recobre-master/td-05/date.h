#ifndef DATE_H
#define DATE_H

struct Date {
    int jour ;
    int mois ;
    int annee ;
} ;
typedef struct Date Date_s;

void afficher_date(const struct Date *ptr_date);

typedef void (*date_free)(void *);
extern date_free d_free;

#endif