#include "file.h"
#include "cellule.h"
#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <cstring>

File_t* File_create(){
    File_t *file = (File_t*)malloc(sizeof(File_t));
    file->first = file->last = 0;
    file->lenght = 0;
    return file;
}

void File_push(File_t* f, gpointer v, void (*free_d)(void *), bool primitive){
    if(primitive){
        free_d = *free;
    }
    Cell_t* cell = create_cell(v, free_d);
    if(f->lenght == 0){
        f->first = cell;
    }
    else{
        Cell_t* last_cell = f->last;
        last_cell->next = cell;
    }
    f->last = cell;
    f->lenght++;
}
/*void File_push(File_t* f, gpointer v){
    File_push(f, v, NULL);
}*/

gpointer File_pop(File_t* f){
    Cell_t * c = f->first;
    gpointer val = Cell_value(c);
    
    if(f->first == f->last){
        f->last = NULL;
    }
    Cell_t* first_cell = f->first;
    f->first = first_cell->next;
    f->lenght--;
    Cell_destroy(c);
    return val;
}

bool File_empty(const File_t* f){
    return f->first == 0; 
}

int File_lenght(const File_t* f){
    return f->lenght;
}

void File_free(File_t* f){
    while(f->lenght > 0){
        File_pop(f);
    }
    free(f);
}