#include <stdlib.h>
#include "cellule.h"
#include <stdio.h>
#include <string.h>

Cell_t* create_cell(gpointer val, void (*free_d)(void *)){
    Cell_t *cell = (Cell_t*)malloc(sizeof(Cell_t));
    if(free_d!=NULL){
        cell->funcfree = free_d;
    }
    else{
        cell->funcfree = NULL;
    }
    
    cell->next = 0;
    val = (gpointer) malloc(sizeof(val));
    cell->val = val;
    return cell;
}

gpointer Cell_value(Cell_t *c){
    return c->val;
}

void free_cell_obj(void (*freefunc)(void *), gpointer obj){
    freefunc(obj);
}

void Cell_destroy(Cell_t *c){
    c->funcfree(c->val);
    free(c->val);
    free(c);
}