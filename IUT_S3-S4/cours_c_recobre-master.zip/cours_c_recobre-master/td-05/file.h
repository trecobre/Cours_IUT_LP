#ifndef FILE_H
#define FILE_H
#include "cellule.h"
#include <stdbool.h>

struct File_s{
    Cell_t * first;
    Cell_t * last;
    int lenght;
};

typedef struct File_s File_t;

File_t* File_create();
void File_push(File_t* f, gpointer v, void (*free_d)(void *), bool primitive);
gpointer File_pop(File_t* f);
int File_lenght(const File_t* f);
bool File_empty(const File_t* f);
//int File_first(const File_t* f);
//int File_last(const File_t* f);
void File_free(File_t* f); 

#endif