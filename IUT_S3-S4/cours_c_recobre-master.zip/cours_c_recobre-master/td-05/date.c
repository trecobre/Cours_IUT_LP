#include <stdlib.h>
#include <stdio.h>
#include "date.h"

void afficher_date(const struct Date *ptr_date){
    if(!(ptr_date->jour == -1 && ptr_date->mois == -1)){
        printf("Date de naissance : %d/%d/%d\n", ptr_date->jour, ptr_date->mois, ptr_date->annee);
    }
}

void date_free(void * date){
    free(date);
}