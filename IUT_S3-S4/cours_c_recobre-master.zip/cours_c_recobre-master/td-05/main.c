#include <stdio.h>
#include <stdlib.h>
#include "file.h"
#include "cellule.h"

int main(void){
    printf("create file\n");
    File_t* file = File_create();
    printf("file created\n");
    printf("lenght : %d\n\n", File_lenght(file));
    printf("add cell\n");
    int v = 10;
    File_push(file, v);
    printf("cell added\n\n");
    printf("add 2nd cell\n");
    v = 20;
    File_push(file, v);
    printf("2nd cell added\n\n");
    printf("add 3rd cell\n");
    v = 30;
    File_push(file, v);
    printf("3rd cell added\n");
    printf("lenght : %d\n\n", File_lenght(file));
    printf("1st cell : %d \nlast cell : %d \n\n", Cell_value(file->first), Cell_value(file->last));
    printf("pop first\n");
    v = File_pop(file);
    printf("1st cell : %d \nlast cell : %d\npoped value :%d \n", Cell_value(file->first), Cell_value(file->last), v);
    printf("lenght : %d\n\n", File_lenght(file));
    File_free(file);
    printf("file free ^^\n");
    return EXIT_SUCCESS;
}