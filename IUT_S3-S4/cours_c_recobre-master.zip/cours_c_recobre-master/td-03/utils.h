#ifndef UTILS_H
#define UTILS_H


/*size_t taille(const char* tab);
char* ajouter(char* dest, char* src);*/
int comparer(const char* tab1, const char* tab2);
#endif
