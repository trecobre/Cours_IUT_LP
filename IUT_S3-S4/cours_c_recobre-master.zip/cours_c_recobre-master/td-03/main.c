#include <stdlib.h>
#include <stdio.h>
#include "utils.h"
#include <string.h>

struct personne
{
    char nom[25];
    char prenom[25];
    int age;
};


int main (void){
    /*struct personne feef = {"fe", "ef", 25};
    printf("%ld \n",sizeof(feef));
    struct personne a[5];
    for(int i=0; i<5; i++){
        printf("adresse de %d = %p \n",i, (void*) &a[i]) ;
    }*/

    char* mot1 = "abdc";
    char* mot2 = "abcd";
    int valeur = comparer(mot1, mot2);
    printf("%d", valeur);
}

