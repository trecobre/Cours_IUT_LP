#include <stdbool.h>

/*size_t taille(const char* tab){
    size_t compter = 0;
    while(tab[compter] != '0'){
        ++compter;
    }
    return compter+1; 
}

char* ajouter(char* dest, char* src){
    size_t longueur_dest = taille(dest);
    size_t longueur_src = taille(src);
    
    int index = 0;
    while(tab[longueur + index] != '0'){
        
    }
}
*/
int comparer(const char* tab1, const char* tab2){
    int i = 0; 
    int pareil = 0; 
    bool sortie = false;
    while(!sortie){
        if(tab1[i]!='0' || tab2[i]!='0' || pareil == 0){
            if (tab1[i] < tab2[i]){
                pareil = -1;
            }
            else if(tab1[i] > tab2[i]){
                pareil = 1;
            }
            ++i;
        }
        else{
            sortie = true;
        }
    }
    return pareil;
}