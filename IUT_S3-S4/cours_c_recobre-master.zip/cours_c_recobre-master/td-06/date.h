#ifndef DATE_H
#define DATE_H

struct Date {
    int jour ;
    int mois ;
    int annee ;
} ;
typedef struct Date Date_s;

void afficher_date(const struct Date *ptr_date);

Date_s create_date(int* j, int* m, int* a);

extern void (*free_date)(void *);

#endif