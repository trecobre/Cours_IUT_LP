#ifndef list_H
#define list_H
#include "cellule.h"
#include <stdbool.h>

typedef Cell_t* Address;

struct list_s{
    Cell_t * first;
};

typedef struct list_s list_t;

list_t* list_create();
void list_add(Address f, gpointer v);
void list_add_np(Address f, gpointer v, void (*freefunc)(void *));
Address address_first (list_t *l);
Address address_next (Address Address );
gpointer get_value (Address Address );
void modifie_value (Address Address, gpointer val);
void set_first(list_t *l, gpointer val);
void set_next (Address Address, gpointer val);
void delete_first(list_t *l);
void delete_next(Address Address );
void list_free(list_t *l); 

#endif