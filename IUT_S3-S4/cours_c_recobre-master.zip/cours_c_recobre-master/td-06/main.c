#include <stdio.h>
#include <stdlib.h>
#include "list.h"
#include "cellule.h"
#include "date.h"

int main(void){
    printf("create list\n");
    list_t* list = list_create();
    printf("list created\n");
    printf("add cell\n");

    //int v = malloc(sizeof(int));
    int v = 10;

    set_first(list, &v);
    Address addr = address_first(list);
    printf("1st cell : %p \n", get_value(addr));
    printf("cell added\n\n");

    printf("add 2nd cell\n");
    v = 20;
    //addr = address_next(addr);
    list_add(addr, &v);
    addr = address_next(addr);

    printf("2nd cell added\n\n");

    Address temp_addr = addr;

    printf("add 3rd cell\n");
    v = 30;
    list_add(addr, &v);
    addr = address_next(addr);
    printf("3rd cell added\n");

    printf("add 4th cell\n");
    v = 40;
    list_add(addr, &v);
    addr = address_next(addr);
    printf("4th cell added\n\n");

    printf("add 5th cell\n");
    v = 50;
    list_add(addr, &v);
    addr = address_next(addr);
    printf("5th cell added\n\n");

    printf("add 6th cell\n");
    v = 60;
    list_add(addr, &v);
    addr = address_next(addr);
    printf("6th cell added\n\n");
    
    addr = address_first(list);
    for(int i = 1; i<7; i++){
        printf("cell : %p \n", get_value(addr));
        addr = address_next(addr);
    }

    printf("add between 2nd and 3rd cell\n");
    //printf("cell : %p \n", get_value(temp_addr));
    v = 25;
    list_add(temp_addr, &v);
    printf("2.5th cell added\n\n");

    int jour = 25;
    int mois = 11;
    int annee = 2002;

    Date_s date = create_date(&jour, &mois, &annee);
    //Date_s date2 = create_date(&jour, &mois, &annee);
    list_add_np(temp_addr, &date, free_date);

    addr = address_first(list);
    for(int i = 1; i<9; i++){
        printf("cell : %p \n", get_value(addr));
        addr = address_next(addr);
    }

    v = 425;
    modifie_value(address_next(address_next(temp_addr)), &v);

    printf("pop first\n");
    delete_first(list);

    printf("pop next 2nd\n");
    delete_next(temp_addr);

    addr = address_first(list);
    for(int i = 1; i<6; i++){
        printf("cell : %p \n", (get_value(addr)));
        addr = address_next(addr);
    }

    printf("1st cell : %p \n", Cell_value(list->first));
    list_free(list);
    printf("file free ^^\n");

    //free(&v);
    return EXIT_SUCCESS;
}


