#include <stdlib.h>
#include "cellule.h"
#include <stdio.h>
#include <string.h>

Cell_t* create_cell(gpointer val, void (*free_d)(void *)){
    Cell_t * cell = malloc(sizeof(Cell_t * ));
    cell->funcfree = free_d;
    cell->val = val;
    cell->val = malloc(sizeof(val));
    cell->next = NULL;
    return cell;
}

gpointer Cell_value(Cell_t *c){
    gpointer *temp = (gpointer *)c->val;
    return temp;
}

void free_cell_obj(void (*freefunc)(void *), gpointer obj){
    freefunc(obj);
}

void Cell_destroy(Cell_t *c){
    c->funcfree(c->val);
    free(c);
}

Cell_t* Cell_next(Cell_t * c){
    return c->next;
}
void Cell_change_val(Cell_t * c, gpointer val){
    c->funcfree((c->val));
    c->val = val;
    c->val = malloc(sizeof(val));
}