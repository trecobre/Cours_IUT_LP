#include "list.h"
#include "cellule.h"
#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>

list_t* list_create(){
    list_t *list = (list_t*)malloc(sizeof(list_t));
    gpointer *vide = malloc(sizeof(char));
    list->first = create_cell(vide, *free);
    free(vide);
    return list;
}

void list_add_np(Address address, gpointer v, void (*freefunc)(void *)){
    Cell_t* cell = create_cell(v, *freefunc);
    //if(address_next(address) != address){
        cell->next = address->next;
    //}
    
    address->next = cell;
}

void list_add(Address address, gpointer v){
    Cell_t* cell = create_cell(v, *free);
    //if(address_next(address) != address){
        cell->next = address->next;
    //}
    
    address->next = cell;
}


Address address_first (list_t *l){
    return l->first;
}

Address address_next (Address address ){
    return Cell_next(address);
}

gpointer get_value (Address address){
    return (Cell_value(address));
}

void modifie_value (Address address, gpointer val){
    Cell_change_val(address, val);
}

void set_first(list_t *l, gpointer val){
    Cell_change_val(l->first, val);
}

void set_next (Address address, gpointer val){
    Cell_change_val(address, val);
}

void delete_first(list_t *l){
    Cell_t * c = l->first;
    Cell_t* first_cell = l->first;
    l->first = first_cell->next;
    Cell_destroy(c);
}

void delete_next( Address address ){
    Cell_t * c = address;
    Cell_t* next = c->next;
    c->next = next->next;
    Cell_destroy(next);
}

void list_free(list_t * l){
    while(l->first->next != 0){
        delete_next(l->first);
    }
    delete_first(l);
    free(l);
}

