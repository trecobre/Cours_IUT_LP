#include <stdlib.h>
#include <stdio.h>
#include "date.h"

void afficher_date(const struct Date *ptr_date){
    if(!(ptr_date->jour == -1 && ptr_date->mois == -1)){
        printf("Date de naissance : %d/%d/%d\n", ptr_date->jour, ptr_date->mois, ptr_date->annee);
    }
}

void date_free(void* date){
    printf("youhytgv");
    free(date);
}
void (*free_date)(void *) = &date_free;

Date_s create_date(int *j, int *m, int *a){
    Date_s *date = malloc(sizeof(int)*3);
    date->jour = j;
    date->mois = m;
    date->annee = a;
    return *date;
}

