#ifndef CELLULE_H
#define CELLULE_H

typedef void* gpointer;

struct Cell_s{
    gpointer val;
    struct Cell_s* next;
    void (*funcfree)(void *);
};

typedef struct Cell_s Cell_t;



Cell_t* create_cell(gpointer val, void (*free_d)(void *));
gpointer Cell_value(Cell_t *c);
void Cell_destroy(Cell_t* c);
Cell_t* Cell_next(Cell_t * c);
void Cell_change_val(Cell_t * c, gpointer val);
void cell_set_next(Cell_t * c, Cell_t * next);

#endif