#include <stdlib.h>
#include <stdio.h>
#include "utils.h"

void demander_entier(char * nom, int * reponse){
    printf("Combien vaut %s ? ", nom);
    scanf("%d", reponse);
}

void echanger_entier(int * a, int * b){
    int temp = b;
    b = a;
    a = temp;
    printf("a vaut %d et b vaut %d.\n", a, b);
}

void ordonner_entier(int * a, int * b){


    if(*b<*a){
        echanger_entier(a, b);
    }
    else{
        printf("(aucun changement : a vaut %d et b vaut %d.\n", a, b);
    }
}

void forme_normalise(int * heure, int * minute, int * seconde){
    while(*seconde > 60){
        *minute += 1;
        *seconde -= 60;
    }
    while(*minute > 60){
        *heure +=1;
        *minute -= 60;
    }
    printf("%d heure(s), %d minute(s), %d seconde(s) \n", *heure, *minute, *seconde);
}

void normaliser_duree(struct Duree *adr_duree){
    while(adr_duree->seconde > 60){
        adr_duree->minute += 1;
        adr_duree->seconde -= 60;
    }
    while(adr_duree->minute > 60){
        adr_duree->heure +=1;
        adr_duree->minute -= 60;
    }
    printf("%d heure(s), %d minute(s), %d seconde(s) \n", adr_duree->heure, adr_duree->minute, adr_duree->seconde);
}

struct Duree construire_duree(int * heures, int * minutes, int * secondes){
    struct Duree duree = {
        .heure = *heures,
        .minute = *minutes,
        .seconde = *secondes
    };
    return duree;
}

void eclate_duree(struct Duree *adr_duree, int * heures, int * minutes, int * secondes){
    *heures = adr_duree->heure;
    *minutes = adr_duree->minute;
    *secondes = adr_duree->seconde;
    printf("%d heure(s), %d minute(s), %d seconde(s) \n", *heures, *minutes, *secondes);
}