#include <stdlib.h>
#include <stdio.h>
#include "utils.h"

int main(void){
    /*Exercice 1 &2*/
    /*
    int a;
    int b;
    demander_entier("a", &a);
    demander_entier("b", &b);
    echanger_entier(a, b); //Exercice 1
    ordonner_entier(a, b); //Exercice 2
    */

    /*Exercice maison*/
    int heure;
    int minute;
    int seconde;
    demander_entier("heure", &heure);
    demander_entier("minute", &minute);
    demander_entier("seconde", &seconde);
    //forme_normalise(&heure, &minute, &seconde);
    struct Duree duree;
    duree = construire_duree(&heure, &minute, &seconde);
    normaliser_duree(&duree);
    eclate_duree(&duree, &heure, &minute, &seconde);
}


