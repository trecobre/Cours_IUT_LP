#ifndef UTILS_H
#define UTILS_H

struct Duree
{
    int heure;
    int minute;
    int seconde;
};
void demander_entier(char * nom, int * reponse);
void echanger_entier(int * a, int * b);
void ordonner_entier(int * a, int * b);
void forme_normalise(int * heure, int * minute, int * seconde);
void normaliser_duree(struct Duree *adr_duree);
struct Duree construire_duree(int * heures, int * minutes, int * secondes);
void eclate_duree(struct Duree *adr_duree, int * heures, int * minutes, int * secondes);
#endif
