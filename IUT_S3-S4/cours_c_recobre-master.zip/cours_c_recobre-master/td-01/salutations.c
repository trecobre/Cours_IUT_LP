// salutations.c
#include <stdio.h>
#include "salutations.h"

void dire_bonjour()
{
   char nom[50];
   int annee;
   scanf("%s", nom);
   scanf("%d", & annee);
   printf("Bonjour %s, vous avez %d ans\n", nom, 2021-annee);
}