// fichier hello.c, premier exemple

#include "salutations.h"
#include <stdlib.h>

// hello.c
int main(void)
{
   dire_bonjour();
   return EXIT_SUCCESS;
}
