// salutations.h
#if !defined SALUTATIONS_H
#define SALUTATIONS_H

void  dire_bonjour();

#endif