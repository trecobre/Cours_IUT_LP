# But du cours

Découverte des notions et méthodes d'apprentissage automatique.

# Infos sur le cours

- Le langage utilisé sera `Python` (version 3)
- Les TP seront rédigés à partir de NoteBooks `Jupyter` : un calepin pourra être demandé à la fin de chaque séance

# Ressources

- Serveur `Mattermost` (prise de contact avec le groupe) : https://mattermost.iut.u-bordeaux.fr/s3-info-21-22/channels/town-square
- Serveur `Discord` (discussions, questions, partage d'écran/audio pour demander une aide individuelle) : TODO:
- Dépôt `Gitlab` : https://gitlab-ce.iut.u-bordeaux.fr/Pierre/m4101_ia_etd

# Livres

- Linear Algebra and Learning from Data de Gilbert Strang.
- Understanding Machine Learning : From Theory to Algorithms.
- Hands-On Machine Learning with Scikit-Learn, Keras, and Tensorflow: Concepts, Tools, and Techniques to Build Intelligent Systems.
Notebooks associés sur : https://github.com/ageron/handson-ml2

# Environnement

Plusieurs solutions seront possibles, l'objectif étant de disposer de l'éditeur `VSCode` et de l'interpréteur `Python` (version 3) avec les paquets de développement associés pour l'analyse de données et l'apprentissage automatique.

On recommande les extensions suivantes :

- https://marketplace.visualstudio.com/items?itemName=ms-python.python
- https://marketplace.visualstudio.com/items?itemName=ms-python.vscode-pylance

Si vous disposez déjà d'un environnement `Python`, vous pouvez simplement ajouter une liste des paquets avec les commandes suivantes (pour une distribution utilisant les paquets `.deb` comme `Debian` ou `Ubuntu`) :

```bash
sudo apt-get install python3-pip python3-dev jupyter
pip3 install jupyter
pip3 install numpy scipy matplotlib
pip3 install tensorflow
pip3 install keras sklearn seaborn
pip3 install ipykernel
python3 -m ipykernel install --user
```

Attention, si votre processeur ne dispose pas des options `AVX2` et `FMA` (sous `VirtualBox` par exemple), vous devrez probablement recompiler vous même la bibliothèque `TensorFlow` (attention, l'opération est un peu longue, 9h dans une VM `VirtualBox` Debian avec 2 CPUs et 4Go RAM) :

```bash
pip3 uninstall tensorflow
git clone https://github.com/tensorflow/tensorflow
git checkout r2.4
```

Installer l'outil `Bazel` :

```bash
sudo apt install curl gnupg
curl -fsSL https://bazel.build/bazel-release.pub.gpg | gpg --dearmor > bazel.gpg
sudo mv bazel.gpg /etc/apt/trusted.gpg.d/
echo "deb [arch=amd64] https://storage.googleapis.com/bazel-apt stable jdk1.8" | sudo tee /etc/apt/sources.list.d/bazel.list
sudo apt update && sudo apt install bazel-3.1.0
sudo ln -s /usr/bin/bazel-3.1.0 /usr/bin/bazel
```

Compiler `TensorFlow` :

```bash
./configure
bazel build --config=noaws --config=nogcp --config=nohdfs --config=nonccl -c opt --copt=-mno-avx --copt=-mno-avx2 --copt=-mno-fma //tensorflow/tools/pip_package:build_pip_package
./bazel-bin/tensorflow/tools/pip_package/build_pip_package /tmp/tensorflow_pkg
```

Installer :

```bash
pip3 install /tmp/tensorflow_pkg/tensorflow-2.4.0-cp37-cp37m-linux_x86_64.whl
```

Tester :

```bash
python3 -c "import tensorflow as tf;print(tf.reduce_sum(tf.random.normal([1000, 1000])))"
```

### VM VirtualBox

Voici les procédures pour installer `VirtualBox` sous :

- Linux : https://wiki.debian.org/VirtualBox
- Windows : https://www.virtualbox.org/manual/ch02.html#installation_windows
- Mac : https://www.virtualbox.org/manual/ch02.html#installation-mac

Vous pouvez télécharger une image `Debian` (3.8Go) avec les principaux outils pour la programmation `C` et `Python` sous : https://box.iut.u-bordeaux.fr/f/614adb35b7694af2a844/

Pour l'importer dans `VirtualBox` : Menu "Fichier / Importer un appareil virtuel" et sélectionner le fichier téléchargé avec l'extension `.ova`.

Les comptes disponibles dans cette VM sont :

- root / root
- user / user

Récupérer ensuite la version pré-compilée de `TensorFlow` ('tensorflow-2.4.0-cp37-cp37m-linux_x86_64.whl') à cette adresse https://box.iut.u-bordeaux.fr/f/65505fe2587d4dd6bdcc/ dans le répertoire `/tmp/`.

Puis, installer les paquets `Python` mentionnés dans la section précédente :

```bash
sudo apt-get update
sudo apt-get install python3-pip python3-dev jupyter
pip3 install jupyter
pip3 install --upgrade numpy
pip3 install scipy matplotlib
pip3 install /tmp/tensorflow-2.4.0-cp37-cp37m-linux_x86_64.whl
pip3 install keras sklearn seaborn
pip3 install ipykernel
python3 -m ipykernel install --user
```

Enfin, configurer `Python` en version 3 par défaut :

```bash
sudo update-alternatives --install /usr/bin/python python /usr/bin/python2.7 1
sudo update-alternatives --install /usr/bin/python python /usr/bin/python3.7 2
#update-alternatives --list python
#update-alternatives --config python
```

Un image `Debian` (5Go) avec ces modifications est disponible ici : https://mybox.inria.fr/f/086b644be8ff4827921b/

### Docker

Si vous pouvez installer `Docker` sur votre machine, vous pourrez alors construire votre propre image (un exemple de `Dockerfile` ici :https://gitlab-ce.iut.u-bordeaux.fr/Pierre/m4101_ia_etd/-/blob/master/deep/.devcontainer/Dockerfile), ou utiliser l'image (11Go) suivant : https://hub.docker.com/repository/docker/tthor/test

```bash
docker pull tthor/test
docker run -it tthor/test
```

Voici les procédures pour installer `Docker` sous :

- Linux : https://docs.docker.com/engine/install/debian/
- Windows : https://docs.docker.com/docker-for-windows/install/
- Mac : https://docs.docker.com/docker-for-mac/install/

Je vous recommande d'utiliser l'éditeur `VSCode` dans votre environnement natif, et d'activer le plugin `remote-docker` (https://code.visualstudio.com/docs/remote/containers-tutorial) afin de profiter du conteneur `Docker` pour compiler/exécuter/tester vos programmes. Un fichier de configuration est disponible sous : https://gitlab-ce.iut.u-bordeaux.fr/Pierre/m4101_ia_etd/-/blob/master/deep/.devcontainer/devcontainer.json

### Espaces collaboratifs en ligne

Il existe aussi de nombreux services en ligne accessibles avec un compte gratuit permettant de disposer d'un environnement de développement :

- 'Repl.it' (https://repl.it/) : IDE multi-langages (C/C++/Java/Python... ) et multi-technos (Web, mobile)
- 'Colaboratory' (https://colab.research.google.com/) : limité à `Python` et aux notebooks `Jupyter`, les ressources matérielles mises à disposition peuvent être limitées
- 'Binder' (https://mybinder.org/) : transformer ce dépôt en une collection de notebooks [interactifs](https://mybinder.org/v2/gl/ramet%2Fm4101-ia-etd/HEAD)

# Séance 1 : 2h

- Introduction [cours 1/2](https://gitlab-ce.iut.u-bordeaux.fr/Pierre/m4101_ia_etd/-/blob/master/intro/m4101_ia_intro.pdf)
- Prise en main Python : [cours python](https://ramet.gitlab.io/python-telecom/)
- Exercice Python : [exercice](https://gitlab-ce.iut.u-bordeaux.fr/Pierre/m4101_ia_etd/-/blob/master/intro/exercice.md)

# Séance 2 : 2h

- Introduction [cours 2/2](https://gitlab-ce.iut.u-bordeaux.fr/Pierre/m4101_ia_etd/-/blob/master/intro/m4101_ia_intro.pdf)
- Demo Python [first dnn](https://ramet.gitlab.io/m4101-ia-etd/first_dnn/first-neural-network-keras.html)

# Séance 3 : 2h

- Analyse de données [cours](https://gitlab-ce.iut.u-bordeaux.fr/Pierre/m4101_ia_etd/-/blob/master/classification/m4101_ia_analyse-donnees.pdf)
- Jupyter [notebook analyse](https://gitlab-ce.iut.u-bordeaux.fr/Pierre/m4101_ia_etd/-/blob/master/classification/m4101_ia_analyse-donnees.ipynb)
- Préparer un jeu de données [pandas](https://ramet.gitlab.io/m4101-ia-etd/pandas/)
- Jupyter [notebook pandas](https://gitlab-ce.iut.u-bordeaux.fr/Pierre/m4101_ia_etd/-/blob/master/pandas/ade.ipynb)
- Demo PCA [nuages de points](https://ramet.gitlab.io/m4101-ia-etd/pca/)
- Jupyter [notebook PCA](https://gitlab-ce.iut.u-bordeaux.fr/Pierre/m4101_ia_etd/-/blob/master/pca/pca.ipynb)

# Séance 4 : 2h

- Algorithme KNN [cours](https://gitlab-ce.iut.u-bordeaux.fr/Pierre/m4101_ia_etd/-/blob/master/classification/m4101_ia_knn.pdf)
- Demo KNN [systèmes de recommandations](https://ramet.gitlab.io/m4101-ia-etd/knn/)
- Jupyter [notebook KNN](https://gitlab-ce.iut.u-bordeaux.fr/Pierre/m4101_ia_etd/-/blob/master/knn/knn.ipynb)
- La malédiction de la dimensionalité [notebook dimension](https://gitlab-ce.iut.u-bordeaux.fr/Pierre/m4101_ia_etd/-/blob/master/classification/m4101_ia_dimension.ipynb)

# Séance 5 : 2h

- Deep Learning [cours](https://gitlab-ce.iut.u-bordeaux.fr/Pierre/m4101_ia_etd/-/blob/master/deep/deep.pdf)
- Jupyter [notebook deep1](https://gitlab-ce.iut.u-bordeaux.fr/Pierre/m4101_ia_etd/-/blob/master/deep/DEEP_1.ipynb)

# Séance 6 : 2h

- Jupyter [notebook deep2](https://gitlab-ce.iut.u-bordeaux.fr/Pierre/m4101_ia_etd/-/blob/master/deep/DEEP_2.ipynb)
- Jupyter [notebook deep3](https://gitlab-ce.iut.u-bordeaux.fr/Pierre/m4101_ia_etd/-/blob/master/deep/DEEP_3.ipynb)
- Jupyter [notebook deep4](https://gitlab-ce.iut.u-bordeaux.fr/Pierre/m4101_ia_etd/-/blob/master/deep/DEEP_4.ipynb)

# Séance 7 : 2h

- Optimisation [cours](https://gitlab-ce.iut.u-bordeaux.fr/Pierre/m4101_ia_etd/-/blob/master/optim/optim.pdf)
- Jupyter [notebook optim1](https://gitlab-ce.iut.u-bordeaux.fr/Pierre/m4101_ia_etd/-/blob/master/optim/m4101_ETD_ia_TP3_V1_Partie1.ipynb)

# Séance 8 : 2h

- Apprentissage par renforcement [cours](https://gitlab-ce.iut.u-bordeaux.fr/Pierre/m4101_ia_etd/-/blob/master/optim/rl.pdf)
- Jupyter [notebook optim2](https://gitlab-ce.iut.u-bordeaux.fr/Pierre/m4101_ia_etd/-/blob/master/optim/m4101_ETD_ia_TP3_V1_Partie2.ipynb)

# Projets

On vous a propose de choisir l’un des 3 blocs de TP ci-dessus et de réaliser un notebook Jupyter qui « rejoue » une démarche similaire, mais sur un problème différent. Par exemple :

- pour le TP1 (PCA) : choisir un autre jeu de données de classification (sklearn.datasets ou fichier CSV), préparer les données, tenter de classifier directement avec 2 attributs puis faire une réduction de dimension pour obtenir un meilleur classifieur.

- pour le TP2 (Deep) :
  - choisir un autre problème de classification et entraîner un réseau de neurones simple,
  - reprendre celui sur les chiffres et étudier l’impact d’un jeu de données « faussé » en apprentissage (suivant le taux d’inversion entre le chiffre 1 et 7 par exemple).

- pour le TP3 (MinMax et/ou RL) : choisir un autre jeu à somme nulle complet, présentant une petite combinatoire, et faire tourner l'algorithme MinMax avec Alpha/Beta, et/ou un algorithme d'apprentissage par renforcement.

Vous devez travailler en **équipe de 4 ou 5 étudiants** et communiquer rapidement à votre enseignant la composition de votre équipe, ainsi que le sujet détaillé retenu. Vous remettrez ce notebook sur un dépôt Git hébergé sur le serveur Gitlab du département (vous donnerez le droit « Reporter » à votre enseignant).
**La date de remise est fixée au vendredi 1 avril 2022 minuit**.
