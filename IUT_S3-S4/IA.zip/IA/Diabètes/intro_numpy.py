import numpy as np
import matplotlib.pyplot as plt

x = list()
x.append(0.1)
x.append(0.2)
x.append(0.3)
x.append(0.4)
x.append(0.5)
x.append(0.6)

y = list()
for i in x:
    y.append(np.sin(i))

"""plt.figure()
plt.plot(x, y)
plt.xlabel(x)
plt.ylabel(y)
plt.title("ma première figure")
plt.show()"""

x = list(range(100))
y = np.sin(x)

"""plt.figure()
plt.plot(x, y)
plt.xlabel(x)
plt.ylabel(y)
plt.title("ma première figure")
plt.show()"""

x= np.arange(0.0, 3.14*2, (3.14-0.0)/1000.0)
y = np.sin(x)

plt.figure()
plt.plot(x, y)
plt.xlabel(x)
plt.ylabel(y)
plt.title("ma première figure")
plt.show()