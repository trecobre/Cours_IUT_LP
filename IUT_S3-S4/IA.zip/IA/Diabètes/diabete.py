import pandas as pnd

df = pnd.read_csv("diabetes.csv")