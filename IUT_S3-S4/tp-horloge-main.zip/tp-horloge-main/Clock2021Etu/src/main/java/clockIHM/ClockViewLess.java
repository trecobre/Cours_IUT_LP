package clockIHM;

import clockController.ClockController;
import clockModel.ClockModel;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.control.Label;

public class ClockViewLess extends ClockView{
	private Label label;
	private ClockModel m;
	public ClockViewLess(String labelText, ClockModel m, ClockController c, int posX, int posY){
		super(labelText, m, c, posX, posY);
		this.m = m;
		label = this.addLabel(m.getHour()+"h:"+m.getMinute()+"m:"+m.getSecond()+"s", (this.getWidth()/2), 5);
		Button buttonDecSec = this.addButton("-1000s", this.getWidth()/4, 30);
		buttonDecSec.setOnAction(new EventHandler<ActionEvent>() {
			
			@Override
			public void handle(ActionEvent arg0) {
				c.incSecond(-1000);
			}
		});
		Button buttonDecMin = this.addButton("-100m", this.getWidth()/2, 30);
		buttonDecMin.setOnAction(new EventHandler<ActionEvent>() {
			
			@Override
			public void handle(ActionEvent arg0) {
				c.incMinute(-100);
			}
		});
		Button buttonDecHour = this.addButton("-10h", (3*this.getWidth())/4, 30);
		buttonDecHour.setOnAction(new EventHandler<ActionEvent>() {
			
			@Override
			public void handle(ActionEvent arg0) {
				c.incHour(-10);
			}
		});
		m.addSecondObserver(new ChangeListener<Number>() {
			
			@Override
			public void changed(ObservableValue<? extends Number> observable, Number oldValue, Number newValue) {
				label.setText(m.getHour()+"h:"+m.getMinute()+"m:"+m.getSecond()+"s");
				
			}
		});
		m.addMinuteObserver(new ChangeListener<Number>() {
			
			@Override
			public void changed(ObservableValue<? extends Number> observable, Number oldValue, Number newValue) {
				label.setText(m.getHour()+"h:"+m.getMinute()+"m:"+m.getSecond()+"s");
				
			}
		});
	}
	
	

	@Override
	public void changed(ObservableValue<? extends Number> arg0, Number arg1, Number arg2) {
		label.setText(m.getHour()+"h:"+m.getMinute()+"m:"+m.getSecond()+"s");
	}
}
