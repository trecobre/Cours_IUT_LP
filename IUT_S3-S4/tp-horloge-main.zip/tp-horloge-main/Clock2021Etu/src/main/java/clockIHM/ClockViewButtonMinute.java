package clockIHM;

import clockController.ClockController;
import clockModel.ClockModel;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class ClockViewButtonMinute extends ClockView {
	private TextField field;
	private Label label;
	private ClockModel m;
	public ClockViewButtonMinute(String labelText, ClockModel m, ClockController c, int posX, int posY){
		super(labelText, m, c, posX, posY);
		this.m = m;
		label = this.addLabel("Veuillez indiquer \nun nombre", (this.getWidth()/2), 26);
		label.setVisible(false);
		field = this.addTextField(""+m.getMinute()+"",(this.getWidth()/2), 1 ); //(this.getWidth()/2), 5
		field.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent arg0) {
				try{
					int da = Integer.parseInt(field.getText());
					System.out.print(da);
					c.setMinute(da);
					label.setVisible(false);
				}
				catch(NumberFormatException ex){
					label.setVisible(true);
				}
			}
		});
		Button buttonInc = this.addButton("+", (this.getWidth()/5), 30);
		buttonInc.setOnAction(new EventHandler<ActionEvent>() {
			
			@Override
			public void handle(ActionEvent arg0) {
				c.incMinute(1);
			}
		});
		Button buttonDec = this.addButton("-", (4*this.getWidth()/5), 30);
		buttonDec.setOnAction(new EventHandler<ActionEvent>() {
			
			@Override
			public void handle(ActionEvent arg0) {
				c.incMinute(-1);
			}
		});
	}
	
	

	@Override
	public void changed(ObservableValue<? extends Number> arg0, Number arg1, Number arg2) {
		field.setText(""+m.getMinute()+"");
		label.setVisible(false);
	}
	
}
