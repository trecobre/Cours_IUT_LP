package clockIHM;




import clockController.ClockController;
import clockModel.ClockModel;
import javafx.application.Platform;
import javafx.beans.value.ChangeListener;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public abstract class ClockView extends Stage implements ChangeListener<Number> {

	//private static final long serialVersionUID = -5525127226647415110L;
	protected ClockModel myModel;
	protected ClockController myController;
	private Group layout;
	Scene scene;
	

	public ClockView(String label, ClockModel tm, ClockController tc, int posX, int posY){
		this(label, posX, posY);	
		myModel = tm; myController = tc;
		layout= new Group();
		scene = new Scene(layout, this.getWidth(), this.getHeight());
	}

	public ClockView(String label, int posX, int posY){
		super();
		myModel = null; myController = null;
		setWidth(300);
		setHeight(100);
		setTitle(label);
		setX(posX);
		setY(posY);
		setOnCloseRequest(e-> Platform.exit());
		show();
	}
	
	public Button addButton(String label, double posX, int posY){
		Button button = new Button(label);
		button.setMaxWidth(getWidth()/5);
		button.setMinWidth(button.getMaxWidth());
		button.setLayoutX(posX-button.getMaxWidth()/2);
		button.setLayoutY(posY);
		layout.getChildren().add(button);
		display();
		return button;
	}
	
	public TextField addTextField(String text, double posX, double posY){
		TextField field = new TextField(text);
		field.setMaxWidth(getWidth()/3);
		field.setAlignment(Pos.CENTER);
		field.setLayoutX(posX-field.getMaxWidth()/2);
		field.setLayoutY(posY);
		
		layout.getChildren().add(field);
		display();
		return field;
	}
	
	public Label addLabel(String labelText, double posX, double posY){
		Label label = new Label(labelText);
		label.setAlignment(Pos.CENTER);
		label.setMaxWidth(getWidth()/2);
		label.setMinWidth(label.getMaxWidth());
		label.setLayoutX(posX-(label.getMaxWidth()/2));
		label.setLayoutY(posY);
		layout.getChildren().add(label);
		display();
		return label;
	}
	
	private void display(){
		this.setScene(scene);
		this.show();
	}
}
