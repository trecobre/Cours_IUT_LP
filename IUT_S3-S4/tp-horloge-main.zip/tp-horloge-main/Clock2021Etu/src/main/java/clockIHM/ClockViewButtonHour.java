package clockIHM;


import clockController.ClockController;
import clockModel.ClockModel;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class ClockViewButtonHour extends ClockView {
	private TextField field;
	private Label label;
	private ClockModel m;
	public ClockViewButtonHour(String labelText, ClockModel m, ClockController c, int posX, int posY){
		super(labelText, m, c, posX, posY);
		this.m = m;
		label = this.addLabel("Veuillez indiquer \nun nombre", (this.getWidth()/2), 26);
		label.setVisible(false);
		field = this.addTextField(""+m.getHour()+"",(this.getWidth()/2), 1 ); //(this.getWidth()/2), 5
		field.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent arg0) {
				try{
					int da = Integer.parseInt(field.getText());
					System.out.print(da);
					c.setHour(da);
					label.setVisible(false);
				}
				catch(NumberFormatException ex){
					label.setVisible(true);
				}
			}
		});
		Button buttonInc = this.addButton("+", (this.getWidth()/5), 30);
		buttonInc.setOnAction(new EventHandler<ActionEvent>() {
			
			@Override
			public void handle(ActionEvent arg0) {
				c.incHour(1);
			}
		});
		Button buttonDec = this.addButton("-", (4*this.getWidth()/5), 30);
		buttonDec.setOnAction(new EventHandler<ActionEvent>() {
			
			@Override
			public void handle(ActionEvent arg0) {
				c.incHour(-1);
			}
		});
	}
	
	
	
	

	@Override
	public void changed(ObservableValue<? extends Number> arg0, Number oldValue, Number newValue) {
		field.setText(""+m.getHour()+"");
		label.setVisible(false);
	}
	
}
