package clockController;

import clockModel.ClockModel;

public class ClockControllerRunnable  extends ClockController implements Runnable {

	public ClockControllerRunnable(ClockModel model) {
		super(model);
	}

	public void run() {
			//TODO
	}

}

