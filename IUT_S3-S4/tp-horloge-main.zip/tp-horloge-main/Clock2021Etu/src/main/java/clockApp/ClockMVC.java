package clockApp;


import clockController.ClockController;
import clockIHM.*;
import clockModel.ClockModel;
import javafx.application.Application;
import javafx.stage.Stage;


public class ClockMVC extends Application {
		@Override
		public void init () { }

		public static void main(String args[]) {	launch(args);	}
			
		@Override
		public void start(Stage stage) {
			ClockModel m = new ClockModel(10,0,0);
			ClockController c = new ClockController(m);
			c.start();
			//5 fenetres a creer
			ClockView vh = new ClockViewButtonHour("RECOBRE - SOHIER | Hour", m, c, 200, 100);
			m.addHourObserver(vh);
			ClockView vm = new ClockViewButtonMinute("RECOBRE - SOHIER | Minute", m,c, 200, 200);
			m.addMinuteObserver(vm);
			ClockView vs = new ClockViewButtonSecond("RECOBRE - SOHIER | Second", m,c, 200, 300);
			m.addSecondObserver(vs);
			ClockView va =	new ClockViewLess("RECOBRE - SOHIER | Less",m,c, 500, 100);
			m.addHourObserver(va);
			m.addMinuteObserver(va);
			m.addSecondObserver(va);
			ClockView vmo =	new ClockViewMore("RECOBRE - SOHIER | More",m,c, 500, 300);
			m.addHourObserver(vmo);
			m.addMinuteObserver(vmo);
			m.addSecondObserver(vmo);
		}
}
