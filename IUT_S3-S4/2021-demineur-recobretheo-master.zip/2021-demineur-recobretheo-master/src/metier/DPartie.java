package metier;

import java.util.Random;

public class DPartie {
	
	private int hauteur, largeur, nbMines; // parametres de la partie
	private DCase[][] matrice; 
	private int caseNonMineeRestante;
	private boolean explosion;
	
	public DPartie(int h, int l, int nb){
		nouvellePartie(h,l,nb);
	}
	
	public void nouvellePartie(int h, int l, int nb){
		creerMatrice(h, l, nb);		
	}
	
	public boolean gagne(){
		return (getCaseNonMineeRestante()==0);
	}
	
	public boolean perdu(){
		return aExplose();
	}
	
	public boolean fini(){
		return( (!perdu()) && (!gagne()));
	}
	
	public void creerMatrice(int h, int l, int nb){
		hauteur = h;
		largeur = l;
		nbMines = nb;
		explosion = false;
		matrice = new DCase[h][l];
		for(int i=0; i<hauteur; i++)
			for(int j=0; j<largeur; j++)
			matrice[i][j] = new DCase();
		miner();
		preparerAlentour(); 
		caseNonMineeRestante = hauteur*largeur-nbMines;
	}
	
	/*public DCase getCase(int i, int j)  {
		try{
			return matrice[i][j];
		}
		catch(ArrayIndexOutOfBoundsException e){ return null; }
	
	}*/
	
	public EtatCase getEtatCase(int i, int j){
		EtatCase a = EtatCase.INCONNU;
		switch(this.matrice[i][j].getMinesAlentour()){
		case 0 : a = EtatCase.ZERO;  break;
		case 1 : a = EtatCase.UN; break;
		case 2 : a = EtatCase.DEUX; break;
		case 3 : a = EtatCase.TROIS; break;
		case 4 : a = EtatCase.QUATRE; break;
		case 5 : a = EtatCase.CINQ; break;
		case 6 : a = EtatCase.SIX; break;
		case 7 : a = EtatCase.SEPT; break;
		case 8 : a = EtatCase.HUIT; break;
		default : a=EtatCase.MINE; break;
		}
		if(!this.gagne() && !this.perdu()){
			
			if(this.matrice[i][j].yaDrapreau()){
				a= EtatCase.DRAPEAU;
			}
			else if(!this.matrice[i][j].estDecouverte()){
				if(this.matrice[i][j].select()){
					a=EtatCase.SELECT;
				}
				else{
					a=EtatCase.INCONNU;
				}
			}
		}
		else if(this.perdu()){
			if(this.matrice[i][j].yaDrapreau() && !this.matrice[i][j].estMine()){
				a= EtatCase.CROIX;
			}
			else if(this.matrice[i][j].estMine()){
				a=EtatCase.MINE;
			}
			else if(!this.matrice[i][j].estDecouverte()){
					a=EtatCase.INCONNU;
			}
		}
		else{
			if(this.matrice[i][j].estMine()){
				a = EtatCase.DRAPEAU;
			}
		}
		return a;
	}
	
	public int getHauteur(){
		return hauteur;
	}
	
	public int getLargeur(){
		return largeur;
	}
	
	public int getMines(){
		return nbMines;
	}
	
	
	public void devoilerCase(int i,int j){

		/* Case d�couverte */
		try{
			   	matrice[i][j].setDecouverte();
			   	caseNonMineeRestante--;
		}
		catch(ArrayIndexOutOfBoundsException e){  }
		
		
		  /* on regarde si la case est min�e */
		try{
			  if(matrice[i][j].estMine())
			  	explosion = true;
			  else{
			  
		  	
		 		/* propagation �ventuelle */

				if(matrice[i][j].getMinesAlentour()==0){
					
					try{
						if(!matrice[i-1][j-1].estDecouverte())
							devoilerCase(i-1,j-1);
					}
					catch(ArrayIndexOutOfBoundsException e){  }
				
					try{
						if(!matrice[i-1][j].estDecouverte())
							devoilerCase(i-1,j);
					}
					catch(ArrayIndexOutOfBoundsException e){  }
				
					try{
						if(!matrice[i-1][j+1].estDecouverte())
							devoilerCase(i-1,j+1);	
					}
					catch(ArrayIndexOutOfBoundsException e){  }
				
					try{
						if(!matrice[i][j-1].estDecouverte())
							devoilerCase(i,j-1);	
					}
					catch(ArrayIndexOutOfBoundsException e){  }
				
					try{
						if(!matrice[i][j+1].estDecouverte())
							devoilerCase(i,j+1);
					}
					catch(ArrayIndexOutOfBoundsException e){  }
				
					try{
						if(!matrice[i+1][j-1].estDecouverte())
							devoilerCase(i+1,j-1);	
					}
					catch(ArrayIndexOutOfBoundsException e){  }
				
					try{
						if(!matrice[i+1][j].estDecouverte())
							devoilerCase(i+1,j);	
					}
					catch(ArrayIndexOutOfBoundsException e){  }
								
					try{
						if(!matrice[i+1][j+1].estDecouverte())
							devoilerCase(i+1,j+1);	
					}
					catch(ArrayIndexOutOfBoundsException e){  }
				}
			}
		}
		catch(ArrayIndexOutOfBoundsException e){  }
		
	}
		
	public void drapeauAction(int i, int j){
		matrice[i][j].drapeauAction();
	}

	private void preparerAlentour(){
		int minesCompteur;
			
		for(int i=0; i<hauteur; i++)
			for(int j=0; j<largeur; j++){
					minesCompteur=0;
					if(!matrice[i][j].estMine()){
						try{
							if(matrice[i-1][j-1].estMine()) 
								minesCompteur++;
						}
						catch(ArrayIndexOutOfBoundsException e){  }
								
						try{
							if(matrice[i-1][j].estMine()) 
								minesCompteur++;
						}
						catch(ArrayIndexOutOfBoundsException e){  }
						
						try{
							if(matrice[i-1][j+1].estMine()) 
								minesCompteur++;
						}
						catch(ArrayIndexOutOfBoundsException e){  }
						
						try{
							if(matrice[i][j-1].estMine()) 
								minesCompteur++;
						}
						catch(ArrayIndexOutOfBoundsException e){  }
						
						try{
							if(matrice[i][j+1].estMine()) 
								minesCompteur++;
						}
						catch(ArrayIndexOutOfBoundsException e){  }
							
						try{
							if(matrice[i+1][j-1].estMine()) 
								minesCompteur++;
						}
						catch(ArrayIndexOutOfBoundsException e){  }
						
						try{
							if(matrice[i+1][j].estMine()) 
								minesCompteur++;
						}
						catch(ArrayIndexOutOfBoundsException e){  }
						
						try{
							if(matrice[i+1][j+1].estMine()) 
								minesCompteur++;
						}
						catch(ArrayIndexOutOfBoundsException e){  }
					
		
				
						/* les mines ont �t�s compt�s*/
						matrice[i][j].setMinesAlentour(minesCompteur);								
					}
			
			}
				
		}
	
	private void miner(){
		int x,y;
		int i=0;
		Random alea = new Random();
		while(i<nbMines){
			x = alea.nextInt(hauteur);
			y = alea.nextInt(largeur);
			if(!matrice[x][y].estMine()){
				matrice[x][y].poserBombe();
				i++;
			}
			
		}
	}

	public int nbrDrapeau(){
		int compteur = 0;
		for(int i=0;i<hauteur;i++)
			for(int j=0;j<largeur;j++){
				if(matrice[i][j].yaDrapreau())
					compteur++;
			}
		return compteur;
}

	public boolean aExplose(){
		return explosion;
	}
	
	public int getCaseNonMineeRestante(){
		return caseNonMineeRestante;
	}

	public void afficher(){
		System.out.println("****carte****");
		for(int i=0; i<hauteur; i++){
			for(int j=0; j<largeur; j++){
				if(matrice[i][j].estMine())
					System.out.print("M ");
				else
					System.out.print(matrice[i][j].getMinesAlentour()+" ");
			}
			System.out.println("");
			
		}
		System.out.println("****carte connue****");
		for(int i=0; i<hauteur; i++){
			for(int j=0; j<largeur; j++){
				if(!matrice[i][j].estDecouverte())
					System.out.print("* ");
				else
					if(matrice[i][j].estMine())
						System.out.print("M ");
					else
						System.out.print(matrice[i][j].getMinesAlentour()+" ");
			}
			System.out.println("");
			
		}
	}
	
}