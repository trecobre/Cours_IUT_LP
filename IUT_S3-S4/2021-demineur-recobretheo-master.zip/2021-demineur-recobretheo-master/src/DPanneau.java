import javax.swing.*;
import java.awt.*;

public class DPanneau extends JPanel{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private DFenetre fenetre;
	
	public DPanneau(DFenetre fenetre){
		super();
		this.fenetre = fenetre;
	}
	
	public void paintComponent(Graphics g){
		super.paintComponent(g);
		for(int i=0; i<fenetre.getLargeur(); i++)
			for(int j=0;j<fenetre.getHauteur(); j++){
				g.drawImage(fenetre.getIcon(i, j),j*20,i*20,this);
			}
	}	
}