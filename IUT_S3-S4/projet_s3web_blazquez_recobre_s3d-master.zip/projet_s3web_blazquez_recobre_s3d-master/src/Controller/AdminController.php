<?php

namespace App\Controller;

use App\Entity\Rating;
use App\Entity\Series;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;

use App\Form\SeriesAdminForm;

class AdminController extends AbstractController
{
    #[Route('admin/', name: 'admin')]
    public function index(): Response
    {
        $this->denyAccessUnlessGranted('ROLE_ADMIN');
        return $this->render('admin/index.html.twig', [
            'controller_name' => 'AdminController',
        ]);
    }

    #[Route('admin/series/', name: 'admin_series')]
    public function series(EntityManagerInterface $entity, Request $request): Response
    {
        $series = new Series();
        $form = $this->createForm(SeriesAdminForm::class, $series);
        $form->handleRequest($request);

        $this->denyAccessUnlessGranted('ROLE_ADMIN');

        if ($form->isSubmitted() && $form->isValid()) {
            $series->setTitle($form->get('title')->getData());
            $series->setPlot($form->get('plot')->getData());
            $series->setImdb($form->get('imdb')->getData());
            $series->setPoster($form->get('poster')->getData());
            $series->setDirector($form->get('director')->getData());
            $series->setYoutubeTrailer($form->get('youtube_trailer')->getData());
            $series->setAwards($form->get('awards')->getData());
            $series->setYearStart($form->get('year_start')->getData());
            $series->setYearEnd($form->get('year_end')->getData());

            $entity->persist($series);
            $entity->flush();
        }

        return $this->render('admin/series_admin.html.twig', [
            'SeriesAdminForm' => $form->createView(),
        ]);
    }

    #[Route('admin/moderation/', name: 'admin_moderation')]
    public function moderation(EntityManagerInterface $entity): Response
    {
        $this->denyAccessUnlessGranted('ROLE_ADMIN');

        $repo = $entity->getRepository(Rating::class);

        $series = $repo->createQueryBuilder('t')
        ->getQuery()->getResult();

        return $this->render('admin/moderation.html.twig', [
            'series' => $series,
        ]);
    }

    #[Route('admin/moderation/{id}', name: 'admin_moderation_delete')]
    public function moderation_delete(EntityManagerInterface $entityManager,int $id): Response
    {
        $this->denyAccessUnlessGranted('ROLE_ADMIN');
        $single_user=$entityManager->getRepository(Rating::class)->findOneBy(['id'=>$id]);
        $entityManager->remove($single_user);
        $entityManager->flush();
                              
        return $this->redirectToRoute('admin_moderation', [], Response::HTTP_SEE_OTHER);
    }
}
