<?php

namespace App\Controller;

use App\Entity\Series;
use App\Entity\Season;
use App\Entity\Episode;
use Symfony\Component\Security\Core\Security;
use App\Entity\User;
use App\Entity\Rating;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use App\Form\RatingFormType;

#[Route('/series')]
class SeriesController extends AbstractController
{

    #[Route('/user/followed/', name: 'series_followed')]
    public function followed(EntityManagerInterface $entityManager,Request $request): Response
    {   
        $this->denyAccessUnlessGranted('ROLE_USER');
        
        $repo = $entityManager->getRepository(User::class);

        $email = $request->getSession()->get(Security::LAST_USERNAME);

        $user = $repo->createQueryBuilder('u')
        ->where('u.email = :mail')
        ->setParameter(':mail', $email)
        ->getQuery()->getOneOrNullResult();
        
        $series = $user->getSeries();
    
        return $this->render('series/followed.html.twig', [
            'series' => $series,
            'referer' => $request->headers->get('referer'),
        ]);
    }

    #[Route('/{page}', name: 'series_index', methods: ['GET'])]
    public function index(EntityManagerInterface $entityManager, int $page): Response
    {   

        if($page <= 1) {
            $page = 1;
        }

        $max = ($page)*15;
        if($max == 0) {
            $max = 15;
        }
        
        $rec = '0';
        $repo = $entityManager->getRepository(Series::class);
        if(isset($_GET['recherche']) && !empty($_GET['recherche'])) {

            $series = $repo->createQueryBuilder('t')
            ->where('t.title like :param')
            ->setParameter(':param', $_GET['recherche'].'%')
            ->setMaxResults($max)
            ->setFirstResult($max-15)
            ->getQuery()->getResult();

            
            $count = $repo->createQueryBuilder('t')
            ->select('count(t)')
            ->where('t.title like :param')
            ->setParameter(':param', $_GET['recherche'].'%')
            ->getQuery()->getSingleScalarResult();

            $rec = $_GET['recherche'];

        } else {
            $count = $repo->count(array());
            $series = $repo->findBy(array(),array(),15,$max);
        }
        
    
        return $this->render('series/index.html.twig', [
            'series' => $series,
            'page' => $page,
            'maxResults' => $count,
            'recherche' => $rec,
        ]);
    }

    #[Route('/show/data/{id}', name: 'series_show', methods: ['GET', 'POST'])]
    public function show(Request $request, EntityManagerInterface $entityManager, Series $series): Response
    {
        $rating = new Rating();
        $form = $this->createForm(RatingFormType::class, $rating);
        $form->handleRequest($request);
        
        $email = $request->request->get('email');

        $email = $request->getSession()->get(Security::LAST_USERNAME);
        
        $fav = 0;
        $session = $email!=null;
        $repo_u = $entityManager->getRepository(User::class);
        $repo_s = $entityManager->getRepository(Season::class);
        $repo_e = $entityManager->getRepository(Episode::class);
        $repo_r = $entityManager->getRepository(Rating::class);
        $selectSeason = 0;
        if($email!=null){
            $user = $repo_u->createQueryBuilder('u')
                ->where('u.email = :mail')
                ->setParameter(':mail', $email)
                ->getQuery()->getOneOrNullResult();
            
            $listFav = $repo_u->createQueryBuilder('u')
                ->where('u.email = :email')
                ->setParameter('email', $email)
                ->getQuery()
                ->getOneOrNullResult();
            
            $listSeries = $listFav->getSeries();
            foreach($listSeries as $serie ){
                if($serie ==  $series){
                    $fav=1;
                }
            }

            if(isset($_GET['fav']) && $fav == 1){
                $user->removeSeries($series);
                $entityManager->flush();
                $fav=0;
            }
            else if(isset($_GET['fav'])){
                $user->addSeries($series);
                $entityManager->flush();
                $fav=1;
            }

            if ($form->isSubmitted() && $form->isValid()) {
                $rating->setValue($form->get('value')->getData());
                $rating->setComment($form->get('comment')->getData());
                $rating->setDate(new \DateTime('now'));
                $rating->setUser($user);
                $rating->setSeries($series);
                $entityManager->persist($rating);
                $entityManager->flush();
            }
        }

        if(isset($_GET['season'])) {
            $season = $repo_s->createQueryBuilder('s')
            ->where('s.series = :param')
            ->andWhere('s.number = :number')
            ->setParameter(':param', $series)
            ->setParameter(':number', $_GET['season'])
            ->getQuery()->getResult();

            $reset_saison = $season;

            $episode = $repo_e->createQueryBuilder('e')
            ->where('e.season = :param')
            ->orderBy('e.number','ASC')
            ->setParameter(':param', reset($reset_saison))
            ->getQuery()->getResult();

            $selectSeason = $_GET['season'];
        }
        else{
            $season = $repo_s->findBy(array('series' => $series), array('number' => 'ASC'));
            $episode = $repo_e->findBy(array('season' => $season), array('number' => 'ASC'));
        }

        $commentRating = $repo_r->createQueryBuilder('t')
            ->where('t.series = :series')
            ->setParameter(':series', $series)
            ->getQuery()->getResult();
        
        return $this->render('series/show.html.twig', [
            'series' => $series,
            'season' => $season,
            'episode' => $episode,
            'seasonSelect' => $selectSeason,
            'session' => $session,
            'fav' => $fav,
            'form' => $form->createView(),
            'rates' => $commentRating,
        ]);
    }

    // Watch and Unwatch an episode

    #[Route('/show/data/episode/watch/{episode}', name: 'series_watch')]
    public function watch(Request $request, EntityManagerInterface $entity, int $episode): Response
    {
        $email = $request->getSession()->get(Security::LAST_USERNAME);

        $repo_u = $entity->getRepository(User::class);
        $user = $repo_u->createQueryBuilder('u')
        ->where('u.email = :mail')
        ->setParameter(':mail', $email)
        ->getQuery()->getOneOrNullResult();

        $repo_e = $entity->getRepository(Episode::class);
        $episodeRef = $repo_e->createQueryBuilder('e')
        ->where('e.id = :episode' )
        ->setParameter(':episode',$episode)
        ->getQuery()->getOneOrNullResult();

        $episodeRef->addUser($user);
        $entity->flush();

        return $this->redirect($request->headers->get('referer'));
    }

    #[Route('/show/data/episode/unwatch/{episode}', name: 'series_unwatch')]
    public function unwatch(Request $request, EntityManagerInterface $entity, int $episode): Response
    {
        $email = $request->getSession()->get(Security::LAST_USERNAME);

        $repo_u = $entity->getRepository(User::class);
        $user = $repo_u->createQueryBuilder('u')
        ->where('u.email = :mail')
        ->setParameter(':mail', $email)
        ->getQuery()->getOneOrNullResult();

        $repo_e = $entity->getRepository(Episode::class);
        $episodeRef = $repo_e->createQueryBuilder('e')
        ->where('e.id = :episode' )
        ->setParameter(':episode',$episode)
        ->getQuery()->getOneOrNullResult();

        $episodeRef->removeUser($user);
        $entity->flush();

        return $this->redirect($request->headers->get('referer'));
    }
}

