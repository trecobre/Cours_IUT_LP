<?php

namespace App\Controller;

use App\Entity\Series;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Security\Core\Security;
use Doctrine\ORM\EntityManagerInterface;

class IndexController extends AbstractController
{
    #[Route('/', name: 'index')]
    public function index(EntityManagerInterface $entity, Request $request): Response
    {
        $email = $request->getSession()->get(Security::LAST_USERNAME);

        $repo = $entity->getRepository(Series::class);

        $count = $repo->createQueryBuilder('t')
        ->select('count(t)')
        ->getQuery()->getSingleScalarResult();

        $random = rand(5,$count);

        $series = $repo->createQueryBuilder('t')
        ->setFirstResult($random-5)
        ->setMaxResults(5)
        ->getQuery()->getResult();


        return $this->render('index/index.html.twig', [
            'controller_name' => 'IndexController',
            'email' => $email,
            'series' => $series,
        ]);
    }

    #[Route('/a-propos', name: 'minfo')]
    public function minfo(): Response
    {
        return $this->render('index/model.html.twig', [
            'controller_name' => 'IndexController',
        ]);
    }
}
