import io.jbotsim.core.Topology;
import io.jbotsim.ui.JViewer;

public class MainPP {
    public static void main(String[] args) {
        Topology tp = new Topology();
        tp.setDefaultNodeModel(CircleNode.class);
        tp.setTimeUnit(100);
        new JViewer(tp);
        tp.start();
        tp.pause();
    }
}

// Q3 : 60
// Q5 : 1
// Q6 : LinkedHashSet pour ne pas avoir de doublons
// Q7 : oui en parcourrant sa hashMap