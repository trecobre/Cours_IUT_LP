import io.jbotsim.core.Color;
import io.jbotsim.core.Message;
import io.jbotsim.core.Node;

import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.Set;

public class CircleNode extends Node {
    double angle;
    Set<CircleNode> voisin;
    HashMap<CircleNode, Set<CircleNode>> voisinDesVoinsins;
    int cpt;
    static int select = 0;
    String status = null;
    public void onStart() {
        angle = (Math.random() > 0.5) ? 0.1 : -0.1;
        voisin = new LinkedHashSet<>();
        voisinDesVoinsins = new HashMap<>();
        cpt=0;
    }
    public void onClock() {
        setDirection((getDirection()-angle)%(2.0*Math.PI));
        move(2);
        if(select==2){
            if(status=="src"){

            }
        }
        sendAll(voisin);
    }

    public Set<CircleNode> getRoute(){
        if(this.status=="dest"){
            Set<CircleNode> temp = new LinkedHashSet<>();
            temp.add(this);
            return temp;
        }
        else{

        }
    }

    public void onMessage(Message msg){
        voisin.add((CircleNode) msg.getSender());
        voisinDesVoinsins.put((CircleNode) msg.getSender(), (Set<CircleNode>) msg.getContent());
    }

    public void onSelection(){
        if(select<2){
            select++;
            if(select==1){
                status="src";
                this.setColor(Color.green);
            }
            else{
                this.setColor(Color.red);
                status="dest";
            }
        }
    }
}

