import io.jbotsim.core.Message;
import io.jbotsim.core.Color;
import io.jbotsim.core.Node;

import java.util.ArrayList;
import java.util.List;

public class TreeNodeV3 extends Node{
    private Node parent;
    private ArrayList<Node> children;
    @Override
    public void onStart() { // Initialisation par défaut
        setColor(Color.green); // Non informé
        children = new ArrayList<>();
    }

    @Override
    public void onSelection() { // Noeud sélectionné
        parent = null;
        setColor(Color.red); // Informé
        sendAll(new Message("Mon message"));
    }

    @Override
    public void onMessage(Message message) {
        if (getColor() == Color.green) { // Si non-informé
            setColor(Color.red); // Devient informé
            parent = message.getSender(); //on récupère le parent
            getCommonLinkWith(parent).setWidth(2); //on met le lien en gras
            List<Node> childrensP = getOutNeighbors();
            for (Node child : childrensP) {
                if (child.getColor() == Color.green) {
                    children.add(child);
                    send(child, message);
                }
                else if(child == parent){
                    send(parent, new Message(message, Integer.toString(getID())));
                }
            }
        }
    }

     @Override
     public void onClock(){
        if(!children.isEmpty()) {
            for (Node child: children) {

            }
            System.out.println(children);
        }

    }
}
