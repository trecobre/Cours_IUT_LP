import io.jbotsim.core.Message;
import io.jbotsim.core.Color;
import io.jbotsim.core.Node;

import java.util.ArrayList;
import java.util.List;

public class TreeNodeV5 extends Node{
    private Node parent;
    private ArrayList<Node> children;
    public static int no = 0;
    @Override
    public void onStart() { // Initialisation par défaut
        setColor(Color.green); // Non informé
        children = new ArrayList<>(); //on crée la liste des enfants
        no ++;
    }

    @Override
    public void onSelection() { // Noeud sélectionné
        parent = null;
        setColor(Color.red); // Informé
        System.out.println(no);
        sendAll(new Message("Mon message"));
    }

    @Override
    public void onMessage(Message message) {
        if (getColor() == Color.green) { // Si non-informé
            setColor(Color.red); // Devient informé
            parent = message.getSender(); //on récupère le parent
            getCommonLinkWith(parent).setWidth(2); //on met le lien en gras
            List<Node> childrensP = getOutNeighbors(); //on récupère tout les voisins d'un noeud
            for (Node child : childrensP) { //pour chaques voisinw
                if (child.getColor() == Color.green) { // si il es vert
                    children.add(child); //on l'ajoute à la liste des enfants
                    send(child, message); // on lui envoi un lessage
                }
            }
        }
    }
}
