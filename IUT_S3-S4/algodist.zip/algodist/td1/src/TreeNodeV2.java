import io.jbotsim.core.Message;
import io.jbotsim.core.Color;
import io.jbotsim.core.Node;

import java.util.ArrayList;
import java.util.List;

public class TreeNodeV2 extends Node{
    private Node parent;
    private ArrayList<Node> children;
    @Override
    public void onStart() { // Initialisation par défaut
        setColor(Color.green); // Non informé
        children = new ArrayList<>(); //on crée la liste des enfants
    }

    @Override
    public void onSelection() { // Noeud sélectionné
        parent = null;
        setColor(Color.red); // Informé
        sendAll(new Message("Mon message"));
    }

    @Override
    public void onMessage(Message message) {
        if (getColor() == Color.green) { // Si non-informé
            setColor(Color.red); // Devient informé
            parent = message.getSender(); //on récupère le parent
            getCommonLinkWith(parent).setWidth(2); //on met le lien en gras
            List<Node> childrensP = getOutNeighbors(); //on récupère tout les voisins d'un noeud
            for (Node child : childrensP) { //pour chaques voisin
                if (child.getColor() == Color.green) { // si il es vert
                    children.add(child); //on l'ajoute à la liste des enfants
                    send(child, message); // on lui envoi un lessage
                }
                else if(child == parent){ //sinon si c'est le parent
                    send(parent, new Message(message, Integer.toString(getID()))); // on lui envoi son propre id
                }
            }
            System.out.println(children);//on affiche la liste des enfants
        }
    }
}
