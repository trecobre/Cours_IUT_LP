import io.jbotsim.core.Color;
import io.jbotsim.core.Node;

public class PPCountingV1 extends PPNode {
    boolean compteur; //on détermine une variable pour définir le noeud qui compte
    int compte; //on determine la variable servant à compter
    @Override
    public void onStart() { // à la création du noeud
        setColor(Color.blue); //on initialise le noeud à la couleur bleu
        this.compteur = false; //par défaut le noeud, une fois créer, n'est pas compteur
    }
    @Override
    public void onSelection() { //à la séléction du noeud
        setColor(Color.yellow); //défini sa couleur à jaune
        this.compteur = true; // il devient le compteur
        compte = 0; // son compteur prend la valeur 0
    }
    @Override
    public void interactWith(Node responder) { // durant une interaction
        if ((this.getColor() == Color.red || this.getColor() == Color.green)&& responder.getColor() == Color.blue) {
            responder.setColor(Color.red);
        }
        else if (this.getColor() == Color.blue && (responder.getColor() == Color.red || responder.getColor() == Color.green)) {
            this.setColor(Color.red);
        }
        else if(this.getColor()==Color.yellow && (responder.getColor()==Color.blue || responder.getColor()==Color.red)){
            this.compte += 1;
            responder.setColor(Color.green);
        }
        else if(responder.getColor()==Color.yellow && (this.getColor()==Color.blue || this.getColor()==Color.red)){
            ((PPCountingV1)responder).compte += 1;
            this.setColor(Color.green);
        }
    }
    @Override
    public String toString(){
        if(this.compteur){
            return Integer.toString(compte);
        }
        else{
            return "";
        }
    }
}

/*
    Q3 : Quelle condition le graphe sous-jacent doit-il satisfaire pour que l'algorithme ait une chance de compter tout le monde ?
    Rep : Le compteur doit etre lié à tous les autres noeuds du graphes (graphe complet)
 */