import io.jbotsim.core.Color;
import io.jbotsim.core.Node;

public class PPCountingV2 extends PPNode {
    boolean compteur = true; //on détermine une variable pour définir le noeud qui compte
    int compte = 1; //on determine la variable servant à compter
    @Override
    public void onStart() { // à la création du noeud
        setColor(Color.blue); //on initialise le noeud à la couleur bleu
    }
    @Override
    public void onSelection() { //à la séléction du noeud
    }
    @Override
    public void interactWith(Node responder) { // durant une interaction
        if (this.getColor() == Color.blue && responder.getColor() == Color.blue) {
            if(this.compte > Integer.parseInt(responder.toString())){
                responder.setColor(Color.red);
                this.compte += Integer.parseInt(responder.toString());
                ((PPCountingV2)responder).compteur = false;
            }
            else{
                this.setColor(Color.red);
                ((PPCountingV2)responder).compte += this.compte;
                this.compteur = false;
            }

        }
    }
    @Override
    public String toString(){
        if(this.compteur){
            return Integer.toString(compte);
        }
        else{
            return "";
        }
    }
}

/*
    Q5 : Est-il vrai que l'algorithme a des chances de réussir (même petites) du moment que le graphe est connexe ?
        Si oui, le succès est-il garanti pour autant dans n'importe quel graphe connexe ?
    Rep : l'algo a des chances de réussir mais elles ne sont pas garanties
 */