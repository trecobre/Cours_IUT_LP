import io.jbotsim.core.Color;
import io.jbotsim.core.Node;

public class PPCountingV3 extends PPNode {
    boolean compteur = true; //on détermine une variable pour définir le noeud qui compte
    int compte = 1; //on determine la variable servant à compter
    @Override
    public void onStart() { // à la création du noeud
        setColor(Color.blue); //on initialise le noeud à la couleur bleu
    }
    @Override
    public void onSelection() { //à la séléction du noeud
    }
    @Override
    public void interactWith(Node responder) { // durant une interaction
        if (this.getColor() == Color.blue && responder.getColor() == Color.blue) {
            if(this.compte > Integer.parseInt(responder.toString())){
                responder.setColor(Color.red);
                this.compte += Integer.parseInt(responder.toString());
                ((PPCountingV3)responder).compteur = false;
            }
            else{
                this.setColor(Color.red);
                ((PPCountingV3)responder).compte += this.compte;
                this.compteur = false;
            }
        }
        else if(this.getColor() == Color.blue && responder.getColor() == Color.red){
            responder.setColor(Color.blue);
            this.setColor(Color.red);
            ((PPCountingV3)responder).compteur = true;
            ((PPCountingV3)responder).compte = this.compte;
            this.compteur = false;
        }
        else if(this.getColor() == Color.red && responder.getColor() == Color.blue){
            this.setColor(Color.blue);
            responder.setColor(Color.red);
            this.compteur = true;
            this.compte = Integer.parseInt(responder.toString());
            ((PPCountingV3)responder).compteur = false;
        }
    }
    @Override
    public String toString(){
        if(this.compteur){
            return Integer.toString(compte);
        }
        else{
            return "";
        }
    }
}

/*
    Q7 : Quel protocole entre Counting v2 and Counting v3 a l'espérance la plus petite ? Autrement dit, lequel converge le plus vite en moyenne ?
    Rep : CountingV3 a l'esperance la plus petite
 */