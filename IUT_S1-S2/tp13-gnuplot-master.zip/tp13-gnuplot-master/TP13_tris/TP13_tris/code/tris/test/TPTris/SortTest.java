package TPTris;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 * Tests unitaires des différents tris.
 */
public class SortTest {

    @Test
    public void testEchanger() {
        int[] tab = {2, 4, 5};
        int i = 0;
        int j = 2;
        Sort.echanger(tab, i, j);
        assertEquals(5, tab[0]);
        assertEquals(2, tab[2]);
    }

    @Test
    public void testTriParSelection() {
        int[] tab = {2, -1, 56, 4, 45, 4, 458, -85, -4, 5};
        int[] tab2 = {2, -1, 56, 4, 45, 4, 458, -85, -4, 5, -85};
        Sort.triParSelection(tab);
        Sort.triParSelection(tab2);
        for (int i = 0; i < (tab.length - 1); i++) {
            assertTrue(tab[i] <= tab[i + 1]);
        }
        for (int i = 0; i < (tab2.length - 1); i++) {
            assertTrue(tab2[i] <= tab2[i + 1]);
        }
    }


    @Test
    public void testTriABulle() {
        int[] tab = {2, -1, 56, 4, 45, 4, 458, -85, -4, 5};
        int[] tab2 = {2, -1, 56, 4, 45, 4, 458, -85, -4, 5, -85};
        Sort.triABulle(tab);
        Sort.triABulle(tab2);
        for (int i = 0; i < (tab.length - 1); i++) {
            assertTrue(tab[i] <= tab[i + 1]);
        }
        for (int i = 0; i < (tab2.length - 1); i++) {
            assertTrue(tab2[i] <= tab2[i + 1]);
        }
    }

    @Test
    public void testTriComptage() {
        int[] tab = {2, -1, 56, 4, 45, 4, 458, -85, -4, 5};
        int[] tab2 = {2, -1, 56, 4, 45, 4, 458, -85, -4, 5, -85};
        Sort.triComptage(tab);
        Sort.triComptage(tab2);
        for (int i = 0; i < (tab.length - 1); i++) {
            assertTrue(tab[i] <= tab[i + 1]);
        }
        for (int i = 0; i < (tab2.length - 1); i++) {
            assertTrue(tab2[i] <= tab2[i + 1]);
        }
    }
}
