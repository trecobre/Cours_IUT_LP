package TPTris;

import java.util.Arrays;

/**
 * Différents tris.
 */
enum Sort {

    TRI_SELECTION,
    TRI_BULLE,
    TRI_COMPTAGE,
    TRI_RAPIDE,
    TRI_PAR_INSERTION,
    TRI_FUSION,
    TRI_JAVA;

    /**
     * Trier un tableau, en choisissant un algorithme.
     *
     * @param tab le tableau à trier
     * @param typeTri l'algorithme de tri à appliquer
     */
    static void tri(int[] tab, Sort typeTri) {
        switch (typeTri) {
            case TRI_SELECTION:
                Sort.triParSelection(tab);
                break;
            case TRI_BULLE:
                Sort.triABulle(tab);
                break;
            case TRI_COMPTAGE:
                Sort.triComptage(tab);
                break;
            case TRI_JAVA:
                Sort.triJava(tab);
                break;
            default:
                System.out.println("Type de tri non supporte : ");
        }
    }

    /**
     * Echanger deux éléments dans un tableau.
     *
     * @param tab le tableau
     * @param i l'indice du premier élément à échanger
     * @param j l'indice du deuxoème élément à échanger
     */
    static void echanger(int[] tab, int i, int j) {
        int save = tab[i];
        tab[i] = tab[j];
        tab[j] = save;
    }

    /**
     * Tri par sélection.
     *
     * @param tab le tableau à trier
     */
    static void triParSelection(int tab[]) {
    int i, j, pos;
    for (i = 0; i < tab.length - 1; i++) {
        pos = i;
        for (j = i + 1; j < tab.length; j++) {
            if (tab[j] < tab[pos]) {
                pos = j;
            }
        }
        echanger(tab, i, pos);
    }
}

    /**
     * Tri à bulle.
     *
     * @param tab le tableau à trier
     */
    static void triABulle(int tab[]) {
        /*for(int i=0; i<tab.length; i++){
            for(int j = 0; j<tab.length-(i+1);j++){
                if(tab[j]>tab[j+1]){
                    echanger(tab, j, j+1);
                }
            }
        }*/
        boolean echange = true;
        int i = tab.length-2, j;
        while((echange) && (i>=0)){
            echange = false;
            for(j=0; j<= i; j++){
                if(tab[j]>tab[j+1]){
                    echanger(tab, j, j+1);
                    echange = true;
                }
            }
            i--;
        }
    }

    /**
     * Tri par comptage.
     *
     * @param tab le tableau à trier
     */
    static void triComptage(int[] tab) {
        int[] compteurs = new int[tab.length];
        for(int i=0; i<tab.length;i++){
            compteurs[i]=0;
        }
        
        for(int i=1; i<tab.length;i++){
            for(int j=0; j<i;j++){
                if(tab[j]<tab[i]){
                    compteurs[i]++;
                }
                else{
                    compteurs[j]++;
                }
            }
        }
        
        int[] copie=new int[tab.length];
        for(int i=0; i<tab.length;i++){
            copie[i]=0;
        }
        
        for(int i=0; i<tab.length;i++){
            tab[compteurs[i]]=copie[i]; 
        }
    }
    
    /**
     * Tri par défaut de Java.
     *
     * @param tab tableau à trier
     */
    static void triJava(int[] tab) {
        Arrays.sort(tab);
    }
}
