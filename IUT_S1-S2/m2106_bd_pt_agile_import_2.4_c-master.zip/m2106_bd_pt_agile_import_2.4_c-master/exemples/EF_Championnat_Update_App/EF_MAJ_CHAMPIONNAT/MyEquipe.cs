﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EF_MAJ_CHAMPIONNAT
{
    public partial class EQUIPES
    {
        public override string ToString()
        {
            return VILLE;
        }

    }
}
