## Projet exemple pour illustrer les mises à jour d'une base de données via Entity Framework

* Base concernée : `Championnat`.
* Opérations de mise à jour : ajout, modification ou suppression de tuples dans la table `Joueurs`.

Pour tester ce projet, vous devrez adapter le fichier `app.config` (nom de votre serveur).
