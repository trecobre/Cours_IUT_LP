## Projet exemple pour illustrer l'interrogation d'une base de données via OLEDB

* Base concernée : `Musique`.
* Opérations de sélections et jointures pour remplir des composants de type `ListBox`.

Pour tester ce projet, vous devrez adapter le fichier `app.config` (nom de votre serveur).
