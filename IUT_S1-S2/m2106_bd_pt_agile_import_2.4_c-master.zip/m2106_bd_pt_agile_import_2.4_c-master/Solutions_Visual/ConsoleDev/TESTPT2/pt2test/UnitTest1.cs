﻿using ConsoleDev;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace pt2test
{
    private static MusiquePT2_CEntities baseMusique= new MusiquePT2_CEntities();
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
