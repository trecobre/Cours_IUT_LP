﻿
namespace WindowsFormsApp1
{
    partial class changerMdp
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.labelEmprunts = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.voirConfirmation = new System.Windows.Forms.CheckBox();
            this.voirMdp = new System.Windows.Forms.CheckBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(129, 64);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(227, 20);
            this.textBox1.TabIndex = 0;
            // 
            // labelEmprunts
            // 
            this.labelEmprunts.AutoSize = true;
            this.labelEmprunts.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelEmprunts.Location = new System.Drawing.Point(17, 9);
            this.labelEmprunts.Name = "labelEmprunts";
            this.labelEmprunts.Size = new System.Drawing.Size(374, 37);
            this.labelEmprunts.TabIndex = 5;
            this.labelEmprunts.Text = "Changer le mot de passe";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(129, 116);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(227, 20);
            this.textBox2.TabIndex = 6;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(129, 167);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(227, 20);
            this.textBox3.TabIndex = 7;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(21, 67);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(106, 13);
            this.label1.TabIndex = 8;
            this.label1.Text = "Ancien mot de passe";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(10, 119);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(117, 13);
            this.label2.TabIndex = 9;
            this.label2.Text = "Nouveau mot de passe";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(10, 170);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(117, 13);
            this.label3.TabIndex = 10;
            this.label3.Text = "Confirmer mot de passe";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(129, 207);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 11;
            this.button1.Text = "Annuler";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(281, 207);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 12;
            this.button2.Text = "Confirmer";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // voirConfirmation
            // 
            this.voirConfirmation.Appearance = System.Windows.Forms.Appearance.Button;
            this.voirConfirmation.BackColor = System.Drawing.Color.Transparent;
            this.voirConfirmation.BackgroundImage = global::WindowsFormsApp1.Properties.Resources.close_eye_logo;
            this.voirConfirmation.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.voirConfirmation.FlatAppearance.BorderSize = 0;
            this.voirConfirmation.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
            this.voirConfirmation.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.voirConfirmation.Location = new System.Drawing.Point(362, 116);
            this.voirConfirmation.Name = "voirConfirmation";
            this.voirConfirmation.Size = new System.Drawing.Size(20, 20);
            this.voirConfirmation.TabIndex = 23;
            this.voirConfirmation.UseVisualStyleBackColor = false;
            // 
            // voirMdp
            // 
            this.voirMdp.Appearance = System.Windows.Forms.Appearance.Button;
            this.voirMdp.BackgroundImage = global::WindowsFormsApp1.Properties.Resources.close_eye_logo;
            this.voirMdp.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.voirMdp.FlatAppearance.BorderSize = 0;
            this.voirMdp.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
            this.voirMdp.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.voirMdp.Location = new System.Drawing.Point(362, 64);
            this.voirMdp.Name = "voirMdp";
            this.voirMdp.Size = new System.Drawing.Size(20, 20);
            this.voirMdp.TabIndex = 22;
            this.voirMdp.UseVisualStyleBackColor = true;
            // 
            // checkBox1
            // 
            this.checkBox1.Appearance = System.Windows.Forms.Appearance.Button;
            this.checkBox1.BackColor = System.Drawing.Color.Transparent;
            this.checkBox1.BackgroundImage = global::WindowsFormsApp1.Properties.Resources.close_eye_logo;
            this.checkBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.checkBox1.FlatAppearance.BorderSize = 0;
            this.checkBox1.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
            this.checkBox1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.checkBox1.Location = new System.Drawing.Point(362, 167);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(20, 20);
            this.checkBox1.TabIndex = 24;
            this.checkBox1.UseVisualStyleBackColor = false;
            // 
            // changerMdp
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(406, 242);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.voirConfirmation);
            this.Controls.Add(this.voirMdp);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.labelEmprunts);
            this.Controls.Add(this.textBox1);
            this.Name = "changerMdp";
            this.Text = "changerMdp";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label labelEmprunts;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.CheckBox voirConfirmation;
        private System.Windows.Forms.CheckBox voirMdp;
        private System.Windows.Forms.CheckBox checkBox1;
    }
}