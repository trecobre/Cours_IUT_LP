import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class sketch_Pong extends PApplet {

// Constantes - Couleurs

final int NOIR = color(0);
final int BLANC = color(255);
final int ROUGE = color(255, 0, 0);
final int VERT = color(0, 255, 0);
final int BLEU = color(0, 0, 255);

// Etat du jeu

/** Gestion de la pause */
boolean enPause = false;

/** La balle */
Ball ball;
PImage balle;

/**racket*/
Racket racket1;
PImage raquette1;
Racket racket2;
PImage raquette2;

/**bouotn**/
Bouton bouton_play;
PImage bouton;
Bouton bouton_quit;

/** les scores**/
int scoreJ1;
int scoreJ2;

/**apparences**/
PFont font;
PImage imageFond;
PImage imageMenu;


int boutonPressed;

/**
 * Fonction d'initialisation Processing.
 */
public void setup()
{
  
  

  /**initialisation image + fonte**/
  imageMenu = loadImage("fond.png");
  font = loadFont("Trebuchet-BoldItalic-30.vlw");
  imageFond = loadImage("imageFond.jpg");
  raquette1 = loadImage("raquette1.jpg");
  raquette2 = loadImage("raquette2.jpg");
  balle = loadImage("ball.png");
  bouton = loadImage("button.png");
  
  imageFond.resize(width,height);
  imageMenu.resize(width,height);

  /***height)/400initialisation variable score**/
  scoreJ1 = 0;
  scoreJ2 = 0;

  // on initialise nos objets
  ball = new Ball();
  racket1 = new Racket(0, raquette1);
  racket2 = new Racket(width-40, raquette2);
  bouton_play = new Bouton(100, 100, bouton);
  bouton_quit = new Bouton(width-150-100, 100, bouton);


  boutonPressed = 0;
}

/**
 * Fonction de rafraichissement Processing.
 */
public void draw()
{
  if (boutonPressed==1) {
    background(imageFond);
    point(ball);
    afficherText();
    showBall(ball); 
    showRacket(racket1);
    showRacket(racket2);
    moveBall(ball);
    gestionClavierDepuisDraw();
  } else if (boutonPressed==2) {
    exit();
  } else {
    gestionMenu();
  }
}

public void gestionClavierDepuisDraw() {
  if (keyPressed) {
    switch(key) {
    case 'z':
      moveRacketUp(racket1);
      break;
    case 's':
      moveRacketDown(racket1);
      break;
    case 'o':
      moveRacketUp(racket2);
      break;
    case 'l':
      moveRacketDown(racket2);
      break;
    case ' ':
      break;
    default:
      println("erreur");
      break;
    }
  }
}

public void keyPressed() {
  if (key==' ') {
    enPause = !enPause;
    if (enPause) {
      noLoop();
    } else {
      loop();
    }
  }
}


public void mouseReleased() {
  if ((mouseX>=bouton_play.x)&&(mouseX<=bouton_play.x+bouton_play.longueur)&&(mouseY>=bouton_play.y)&&(mouseY<=bouton_play.y+bouton_play.largeur)) {
    boutonPressed = 1;
  }
  if ((mouseX>=bouton_quit.x)&&(mouseX<=bouton_quit.x+bouton_quit.longueur)&&(mouseY>=bouton_quit.y)&&(mouseY<=bouton_quit.y+bouton_quit.largeur)) {
    boutonPressed = 2;
  }
}

public void point(Ball b) {
  if (b.x + (BALL_WIDTH/2) >= width) {
    scoreJ1 = reinit(scoreJ1, b);
  } else if (b.x - (BALL_WIDTH/2) <= 0) {
    scoreJ2 = reinit(scoreJ2, b);
  }
}

public int reinit(int score, Ball b) {
  b.x=width/2;
  b.y=height/2;
  return score+1;
}

public void afficherText() {
  fill(BLANC);
  textAlign(CENTER);
  textFont(font, 30);
  text("Score", (width/2), 50);
  text(scoreJ1, ((width*3)/8), 75);
  text(scoreJ2, ((width*5)/8), 75);
}
/** largeur (ou diamètre) de la balle */
final int BALL_WIDTH = 10;
/** vitesse de déplacement de la balle */
final int BALL_SPEED = 3;
/** couleur de la balle */
final int BALL_COLOR = BLANC; 
/*
Une balle.
 */
class Ball {

  /** abscisse du centre de la balle */
  int x;

  /** ordonnée du centre de la balle */
  int y;

  /** mouvement sur l'axe des abscisses */
  int mvt_x;

  /** mouvement sur l'axe des ordonnées */
  int mvt_y;
  Ball() {
    x = width/2;
    y = height/2;
    mvt_x = BALL_SPEED;
    mvt_y = BALL_SPEED;
  }
}

/**
 * Initialisation d'une balle : tous les attributs prennent des valeurs par défaut.
 */


/**
 * Affichage de la balle
 */
public void showBall(Ball b)
{
  image(balle, b.x, b.y);
}

/**
 * Déplacement de la balle
 */
public void moveBall(Ball b)
{
  // Mouvement Horizontal
  b.x += b.mvt_x;
  if (collisionHorizontale(b))
  {
    b.x -= b.mvt_x; // mouvement annulé
    b.mvt_x *= -1; // changement de direction
  }

  // Mouvement Vertical
  b.y += b.mvt_y;
  if (collisionVerticale(b))
  {
    b.y -= b.mvt_y; // mouvement annulé
    b.mvt_y *= -1; // changement de direction
  }
}

/**
 * Retourne vrai si la balle ....
 */
public boolean collisionHorizontale(Ball b)
{
  return (collision(b.x-(BALL_WIDTH/2), b.y-(BALL_WIDTH/2), BALL_WIDTH, BALL_WIDTH, racket1.x, racket1.y, racket1.longueur, racket1.largeur) 
      || collision(b.x-(BALL_WIDTH/2), b.y-(BALL_WIDTH/2), BALL_WIDTH, BALL_WIDTH, racket2.x, racket2.y, racket2.longueur, racket2.largeur) 
      || ((b.x + (BALL_WIDTH/2)) > width) || ((b.x - (BALL_WIDTH/2)) < 0));
}

/**
 * Retourne vrai si la balle ...
 */
public boolean collisionVerticale(Ball b)
{
  return (collision(b.x-(BALL_WIDTH/2), b.y-(BALL_WIDTH/2), BALL_WIDTH, BALL_WIDTH, racket1.x, racket1.y, racket1.longueur, racket1.largeur) 
      || collision(b.x-(BALL_WIDTH/2), b.y-(BALL_WIDTH/2), BALL_WIDTH, BALL_WIDTH, racket2.x, racket2.y, racket2.longueur, racket2.largeur) 
      || ((b.y + (BALL_WIDTH/2)) > height) || ((b.y - (BALL_WIDTH/2)) < 0));
}
/** largeur d'une raquette */
final int RACKET_WIDTH  = 10;
/** hauteur d'une raquette */
final int RACKET_HEIGHT = 40;
/** vitesse de déplacement vertical d'une raquette */
final int RACKET_SPEED  = 7;
/** distance du bord de la fenêtre pour la raquette */
final int BORDER_SPACE  = 20;


/**
 * Une raquette.
 */
class Racket {
  int x;
  int y;
  int largeur;
  int longueur;
  PImage image;
  Racket(int posX, PImage img) {
    x = (posX + BORDER_SPACE);
    y = (height - RACKET_HEIGHT)/2;
    largeur = RACKET_HEIGHT;
    longueur = RACKET_WIDTH;
    image = img;
  }
}

public void showRacket(Racket r){
  image(r.image, r.x, r.y);
}

public void moveRacketUp(Racket r) {
  if(r.y >= 0){
  r.y-=5;
  }
  else{
    r.y = 0;
  }
  showRacket(r);
}

public void moveRacketDown(Racket r) {
  if(r.y+r.largeur <= height){
  r.y+=5;
  }
  else{
    r.y = height-r.largeur;
  }
  showRacket(r);
}
/**
 * Détection de collision entre 2 rectangles a et b
 *
 * @param ax rectangle 1 : abscisse du coin haut/gauche
 * @param ay rectangle 1 : ordonnée du coin haut/gauche
 * @param aw rectangle 1 : largeur
 * @param ah rectangle 1 : hauteur
 * @param bx rectangle 2 : abscisse du coin haut/gauche
 * @param by rectangle 2 : ordonnée du coin haut/gauche
 * @param bw rectangle 2 : largeur
 * @param bh rectangle 2 : hauteur
 * @return true si il y a collision entre les deux rectangles, false sinon
 */
public boolean collision( int ax, int ay, int aw, int ah,
                   int bx, int by, int bw, int bh)
{
  // il y a collision si les abscisses se chevauchent, ainsi que les ordonnées
  return chevauchementIntervalles(ax, ax+aw, bx, bx+bw)
      && chevauchementIntervalles(ay, ay+ah, by, by+bh);
}

/**
 * Détermine si deux intervalles se chevauchent (s'intersectent).
 *
 * @param a_min borne inférieure du premier intervalle
 * @param a_max borne supérieure du premier intervalle
 * @param b_min borne inférieure du deuxième intervalle
 * @param b_max borne supérieure du deuxième intervalle
 */
public boolean chevauchementIntervalles(int a_min, int a_max, int b_min, int b_max)
{
    int plus_grand_min = max(a_min, b_min);
    int plus_petit_max = min(a_max, b_max);
    return plus_grand_min <= plus_petit_max;
}
int bouton_height = 150;
int bouton_width = 60;

public void Menu(Bouton bouton1, Bouton bouton2, int val1x, int val1y, int val2x, int val2y) {
  background(imageMenu);
  copy(bouton1.image, val1x, val1y, bouton1.longueur, bouton1.largeur, bouton1.x, bouton1.y, bouton1.longueur, bouton1.largeur);
  copy(bouton2.image, val2x, val2y, bouton2.longueur, bouton2.largeur, bouton2.x, bouton2.y, bouton2.longueur, bouton2.largeur);
}

public void gestionMenu() {
  if ((mouseX>=bouton_play.x)&&(mouseX<=bouton_play.x+bouton_play.longueur)&&(mouseY>=bouton_play.y)&&(mouseY<=bouton_play.y+bouton_play.largeur)) {
    Menu(bouton_play, bouton_quit, 200, 100, 0, 0);
  } else if ((mouseX>=bouton_quit.x)&&(mouseX<=bouton_quit.x+bouton_quit.longueur)&&(mouseY>=bouton_quit.y)&&(mouseY<=bouton_quit.y+bouton_quit.largeur)) {
    Menu(bouton_play, bouton_quit, 0, 100, 200, 0);
  } else {
    Menu(bouton_play, bouton_quit, 0, 100, 0, 0);
  }
}

class Bouton {
  int longueur;
  int largeur;
  int x;
  int y;
  PImage image;
  Bouton(int posX, int posY, PImage img) {
    longueur = bouton_height;
    largeur = bouton_width;
    x = posX;
    y = posY;
    image = img;
  }
}
  public void settings() {  size(640, 400); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "sketch_Pong" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
