/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sokoban;
import java.util.*;

/**
 *
 * @author trecobre
 */
public class TextBoardBuilder implements BoardBuilder{
    public String name;
    public ArrayList<String> lines = new ArrayList<String>();
    public int maxLenght = 0;
    
    public TextBoardBuilder(String name){
        this.name=name;
    }
    
    public void addRow(String line){
        this.lines.add(line);
        if(line.length()>maxLenght) maxLenght=line.length();
    }
    
    @Override
    public Board build(){
        String[] board = new String[this.lines.size()];
        this.lines.toArray(board);
        Board b = new Board(this.name,board , this.maxLenght);
        return b;
    }
}
