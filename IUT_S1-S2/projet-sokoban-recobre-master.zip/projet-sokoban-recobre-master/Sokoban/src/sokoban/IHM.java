/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sokoban;

import java.util.Scanner;
import java.util.concurrent.TimeUnit;

/**
 *
 * @author trecobre
 */
public class IHM {
    public int currentMode;
    public char getText(boolean adminOn){
        Scanner in = new Scanner(System.in);
        String possibleMoves = "123456zZsSqQdDrR";
        boolean verif = false;
        String charAsString = "";
        while(!verif){
            
            try{
                charAsString = in.nextLine();
                if(charAsString.length()==1 &&
                    possibleMoves.contains(charAsString)){
                    verif = true;
                }
                else if (charAsString.equals("123") && !adminOn){
                    Administrator adminMode = new Administrator();
                    adminMode.menuAdmin(this);
                }
                
            }
            catch(NullPointerException e){
                try{
                    TimeUnit.MILLISECONDS.sleep(1);
                }
                catch(InterruptedException f){
                    //whatever
                }
                
            }
        }
        return charAsString.charAt(0);
    }
    
    public char setupGame(){
        System.out.println("Choisissez d'ou vient le plateau. \n1- code brut \n2- fichier texte \n3- base de donnée \n4- Quitter");
        return this.getText(false);
    }
    
    public String getBoardName(){
        Scanner in = new Scanner(System.in);
        System.out.print("Veuillez indiquer le nom ou le début du nom du plateau à supprimer : ");
        return in.nextLine();
    }
    
    public void print(Board b){
        //BoardTextFile.updateFile(b);
        for(int i=0; i<b.longY; i++){
            for(int j=0; j<b.longX; j++){
                System.out.print(" "+b.board[i][j]);
            }
            System.out.println();
        }
    }
    public void choiceMenu(){
        Board b = null;
        dataBase dB = new dataBase();
        BoardTextFile textFile = new BoardTextFile();
        Player player = new Player();
        char choice = '0';
        boolean trueMode = false;
        while(!trueMode){
            choice = this.setupGame();
            switch(choice){
                case '1': b = player.testBoard();
                    trueMode = true; 
                    break;
                case '2' : b = textFile.fileToBoard(); 
                    trueMode = true; 
                    break;
                case '3' : b= dB.boardFromDB("-");
                    trueMode = true;
                    break;
                case '4' : System.exit(0);
                default : System.out.println("mauvaise entrée"); 
            }
            
        }
        currentMode = choice;
        System.out.println("");
        player.game(b, this);
    }
    
    public String choiceLevel(dataBase db){
        Scanner in = new Scanner(System.in);
        System.out.println("Voici la liste des niveaux disponibles dans la base de données : ");
        System.out.println("");
        try{
            TimeUnit.MILLISECONDS.sleep(500);
        }
        catch(InterruptedException f){
            //whatever
        }
        db.listBoard(false);
        System.out.print("Sélection du niveau : ");
        return in.nextLine();
    }
}
