/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sokoban;
import java.sql. Statement ; 
import java.sql. PreparedStatement ; 
import java.sql. ResultSet ; 
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ArrayList;
/**
 *
 * @author theol
 */
public class dataBase {
    public Administrator Admin = new Administrator();
    public IHM display = new IHM();
    public String chemin = "\\data\\mapDB.db";
    public String URL = "jdbc:sqlite:" + chemin;
    public Board main(){
        Board b =null;
        String sqlite_driver = "org.sqlite.JDBC";
        try {
            Class.forName(sqlite_driver);
        } catch (ClassNotFoundException ex) {
            System.err.println("* Driver " + sqlite_driver + " introuvable.");
            System.exit(1);
        }
        try (Connection connexion = DriverManager.getConnection(URL)) {
            b = boardFromDB("simple");
            //System.out.println("yeyu");
        } catch (SQLException ex) {
            System.err.println("* Base " + URL + " introuvable.");
        }
        return b;
    }
    
    public int getNbRow(String boardId){
        String sql = "select nb_rows from boards where board_id = ?";
        int nbRows;
        try(Connection c = DriverManager.getConnection(URL)){
            PreparedStatement ps = c.prepareStatement(sql);
            ps.setString(1, boardId);
            ResultSet resultat = ps.executeQuery();
            nbRows = resultat.getInt("nb_rows");
        }
        catch(SQLException e){
            nbRows=-1;
        }
        return nbRows;
    }
    
    
    
    public Board boardFromDB(String boardId){
        if(boardId.equals("-")){
            boardId = display.choiceLevel(this);
        }
        String sql1 = "select board_id from Boards where board_id = ?";   
        String name ="";
        try(Connection c = DriverManager.getConnection(URL)){
            PreparedStatement ps = c.prepareStatement(sql1);
            ps.setString(1, boardId);
            ResultSet resultat = ps.executeQuery();
            name = resultat.getString("board_id");
        }
        catch(SQLException e){
            //System.err.println("* Livre introuvable");
        }
        var builder = new TextBoardBuilder(name);
        for(int i = 0; i<getNbRow(boardId); i++){
            String sql = "select * from rows where board_id = ? AND row_num = ?";
            try(Connection c = DriverManager.getConnection(URL)){
                PreparedStatement ps = c.prepareStatement(sql);
                ps.setString(1, boardId);
                ps.setInt(2, i);
                ResultSet resultat = ps.executeQuery();
                builder.addRow(resultat.getString("description"));

            }
            catch(SQLException e){
                //System.err.println("* Livre introuvable");
            }
        }
        return builder.build();
    }
    
    public void createDB(){
        
    }
    
    public void addFromFile(){
        BoardTextFile fileToBoard = new BoardTextFile();
        Board b = fileToBoard.fileToBoard();
        
        String sql = "select board_id from Boards where board_id LIKE 'fromFile%'";
        int max=0;    
        try(Connection c = DriverManager.getConnection(URL)){
            PreparedStatement ps = c.prepareStatement(sql);
            ResultSet resultat = ps.executeQuery();
            int temp2;
            while(resultat.next()){
                temp2 = 0;
                String temp = resultat.getString("board_id");
                
                try {
                    temp2 = ((temp.charAt(8)-48)*1000)+((temp.charAt(9)-48)*100)+((temp.charAt(10)-48)*10)+(temp.charAt(11)-48);
                    if(temp2>max) max=temp2;
                }
                
                catch(StringIndexOutOfBoundsException e){
                }
                
            }

        }
        catch(SQLException e){
            //System.err.println("* Livre introuvable");
        }
        max+=1;
        
        StringBuilder numberForName = new StringBuilder();
        numberForName.append(max);
        //numberForName.reverse();
        while(numberForName.length()<4){
            numberForName.insert(0, 0);
        }
        String name = "fromFile"+numberForName.toString();
        
        String sql1 = "INSERT INTO Boards (board_id, name, nb_rows, nb_cols) VALUES ('"+name+"', '"+b.level+"' ,"+b.longY+", "+b.longX+")";
        try(Connection c = DriverManager.getConnection(URL)){
                Statement ps = c.createStatement();
                ps.executeUpdate(sql1);
                
                String sql2 = "INSERT INTO rows VALUES ('"+name+"', ?, ?)";
                for(int rowNum = 0; rowNum < b.longY; rowNum++){
                    String line = "";
                    for(int colNum = 0; colNum < b.longX; colNum++){
                        line+=b.board[rowNum][colNum];
                    }
                    PreparedStatement ps2 = c.prepareStatement(sql2);
                    ps2.setInt(1, rowNum);
                    ps2.setString(2, line);
                    ps2.executeUpdate();
                    
                }
                
            }
            catch(SQLException e){
                System.err.println(e.getMessage());
            }
        System.out.println("Board "+name+" created successfully.");
        Admin.menuAdmin(display);
    }
    public void removeBoard(){
        IHM askboard = new IHM();
        String sql = "";
        boolean onlyOneBoard = false;
        String boardToRemove = "";
        ArrayList<String> resList = new ArrayList<>();
        try(Connection c = DriverManager.getConnection(URL)){
            
            while(!onlyOneBoard){
                boardToRemove = askboard.getBoardName();
                sql = "select board_id from Boards where board_id LIKE '"+boardToRemove+"%'";
                PreparedStatement ps = c.prepareStatement(sql);
                ResultSet resultat = ps.executeQuery();
                while(resultat.next()){
                    resList.add(resultat.getString("board_id"));
                    if(boardToRemove.equals(resList.get(resList.size()-1))){
                        onlyOneBoard=true;
                    }
                }
                if(resList.size()!=1 && !onlyOneBoard){
                    resultat = ps.executeQuery();
                    while(resultat.next()){
                        Board b = this.boardFromDB(resultat.getString("board_id"));
                        System.out.println(b.level);
                    }
                }
            }
            
        }
        catch(SQLException e){
            //System.err.println("* Livre introuvable");
        }
        
        String sql1 = "DELETE FROM Boards WHERE board_id = '"+boardToRemove+"'";
        try(Connection c = DriverManager.getConnection(URL)){
                Statement ps = c.createStatement();
                ps.executeUpdate(sql1);
                String sql2 = "DELETE FROM rows WHERE board_id = '"+boardToRemove+"'";
                PreparedStatement ps2 = c.prepareStatement(sql2);
                ps2.executeUpdate();
            }
            catch(SQLException e){
                System.err.println(e.getMessage());
            }
        System.out.println("Board "+boardToRemove+" removed successfully.");
        Admin.menuAdmin(display);
    }
    public void listBoard(boolean adminMode){
        String sql = "select board_id from boards";
        try(Connection c = DriverManager.getConnection(URL)){
            PreparedStatement ps = c.prepareStatement(sql);
            ResultSet resultat = ps.executeQuery();
            while(resultat.next()){
                Board b = this.boardFromDB(resultat.getString("board_id"));
                System.out.println(b.level);
            }
        }
        catch(SQLException e){
            //
        }
        if(adminMode)Admin.menuAdmin(display);
    }
    public void showBoard(){
        IHM view = new IHM();
        String boardToShow = view.choiceLevel(this);
        String sql = "select board_id from boards WHERE board_id = '"+boardToShow+"'";
        try(Connection c = DriverManager.getConnection(URL)){
            PreparedStatement ps = c.prepareStatement(sql);
            ResultSet resultat = ps.executeQuery();
            Board b = this.boardFromDB(resultat.getString("board_id"));
            System.out.println(b.level);
            view.print(b);
            
        }
        catch(SQLException e){
            //
        }
        Admin.menuAdmin(display);
    }
}
