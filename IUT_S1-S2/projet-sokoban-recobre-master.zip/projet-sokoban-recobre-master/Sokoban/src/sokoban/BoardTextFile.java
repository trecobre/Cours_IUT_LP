/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sokoban;
import java.util.Scanner;
import java.io.File; 
import java.io.FileNotFoundException;  
import java.io.FileWriter;
import java.io.IOException;

/**
 *
 * @author trecobre
 */
public class BoardTextFile {
    public static void updateFile(Board b){
        try {
            FileWriter textFileWrite = new FileWriter("\\data\\mapText.txt");
            textFileWrite.append(b.level + "\n");
            for(int i=0; i<b.longY; i++){
                for(int j=0; j<b.longX; j++){
                    textFileWrite.append(b.board[i][j]);
                }
                textFileWrite.append("\n");
            }
            textFileWrite.close();
            } catch (IOException e) {
                System.out.println("lol");
            }
    }
    
    
    public Board fileToBoard(){
        Board b;
        try {
            File textFile = new File("\\data\\mapText.txt");
            Scanner reader = new Scanner(textFile);
            var builder = new TextBoardBuilder(reader.nextLine());
            while (reader.hasNextLine()) {
                builder.addRow(reader.nextLine());
            }
            reader.close();
            b = builder.build();
        } 
        catch (FileNotFoundException e) {
            b= new Board("error",0,0);
        }
        return b;
    }
}

       
        