/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sokoban;
import java.util.*;
/**
 *
 * @author trecobre
 */
public class Board {
    public String level;
    public int longX;
    public int longY;
    public char[][] board;
    public int[] posPlayer = {0,0};
    public ArrayList<int[]> coordTarget = new ArrayList<int[]>();
    
    public Board(String level, int longX, int longY){
        this.level = level;
        this.longX = longX;
        this.longY = longY;
        this.board = new char [longY][longX];
    }
    
    public Board(String level, String[] lines, int longY){
        this.level = level;
        this.longY = lines.length; //nb colonne
        this.longX = longY; //nb ligne
        this.board = new char [longX][longY];
        int y=0;
        for(String line : lines){
            int x =0;
            for(char c : line.toCharArray()){
                this.board[y][x] = c;
                
                if(c=='T'){
                    int[] temp = {x, y};
                    System.out.println();
                    this.coordTarget.add(temp);
                }
                else if(c=='P'){
                    this.playerPos(y, x);
                    this.posPlayer[0]=x;
                    this.posPlayer[1]=y;
                }
                x+=1;
            }
            y+=1;
        }
        /*for(int i = 0; i<this.longX; i++){ 
            for(int j =0; j<this.longY; j++){
                this.board[i][j] = lines[i].charAt(j);
                
            }
        }*/
    }
    
    public void addWall(int posX, int posY, int wallLenght, char orientation){
        int staticPos = 0;
        int nonStaticPos = 0; 
        int maxLenght = 0;
        boolean charAccepted = true;
        switch(orientation){
            case 'H' : 
                staticPos = posX; 
                nonStaticPos = posY; 
                maxLenght = this.longY-1;
                break;
            case 'V' : 
                staticPos = posY; 
                nonStaticPos = posX;
                maxLenght = this.longX-1;
                break;
            default : 
                charAccepted = false;
        }
        if(charAccepted){
            if((nonStaticPos+wallLenght)>=maxLenght){
                wallLenght = maxLenght - nonStaticPos;
            }

            for(int i=nonStaticPos; i<=wallLenght; i++){
                if(orientation == 'V'){
                    this.board[staticPos][nonStaticPos+i] = '#';
                }
                else{
                    this.board[nonStaticPos+i][staticPos] = '#';
                }
            }
        }
    }
    
    public void addOneCaseElement(int posX, int posY, char type){
        int[] coord = {posX, posY};
        if(type == 'C' || type=='T')
        this.board[posY][posX]=type;
        if(type=='T') this.coordTarget.add(coord);
    }
    
    public void playerPos(int moveX, int moveY){
        if(this.posPlayer[1] != 0 && this.posPlayer[0]!=0){
            this.board[this.posPlayer[1]][this.posPlayer[0]] = '.';
        }
        
        this.posPlayer[1]+=moveX;
        this.posPlayer[0]+=moveY;
        if(this.board[this.posPlayer[1]][this.posPlayer[0]]=='#'){
            this.posPlayer[1]-=moveX;
            this.posPlayer[0]-=moveY;
            System.out.println("mouvement impossible");
        }
        else if(this.board[this.posPlayer[1]][this.posPlayer[0]]=='C'){
            if(this.board[this.posPlayer[1]+moveX][this.posPlayer[0]+moveY]=='.' || 
                    this.board[this.posPlayer[1]+moveX][this.posPlayer[0]+moveY]=='T'){
                this.board[this.posPlayer[1]+moveX][this.posPlayer[0]+moveY]='C';
            }
            else{
                this.posPlayer[1]-=moveX;
                this.posPlayer[0]-=moveY;
            }
        }
        this.board[this.posPlayer[1]][this.posPlayer[0]] = 'P';
        replaceTarget();
    }
    
    public void replaceTarget(){
        for(int[] Target : coordTarget){
            if(board[Target[1]][Target[0]]=='.')
                board[Target[1]][Target[0]]='T';
        }
    }
    
    public void fillBoard(){
        for(int i=0; i<this.longX; i++){
            for(int j=0; j<this.longY; j++){
                this.board[j][i] = '.';
            }
        }
    }

    public boolean verifWin(){
        
        boolean[] checkTarget = new boolean[this.coordTarget.size()];
        boolean toReturn = true;
        int pointer = 0;
        for(int[] Target : coordTarget){
            if(board[Target[1]][Target[0]]=='C')
                checkTarget[pointer] = true;
            else checkTarget[pointer] = false;
            pointer++;
        }
       
        pointer = 0;
        while(toReturn && pointer<this.coordTarget.size()){
            toReturn = checkTarget[pointer];
            pointer+=1;
        }
        return toReturn;
    }
    
    public Board resetBoard(IHM play){
        Board b = null;
        Player player = new Player();
        BoardTextFile textFile = new BoardTextFile();
        dataBase dB = new dataBase();
        switch(play.currentMode){
            case '1': b = player.testBoard();
                break;
            case '2' : b = textFile.fileToBoard(); 
                break;
            case '3' : b = dB.boardFromDB("simple");
                break;
            default : System.out.println("mauvaise entrée"); 
        }
        return b;
    }
}
