/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sokoban;

import java.util.concurrent.TimeUnit ;
/**
 *
 * @author trecobre
 */
public class Player {

    /**
     * @param args the command line arguments
     */
    
    
    
    public static void main(String[] args) {
        // TODO code application logic here
        IHM play = new IHM();
        play.choiceMenu();
    }
    
    public void game(Board b, IHM play){
        play.print(b);
        while(!b.verifWin()){
            char key = play.getText(false);
            switch(key){
                case 'q': 
                case 'Q': b.playerPos(0,-1);
                            break;
                case 'd': 
                case 'D': b.playerPos(0,1);
                            break;
                case 'z': 
                case 'Z': b.playerPos(-1,0);
                            break;
                case 's': 
                case 'S': b.playerPos(1,0);
                            break;
                case 'r':
                case 'R': b = b.resetBoard(play);
                            break;
                default : b.playerPos(0,0);
            }
                play.print(b);
                try{
                    TimeUnit.SECONDS.sleep(1);
                }
                catch(InterruptedException e){
                    System.out.println("peux po attendre");
                }
            
        }
        System.out.println("Bravo ! Vous avez réussi le niveau "+b.level+".");
        System.out.println();
        play.choiceMenu();
    }
    
    
    
    
    
    public Board testBoard(){
        Board b = new Board("test", 10, 10);
        b.fillBoard();
        b.addWall(0, 0, 10, 'H');
        b.addWall(9, 0, 10, 'H');
        b.addWall(0, 0, 10, 'V');
        b.addWall(0, 9, 12, 'V');
        b.addWall(2, 5, 10, 'V');
        b.addOneCaseElement(6, 4, 'C');
        b.addOneCaseElement(6, 6, 'C');
        b.addOneCaseElement(6, 3, 'T');
        b.addOneCaseElement(6, 7, 'T');
        b.playerPos(7,8);
        
        return b;
    }
}
