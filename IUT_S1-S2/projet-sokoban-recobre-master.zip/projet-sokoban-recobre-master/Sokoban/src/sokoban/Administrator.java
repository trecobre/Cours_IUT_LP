/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sokoban;

import java.util.concurrent.TimeUnit;

/**
 *
 * @author theol
 */
public class Administrator {
    public void menuAdmin(IHM display){
        System.out.println("ADMINISTRATION INTERFACE - USE WITH CAUTION \n1- Create a new database \n2- List of boards \n3- Show borads \n4- Add board from file \n5- Remove board from database \n6- Quit ");
        boolean acceptedEntry = false;
        dataBase db = new dataBase();
        while(!acceptedEntry){
            char choice = display.getText(true);
            switch(choice){
                case '1': db.createDB();
                            break;
                case '2': db.listBoard(true);
                            break;
                case '3': db.showBoard();
                            break; 
                case '4': db.addFromFile();
                            break;
                case '5': db.removeBoard();
                            break; 
                case '6': this.quit(display);
                          acceptedEntry = true;
                            break;
                default : 
            }
                
                try{
                    TimeUnit.SECONDS.sleep(1);
                }
                catch(InterruptedException e){
                    System.out.println("peux po attendre");
                }
        }
    }
    
    public void quit(IHM display){
        display.choiceMenu();
    }
    
    
}
