/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gomoku;

/**
 *
 * @author nboudmea
 */
public class Gomoku{
    public static void main() {
        System.out.println("Saisissez le nombre de joueur : ");
        String nbJ = System.console().readLine();
        int nbJoueur = Integer.parseInt(nbJ);
        
        System.out.println("Saisissez le nombre de ligne du plateau : ");
        String ligPlateau = System.console().readLine();
        System.out.println("Saisissez le nombre de coonne du plateau : ");
        String colPlateau = System.console().readLine();
        int longPlateau = Integer.parseInt(colPlateau);
        int hautPlateau = Integer.parseInt(ligPlateau);
        Plateau plateau = new Plateau(longPlateau, hautPlateau);
        plateau.setPlateau();
        if(nbJoueur==1){
            System.out.println("Nom du joueur : ");
            String nomJoueur1 = System.console().readLine();
            Joueur joueur1 = new Joueur(nomJoueur1, false, false);
            Joueur joueur2 = new Joueur("bot", true, true);
            Jeu1j(plateau, joueur1, joueur2);
        }
        else if(nbJoueur==2){
            System.out.println("Nom du joueur 1 (blanc) : ");
            String nomJoueur1 = System.console().readLine();
            System.out.println("Nom du joueur 2 (noir) : ");
            String nomJoueur2 = System.console().readLine();
            Joueur joueur1 = new Joueur(nomJoueur1, false, false);
            Joueur joueur2 = new Joueur(nomJoueur2, true, false);
            Jeu2j(plateau, joueur1, joueur2);
        }
        
    }
    
    public static void Jeu2j(Plateau plateau, Joueur joueur1, Joueur joueur2){
        boolean conditionVictoire = true;
        int indicePose = 0;
        Pion[][] pose = new Pion[plateau.hauteur*plateau.longueur][2];
        while (!conditionVictoire || indicePose<(plateau.hauteur*plateau.longueur)){
            System.out.println("Joueur 1 : veuillez entrer les coordonnées du pion à poser sous la forme \"ligne,colonne\".");
            String pionJ1 = System.console().readLine();
            pose[indicePose][0] = new Pion(pionJ1, true);
            
            System.out.println("Joueur 2 : veuillez entrer les coordonnées du pion à poser sous la forme \"ligne,colonne\".");
            String pionJ2 = System.console().readLine();
            pose[indicePose][1] = new Pion(pionJ2, false);
            
            indicePose++;
            conditionVictoire = detectAligne(pose, indicePose);
        }
    }
    public static void Jeu1j(Plateau plateau, Joueur joueur1, Joueur joueur2){
        //todo
    }
    
    public static boolean detectAligne(Pion[][] pose, int taille){
        
        for(int i = 0; i<=1; i++){
            for(int j = 0; j<taille; j++){
                for(int k = pose[j][i].poseX-1; k<=pose[j][i].poseX; k++){
                    for(int l = pose[j][i].poseY-1; l<pose[j][i].poseY; l++){
                        if(pose[k][l].couleurJoueur == pose[j][i].couleurJoueur){
                            
                        }
                    }
                }
            }
        }
    }
    
    public static boolean ligne(Pion pion, int x, int y, int ind, Pion[][] pose){
        int lecX = x-pion.poseX;
        int lecY = y-pion.poseY;
        boolean verif = false;
        int lec = 0;
        while(!verif || lec<5){
            if()
        }
    }
    
}

