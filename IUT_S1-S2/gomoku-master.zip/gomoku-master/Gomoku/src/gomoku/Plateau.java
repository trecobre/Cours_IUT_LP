/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gomoku;

/**
 *
 * @author nboudmea
 */
public class Plateau {
    public int longueur;
    public int hauteur;
    public int[][] plateau;
    
 
    public Plateau(int longueur, int hauteur){
        plateau = new int [longueur + 1][hauteur + 1]; 
        this.longueur = longueur;
        this.hauteur = hauteur;
    }
    public void setPlateau(){
        for(int i=1; i<= this.longueur; i++){
            plateau[0][i] = i;
        }
         for(int j=1; j<= this.hauteur; j++){
            plateau[j][0] = j;
        }
    }
}
