/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gomoku;

/**
 *
 * @author trecobre
 */
public class Pion {
    public int poseX;
    public int poseY;
    public boolean couleurJoueur;
    
    public Pion(String position, boolean couleurJoueur){
        this.couleurJoueur = couleurJoueur;
        String[] pos = position.split(",");
        this.poseX = Integer.parseInt(pos[0]);
        this.poseY = Integer.parseInt(pos[1]);
    }
    public Pion(int x, int y, boolean couleurJoueur){
        this.poseX = x;
        this.poseY = y;
        this.couleurJoueur = couleurJoueur;
    }
}
