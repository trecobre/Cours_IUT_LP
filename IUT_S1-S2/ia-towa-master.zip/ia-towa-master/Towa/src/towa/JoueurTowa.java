package towa;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Joueur implémentant les actions possibles à partir d'un plateau, pour un
 * niveau donné.
 */
public class JoueurTowa implements IJoueurTowa {

    /**
     * Cette méthode renvoie, pour un plateau donné et un joueur donné, toutes
     * les actions possibles pour ce joueur.
     *
     * @param plateau le plateau considéré
     * @param joueurNoir vrai si le joueur noir joue, faux si c'est le blanc
     * @param niveau le niveau de la partie à jouer
     * @return l'ensemble des actions possibles
     */
    @Override
    public String[] actionsPossibles(Case[][] plateau, boolean joueurNoir, int niveau) {
        // afficher l'heure de lancement
        SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss.SSS");
        System.out.println("actionsPossibles : lancement le " + format.format(new Date()));
        // on compte le nombre de pions sur le plateau avant action
        final int nbPionsNoirs = nbPions(plateau, true);
        final int nbPionsBlancs = nbPions(plateau, false);
        // calculer les actions possibles
        String actions[] = new String[1028];
        int nbActions = 0;
        // pour chaque ligne
        for (int lig = 0; lig < Coordonnees.NB_LIGNES; lig++) {
            // pour chaque colonne
            for (int col = 0; col < Coordonnees.NB_COLONNES; col++) {
                Coordonnees coord = new Coordonnees(lig, col);
                // si la pose d'un pion de cette couleur est possible sur cette case
                if (posePossible(plateau, coord, joueurNoir)) {
                    // on ajoute l'action dans les actions possibles
                    if(joueurNoir){
                        actions[nbActions] = chaineActionPose(coord, nbPionsNoirs + poseTourAdjacente(coord, plateau, joueurNoir), nbPionsBlancs);
                    }
                    else{
                        actions[nbActions] = chaineActionPose(coord, nbPionsNoirs, nbPionsBlancs+poseTourAdjacente(coord, plateau, joueurNoir));
                    }
                    nbActions++;
                }
                if (plateau[lig][col].tourPresente && plateau[lig][col].estNoire == joueurNoir) {
                    // on ajoute l'action dans les actions possibles
                    int nbPionsRetire = activationTour(plateau, coord, joueurNoir);
                    if(joueurNoir){
                        actions[nbActions] = chaineActionActivation(coord, nbPionsNoirs, nbPionsBlancs-nbPionsRetire);
                        nbActions++;
                    }
                    else{
                        actions[nbActions] = chaineActionActivation(coord, nbPionsNoirs-nbPionsRetire, nbPionsBlancs);
                        nbActions++;
                    }
                }
            }
        }
        System.out.println("actionsPossibles : fin");
        return Utils.nettoyerTableau(actions);
    }

    /**
     * Indique s'il est possible de poser un pion sur une case pour ce plateau,
     * ce joueur, dans ce niveau.
     *
     * @param plateau le plateau
     * @param coord coordonnées de la case à considérer
     * @param estNoir vrai ssi il s'agit du tour du joueur noir
     * @return vrai si la pose d'un pion sur cette case est autorisée dans ce
     * niveau
     */
    boolean posePossible(Case[][] plateau, Coordonnees coord, boolean estNoir) {
        return(!plateau[coord.ligne][coord.colonne].tourPresente || (plateau[coord.ligne][coord.colonne].estNoire == estNoir && plateau[coord.ligne][coord.colonne].hauteur<4));
    }
    
    int poseTourAdjacente(Coordonnees coord, Case[][] plateau, boolean estNoir){
        int nbToursPose = 1;
        int[] tableauAdjacent = caseAdjacentes(coord);
        if(!plateau[coord.ligne][coord.colonne].tourPresente)
            for(int i =tableauAdjacent[0]; i<=tableauAdjacent[1]; i++){
                for(int j = tableauAdjacent[2]; j<=tableauAdjacent[3]; j++){
                    if((plateau[i][j].tourPresente) && (plateau[i][j].estNoire != estNoir)){
                        nbToursPose = 2;
                    }
                }
            }
        return nbToursPose;
    }
    
    static int[] caseAdjacentes(Coordonnees coord){
        int ligneMin, ligneMax, colonneMin, colonneMax;
        switch (coord.ligne){
            case 0:
                ligneMin = 0;
                ligneMax = coord.ligne+1;
                break;
            case Coordonnees.NB_LIGNES-1:
                ligneMin = coord.ligne-1;
                ligneMax = Coordonnees.NB_LIGNES-1;
                break;
            default:
                ligneMin=coord.ligne-1;
                ligneMax=coord.ligne+1;
                break;
        }
        switch (coord.colonne){
            case 0:
                colonneMin = 0;
                colonneMax = coord.colonne+1;
                break;
            case Coordonnees.NB_COLONNES-1:
                colonneMin = coord.colonne-1;
                colonneMax = Coordonnees.NB_COLONNES-1;
                break;
            default:
                colonneMin=coord.colonne-1;
                colonneMax=coord.colonne+1;
                break;
        }
        int[] tableau3x3 = {ligneMin, ligneMax, colonneMin, colonneMax};
        return tableau3x3;
    }
    
    
    static int activationTour(Case[][] plateau, Coordonnees coord, boolean estNoir) {
        int[] tableauAdjacent = caseAdjacentes(coord);
        int nbToursRetire = 0;
        for(int i =tableauAdjacent[0]; i<=tableauAdjacent[1]; i++){
            for(int j = tableauAdjacent[2]; j<=tableauAdjacent[3]; j++){
                if((plateau[i][j].tourPresente) && (plateau[i][j].estNoire != estNoir) && (plateau[i][j].hauteur<plateau[coord.ligne][coord.colonne].hauteur)){
                    //plateau[i][j].tourPresente = false;
                    nbToursRetire+=plateau[i][j].hauteur;
                }
            }
        }
        for(int i=0; i<Coordonnees.NB_COLONNES; i++){
            if((plateau[coord.ligne][i].tourPresente) && (plateau[coord.ligne][i].estNoire != estNoir) && (plateau[coord.ligne][i].hauteur<plateau[coord.ligne][coord.colonne].hauteur)
                    && !(coord.colonne-1<=i && i<=coord.colonne+1)){
                nbToursRetire+=plateau[coord.ligne][i].hauteur;
            }
        }
        for(int i=0; i<Coordonnees.NB_LIGNES; i++){
            if((plateau[i][coord.colonne].tourPresente) && (plateau[i][coord.colonne].estNoire != estNoir) && (plateau[i][coord.colonne].hauteur<plateau[coord.ligne][coord.colonne].hauteur)
                    && !(coord.ligne-1<=i && i<=coord.ligne+1)){
                nbToursRetire+=plateau[i][coord.colonne].hauteur;
            }
        }
        return nbToursRetire;
    }
   
    /**
     * Nombre de pions d'une couleur donnée sur le plateau.
     *
     * @param plateau le plateau
     * @param estNoir vrai si on compte les pions noirs, faux sinon
     * @return le nombre de pions de cette couleur sur le plateau
     */
    static int nbPions(Case[][] plateau, boolean estNoir) {
        int pions = 0;
        for(int i = 0; i<Coordonnees.NB_LIGNES; i++){
            for(int j = 0; j<Coordonnees.NB_COLONNES; j++){
                if(plateau[i][j].estNoire==estNoir){
                    pions+=plateau[i][j].hauteur;
                }
            }
        }
        return pions; // TODO il y en aura besoin à un moment !
    }

    /**
     * Chaîne de caractères correspondant à une action-mesure de pose.
     *
     * @param coord coordonnées de la case où poser le pion
     * @param nbPionsNoirs nombre de pions noirs si cette action était jouée
     * @param nbPionsBlancs nombre de pions blancs si cette action était jouée
     * @return la chaîne codant cette action-mesure
     */
    static String chaineActionPose(Coordonnees coord,
            int nbPionsNoirs, int nbPionsBlancs) {
        return "P" + coord.carLigne() + coord.carColonne() + ","
                + nbPionsNoirs + "," + nbPionsBlancs;
    }
    
    static String chaineActionActivation(Coordonnees coord,
            int nbPionsNoirs, int nbPionsBlancs) {
        return "A" + coord.carLigne() + coord.carColonne() + ","
                + nbPionsNoirs + "," + nbPionsBlancs;
    }
}
