﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("Hello, World!");

void valabs(int value)
{
    String toWrite = "Valeur de base : " + value + "\nValeur absolue : " + (value < 0 ? value*-1 : value) + "\n\n";
    Console.WriteLine(toWrite);
}

for(int val = 0; val<1000; val++)
{
    Console.Write(fib(val));
}

ulong fib(int rank)
{
    ulong first = 0;
    ulong second = 1;
    if (rank > 2)
    {
        for(int i = 1; i < rank; i++)
        {
            ulong actual = first + second;
            first = second;
            second = actual;
        }
    }
    return rank == 0 ? first : second;
}