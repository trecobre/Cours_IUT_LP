﻿namespace TP4.Models
{
    public class DataModel
    {

        public int userId { get; set; }
        public int id { get; set; }
        public String title { get; set; }
        public String body { get; set; }
        public DataModel(int userId, int id, string title, string body)
        {
            this.userId = userId;
            this.id = id;
            this.title = title;
            this.body = body;
        }

    }
}
