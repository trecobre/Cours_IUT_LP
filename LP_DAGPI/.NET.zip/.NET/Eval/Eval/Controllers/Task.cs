﻿using Eval.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;

namespace Eval.Controllers
{
    public class Task : Controller
    {
        // GET: Task
        public ActionResult Index()
        {
            return View(ProjectStorage.GetAll());
        }

        // GET: Task/Details/5

        public ActionResult Details(String id)
        {
            return View(ProjectStorage.GetById(id));
        }

        // GET: Task/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Task/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(IFormCollection collection)
        {
            String name = collection["Name"];
            String description = collection["Description"];
            SimpleTask task = new SimpleTask(name, description);
            ProjectStorage.Add(task.Id, task);
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: Task/Edit/5
        public ActionResult Edit(String id)
        {
            return View(ProjectStorage.GetById(id));
        }

        // POST: Task/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(String id, IFormCollection collection)
        {
            SimpleTask task = ProjectStorage.GetById(id);
            task.Name = collection["Name"];
            task.Description = collection["Description"];
            ProjectStorage.Update(id, task);
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: Task/Delete/5
        public ActionResult Delete(String id)
        {
            return View(ProjectStorage.GetById(id));
        }

        // POST: Task/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(String id, IFormCollection collection)
        {
            ProjectStorage.Remove(id);
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
