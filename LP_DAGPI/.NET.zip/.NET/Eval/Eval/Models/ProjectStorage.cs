﻿namespace Eval.Models
{
    public class ProjectStorage
    {
        private static Dictionary<String, SimpleTask> listTasks = new Dictionary<string, SimpleTask>();
        public static void Add(String name, SimpleTask task)
        {
            listTasks.Add(name, task);
        }
        public static void Remove(String name)
        {
            listTasks.Remove(name);
        }
        public static void Update(String name, SimpleTask task) {
            listTasks[name] = task;
        }
        public static SimpleTask Get(String name) {
            return listTasks.GetValueOrDefault(name);
        }

        public static SimpleTask GetById(String id) {
            return listTasks[id];
        }

        public static List<SimpleTask> GetAll()
        {
            List<SimpleTask> list = new List<SimpleTask>();
            foreach(var couple in listTasks)
            {
                list.Add(Get(couple.Key));
            }
            return list;
        }
    }
}
