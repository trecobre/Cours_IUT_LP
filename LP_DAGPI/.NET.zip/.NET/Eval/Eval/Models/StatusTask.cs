﻿namespace Eval.Models
{
    public enum StatusTask
    {
        BackLog,
        Inprogress,
        Ended
    }
}
