﻿namespace Eval.Models
{
    public class SimpleTask
    {
        public String Id{ get;set; }
        public String Name{ get;set; }
        public String Description{ get;set; }
        public StatusTask Status{ get;set; }
        public int AdvancementRate{ get;set; }
        public DateTime CreationDate{ get;set; }
        public DateTime StartDate{ get;set;}
        public DateTime EndDate { get; set; }

        public SimpleTask() {
            this.Name = "";
            this.Description = "";
            this.setDefaultValueOnCreate();
        }
        public SimpleTask(string name) {
            this.Name = name;
            this.Description = "";
            this.setDefaultValueOnCreate();
        }
        public SimpleTask(string name, string description) {
            this.Name = name;
            this.Description = description;
            this.setDefaultValueOnCreate();
        }
        
        private void setDefaultValueOnCreate()
        {
            this.Id = Guid.NewGuid().ToString("n").Substring(0, 8);
            this.Status = StatusTask.BackLog;
            this.CreationDate = DateTime.Now;
        }

        public String GetSummary()
        {
            if(this.Description.Length > 30)
            {
                return this.Description.Substring(0, 30);
            }
            return this.Description;
        }

    }
}
