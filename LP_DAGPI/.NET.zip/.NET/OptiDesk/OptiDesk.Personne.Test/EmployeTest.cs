﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OptiDesk.Personne.Dto.Pivot;

namespace OptiDesk.Personne.Test
{
    [TestClass]
    public class EmployeTest
    {
        [TestMethod]
        public void Personne_Compte_NombreConnecte()
        {
            Employe e1 = new Employe("Nom1", "Prenom1");
            Employe e2 = new Employe("Nom2", "Prenom2");
            
            Assert.AreEqual<int>(0, Employe.NombreConnecte());
            
            e1.Login(Employe.EmptyValue, Employe.EmptyValue);
            e2.Login(Employe.EmptyValue, Employe.EmptyValue);

            Assert.AreEqual<int>(2, Employe.NombreConnecte());

            e1.Logout();
            Assert.AreEqual<int>(1, Employe.NombreConnecte());
        }
    }
}
