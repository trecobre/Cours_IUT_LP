﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OptiDesk.Personne.Dto.Pivot
{
    /// <summary>
    /// Classe abstraite représentant une personne
    /// </summary>
    public abstract class Personne
    {
        #region Accessors
        /// <summary>
        /// Nom de la personne
        /// </summary>
        public string Nom
        {
            get;
            set;
        }

        /// <summary>
        /// Prénom de la personne
        /// </summary>
        public string Prenom
        {
            get;
            set;
        }

        /// <summary>
        /// Propriété Adresse 1
        /// </summary>
        public string Adresse1 { get; set; }

        /// <summary>
        /// Propriété Adresse 2
        /// </summary>
        public string Adresse2 { get; set; }

        /// <summary>
        /// Propriété Code postal
        /// </summary>
        public int CodePostal { get; set; }

        public string Ville { get; set; }
        #endregion

        #region Constructors
        /// <summary>
        /// Constructeur : nom / prenom
        /// </summary>
        /// <param name="nom">Nom de la personne</param>
        /// <param name="prenom">Prénom de la personne</param>
        public Personne(string nom, string prenom)
        {
            this.Nom = nom;
            this.Prenom = prenom;
        } 

        /// <summary>
        /// Constructeur par défault
        /// </summary>
        public Personne()
        {

        }
        #endregion

        #region Méthodes
        /// <summary>
        ///  Méthode abstraite pour décliner son identité
        /// </summary>
        /// <returns></returns>
        public abstract string SePresenter(); 
        #endregion
    }
}
