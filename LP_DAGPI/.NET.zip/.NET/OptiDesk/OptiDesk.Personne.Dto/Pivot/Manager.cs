﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OptiDesk.Personne.Dto.Pivot
{
    public sealed class Manager : Employe
    {
        #region Constructors
        public Manager(string nom, string prenom) : base(nom, prenom)
        {
        } 
        #endregion
    }
}
