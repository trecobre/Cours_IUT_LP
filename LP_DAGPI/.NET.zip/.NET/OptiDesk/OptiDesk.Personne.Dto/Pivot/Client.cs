﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OptiDesk.Personne.Dto.Pivot
{
    public class Client : Personne
    {
        public int Id
        {
            get;
            private set;
        }      
   
        public string NumSS
        {
            get;
            private set;
        } 

        #region Constructors
        public Client(int id, string nom, string prenom, string numSS)
            : base(nom, prenom)
        {
            this.NumSS = numSS;
            this.Id = id;
        }

        public Client()
        {

        }

        public Client(string prenom, string nom, string numSS, string adresse1, string adresse2, string codePostal, string ville)
            : base(nom, prenom)
        {
            this.Adresse1 = adresse1;
            this.Adresse2 = adresse2;
            this.CodePostal = CodePostal;
            this.Ville = ville;
        }

        #endregion

        #region Méthodes
        public override string SePresenter()
        {
            return string.Format("#{2}:{0} {1}", Prenom, Nom, NumSS);
        } 
        #endregion
    }
}
