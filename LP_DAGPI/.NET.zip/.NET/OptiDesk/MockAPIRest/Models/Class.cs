﻿namespace MockAPIRest.Models
{
    public class Class
    {
    }
}
