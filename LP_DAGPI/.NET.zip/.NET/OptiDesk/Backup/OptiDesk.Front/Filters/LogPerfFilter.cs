﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Web;
using System.Web.Http.Filters;
using System.Web.Mvc;

namespace OptiDesk.Front.Filters
{
    public class LogPerfFilter : System.Web.Mvc.FilterAttribute, System.Web.Mvc.IActionFilter
    {
        private Stopwatch timer;
        public void OnActionExecuting(ActionExecutingContext filterContext)
        {
            timer = Stopwatch.StartNew();
        }
        public void OnActionExecuted(ActionExecutedContext filterContext)
        {
            timer.Stop();
            if (filterContext.Exception == null)
            {
                filterContext.HttpContext.Response.Write(string.Format("<div>Action method elapsed time: {0:F6} </div>", timer.Elapsed.TotalSeconds));
                filterContext.HttpContext.Response.Write(string.Format("<div>Action name : {0} </div>", filterContext.ActionDescriptor.ActionName));
            }
        }
    }
}