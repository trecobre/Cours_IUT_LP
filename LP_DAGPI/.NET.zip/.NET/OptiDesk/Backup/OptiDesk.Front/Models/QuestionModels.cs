﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OptiDesk.Front.Models
{
    public class QuestionModels
    {
        public string Email
        { get; set; }

        public string Contenu
        { get; set; }

        public DateTime DateCreation
        { get; private set; }

        public QuestionModels()
        {
            this.DateCreation = DateTime.Now;
        }
    }
}