﻿using OptiDesk.Front.Filters;
using OptiDesk.Personne.Bll;
using OptiDesk.Personne.Dto.Pivot;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace OptiDesk.Front.Controllers
{
     [LogPerfFilter]
    public class ClientController : Controller
    {
        //
        // GET: /Client/

        public ActionResult Index()
        {
            return View();
        }

        //
        // GET: /Client/Details/5
        [LogPerfFilter]
        public ActionResult Details(int id)
        {
            Client datas = null;
            
            using (PersonneFrontService svc = new PersonneFrontService())
            {
                datas = svc.RechercheClient(id);
            }
            
            return View(datas);
        }

        public ActionResult List()
        {
            List<Client> datas = null;
            
            using (PersonneFrontService svc = new PersonneFrontService())
            {
                datas = svc.ListeClient(0);
            }
            
            return View(datas);
        }

        //
        // GET: /Client/Create

        public ActionResult Create()
        {
            return View();
        }

        //
        // POST: /Client/Create
        //FormCollection
        [HttpPost]
        public ActionResult Create(Client item)
        {
            try
            {
                using (PersonneFrontService svc = new PersonneFrontService())
                {
                    var result = svc.CreerClient(item);
                }

                return RedirectToAction("List");
            }
            catch
            {
                return View();
            }
        }

        //
        // GET: /Client/Edit/5

        public ActionResult Edit(int id)
        {
            Client datas = null;
            
            using (PersonneFrontService svc = new PersonneFrontService())
            {
                datas = svc.RechercheClient(id);
            }
            
            return View(datas);
        }

        //
        // POST: /Client/Edit/5

        [HttpPost]
        public ActionResult Edit(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add update logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        //
        // GET: /Client/Delete/5

        public ActionResult Delete(int id)
        {
            return View();
        }

        //
        // POST: /Client/Delete/5

        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
