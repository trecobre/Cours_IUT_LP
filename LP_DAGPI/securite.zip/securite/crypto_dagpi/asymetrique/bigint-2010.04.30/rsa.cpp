#include <iostream>
#include <stdlib.h>
#include <unistd.h>

// `BigIntegerLibrary.hh' includes all of the library headers.
#include "BigIntegerLibrary.hh"

using namespace std;

#define TAILLEMIN 1000
#define TAILLEMAX 1000000000

BigInteger puissance (BigInteger a, BigInteger e, BigInteger n)
{
  BigInteger p;
  for(p=1;e>0;e=e/2) {
    if (e % 2 != 0)
      p=(p*a)%n;
    a=(a*a)%n;
  }
  return p;
}

bool test_premier(BigInteger n) // test de Fermat
{
  if ( (puissance(2,n-1,n)==1) &&
       (puissance(3,n-1,n)==1) &&
       (puissance(5,n-1,n)==1) &&
       (puissance(7,n-1,n)==1) &&
       (puissance(11,n-1,n)==1) &&
       (puissance(13,n-1,n)==1) )
    return true; // probablement premier (garantie si n<2^15)
  return false;
}

BigInteger pgcd(BigInteger u, BigInteger v)
{
  BigInteger t;
  while (v!=0) {
    t = u;
    u = v;
    v = t % v;
  }
  return u < 0 ? -u : u; /* abs(u) */
}

BigInteger bezout(BigInteger a, BigInteger b) // calcul p et q tq : p*a+q*b=pgcd(a,b)
{
  // On sauvegarde les valeurs de a et b.
  BigInteger a0 = a;
  BigInteger b0 = b;

  // Initialisations. On laisse invariant p*a0 + q*b0 = a et  r*a0 + s*b0 = b.
  BigInteger p = 1; BigInteger q = 0;
  BigInteger r = 0; BigInteger s = 1;
  BigInteger c,quotient,nouveau_r,nouveau_s;

  // La boucle principale.
  while (b != 0) {
    c = a % b;
    quotient = a/b;
    a = b;
    b = c;
    nouveau_r = p - quotient * r; nouveau_s = q - quotient * s;
    p = r; q = s;
    r = nouveau_r; s = nouveau_s;
  }

  return p; // on n'a besoin que de p
}

BigInteger myrand(BigInteger taille)
{
  int tmp=rand()*rand(); // limite à MAXINT ...
  BigInteger x=tmp;
  return x%(taille-1)+1;
}

int main()
{
  srand(getpid()); // initialisation du generateur aleatoire

  // Bob : tirer 2 nombres premiers p et q
  BigInteger p = myrand(TAILLEMAX)+TAILLEMIN;
  while (!test_premier(p))
    p = myrand(TAILLEMAX)+TAILLEMIN;

  BigInteger q = myrand(TAILLEMAX)+TAILLEMIN;
  while (!test_premier(q))
    q = myrand(TAILLEMAX)+TAILLEMIN;

  cout << "2 nombres probalement premiers (p,q) : " << p << "," << q << endl;

  BigInteger n=p*q;
  cout << "n=p*q=" << n << endl;
  BigInteger phi=(p-1)*(q-1); // indicatrice d'Euler
  cout << "phi(n)=" << phi << endl;

  // Bob : cle publique (e,n)
  BigInteger e = myrand(phi); // e>0 et e<n
  while (pgcd(e,phi)!=1)    // e premier avec phi(n)
    e = myrand(phi);
  cout << "cle publique e=: " << e << "," << n << endl;

  // Bob : cle privee (d,n) inverse de e modulo phi(n)
  BigInteger d;
  d=bezout(e,phi);
  if (d<0) d=d+phi; // car d est defini modulo phi(n)
  cout << "cle privee d=: " << d << "," << n << endl;

  // Alice : chiffrement de m avec la cle publique (e,n) de Bob : c=m^e%n
  BigInteger m = myrand(n); // m>0 et m<n
  cout << "message en clair m=" << m << endl;
  BigInteger c = puissance(m,e,n);
  cout << "message chiffre  c=" << c << endl;

  // Bob : dechiffrement de c avec sa cle privee (d,n) : m=c^d%n
  m = puissance(c,d,n);
  cout << "message en clair m=" << m << endl;
}
