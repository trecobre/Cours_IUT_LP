#include <iostream>
#include <stdlib.h>
#include <assert.h>
#include <unistd.h>

// `BigIntegerLibrary.hh' includes all of the library headers.
#include "BigIntegerLibrary.hh"

using namespace std;

#define TAILLEMIN 1000
#define TAILLEMAX 1000000000
#define TAILLEEMPREINTE 100

BigInteger puissance (BigInteger a, BigInteger e, BigInteger n)
{
  BigInteger p;
  for(p=1;e>0;e=e/2) {
    if (e % 2 != 0)
      p=(p*a)%n;
    a=(a*a)%n;
  }
  return p;
}

bool test_premier(BigInteger n) // test de Fermat
{
  if ( (puissance(2,n-1,n)==1) &&
       (puissance(3,n-1,n)==1) &&
       (puissance(5,n-1,n)==1) &&
       (puissance(7,n-1,n)==1) &&
       (puissance(11,n-1,n)==1) &&
       (puissance(13,n-1,n)==1) )
    return true; // probablement premier (garantie si n<2^15)
  return false;
}

BigInteger pgcd(BigInteger u, BigInteger v)
{
  BigInteger t;
  while (v!=0) {
    t = u;
    u = v;
    v = t % v;
  }
  return u < 0 ? -u : u; /* abs(u) */
}

BigInteger bezout(BigInteger a, BigInteger b) // calcul p et q tq : p*a+q*b=pgcd(a,b)
{
  // On sauvegarde les valeurs de a et b.
  BigInteger a0 = a;
  BigInteger b0 = b;

  // Initialisations. On laisse invariant p*a0 + q*b0 = a et  r*a0 + s*b0 = b.
  BigInteger p = 1; BigInteger q = 0;
  BigInteger r = 0; BigInteger s = 1;
  BigInteger c,quotient,nouveau_r,nouveau_s;

  // La boucle principale.
  while (b != 0) {
    c = a % b;
    quotient = a/b;
    a = b;
    b = c;
    nouveau_r = p - quotient * r; nouveau_s = q - quotient * s;
    p = r; q = s;
    r = nouveau_r; s = nouveau_s;
  }

  return p; // on n'a besoin que de p
}

BigInteger myrand(BigInteger taille)
{
  int tmp=rand()*rand(); // limite à MAXINT ...
  BigInteger x=tmp;
  return x%(taille-1)+1;
}

BigInteger empreinte(BigInteger x)
{
  return x%13; // empreinte(X)=X%13 !!! (a remplacer par MD5SUM ou SHASUM...)
}

int main()
{
  srand(getpid()); // initialisation du generateur aleatoire

  // Alice : tirer 2 nombres premiers p et q
  BigInteger pA = myrand(TAILLEMAX/TAILLEEMPREINTE)+TAILLEMIN;
  while (!test_premier(pA))
    pA = myrand(TAILLEMAX/TAILLEEMPREINTE)+TAILLEMIN;

  BigInteger qA = myrand(TAILLEMAX/TAILLEEMPREINTE)+TAILLEMIN;
  while (!test_premier(qA))
    qA = myrand(TAILLEMAX/TAILLEEMPREINTE)+TAILLEMIN;

  cout << "2 nombres probalement premiers (p,q) : " << pA << "," << qA << endl;

  BigInteger nA=pA*qA;
  cout << "n=p*q=" << nA << endl;
  BigInteger phiA=(pA-1)*(qA-1); // indicatrice d'Euler
  cout << "phi(n)=" << phiA << endl;

  // Alice : cle publique (e,n)
  BigInteger eA = myrand(nA); // e>0 et e<n
  while (pgcd(eA,phiA)!=1)    // e premier avec phi(n)
    eA = myrand(nA);
  cout << "cle publique Alice e=: " << eA << "," << nA << endl;

  // Alice : cle privee (d,n) inverse de e modulo phi(n)
  BigInteger dA;
  dA=bezout(eA,phiA);
  if (dA<0) dA=dA+phiA; // car d est defini modulo phi(n)
  cout << "cle privee Alice d=: " << dA << "," << nA << endl;

  // Alice : construire un message et son empreinte chiffrée
  BigInteger m = myrand(TAILLEMAX/TAILLEEMPREINTE)+TAILLEMIN;
  BigInteger e = empreinte(m);
  BigInteger ec = puissance(e, dA, nA);
  cout << "message m=" << m << endl;
  cout << "empreinte chiffre ec=" << ec << endl;

  // Bob : verification message
  assert(empreinte(m)==puissance(ec,eA,nA));
  cout << "signature correcte" << endl;
}
