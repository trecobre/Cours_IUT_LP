#include <iostream>
#include <stdlib.h>
#include <unistd.h>

// `BigIntegerLibrary.hh' includes all of the library headers.
#include "BigIntegerLibrary.hh"

using namespace std;

#define TAILLEMIN 1000
#define TAILLEMAX 1000000000

BigInteger puissance (BigInteger a, BigInteger e, BigInteger n)
{
  BigInteger p;
  for(p=1;e>0;e=e/2) {
    if (e % 2 != 0)
      p=(p*a)%n;
    a=(a*a)%n;
  }
  return p;
}

bool test_premier(BigInteger n) // test de Fermat
{
  if ( (puissance(2,n-1,n)==1) &&
       (puissance(3,n-1,n)==1) &&
       (puissance(5,n-1,n)==1) &&
       (puissance(7,n-1,n)==1) &&
       (puissance(11,n-1,n)==1) &&
       (puissance(13,n-1,n)==1) )
    return true; // probablement premier (garantie si n<2^15)
  return false;
}

BigInteger pgcd(BigInteger u, BigInteger v)
{
  BigInteger t;
  while (v!=0) {
    t = u;
    u = v;
    v = t % v;
  }
  return u < 0 ? -u : u; /* abs(u) */
}

BigInteger bezout(BigInteger a, BigInteger b) // calcul p et q tq : p*a+q*b=pgcd(a,b)
{
  // On sauvegarde les valeurs de a et b.
  BigInteger a0 = a;
  BigInteger b0 = b;

  // Initialisations. On laisse invariant p*a0 + q*b0 = a et  r*a0 + s*b0 = b.
  BigInteger p = 1; BigInteger q = 0;
  BigInteger r = 0; BigInteger s = 1;
  BigInteger c,quotient,nouveau_r,nouveau_s;

  // La boucle principale.
  while (b != 0) {
    c = a % b;
    quotient = a/b;
    a = b;
    b = c;
    nouveau_r = p - quotient * r; nouveau_s = q - quotient * s;
    p = r; q = s;
    r = nouveau_r; s = nouveau_s;
  }

  return p; // on n'a besoin que de p
}

BigInteger myrand(BigInteger taille)
{
  int tmp=rand()*rand(); // limite à MAXINT ...
  BigInteger x=tmp;
  return x%(taille-1)+1;
}

int main()
{
  srand(getpid()); // initialisation du generateur aleatoire

  // tirer un nombre premier p
  BigInteger p = myrand(TAILLEMAX)+TAILLEMIN;
  while (!test_premier(p))
    p = myrand(TAILLEMAX)+TAILLEMIN;

  cout << "1 nombre probalement premier : " << p << endl;

  // g un generateur de Zp
  BigInteger g = myrand(p);
  while (pgcd(g,p)!=1)
    g = myrand(p);

  // Alice : generation des cles publique/privee
  BigInteger s = myrand(p);
  cout << "cle secrete Alice : s=" << s << endl;
  BigInteger h = puissance(g,s,p);
  cout << "cle publique Alice : (p,g,h)=" << p << "," << g << "," << h << endl;

  // Bob : chiffrement avec la cle publique d'Alice
  BigInteger m = myrand(p);
  cout << "message en clair : m=" << m << endl;
  BigInteger k = myrand(p);
  BigInteger c1 = puissance(g,k,p);
  BigInteger c2 = m*puissance(h,k,p);
  cout << "message chiffre envoye : (c1,c2)=" << c1 << "," << c2 << endl;

  // Alice : dechiffrement avec sa cle privee
  BigInteger tmp = puissance(c1,s,p);
  cout << "message en clair : m=" << c2/tmp << endl;
}
