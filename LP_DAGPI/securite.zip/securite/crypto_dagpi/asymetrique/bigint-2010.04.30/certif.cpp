#include <iostream>
#include <stdlib.h>
#include <assert.h>
#include <unistd.h>

// `BigIntegerLibrary.hh' includes all of the library headers.
#include "BigIntegerLibrary.hh"

using namespace std;

#define TAILLEMIN 1000
#define TAILLEMAX 1000000000
#define TAILLEEMPREINTE 100

BigInteger puissance (BigInteger a, BigInteger e, BigInteger n)
{
  BigInteger p;
  for(p=1;e>0;e=e/2) {
    if (e % 2 != 0)
      p=(p*a)%n;
    a=(a*a)%n;
  }
  return p;
}

bool test_premier(BigInteger n) // test de Fermat
{
  if ( (puissance(2,n-1,n)==1) &&
       (puissance(3,n-1,n)==1) &&
       (puissance(5,n-1,n)==1) &&
       (puissance(7,n-1,n)==1) &&
       (puissance(11,n-1,n)==1) &&
       (puissance(13,n-1,n)==1) )
    return true; // probablement premier (garantie si n<2^15)
  return false;
}

BigInteger pgcd(BigInteger u, BigInteger v)
{
  BigInteger t;
  while (v!=0) {
    t = u;
    u = v;
    v = t % v;
  }
  return u < 0 ? -u : u; /* abs(u) */
}

BigInteger bezout(BigInteger a, BigInteger b) // calcul p et q tq : p*a+q*b=pgcd(a,b)
{
  // On sauvegarde les valeurs de a et b.
  BigInteger a0 = a;
  BigInteger b0 = b;

  // Initialisations. On laisse invariant p*a0 + q*b0 = a et  r*a0 + s*b0 = b.
  BigInteger p = 1; BigInteger q = 0;
  BigInteger r = 0; BigInteger s = 1;
  BigInteger c,quotient,nouveau_r,nouveau_s;

  // La boucle principale.
  while (b != 0) {
    c = a % b;
    quotient = a/b;
    a = b;
    b = c;
    nouveau_r = p - quotient * r; nouveau_s = q - quotient * s;
    p = r; q = s;
    r = nouveau_r; s = nouveau_s;
  }

  return p; // on n'a besoin que de p
}

BigInteger myrand(BigInteger taille)
{
  int tmp=rand()*rand(); // limite à MAXINT ...
  BigInteger x=tmp;
  return x%(taille-1)+1;
}

BigInteger empreinte(BigInteger x)
{
  return x%13; // empreinte(X)=X%13 !!! (a remplacer par MD5SUM ou SHASUM...)
}

int main()
{
  srand(getpid()); // initialisation du generateur aleatoire

  // Alice : tirer 2 nombres premiers p et q
  BigInteger pA = myrand(TAILLEMAX/TAILLEEMPREINTE)+TAILLEMIN;
  while (!test_premier(pA))
    pA = myrand(TAILLEMAX/TAILLEEMPREINTE)+TAILLEMIN;

  BigInteger qA = myrand(TAILLEMAX/TAILLEEMPREINTE)+TAILLEMIN;
  while (!test_premier(qA))
    qA = myrand(TAILLEMAX/TAILLEEMPREINTE)+TAILLEMIN;

  cout << "2 nombres probalement premiers (p,q) : " << pA << "," << qA << endl;

  BigInteger nA=pA*qA;
  cout << "n=p*q=" << nA << endl;
  BigInteger phiA=(pA-1)*(qA-1); // indicatrice d'Euler
  cout << "phi(n)=" << phiA << endl;

  // Alice : cle publique (e,n)
  BigInteger eA = myrand(nA); // e>0 et e<n
  while (pgcd(eA,phiA)!=1)    // e premier avec phi(n)
    eA = myrand(nA);
  cout << "cle publique Alice e=: " << eA << "," << nA << endl;

  // Alice : cle privee (d,n) inverse de e modulo phi(n)
  BigInteger dA;
  dA=bezout(eA,phiA);
  if (dA<0) dA=dA+phiA; // car d est defini modulo phi(n)
  cout << "cle privee Alice d=: " << dA << "," << nA << endl;

  // CA : tirer 2 nombres premiers p et q
  BigInteger pCA = myrand(TAILLEMAX)+TAILLEMIN;
  while (!test_premier(pCA))
    pCA = myrand(TAILLEMAX)+TAILLEMIN;

  BigInteger qCA = myrand(TAILLEMAX)+TAILLEMIN;
  while (!test_premier(qCA))
    qCA = myrand(TAILLEMAX)+TAILLEMIN;

  cout << "2 nombres probalement premiers (p,q) : " << pCA << "," << qCA << endl;

  BigInteger nCA=pCA*qCA;
  cout << "n=p*q=" << nCA << endl;
  BigInteger phiCA=(pCA-1)*(qCA-1); // indicatrice d'Euler
  cout << "phi(n)=" << phiCA << endl;

  // CA : cle publique (e,n)
  BigInteger eCA = myrand(nCA); // e>0 et e<n
  while (pgcd(eCA,phiCA)!=1)    // e premier avec phi(n)
    eCA = myrand(nCA);
  cout << "cle publique CA e=: " << eCA << "," << nCA << endl;

  // CA : cle privee (d,n) inverse de e modulo phi(n)
  BigInteger dCA;
  dCA=bezout(eCA,phiCA);
  if (dCA<0) dCA=dCA+phiCA; // car d est defini modulo phi(n)
  cout << "cle privee CA d=: " << dCA << "," << nCA << endl;

  cout << "calcul empreinte" << endl;

  // Alice : construire un message contenant sa cle publique et son empreinte
  BigInteger m=eA*TAILLEEMPREINTE+empreinte(eA); // concatenation
  cout << "cle publique Alice + empreinte m=" << m << endl;
  BigInteger c=puissance(m,eCA,nCA); // chiffre m avec cle publique CA
  cout << "message chiffre : " << c << endl;

  // CA : recuperer la cle publique d'Alice et verification
  BigInteger tmp=puissance(c,dCA,nCA);
  BigInteger tmpG=tmp/TAILLEEMPREINTE; // cle publique d'Alice
  BigInteger tmpD=tmp-tmpG*TAILLEEMPREINTE; // l'empreinte associee
  cout << "message dechiffre : " << tmpG << " " << tmpD << endl;
  assert(tmpD==empreinte(tmpD));
  cout << "empreinte correcte" << endl;

  // CA : generation du certificat de la cle publique d'Alice
  cout << "generation certificat" << endl;
  BigInteger cert=puissance(tmpG,dCA,nCA);
  cout << "certificat pour la cle publique d'Alice cert=" << cert << endl;

  // Bob : verification du certificat de la cle publique d'Alice
  assert(eA==puissance(cert,eCA,nCA));
  cout << "certificat correct" << endl;
}
