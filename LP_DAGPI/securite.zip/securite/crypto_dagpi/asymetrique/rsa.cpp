#include <iostream>
#include <stdlib.h>
#include <unistd.h>

using namespace std;

#define TAILLEMIN 1000
#define TAILLEMAX 10000

long puissance (long a, long e, long n)
{
  long p;
  for(p=1;e>0;e=e/2) {
    if (e % 2 != 0)
      p=(p*a)%n;
    a=(a*a)%n;
  }
  return p;
}

bool test_premier(long n) // test de Fermat
{
  if ( (puissance(2,n-1,n)==1) &&
       (puissance(3,n-1,n)==1) &&
       (puissance(5,n-1,n)==1) &&
       (puissance(7,n-1,n)==1) &&
       (puissance(11,n-1,n)==1) &&
       (puissance(13,n-1,n)==1) )
    return true; // probablement premier (garantie si n<2^15)
  return false;
}

long pgcd(long u, long v)
{
  long t;
  while (v) {
    t = u;
    u = v;
    v = t % v;
  }
  return u < 0 ? -u : u; /* abs(u) */
}

long bezout(long a, long b) // calcul p et q tq : p*a+q*b=pgcd(a,b)
{
  // On sauvegarde les valeurs de a et b.
  long a0 = a;
  long b0 = b;

  // Initialisations. On laisse invariant p*a0 + q*b0 = a et  r*a0 + s*b0 = b.
  long p = 1; long q = 0;
  long r = 0; long s = 1;
  long c,quotient,nouveau_r,nouveau_s;

  // La boucle principale.
  while (b != 0) {
    c = a % b;
    quotient = a/b;
    a = b;
    b = c;
    nouveau_r = p - quotient * r; nouveau_s = q - quotient * s;
    p = r; q = s;
    r = nouveau_r; s = nouveau_s;
  }

  return p; // on n'a besoin que de p
}

int main()
{
  srand(getpid());
  cout << puissance(3333,967,4247) << endl;
  cout << puissance(3790,2983,4247) << endl;

  long p = rand()%TAILLEMAX+TAILLEMIN;
  while (!test_premier(p))
    p = rand()%TAILLEMAX+TAILLEMIN;

  long q = rand()%TAILLEMAX+TAILLEMIN;
  while (!test_premier(q))
    q = rand()%TAILLEMAX+TAILLEMIN;

  cout << "2 nombres probalement premiers : " << p << " , " << q << endl;

  long n=p*q;
  cout << "n=p*q=" << n << endl;
  long phi=(p-1)*(q-1); // indicatrice d'Euler
  cout << "phi(n)=" << phi << endl;

  // cle publique : e
  long e = rand()%(phi-1)+1; // e>0 et e<phi(n)
  while (pgcd(e,phi)!=1)   // e premier avec phi(n)
    e = rand()%(phi-1)+1;

  cout << "cle publique : " << e << " , " << n << endl;

  // cle privee : d (inverse de e modulo phi(n))
  long d;
  d=bezout(e,phi);
  if (d<0) d=d+phi; // car d est defini modulo phi(n)
  cout << "cle privee : " << d << " , " << n << endl;

  // chiffrement de m : c=m^e%n avec la cle publique (e,n)
  long m = rand()%(n-1)+1; // m>0 et m<n
  cout << "message en clair m=" << m << endl;
  long c = puissance(m,e,n);
  cout << "message chiffre  c=" << c << endl;

  // dechiffrement de c : m=c^d%n avec la cle privee (d,n)
  m = puissance(c,d,n);
  cout << "message en clair m=" << m << endl;
}
