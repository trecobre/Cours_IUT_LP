# Module Crypto DAGPI

## But du cours

Découverte des notions de sécurité informatique et des principales méthodes de chiffrement.

## Infos sur le cours

- Vous êtes libre du langage de programmation et de l'environnement système à utiliser pour développer les exercices demandés.
- En particulier : `C/C++`, `Java`, et `Python` sont plutôt bien adaptés.
- Des éléments de correction seront donnés en `C/C++` et `Python`.

## Ressources

- Serveur `Discord` (discussions, questions, partage d'écran/audio pour demander une aide individuelle) :https://discord.gg/WFCV7jq
- Dépôt `Gitlab` : https://gitlab-ce.iut.u-bordeaux.fr/Pierre/crypto_dagpi

## Généralités

Quelques notions sur la sécurité informatique en générale.

## Cryptographie symétrique

En particulier :
- chiffrement mono-alphabétique (type Cesar)
- chiffrement poly-alphabétique (type Vigenere)
- réseaux de Feistel

Une feuille d'exercice est disponible dans le sous répertoire correspondant.

### Cesar

On vous demande de casser un chiffrement de type Cesar. Le message `cesar1_chiffre.txt` contient un texte en Français (sans espace et sans ponctuation pour simplifier). Le code `cesar.cpp` permet d'utiliser la clé de chiffrement (ou déchiffrement), 'a' par exemple :

~~~bash
g++ cesar.cpp -o cesar
./cesar cesar1_chiffre.txt a
~~~

A l'aide du code `freq.py` (en Python) qui calcule les fréquences d'apparition des lettres dans le message, déterminez le décalage et donc la clé de déchiffrement qui permet de retrouver le message.

~~~bash
python2 freq.py cesar1_chiffre.txt
~~~

### Vigenere

En utilisant le principe de l'indice de coïncidence, retrouver le message en clair correspondant à `vigenere1_chiffre.txt`. Vous pouvez essayer avec le code 'pouet' par exemple :

~~~bash
g++ vigenere.cpp -o vigenere
./vigenere vigenere1_chiffre.txt pouet
~~~

A l'aide du code `ic.py` :
~~~bash
python2 ic.py vigenere1_chiffre.txt 1
python2 ic.py vigenere1_chiffre.txt 2
python2 ic.py vigenere1_chiffre.txt 3
...
~~~
trouvez la longueur de la clé (sachant que le message est en Français).

Etant donné le code `decoup.py`, vous pouvez extraire les caractères du message en position 'i' (modulo la longueur de la clé) et utiliser la technique de Cesar sur chaque morceaux (fichiers `prt*.txt`) pour retrouver lettre par lettre le code de déchiffrement.

### Feistel

On vous demande d'implémenter en Python (ou en C ou en Java) un réseau de Feistel simple.
Vous fixerez le nombre de rondes et la taille d'un bloc.
Un tableau d'entiers ou bouléens sera utilisé pour stocker les message binaires (plain-text et cypher-text).
La fonction d'encodage pourra être un simple XOR avec le même mot de passe à chaque ronde (le générateur de sous-clés se résume à une fonction identité).

## Cryptographie asymétrique

En particulier :
- `RSA`
- `Diffie-Hellman`
- signatures et certificats

### RSA

On vous demande d'implémenter en Python (ou en C ou en Java) le crypto-système `RSA`.
Vous aurez besoin des fonctions suivantes :
- une fonction qui calcule l'exponentiation modulaire `a^e mod n` (attention vous ne pouvez pas élever directement à la puissance vue la taille des nombres, ne pas utiliser la fonction 'pow') :
~~~C
long puissance (long a, long e, long n)
{
  long p;
  for(p=1;e>0;e=e/2) {
    if (e % 2 != 0)
      p=(p*a)%n;
    a=(a*a)%n;
  }
  return p;
}
~~~
- une fonction qui vérifie si un nombre donné est pseudo-premier (algorithme donné dans la copie d'écran `primalite.png`) :
~~~C
bool test_premier(long n) // test de Fermat
{
  if ( (puissance(2,n-1,n)==1) &&
       (puissance(3,n-1,n)==1) &&
       (puissance(5,n-1,n)==1) &&
       (puissance(7,n-1,n)==1) &&
       (puissance(11,n-1,n)==1) &&
       (puissance(13,n-1,n)==1) )
    return true; // probablement premier (garantie si n<2^15)
  return false;
}
~~~
- une fonction qui calcule le `pgcd(a,b)`:
~~~C
long pgcd(long u, long v)
{
  long t;
  while (v) {
    t = u;
    u = v;
    v = t % v;
  }
  return u < 0 ? -u : u;
}
~~~
- une fonction Bezout pour trouver `d` tel que `e.d = 1 mod phi(n)`. Vous avez un code en HTML pour tester.
Etant donnés 2 nombres `a` et `b`, Bezout permet de calculer `p` et `q` tel que `p.a + q.b = pgcd(a,b)`. Attention `p`et `q` sont des entiers relatifs !
~~~C
long bezout(long a, long b)
{
  // On sauvegarde les valeurs de a et b.
  long a0 = a;
  long b0 = b;

  // On laisse invariant p*a0 + q*b0 = a et  r*a0 + s*b0 = b.
  long p = 1; long q = 0;
  long r = 0; long s = 1;
  long c,quotient,nouveau_r,nouveau_s;

  // La boucle principale.
  while (b != 0) {
    c = a % b;
    quotient = a/b;
    a = b;
    b = c;
    nouveau_r = p - quotient * r; nouveau_s = q - quotient * s;
    p = r; q = s;
    r = nouveau_r; s = nouveau_s;
  }

  return p; // on n'a besoin que de p
}
~~~
Sachant qu'on a choisit `e` tel que `pgcd(e,phi(n))=1`, en calculant `bezout(e,phi(n))`, on récupère `d` tel que `d.e = pgcd(e,phi(n)) + k.phi(n) = 1 mod phi(n)`.

Vous pouvez tester avec l'exemple donné dans le support de cours.

A l'aide d'une bibliothèque manipulant des entiers de grande taille (> 32bit ou 64bit), comme `BigInteger` en Java, modifiez votre code pour générer des clés asymétriques de plus grande taille et testez sur des messages plus longs.

### Diffie-Hellman

Avec les mêmes fonctions, on vous demande d'écrire le protocole `Diffie-Hellman` permettant de générer un secret entre 2 interlocuteurs sur un réseau non fiable. On fixe deux nombres `g` et `p` connus de tous, et Alice (resp. Bob) génère un nombre aléatoire `a` (resp. `b`) qui ne sont jamais communiqués sur le réseau.

### Signature et certificats

Toujours avec les mêmes fonctions, on retourne le chiffrement asymétrique afin de signer une information de manière numérique. On vous demande d'implémenter cette méthode en signant un message donné (ici un nombre de grande taille pour simplifier). On utilisera une fonction simple pour calculer une empreinte du message à envoyer.


Etendre cette implémentation pour générer un certificat pour la clé publique d'Alice signée par une autorité de certification (CA) disposant également d'une paire de clés asymétriques avec la séquence suivante :

~~~C
  // Alice : tire 2 nombres premiers pA et qA, nA=pA*qA
  // Alice : clé publique (eA,nA)
  // Alice : clé privée (dA,nA)

  // CA : tire 2 nombres premiers pCA et qCA, nCA=pCA*qCA
  // CA : clé publique (eCA,nCA)
  // CA : clé privée (dCA,nCA)

  // Alice : construire un message contenant sa clé publique et son empreinte
  // (elle signe en chiffrant l'empreinte avec sa clé privée)
  // (elle communique de manière confidentielle avec CA, en chiffrant avec la clé publique de CA)

  // CA : récupère la clé publique d'Alice et vérifie l'empreinte
  // CA : génère le certificat de la clé publique d'Alice
  // (chiffrement de la clé publique d'Alice avec la clé privée de CA)

  // Bob : vérifie le certificat d'Alice
  // (la clé publique d'Alice doit correspondre au déchiffrement du certificat avec la clé publique de CA)
~~~
