#include "menuwindow.h"
#include "ui_menuwindow.h"
#include "settingswindow.h"
#include <QKeyEvent>

MenuWindow::MenuWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MenuWindow)
{
    ui->setupUi(this);
    ui->anarchyLabel->setHidden(true);
    initKonami();
    connect(ui->startButton, &QPushButton::released, this, &MenuWindow::btnDemarrerAction);
    connect(ui->settingsButton, &QPushButton::released, this, &MenuWindow::btnSettingsAction);
}

MenuWindow::~MenuWindow()
{
    delete ui;
}

bool MenuWindow::getJ1isIA() const
{
    return j1isIA;
}

bool MenuWindow::getJ2isIA() const
{
    return j2isIA;
}

bool MenuWindow::getIsTimer() const
{
    return isTimer;
}

int MenuWindow::getTimerDuree() const
{
    return duree;
}

bool MenuWindow::getIsDemarrer() const
{
    return isDemarrer;
}

int MenuWindow::getIAdelay() const{
    return IAdelay;
}

bool MenuWindow::getKonami() const{
    return isKonami;
}

bool MenuWindow::getJ1isStockfish() const
{
    return j1isStockfish;
}

bool MenuWindow::getJ2isStockfish() const
{
    return j2isStockfish;
}

int MenuWindow::getIABlancLvl() const
{
    return lvlIABlanc;
}

int MenuWindow::getIANoirLvl() const
{
    return lvlIANoir;
}

void MenuWindow::btnDemarrerAction(){
    this->isDemarrer = true;
    close();
}

void MenuWindow::btnSettingsAction(){
    SettingsWindow sw;
    sw.setDefaultValue(j1isIA, j2isIA, j1isStockfish, j2isStockfish, isTimer, IAdelay, duree);
    int result = sw.exec();
    if(result == 1){
        j1isIA = sw.getIAj1();
        j2isIA = sw.getIAj2();
        j1isStockfish = sw.getStockfishIAj1();
        j2isStockfish = sw.getStockfishIAj2();
        lvlIABlanc = sw.getLvlIABlanc();
        lvlIANoir = sw.getLvlIANoir();
        IAdelay = sw.getIAdelay();
        duree = sw.getTimer();
        isTimer = sw.getIsTimer();
    }

}

void MenuWindow::initKonami(){
    konamiMap[0] = std::make_pair(Qt::Key_Up, false);
    konamiMap[1] = std::make_pair(Qt::Key_Up, false);
    konamiMap[2] = std::make_pair(Qt::Key_Down, false);
    konamiMap[3] = std::make_pair(Qt::Key_Down, false);
    konamiMap[4] = std::make_pair(Qt::Key_Left, false);
    konamiMap[5] = std::make_pair(Qt::Key_Right, false);
    konamiMap[6] = std::make_pair(Qt::Key_Left, false);
    konamiMap[7] = std::make_pair(Qt::Key_Right, false);
    konamiMap[8] = std::make_pair(Qt::Key_B, false);
    konamiMap[9] = std::make_pair(Qt::Key_A, false);
    konamiMap[10] = std::make_pair(Qt::Key_Return, false);
}

void MenuWindow::keyPressEvent(QKeyEvent *event)
{
    std::map<int, std::pair<Qt::Key, bool>>::iterator it;
    bool validate = true;
    int last = -1;
    for(it = konamiMap.begin(); it != konamiMap.end(); it++){
        if(!it->second.second && event->key() == it->second.first){
            it->second.second = true;
            last = it->first;
            break;
        }
        else if(!it->second.second && event->key() != it->second.first){
            validate = false;
            break;
        }
    }
    if(!validate){
        initKonami();
    }
    if(last == 10){
        isKonami = true;
        ui->anarchyLabel->setHidden(false);
        QFont font = ui->anarchyLabel->font();
        font.setPointSize(60);
        ui->titleLabel->setFont(font);

        QPalette palette(Qt::red);
        setPalette(palette);

        font.setPointSize(ui->startButton->font().pointSize());
        ui->startButton->setFont(font);

        ui->startButton->setStyleSheet("border:none;");
        ui->settingsButton->setStyleSheet("border:none;");
    }
}

void MenuWindow::showEvent(QShowEvent *)
{
    initKonami();
    isDemarrer = false;
}

