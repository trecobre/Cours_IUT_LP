#ifndef STOCKFISH_H
#define STOCKFISH_H

#include <QObject>
#include <QProcess>

class Stockfish : public QObject
{
    Q_OBJECT
public:
    explicit Stockfish(int skillLevel, QObject *parent = nullptr);

    ~Stockfish();

    /**
     * @brief Lancer le calcul du mouvement à faire en fonction de l'état de l'échiquier.
     * Le résultat sera transmis via le signal moveFound
     * @param fen : La chaine FEN représentant l'état de l'échiquier
     * @param depth : Profondeur de recherche : plus elle est élevée, plus le mouvement sera bon
     */
    void calcMove(QString fen, int depth);
    void setLevel(int lvl);

signals:
    /**
     * @brief Emis quand Stockfish trouve un mouvement
     * @param Paire de 2 paires d'entiers : coordonnées de départ et d'arrivée
     */
    void moveFound(std::pair<std::pair<int, int>, std::pair<int, int>> move);

private:
    QProcess m_process;
    QString m_program;

    bool initialized = false;
    int m_skillLevel;

private slots:
    void read();
    void started();
};

#endif // STOCKFISH_H
