#include "jeu.h"

Jeu::Jeu() : iaBlanc(&joueurBlanc, 1), iaNoir(&joueurNoir, 20)
{
    joueurBlanc.placerPieces(echiquier);
    joueurNoir.placerPieces(echiquier);

    connect(&joueurBlanc, &Joueur::timerFini, this, &Jeu::joueurTimeout);
    connect(&joueurNoir, &Joueur::timerFini, this, &Jeu::joueurTimeout);
}

Echiquier &Jeu::getEchiquier()
{
    return echiquier;
}

JoueurNoir &Jeu::getJoueurNoir()
{
    return joueurNoir;
}

JoueurBlanc &Jeu::getJoueurBlanc()
{
    return joueurBlanc;
}

bool Jeu::prochainJoueur()
{
    if (joueurActif && timersEnabled)
    {
        joueurActif->stopTimer();
    }

    if (!joueurActif || joueurActif == &joueurNoir)
    {
        joueurActif = &joueurBlanc;
    }
    else
    {
        joueurActif = &joueurNoir;
    }

    if (timersEnabled)
    {
        joueurActif->startTimer();
    }

    bool ret = !joueurActif->isEchecEtMat(echiquier, joueurActif == &joueurBlanc ? dynamic_cast<Joueur&>(joueurNoir) : dynamic_cast<Joueur&>(joueurBlanc));

    if (!ret)
    {
        isFini = true;

        joueurBlanc.stopTimer();
        joueurNoir.stopTimer();
    }

    return ret;
}

Joueur *Jeu::getJoueurActif() const
{
    return joueurActif;
}

void Jeu::joueurTimeout(Joueur* joueur)
{
    joueurBlanc.stopTimer();
    joueurNoir.stopTimer();

    isFini = true;

    emit jeuFini(joueur->isWhite() ? &joueurNoir : &dynamic_cast<Joueur&>(joueurBlanc), joueur);
}

bool Jeu::getIsFini() const
{
    return isFini;
}

QString Jeu::getFEN()
{
    QString output = echiquier.FEN();

    output += ' ';

    output += joueurActif->isWhite() ? 'w' : 'b';

    output += ' ';

    Piece* tourWQ = echiquier.getPiece(1, 1);
    Piece* tourWK = echiquier.getPiece(8, 1);
    Piece* tourBQ = echiquier.getPiece(1, 8);
    Piece* tourBK = echiquier.getPiece(8, 8);
    Piece* roiW = echiquier.getPiece(5, 1);
    Piece* roiB = echiquier.getPiece(5, 8);

    const bool wRoqueQ = tourWQ && tourWQ->FEN() == 'R' && tourWQ->getMove() == 0 && roiW && roiW->FEN() == 'K' && roiW->getMove() == 0;
    const bool wRoqueK = tourWK && tourWK->FEN() == 'R' && tourWK->getMove() == 0 && roiW && roiW->FEN() == 'K' && roiW->getMove() == 0;

    const bool bRoqueQ = tourBQ && tourBQ->FEN() == 'R' && tourBQ->getMove() == 0 && roiB && roiB->FEN() == 'K' && roiB->getMove() == 0;
    const bool bRoqueK = tourBK && tourBK->FEN() == 'R' && tourBK->getMove() == 0 && roiB && roiB->FEN() == 'K' && roiB->getMove() == 0;

    if (wRoqueK) output += 'K';
    if (wRoqueQ) output += 'Q';
    if (bRoqueK) output += 'k';
    if (bRoqueQ) output += 'q';
    if (!wRoqueK && !wRoqueQ && !bRoqueK && !bRoqueQ) output += '-';

    output += " -"; // En passant, non géré atm
    output += " 0 1"; // Regle des 50 coups, non gérée atm

    return output;
}

IA* Jeu::getIA(bool isWhite)
{
    return isWhite ? &iaBlanc : &iaNoir;
}

void Jeu::promotionPiece(Piece * p, Piece::PiecePromotion piecePromo){
    int x = p->x();
    int y = p->y();
    this->echiquier.promouvoirPiece(p, piecePromo, false);
    this->joueurActif->changerPiece(p, this->echiquier.getPiece(x, y));
}

void Jeu::promotionPiece(Piece * p, Piece::PiecePromotion piecePromo, bool isKonami){
    int x = p->x();
    int y = p->y();
    Joueur* joueur;
    if(p->isWhite()){
        joueur = &joueurBlanc;
    }
    else{
        joueur = &joueurNoir;
    }
    this->echiquier.promouvoirPiece(p, piecePromo, isKonami);
    joueur->changerPiece(p, this->echiquier.getPiece(x, y));
}
