#include "settingswindow.h"
#include <QPushButton>
#include "ui_settingswindow.h"
#include <QSizePolicy>

SettingsWindow::SettingsWindow(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::SettingsWindow)
{
    ui->setupUi(this);
    setFixedSize(size());
    connect(ui->j1_checkbox, &QCheckBox::clicked, this, &SettingsWindow::changeLabelJ1Checkbox);
    connect(ui->j2_checkbox, &QCheckBox::clicked, this, &SettingsWindow::changeLabelJ2Checkbox);
    connect(ui->j1_avanceCheckbox, &QCheckBox::clicked, this, &SettingsWindow::changeIAAdvanced1Parameter);
    connect(ui->j2_avanceCheckbox, &QCheckBox::clicked, this, &SettingsWindow::changeIAAdvanced2Parameter);
    connect(ui->timer_checkbox, &QCheckBox::clicked, this, &SettingsWindow::changeStateDureeSpinBox);
}

SettingsWindow::~SettingsWindow()
{
    delete ui;
}


bool SettingsWindow::getIAj1(){
    return ui->j1_checkbox->isChecked();
}

bool SettingsWindow::getStockfishIAj2()
{
    return ui->j2_avanceCheckbox->isChecked();
}

bool SettingsWindow::getStockfishIAj1()
{
    return ui->j1_avanceCheckbox->isChecked();
}

bool SettingsWindow::getIAj2(){
    return ui->j2_checkbox->isChecked();
}

int SettingsWindow::getIAdelay(){
    return ui->IAdelaySpinBox->value()*1000;
}

bool SettingsWindow::getIsTimer(){
    return ui->timer_checkbox->isChecked();
}

int SettingsWindow::getTimer(){
    return ui->dureeSpinBox->value();
}

int SettingsWindow::getLvlIABlanc(){
    return ui->spinBoxIAAvancee1->value();
}

int SettingsWindow::getLvlIANoir(){
    return ui->spinBoxIAAvancee2->value();
}

void SettingsWindow::setDefaultValue(bool isIAj1, bool isIAj2, bool isj1Stockfish, bool isj2Stockfish, bool isTimer, int IAdelay, int duree){
    ui->j1_checkbox->setChecked(isIAj1);
    ui->j2_checkbox->setChecked(isIAj2);
    ui->j1_avanceCheckbox->setChecked(isj1Stockfish);
    ui->j2_avanceCheckbox->setChecked(isj2Stockfish);
    ui->timer_checkbox->setChecked(isTimer);
    changeLabelJ1Checkbox();
    changeLabelJ2Checkbox();
    ui->IAdelaySpinBox->setValue(IAdelay/1000);
    ui->dureeSpinBox->setValue(duree);
}

void SettingsWindow::changeLabelJ1Checkbox(){
    QString text = ui->j1_checkbox->isChecked() ? "Le joueur blanc est joué par l'IA." : "Le joueur blanc est joué par un humain.";
    ui->j1_avanceCheckbox->setEnabled(ui->j1_checkbox->isChecked());
    ui->j1_checkbox->setText(text);
    changeStateIADelaySpinBox();
}

void SettingsWindow::changeLabelJ2Checkbox(){
    QString text = ui->j2_checkbox->isChecked() ? "Le joueur noir est joué par l'IA." : "Le joueur noir est joué par un humain.";
    ui->j2_avanceCheckbox->setEnabled(ui->j2_checkbox->isChecked());
    ui->j2_checkbox->setText(text);
    changeStateIADelaySpinBox();
}

void SettingsWindow::changeStateDureeSpinBox(){
    ui->dureeSpinBox->setEnabled(ui->timer_checkbox->isChecked());
    ui->label_2->setEnabled(ui->timer_checkbox->isChecked());
}

void SettingsWindow::changeStateIADelaySpinBox(){
    bool isEnabled = ui->j1_checkbox->isChecked() || ui->j2_checkbox->isChecked();
    ui->IAdelaySpinBox->setEnabled(isEnabled);
    ui->label->setEnabled(isEnabled);
}

void SettingsWindow::changeIAAdvanced1Parameter(){
    bool isEnabled = ui->j1_avanceCheckbox->isChecked();
    ui->spinBoxIAAvancee1->setEnabled(isEnabled);
    ui->label_3->setEnabled(isEnabled);
}

void SettingsWindow::changeIAAdvanced2Parameter(){
    bool isEnabled = ui->j2_avanceCheckbox->isChecked();
    ui->spinBoxIAAvancee2->setEnabled(isEnabled);
    ui->label_4->setEnabled(isEnabled);
}
