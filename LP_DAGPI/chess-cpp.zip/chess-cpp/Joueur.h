/**
 * Header de Joueur.cxx
 *
 * @file Joueur.h
 */

#if !defined Joueur_h
#define Joueur_h

#include <vector>
#include "Piece.h"
#include "Echiquier.h"
#include <memory>
#include <vector>
#include <QTimer>

using namespace std;
class Joueur : public QObject
{
    Q_OBJECT
protected:
    vector<unique_ptr<Piece>> m_pieces;
    Roi* getRoi();

    int m_tempsRestant = 60000; // Temps en 1/100 de sec
    QTimer m_timer;
    bool isIA = false;

    friend class TestChess;

private slots:
    void timerTick();

signals:
    void tempsRestantChanged(Joueur* source);
    void timerFini(Joueur* source);

public:
    Joueur();
    virtual ~Joueur();
    void         placerPieces( Echiquier &e );
    void         affiche();
    virtual bool isWhite() = 0;  // methode virtuelle pure -> classe abstraite
    bool isEchec(Echiquier& e, Joueur& adversaire);
    bool isEchecEtMat(Echiquier& e, Joueur& adversaire);
    void changerPiece(Piece* anciennePiece, Piece* nouvellePiece);

    void setTimerDuree(int duree);

    void startTimer();
    void stopTimer();

    int getTempsRestant() const;
    int getTimeRestantCent() const;

    /**
     * @brief Retourne un vector de pairs d'entiers correspondants aux coordonnées de tous les mouvements possibles par ce joueur.
     * @return Une liste de paires d'entiers où le premier élément est x, le deuxième est y
     */
    vector<std::tuple<Piece*, int, int>> getMouvementsValides(Echiquier& e);
    bool getIsIA() const;
    void setIsIA(bool newIsIA);
};

class JoueurBlanc : public Joueur
{
public:
    JoueurBlanc();
    bool isWhite();
};

class JoueurNoir : public Joueur
{
public:
    JoueurNoir();
    bool isWhite();
};

#endif
