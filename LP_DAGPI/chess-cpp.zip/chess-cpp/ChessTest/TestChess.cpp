#include <QTest>
#include "../Piece.h"
#include "../jeu.h"
#include "../Joueur.h"

class TestChess : public QObject
{
    Q_OBJECT
private slots:
    void pieces();
    void jeu();
    void joueur();
    void echiquier();
    void mouvements();
};

/**
 * @brief Test général des pièces : couleurs et positions
 */
void TestChess::pieces()
{
    qInfo() << "Test Pion";

    Pion pionB(true, 1);
    Pion pionN(false, 3);

    QVERIFY(pionB.isWhite());
    QVERIFY(pionN.isBlack());

    QVERIFY(pionB.x() == 1);
    QVERIFY(pionB.y() == 2);
    QVERIFY(pionN.x() == 3);
    QVERIFY(pionN.y() == 7);

    qInfo() << "Test Tour";

    Tour tourB(true, true);
    Tour tourN(false, false);

    QVERIFY(tourB.isWhite());
    QVERIFY(tourN.isBlack());

    QVERIFY(tourB.x() == 1);
    QVERIFY(tourB.y() == 1);
    QVERIFY(tourN.x() == 8);
    QVERIFY(tourN.y() == 8);

    qInfo() << "Test Cavalier";

    Cavalier cavalierB(true, true);
    Cavalier cavalierN(false, false);

    QVERIFY(cavalierB.isWhite());
    QVERIFY(cavalierN.isBlack());

    QVERIFY(cavalierB.x() == 2);
    QVERIFY(cavalierB.y() == 1);
    QVERIFY(cavalierN.x() == 7);
    QVERIFY(cavalierN.y() == 8);

    qInfo() << "Test Fou";

    Fou fouB(true, true);
    Fou fouN(false, false);

    QVERIFY(fouB.isWhite());
    QVERIFY(fouN.isBlack());

    QVERIFY(fouB.x() == 3);
    QVERIFY(fouB.y() == 1);
    QVERIFY(fouN.x() == 6);
    QVERIFY(fouN.y() == 8);

    qInfo() << "Test Reine";

    Reine reineB(true);
    Reine reineN(false);

    QVERIFY(reineB.isWhite());
    QVERIFY(reineN.isBlack());

    QVERIFY(reineB.x() == 4);
    QVERIFY(reineB.y() == 1);
    QVERIFY(reineN.x() == 4);
    QVERIFY(reineN.y() == 8);

    qInfo() << "Test Roi";

    Roi roiB(true);
    Roi roiN(false);

    QVERIFY(roiB.isWhite());
    QVERIFY(roiN.isBlack());

    QVERIFY(roiB.x() == 5);
    QVERIFY(roiB.y() == 1);
    QVERIFY(roiN.x() == 5);
    QVERIFY(roiN.y() == 8);
}

/**
 * @brief Test de la classe Jeu
 */
void TestChess::jeu()
{
    qInfo() << "Test Jeu";

    Jeu jeu;

    // Vérifier que les joueurs ont bien été créés
    QVERIFY(&jeu.getJoueurBlanc());
    QVERIFY(&jeu.getJoueurNoir());

    // A l'instanciantion, il ne doit pas encore y avoir de joueur actif
    QVERIFY(!jeu.getJoueurActif());

    // On doit pouvoir passer au joueur suivant pour démarrer la partie
    QVERIFY(jeu.prochainJoueur());

    QVERIFY(jeu.getJoueurActif() == &jeu.getJoueurBlanc());

    QVERIFY(jeu.prochainJoueur());

    QVERIFY(jeu.getJoueurActif() == &jeu.getJoueurNoir());
}

/**
 * @brief Test de la classe Joueur
 */
void TestChess::joueur()
{
    qInfo() << "Test Joueur";

    JoueurBlanc jb;
    JoueurNoir jn;

    QVERIFY(jb.isWhite());
    QVERIFY(!jn.isWhite());

    QVERIFY(jb.m_pieces.size() == 16);
    QVERIFY(jn.m_pieces.size() == 16);

    Echiquier e;
    jb.placerPieces(e);
    jn.placerPieces(e);

    // Vérifier que les pièces ont bien été placées
    // On se contentera de vérifier la présence des rois

    QVERIFY(dynamic_cast<Roi*>(e.getPiece(5, 1)));
    QVERIFY(dynamic_cast<Roi*>(e.getPiece(5, 8)));
}

/**
 * @brief Test de la classe Echiquier
 */
void TestChess::echiquier()
{
    qInfo() << "Test Echiquier";

    Echiquier e;

    for (int i=0; i<64; i++)
    {
        QVERIFY(e.m_cases[i] == nullptr);
    }

    Roi roi(true);

    QVERIFY(e.placer(&roi));

    QVERIFY(e.getPiece(5, 1) == &roi);

    QVERIFY(e.deplacer(&roi, 6, 2));

    QVERIFY(e.getPiece(6, 2) == &roi);

    QVERIFY(e.getRoi(true) == &roi);

    QVERIFY(e.enleverPiece(6, 2) == &roi);

    QVERIFY(e.getPiece(6, 2) == nullptr);
}

/**
 * @brief Test de la validité des mouvements des pièces
 */
void TestChess::mouvements()
{
    {
        qInfo() << "Test mouvements Pion";

        Echiquier e;
        Pion p(true, 1);

        e.placer(&p);
        QVERIFY(p.getMouvementsValides(e).size() == 2);
        QVERIFY(p.mouvementValide(e, 1, 3));
        QVERIFY(p.mouvementValide(e, 1, 4));
    }

    {
        qInfo() << "Test mouvements Tour";

        Echiquier e;
        Tour p(true, true);

        e.placer(&p);
        QVERIFY(p.getMouvementsValides(e).size() == 14);
        QVERIFY(p.mouvementValide(e, 1, 8));
        QVERIFY(p.mouvementValide(e, 8, 1));
    }

    {
        qInfo() << "Test mouvements Cavalier";

        Echiquier e;
        Cavalier p(true, true);

        e.placer(&p);
        QVERIFY(p.getMouvementsValides(e).size() == 3);
        QVERIFY(p.mouvementValide(e, 1, 3));
        QVERIFY(p.mouvementValide(e, 3, 3));
        QVERIFY(p.mouvementValide(e, 4, 2));
    }

    {
        qInfo() << "Test mouvements Fou";

        Echiquier e;
        Fou p(true, true);

        e.placer(&p);
        QVERIFY(p.getMouvementsValides(e).size() == 7);
        QVERIFY(p.mouvementValide(e, 1, 3));
        QVERIFY(p.mouvementValide(e, 8, 6));
    }

    {
        qInfo() << "Test mouvements Reine";

        Echiquier e;
        Reine p(true);

        e.placer(&p);
        QVERIFY(p.getMouvementsValides(e).size() == 21);
        QVERIFY(p.mouvementValide(e, 1, 1));
        QVERIFY(p.mouvementValide(e, 8, 1));
        QVERIFY(p.mouvementValide(e, 4, 8));
        QVERIFY(p.mouvementValide(e, 1, 4));
        QVERIFY(p.mouvementValide(e, 8, 5));
        QVERIFY(p.mouvementValide(e, 4, 8));
    }

    {
        qInfo() << "Test mouvements Roi";

        Echiquier e;
        Roi p(true);

        e.placer(&p);
        QVERIFY(p.getMouvementsValides(e).size() == 5);
        QVERIFY(p.mouvementValide(e, 4, 1));
        QVERIFY(p.mouvementValide(e, 6, 1));
        QVERIFY(p.mouvementValide(e, 4, 2));
        QVERIFY(p.mouvementValide(e, 5, 2));
        QVERIFY(p.mouvementValide(e, 6, 2));
    }
}

QTEST_MAIN(TestChess)
#include "TestChess.moc"
