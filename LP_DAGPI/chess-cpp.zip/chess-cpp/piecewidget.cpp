#include "piecewidget.h"
#include "ui_piecewidget.h"

PieceWidget::PieceWidget(int x, int y, bool isWhite, QWidget *parent) :
    QWidget(parent),
    ui(new Ui::PieceWidget),
    m_x(x),
    m_y(y),
    isWhite(isWhite)
{
    ui->setupUi(this);

    setHighlighted(false);
}

PieceWidget::~PieceWidget()
{
    delete ui;
}

void PieceWidget::setPiece(Piece *piece)
{
    m_piece = piece;

    if (m_piece)
    {
        QChar pieceChar(m_piece->display());
        QString pieceDisplay = pieceChar.isUpper() ? pieceChar.toLower() + 'b' : pieceChar + 'n';

        ui->frame->setStyleSheet("image: url(:/images/resources/" + pieceDisplay + ".png);");
    }
    else
    {
        ui->frame->setStyleSheet("");
    }
}

Piece *PieceWidget::getPiece() const
{
    return m_piece;
}

int PieceWidget::x()
{
    return m_x;
}

int PieceWidget::y()
{
    return m_y;
}

void PieceWidget::setHighlighted(bool highlight)
{
    if (highlight || isEchec)
    {
        QString color = isEchec ? "rgb(180, 50, 50)" : "rgb(50, 180, 50)";
        setStyleSheet("background-color: " + color + ";");
    }
    else
    {
        QString color = isWhite ? "white" : "rgb(105, 105, 105)";
        setStyleSheet("background-color: " + color + ";");
    }
}

void PieceWidget::setIsEchec(bool newIsEchec)
{
    isEchec = newIsEchec;

    setHighlighted(isEchec);
}

void PieceWidget::mousePressEvent(QMouseEvent *)
{
    emit clicked(this);
}
