#ifndef PIECEWIDGET_H
#define PIECEWIDGET_H

#include <QWidget>
#include "Piece.h"

namespace Ui {
class PieceWidget;
}

class PieceWidget : public QWidget
{
    Q_OBJECT

public:
    explicit PieceWidget(int x, int y, bool isWhite, QWidget *parent = nullptr);
    ~PieceWidget();

    void setPiece(Piece* piece);
    Piece* getPiece() const;

    int x();
    int y();

    void setHighlighted(bool highlight);

    void setIsEchec(bool newIsEchec);

private:
    Ui::PieceWidget *ui;
    Piece* m_piece = nullptr;
    int m_x, m_y;

    bool isWhite;
    bool highlighted = false;
    bool isEchec = false;

signals:
    void clicked(PieceWidget* source);

protected:
    void mousePressEvent(QMouseEvent* event);
};

#endif // PIECEWIDGET_H
