/**
 * Mise en oeuvre de Echiquier.h
 *
 * @file Echiquier.cxx
 */

#include <iostream>
#include <assert.h>
// A besoin de la declaration de la classe
#include "Echiquier.h"
#include <QDebug>
#include "Utils.h"

using namespace std;

/**
 * Constructeur par defaut.
 * Initialise a vide l'echiquier.
 */
Echiquier::Echiquier()
{
    for ( int i = 0; i < 64; i++ )
        m_cases[i] = nullptr;
}

/**
 * Recupere la piece situee sur une case.
 *
 * @param x un entier entre 1 et 8
 * @param y un entier entre 1 et 8
 *
 * @return nullptr si aucune piece n'est sur cette case et un pointeur
 * vers une piece sinon.
 */
Piece* Echiquier::getPiece( int x, int y ) const
{
    assert( x >= 1 && x <= 8 && y >= 1 && y <= 8 );
    return m_cases[( x - 1 ) + 8 * ( y - 1 )];
}

const Roi *Echiquier::getRoi(bool isWhite) const
{
    for (const auto& piece : m_cases)
    {
        if (const auto* roi = dynamic_cast<Roi*>(&*piece); roi && roi->isWhite() == isWhite)
        {
            return roi;
        }
    }

    return nullptr;
}

/**
 * Place une piece sur l'echiquier, aux coordonnees specifiees dans la piece.
 *
 * @param p un pointeur vers une piece
 *
 * @return 'true' si le placement s'est bien passe, 'false' sinon
 * (case occupee, coordonnees invalides, piece vide )
 */
bool
Echiquier::placer( Piece *p )
{
    if (p==nullptr)
        return false;
    assert( p->x() >= 1 && p->x() <= 8 && p->y() >= 1 && p->y() <= 8 );
    int i = ( ( *p ).x() - 1 ) + 8 * ( p->y() - 1 );
    if (m_cases[i] != nullptr)
        return false;
    m_cases[i] = p;
    return true;
}

/**
 * Deplace une piece sur l'echiquier, des coordonnees specifiees
 * dans la piece aux coordonnees x,y.
 *
 * @param p un pointeur vers une piece
 * @param x un entier entre 1 et 8
 * @param y un entier entre 1 et 8
 *
 * @return 'true' si le placement s'est bien passe, 'false' sinon
 * (case occupee, coordonnees invalides, piece vide, piece pas
 * presente au bon endroit sur l'echiquier)
 */
bool
Echiquier::deplacer( Piece *p, int x, int y, bool incrementMoveCount )
{
    bool coordsValides = x >= 1 && x <= 8 && y >= 1 && y <= 8;
    assert(coordsValides);

    if (const Piece* targetPiece = getPiece(x, y); (targetPiece && targetPiece->isWhite() == p->isWhite()) || !p || !coordsValides)
    {
        return false;
    }
    if(incrementMoveCount){
        if (auto* roi = dynamic_cast<Roi*>(&*p); roi)
        {
            if(roi->getMove() == 0){
                if(x == 7){
                    roi->roque(*this, false);
                }
                if(x == 3){
                    roi->roque(*this, true);
                }
            }
        }
    }
    enleverPiece(p->x(), p->y());
    enleverPiece(x, y);
    p->move(x, y, incrementMoveCount);
    return placer(p);
}

bool Echiquier::piecePromotable(Piece *p){
    Pion* piece = dynamic_cast<Pion*>(p);
    return piece && ((piece->isWhite() && piece->y()==8) || (piece->isBlack() && piece->y()==1));
}

void Echiquier::promouvoirPiece(Piece *p, Piece::PiecePromotion promo, bool konami){
    if (konami || this->piecePromotable(p)){
        this->enleverPiece(p->x(), p->y());
        Pion* piece = dynamic_cast<Pion*>(p);
        p = piece->promotion(promo);
        this->placer(p);
    }
}

/**
 * Enleve la piece situee sur une case (qui devient vide).
 *
 * @param x un entier entre 1 et 8
 * @param y un entier entre 1 et 8
 *
 * @return nullptr si aucune piece n'est sur cette case et le pointeur
 * vers la piece enlevee sinon.
 */
Piece *
Echiquier::enleverPiece( int x, int y )
{
    assert(x >= 1 && x <= 8 && y >= 1 && y <= 8);

    const int index = ( x - 1 ) + 8 * ( y - 1 );
    Piece* p = m_cases[index];

    m_cases[index] = nullptr;

    return p;
}

/**
 * Affiche l'echiquier avec des # pour les cases noires et . pour
 * les blanches si elles sont vides, et avec B pour les pieces
 * blanches et N pour les pieces noires.
 */
void Echiquier::affiche() const
{
    Utils::cout()  << "  ABCDEFGH" << Utils::endl();
    for ( int y = 8; y > 0; y-- ) {
        Utils::cout() << y << " ";
        for ( int x = 1; x <= 8; ++x ) {
            char   c;
            Piece *p = getPiece( x, y );
            if ( p == nullptr )
                c = ( ( x + y ) % 2 ) == 0 ? '#' : '.';
            else
                c = p->display();
            Utils::cout() << c;
        }
        Utils::cout() << " " << y << Utils::endl();
    }
    Utils::cout() << "  ABCDEFGH" << Utils::endl();
}

QString Echiquier::FEN() const
{
    QString output = "";
    int emptyCounter = 0;

    for (int y=8; y>=1; y--)
    {
        for (int x=1; x<=8; x++)
        {
            if (auto* p = getPiece(x, y))
            {
                if (emptyCounter > 0)
                {
                    output += QString::number(emptyCounter);
                    emptyCounter = 0;
                }

                output += p->FEN();
            }
            else
            {
                emptyCounter++;
            }
        }

        if (emptyCounter > 0)
        {
            output += QString::number(emptyCounter);
            emptyCounter = 0;
        }

        if (y != 1)
        {
            output += "/";
        }
    }

    return output;
}
