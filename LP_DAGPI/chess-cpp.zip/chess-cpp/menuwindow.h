#ifndef MENUWINDOW_H
#define MENUWINDOW_H

#include <QMainWindow>

namespace Ui {
class MenuWindow;
}

class MenuWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MenuWindow(QWidget *parent = nullptr);
    ~MenuWindow();
    bool getJ1isIA() const;
    bool getJ2isIA() const;
    bool getIsTimer() const;
    bool getIsDemarrer() const;
    int getIAdelay() const;
    int getTimerDuree() const;
    bool getKonami() const;
    int getIABlancLvl() const;
    int getIANoirLvl() const;

    bool getJ1isStockfish() const;

    bool getJ2isStockfish() const;

private:
    Ui::MenuWindow *ui;
    bool j1isIA = false;
    bool j2isIA = true;
    bool j1isStockfish = false;
    bool j2isStockfish = true;
    bool isTimer = true;
    bool isDemarrer = false;
    bool isKonami = false;
    int IAdelay = 3000;
    int duree = 10;
    int lvlIABlanc = 10;
    int lvlIANoir = 10;
    void btnDemarrerAction();
    void btnSettingsAction();
    std::map<int, std::pair<Qt::Key, bool>> konamiMap;
    void initKonami();
    void keyPressEvent(QKeyEvent *event) override;
    void showEvent(QShowEvent* event) override;
};

#endif // MENUWINDOW_H
