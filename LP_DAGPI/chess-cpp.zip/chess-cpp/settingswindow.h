#ifndef SETTINGSWINDOW_H
#define SETTINGSWINDOW_H

#include <QDialog>

namespace Ui {
class SettingsWindow;
}

class SettingsWindow : public QDialog
{
    Q_OBJECT

public:
    explicit SettingsWindow(QWidget *parent = nullptr);
    ~SettingsWindow();
    bool getIAj2();
    bool getIAj1();
    bool getStockfishIAj2();
    bool getStockfishIAj1();
    int getIAdelay();
    int getTimer();
    int getLvlIABlanc();
    int getLvlIANoir();
    bool getIsTimer();
    void setDefaultValue(bool isIAj1, bool isIAj2, bool isj1Stockfish, bool isj2Stockfish, bool isTimer, int IAdelay, int duree);

private:
    void changeLabelJ1Checkbox();
    void changeLabelJ2Checkbox();
    void changeIAAdvanced1Parameter();
    void changeIAAdvanced2Parameter();
    void changeLabelTimerCheckbox();
    void changeStateDureeSpinBox();
    void changeStateIADelaySpinBox();
    Ui::SettingsWindow *ui;
};

#endif // SETTINGSWINDOW_H
