#include "timerwidget.h"
#include "ui_timerwidget.h"
#include "Utils.h"

TimerWidget::TimerWidget(Joueur* joueur, QWidget *parent) :
    QWidget(parent),
    ui(new Ui::TimerWidget),
    m_joueur(joueur)
{
    ui->setupUi(this);

    connect(joueur, &Joueur::tempsRestantChanged, this, &TimerWidget::updateTimer);

    updateTimer();
}

TimerWidget::~TimerWidget()
{
    delete ui;
}

void TimerWidget::updateTimer()
{
    int time = m_joueur->getTempsRestant();
    QString minutes = Utils::formatNumber(time / 60);
    QString secondes = Utils::formatNumber(time % 60);
    QString centiemes = Utils::formatNumber(m_joueur->getTimeRestantCent() % 100);

    if (time >= 10)
    {
        if (isRed)
        {
            isRed = false;
            ui->label->setStyleSheet("color: black;");
        }

        ui->label->setText(minutes + ":" + secondes);
    }
    else
    {
        if (!isRed)
        {
            isRed = true;
            ui->label->setStyleSheet("color: rgb(180, 50, 50);");
        }

        ui->label->setText(minutes + ":" + secondes + "." + centiemes);
    }
}
