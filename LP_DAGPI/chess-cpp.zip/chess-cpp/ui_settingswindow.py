# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'settingswindow.ui'
##
## Created by: Qt User Interface Compiler version 6.3.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QAbstractButton, QApplication, QCheckBox, QDialog,
    QDialogButtonBox, QDoubleSpinBox, QFrame, QHBoxLayout,
    QLabel, QSizePolicy, QSpacerItem, QSpinBox,
    QVBoxLayout, QWidget)
import resources_rc

class Ui_SettingsWindow(object):
    def setupUi(self, SettingsWindow):
        if not SettingsWindow.objectName():
            SettingsWindow.setObjectName(u"SettingsWindow")
        SettingsWindow.setWindowModality(Qt.NonModal)
        SettingsWindow.resize(459, 495)
        font = QFont()
        font.setFamilies([u"Arial"])
        font.setPointSize(15)
        SettingsWindow.setFont(font)
        SettingsWindow.setContextMenuPolicy(Qt.ActionsContextMenu)
        icon = QIcon()
        icon.addFile(u":/images/resources/settings.png", QSize(), QIcon.Normal, QIcon.Off)
        SettingsWindow.setWindowIcon(icon)
        self.verticalLayout_2 = QVBoxLayout(SettingsWindow)
        self.verticalLayout_2.setObjectName(u"verticalLayout_2")
        self.verticalLayout = QVBoxLayout()
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.verticalLayout.setContentsMargins(20, -1, 20, -1)
        self.j1_checkbox = QCheckBox(SettingsWindow)
        self.j1_checkbox.setObjectName(u"j1_checkbox")
        self.j1_checkbox.setFont(font)
        self.j1_checkbox.setFocusPolicy(Qt.NoFocus)
        self.j1_checkbox.setContextMenuPolicy(Qt.DefaultContextMenu)
        self.j1_checkbox.setLayoutDirection(Qt.LeftToRight)
        self.j1_checkbox.setInputMethodHints(Qt.ImhNone)
        self.j1_checkbox.setChecked(False)
        self.j1_checkbox.setTristate(False)

        self.verticalLayout.addWidget(self.j1_checkbox)

        self.j1_avanceCheckbox = QCheckBox(SettingsWindow)
        self.j1_avanceCheckbox.setObjectName(u"j1_avanceCheckbox")
        self.j1_avanceCheckbox.setEnabled(False)
        font1 = QFont()
        font1.setFamilies([u"Arial"])
        font1.setPointSize(14)
        self.j1_avanceCheckbox.setFont(font1)

        self.verticalLayout.addWidget(self.j1_avanceCheckbox)

        self.horizontalLayout_3 = QHBoxLayout()
        self.horizontalLayout_3.setObjectName(u"horizontalLayout_3")
        self.horizontalLayout_3.setContentsMargins(-1, 0, -1, -1)
        self.label_3 = QLabel(SettingsWindow)
        self.label_3.setObjectName(u"label_3")
        self.label_3.setEnabled(False)
        self.label_3.setFont(font)

        self.horizontalLayout_3.addWidget(self.label_3)

        self.spinBoxIAAvancee1 = QSpinBox(SettingsWindow)
        self.spinBoxIAAvancee1.setObjectName(u"spinBoxIAAvancee1")
        self.spinBoxIAAvancee1.setEnabled(False)
        self.spinBoxIAAvancee1.setMinimum(1)
        self.spinBoxIAAvancee1.setMaximum(20)
        self.spinBoxIAAvancee1.setValue(10)

        self.horizontalLayout_3.addWidget(self.spinBoxIAAvancee1)


        self.verticalLayout.addLayout(self.horizontalLayout_3)

        self.j2_checkbox = QCheckBox(SettingsWindow)
        self.j2_checkbox.setObjectName(u"j2_checkbox")
        self.j2_checkbox.setFont(font)
        self.j2_checkbox.setFocusPolicy(Qt.NoFocus)

        self.verticalLayout.addWidget(self.j2_checkbox)

        self.j2_avanceCheckbox = QCheckBox(SettingsWindow)
        self.j2_avanceCheckbox.setObjectName(u"j2_avanceCheckbox")
        self.j2_avanceCheckbox.setFont(font1)

        self.verticalLayout.addWidget(self.j2_avanceCheckbox)

        self.horizontalLayout_5 = QHBoxLayout()
        self.horizontalLayout_5.setObjectName(u"horizontalLayout_5")
        self.horizontalLayout_5.setContentsMargins(-1, 0, -1, -1)
        self.label_4 = QLabel(SettingsWindow)
        self.label_4.setObjectName(u"label_4")

        self.horizontalLayout_5.addWidget(self.label_4)

        self.spinBoxIAAvancee2 = QSpinBox(SettingsWindow)
        self.spinBoxIAAvancee2.setObjectName(u"spinBoxIAAvancee2")
        self.spinBoxIAAvancee2.setMinimum(1)
        self.spinBoxIAAvancee2.setMaximum(20)
        self.spinBoxIAAvancee2.setValue(10)

        self.horizontalLayout_5.addWidget(self.spinBoxIAAvancee2)


        self.verticalLayout.addLayout(self.horizontalLayout_5)

        self.verticalSpacer_4 = QSpacerItem(20, 40, QSizePolicy.Minimum, QSizePolicy.Expanding)

        self.verticalLayout.addItem(self.verticalSpacer_4)

        self.horizontalLayout = QHBoxLayout()
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.label = QLabel(SettingsWindow)
        self.label.setObjectName(u"label")
        self.label.setFont(font)

        self.horizontalLayout.addWidget(self.label)

        self.IAdelaySpinBox = QDoubleSpinBox(SettingsWindow)
        self.IAdelaySpinBox.setObjectName(u"IAdelaySpinBox")
        self.IAdelaySpinBox.setFocusPolicy(Qt.NoFocus)
        self.IAdelaySpinBox.setDecimals(1)
        self.IAdelaySpinBox.setMinimum(0.100000000000000)
        self.IAdelaySpinBox.setMaximum(100.000000000000000)
        self.IAdelaySpinBox.setSingleStep(0.500000000000000)

        self.horizontalLayout.addWidget(self.IAdelaySpinBox)


        self.verticalLayout.addLayout(self.horizontalLayout)

        self.verticalSpacer_3 = QSpacerItem(20, 40, QSizePolicy.Minimum, QSizePolicy.Expanding)

        self.verticalLayout.addItem(self.verticalSpacer_3)

        self.line = QFrame(SettingsWindow)
        self.line.setObjectName(u"line")
        self.line.setFrameShape(QFrame.HLine)
        self.line.setFrameShadow(QFrame.Sunken)

        self.verticalLayout.addWidget(self.line)

        self.verticalSpacer_2 = QSpacerItem(20, 40, QSizePolicy.Minimum, QSizePolicy.Expanding)

        self.verticalLayout.addItem(self.verticalSpacer_2)

        self.timer_checkbox = QCheckBox(SettingsWindow)
        self.timer_checkbox.setObjectName(u"timer_checkbox")
        self.timer_checkbox.setFont(font)
        self.timer_checkbox.setFocusPolicy(Qt.NoFocus)
        self.timer_checkbox.setContextMenuPolicy(Qt.DefaultContextMenu)
        self.timer_checkbox.setLayoutDirection(Qt.LeftToRight)
        self.timer_checkbox.setInputMethodHints(Qt.ImhNone)
        self.timer_checkbox.setChecked(False)
        self.timer_checkbox.setTristate(False)

        self.verticalLayout.addWidget(self.timer_checkbox)

        self.horizontalLayout_2 = QHBoxLayout()
        self.horizontalLayout_2.setObjectName(u"horizontalLayout_2")
        self.label_2 = QLabel(SettingsWindow)
        self.label_2.setObjectName(u"label_2")
        self.label_2.setFont(font)

        self.horizontalLayout_2.addWidget(self.label_2)

        self.dureeSpinBox = QDoubleSpinBox(SettingsWindow)
        self.dureeSpinBox.setObjectName(u"dureeSpinBox")
        self.dureeSpinBox.setFocusPolicy(Qt.NoFocus)
        self.dureeSpinBox.setDecimals(0)
        self.dureeSpinBox.setMinimum(1.000000000000000)
        self.dureeSpinBox.setMaximum(1000.000000000000000)
        self.dureeSpinBox.setSingleStep(1.000000000000000)
        self.dureeSpinBox.setValue(10.000000000000000)

        self.horizontalLayout_2.addWidget(self.dureeSpinBox)


        self.verticalLayout.addLayout(self.horizontalLayout_2)

        self.verticalSpacer = QSpacerItem(20, 40, QSizePolicy.Minimum, QSizePolicy.Expanding)

        self.verticalLayout.addItem(self.verticalSpacer)


        self.verticalLayout_2.addLayout(self.verticalLayout)

        self.horizontalLayout_4 = QHBoxLayout()
        self.horizontalLayout_4.setObjectName(u"horizontalLayout_4")
        self.horizontalLayout_4.setContentsMargins(-1, -1, 20, -1)
        self.horizontalSpacer_2 = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.horizontalLayout_4.addItem(self.horizontalSpacer_2)

        self.buttonBox = QDialogButtonBox(SettingsWindow)
        self.buttonBox.setObjectName(u"buttonBox")
        self.buttonBox.setFocusPolicy(Qt.NoFocus)
        self.buttonBox.setContextMenuPolicy(Qt.DefaultContextMenu)
        self.buttonBox.setOrientation(Qt.Horizontal)
        self.buttonBox.setStandardButtons(QDialogButtonBox.Cancel|QDialogButtonBox.Ok)

        self.horizontalLayout_4.addWidget(self.buttonBox)


        self.verticalLayout_2.addLayout(self.horizontalLayout_4)


        self.retranslateUi(SettingsWindow)
        self.buttonBox.accepted.connect(SettingsWindow.accept)
        self.buttonBox.rejected.connect(SettingsWindow.reject)

        QMetaObject.connectSlotsByName(SettingsWindow)
    # setupUi

    def retranslateUi(self, SettingsWindow):
        SettingsWindow.setWindowTitle(QCoreApplication.translate("SettingsWindow", u"Param\u00e8tre de jeu", None))
        self.j1_checkbox.setText(QCoreApplication.translate("SettingsWindow", u" : Activer l'IA pour le joueur Blanc", None))
        self.j1_avanceCheckbox.setText(QCoreApplication.translate("SettingsWindow", u"Utiliser l'IA avanc\u00e9e", None))
        self.label_3.setText(QCoreApplication.translate("SettingsWindow", u"Niveau de l'IA avanc\u00e9e", None))
        self.j2_checkbox.setText(QCoreApplication.translate("SettingsWindow", u" : Activer l'IA pour le joueur Noir", None))
        self.j2_avanceCheckbox.setText(QCoreApplication.translate("SettingsWindow", u"Utiliser l'IA avanc\u00e9e", None))
        self.label_4.setText(QCoreApplication.translate("SettingsWindow", u"Niveau de l'IA avanc\u00e9e", None))
        self.label.setText(QCoreApplication.translate("SettingsWindow", u"Temps choix IA", None))
        self.IAdelaySpinBox.setSuffix(QCoreApplication.translate("SettingsWindow", u" secondes", None))
        self.timer_checkbox.setText(QCoreApplication.translate("SettingsWindow", u" : Jeu avec timer activ\u00e9", None))
        self.label_2.setText(QCoreApplication.translate("SettingsWindow", u"Dur\u00e9e du Timer ", None))
        self.dureeSpinBox.setSuffix(QCoreApplication.translate("SettingsWindow", u" minutes", None))
    # retranslateUi

