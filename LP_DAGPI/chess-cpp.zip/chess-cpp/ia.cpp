#include "ia.h"
#include <QTimer>
#include <QRandomGenerator>

constexpr int IA_MIN_THINK_TIME = 499;

IA::IA(Joueur* joueur, int skillLevel) : m_joueur(joueur), stockfish(skillLevel)
{
    connect(&stockfish, &Stockfish::moveFound, this, &IA::moveFound);
}

void IA::play(Echiquier& e, QString fen)
{
    m_echiquier = &e;
    m_fen = fen;
    QTimer::singleShot(IA_MIN_THINK_TIME < delayMax ? QRandomGenerator::global()->bounded(IA_MIN_THINK_TIME, delayMax) : delayMax, this, &IA::doPlay);
}

void IA::setUseStockfish(bool newUseStockfish, int lvl)
{
    useStockfish = newUseStockfish;
    stockfish.setLevel(lvl);
}

void IA::doPlay()
{
    if (m_joueur->getTimeRestantCent() > 0)
    {
        if (useStockfish)
        {
            stockfish.calcMove(m_fen, m_depth);
        }
        else
        {
            auto mouvements = m_joueur->getMouvementsValides(*m_echiquier);
            quint32 size = mouvements.size();
            auto move = mouvements[QRandomGenerator::global()->bounded(size)];

            lastPiece = std::get<0>(move);
            lastStartX = lastPiece->x();
            lastStartY = lastPiece->y();
            lastEndX = std::get<1>(move);
            lastEndY = std::get<2>(move);

            m_echiquier->deplacer(std::get<0>(move), std::get<1>(move), std::get<2>(move));

            emit mouvementPlayed();
        }
    }
}

void IA::moveFound(std::pair<std::pair<int, int>, std::pair<int, int> > move)
{
    lastPiece = m_echiquier->getPiece(move.first.first, move.first.second);
    lastStartX = lastPiece->x();
    lastStartY = lastPiece->y();
    lastEndX = move.second.first;
    lastEndY = move.second.second;

    m_echiquier->deplacer(lastPiece, lastEndX, lastEndY);

    emit mouvementPlayed();
}
