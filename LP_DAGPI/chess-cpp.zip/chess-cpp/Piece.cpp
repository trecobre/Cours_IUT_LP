/**
 * Mise en oeuvre de Piece.h
 *
 * @file Piece.cxx
 */

// A besoin de la declaration de la classe
#include <iostream>
#include "Piece.h"
#include "Echiquier.h"
#include <QDebug>
#include <typeinfo>

using namespace std;

Piece::Piece()
{
    // ne fait rien => objet instancie mais non valide.
}

Piece::Piece( const Piece &autre )
{
    // autre.m_x = 0; // protection const
    m_x     = autre.m_x;
    m_y     = autre.m_y;
    m_white = autre.m_white;
}

Piece::Piece( int x, int y, bool white )
{
    m_x     = x;
    m_y     = y;
    m_white = white;
}

Piece::~Piece()
{
}

Piece& Piece::operator=( const Piece &autre )
{
    m_x     = autre.m_x;
    m_y     = autre.m_y;
    m_white = autre.m_white;
    return *this;
}

void Piece::init( int x, int y, bool white )
{
    m_x     = x;
    m_y     = y;
    m_white = white;
}

void Piece::move( int targetX, int targetY, bool incrementMoveCount)
{
    m_x = targetX;
    m_y = targetY;
    if( incrementMoveCount)
        m_move ++;
}

int Piece::x() const
{
    return m_x;
}

int Piece::y() const
{
    return m_y;
}

int Piece::getMove() const
{
    return m_move;
}

bool Piece::isWhite() const
{
    return m_white;
}

bool Piece::isBlack() const
{
    return !m_white;
}

void Piece::affiche() const
{
    qDebug() << "Piece: x=" << m_x << " y=" << m_y << " " << ( m_white ? "blanche" : "noire" );
}

char Piece::display() const
{
    return m_white ? 'B' : 'N';
}

char Piece::FEN() const
{
    return 'X';
}

Piece& Piece::plusforte( Piece &autre )
{
    if ( autre.x() > m_x )
        return autre;
    else
        return *this;
}

bool Piece::mouvementValide(Echiquier &e, int targetX, int targetY)
{
    return caseAtteignable(e, targetX, targetY) && !mouvementCauseEchec(e, targetX, targetY);
}

bool Piece::mouvementCauseEchec(Echiquier &e, int targetX, int targetY)
{
    std::pair originalCoords(x(), y());

    // On simule le mouvement pour voir s'il cause un échec
    Piece* piecePrise = e.enleverPiece(targetX, targetY);
    e.deplacer(this, targetX, targetY , false);

    const Roi* roi = e.getRoi(isWhite());

    bool retValue = false;

    for (int xOther=1; xOther<=8; xOther++)
    {
        for (int yOther=1; yOther<=8; yOther++)
        {
            if (Piece* p = e.getPiece(xOther, yOther); p && p->isWhite() != isWhite() && p->caseAtteignable(e, roi->x(), roi->y()))
            {
                retValue = true;
                break;
            }
        }

        if (retValue)
        {
            break;
        }
    }

    // On annule le mouvement
    e.deplacer(this, originalCoords.first, originalCoords.second,false);
    if (piecePrise)
    {
        e.placer(piecePrise);
    }

    return retValue;
}

std::vector<std::pair<int, int> > Piece::getMouvementsValides(Echiquier &e)
{
    vector<std::pair<int, int>> mouvementsValides;

    for (int x=1; x<=8; x++)
    {
        for (int y=1; y<=8; y++)
        {
            if (mouvementValide(e, x, y))
            {
                mouvementsValides.push_back({x, y});
            }
        }
    }

    return mouvementsValides;
}

Fou::Fou( bool white, bool left ) : Piece( left ? 3 : 6, white ? 1 : 8, white )
{
}

char Fou::display() const
{
    return m_white ? 'F' : 'f';
}

char Fou::FEN() const
{
    return m_white ? 'B' : 'b';
}

bool Fou::caseAtteignable(Echiquier &e, int targetX, int targetY ) const
{
    if (targetX == x() && targetY == y())
    {
        return false;
    }

    // Mouvement diagonal -> targetX - startX == targetY - startY

    if (std::abs(targetX - x()) !=  std::abs(targetY - y()))
    {
        return false;
    }

    // Vérifier qu'aucune pièce ne se trouve sur le chemin

    int currentX = x();
    int currentY = y();

    do
    {
        currentX = currentX < targetX ? currentX + 1 : currentX - 1;
        currentY = currentY < targetY ? currentY + 1 : currentY - 1;

        if (currentX != targetX && e.getPiece(currentX, currentY))
        {
            return false;
        }
    } while (currentX != targetX);

    // Vérifier que la case d'arrivée est inoccuppée ou occupée par une pièce de l'adversaire

    auto* p = e.getPiece(targetX, targetY);

    return !p || p->isWhite() != isWhite();
}

Tour::Tour( bool white, bool left ) : Piece( left ? 1 : 8, white ? 1 : 8, white )
{
}

char Cavalier::display() const
{
    return m_white ? 'C' : 'c';
}

char Cavalier::FEN() const
{
    return m_white ? 'N' : 'n';
}

bool Cavalier::caseAtteignable(Echiquier &e, int targetX, int targetY ) const
{
    if (targetX == x() && targetY == y())
    {
        return false;
    }

    int diffX = std::abs(targetX - x());
    int diffY = std::abs(targetY - y());

    const bool isMouvementCavalier = (diffX == 2 && diffY == 1) || (diffX == 1 && diffY == 2);

    auto* p = e.getPiece(targetX, targetY);

    return isMouvementCavalier && (!p || p->isWhite() != isWhite());
}

Cavalier::Cavalier( bool white, bool left ) : Piece( left ? 2 : 7, white ? 1 : 8, white )
{
}

char Tour::display() const
{
    return m_white ? 'T' : 't';
}

char Tour::FEN() const
{
    return m_white ? 'R' : 'r';
}

bool Tour::caseAtteignable(Echiquier &e, int targetX, int targetY ) const
{
    if (targetX == x() && targetY == y())
    {
        return false;
    }

    const bool isMouvementTour = (targetX == x() && targetY != y()) || (targetX != x() && targetY == y());

    if (!isMouvementTour)
    {
        return false;
    }

    // Vérifier qu'aucune pièce ne se trouve sur le chemin

    bool isMouvementVertical = targetX == x();
    int current = isMouvementVertical ? y() : x();
    const int target = isMouvementVertical ? targetY : targetX;

    do
    {
        current = current < target ? current + 1 : current - 1;

        if (current != target)
        {
            auto* p = isMouvementVertical ? e.getPiece(targetX, current) : e.getPiece(current, targetY);

            if (p)
            {
                return false;
            }
        }
    } while (current != target);

    // Vérifier que la case d'arrivée est inoccuppée ou occupée par une pièce de l'adversaire

    auto* p = e.getPiece(targetX, targetY);

    return !p || p->isWhite() != isWhite();
}

Reine::Reine( bool white )
    : Piece( 4, ( white ) ? 1 : 8, white ), Tour( white, true ), Fou( white, true )
{
}

char Reine::display() const
{
    return m_white ? 'Q' : 'q';
}

char Reine::FEN() const
{
    return display();
}

bool Reine::caseAtteignable(Echiquier &e, int targetX, int targetY ) const
{
    return Tour::caseAtteignable( e, targetX, targetY ) || Fou::caseAtteignable( e, targetX, targetY );
}

Roi::Roi( bool white ) : Piece( 5, ( white ) ? 1 : 8, white )
{
}

char Roi::display() const
{
    return m_white ? 'R' : 'r';
}

char Roi::FEN() const
{
    return m_white ? 'K' : 'k';
}

bool Roi::caseAtteignable(Echiquier &e, int targetX, int targetY ) const
{

    if (getMove() == 0){
        if((std::abs(targetX - x()) > 2 || std::abs(targetY - y()) > 0) && (std::abs(targetX - x()) > 1 ||std::abs(targetY - y()) > 1)){

            return false;
        }

        //verifie si mouvement roque valide
        if(this->isWhite())
        {
            //petit roque blanc
            if(targetX == 7 && targetY == 1){
                auto* P61 = e.getPiece(6, 1);
                auto* P71 = e.getPiece(7,1);
                auto* TPB = e.getPiece(8,1);
                if(P61 || P71){
                    return false;
                }
                if(!TPB){
                    return false;
                }
                else if(TPB->getMove() > 0){
                    return false;
                }
            }
            //grand roque blanc
            if(targetX == 3 && targetY == 1){
                auto* TGB = e.getPiece(1,1);
                auto* P41 = e.getPiece(4, 1);
                auto* P21 = e.getPiece(2, 1);
                auto* P31 = e.getPiece(3, 1);
                if(P41 || P21 || P31){
                    return false;
                }
                if(!TGB){
                    return false;
                }
                else if(TGB->getMove() > 0){
                    return false;
                }
            }
        }
        else{
            //petit roque noir
            if(targetX == 7 && targetY == 8){
                auto* TPN = e.getPiece(8,8);
                auto* P68 = e.getPiece(6, 8);
                auto* P78 = e.getPiece(7, 8);
                if(P68 || P78){
                    return false;
                }
                if(!TPN){
                    return false;
                }
                else if(TPN->getMove() > 0){
                    return false;
                }
            }
            //grand roque noir
            if(targetX == 3 && targetY == 8){
                auto* TGN = e.getPiece(1,8);
                auto* P48 = e.getPiece(4, 8);
                auto* P28 = e.getPiece(2, 8);
                auto* P38 = e.getPiece(3,8);
                if(P48||P28 || P38){
                    return false;
                }
                if(!TGN){
                    return false;
                }
                else if(TGN->getMove() > 0){
                    return false;
                }
            }
        }
    }
    else{
        if(std::abs(targetX - x()) > 1 || std::abs(targetY - y()) > 1){
            return false;
        }
    }

    // Vérifier que la case d'arrivée est inoccuppée ou occupée par une pièce de l'adversaire
    auto* p = e.getPiece(targetX, targetY);

    return !p || p->isWhite() != isWhite();
}

void Roi::roque(Echiquier &e , bool isGrand)
{
    if(isGrand){
        if(this->isWhite()){
            auto* tour = e.getPiece(1,1);
            e.deplacer(tour,4,1,false);
        }
        else{
            auto* tour = e.getPiece(1,8);
            e.deplacer(tour,4,8,false);
        }
    }
    else{
        if(this->isWhite()){
            auto* tour = e.getPiece(8,1);
            e.deplacer(tour,6,1,false);
        }else{
            auto* tour = e.getPiece(8,8);
            e.deplacer(tour,6,8,false);
        }
    }
}


Pion::Pion( bool white, int x ) : Piece( x, ( white ) ? 2 : 7, white )
{
}

char Pion::display() const
{
    return m_white ? 'P' : 'p';
}

char Pion::FEN() const
{
    return display();
}

bool Pion::caseAtteignable(Echiquier &e, int targetX, int targetY ) const
{
    if (targetX == x() && targetY == y())
    {
        return false;
    }

    // Mouvement uniquement en avant

    bool enAvant = (isWhite() && targetY > y()) || (isBlack() && targetY < y());

    if (!enAvant)
    {
        return false;
    }

    if (targetX != x() && std::abs(targetX - x()) == 1 && std::abs(targetY - y()) == 1)
    {
        // Possible uniquement si prise

        auto* p = e.getPiece(targetX, targetY);

        return p && p->isWhite() != isWhite();
    }

    if (targetX != x())
    {
        return false;
    }

    bool isMouvementVertical = targetX == x();
    int current = isMouvementVertical ? y() : x();
    const int target = isMouvementVertical ? targetY : targetX;

    do
    {
        current = current < target ? current + 1 : current - 1;

        if (current != target)
        {
            auto* p = isMouvementVertical ? e.getPiece(targetX, current) : e.getPiece(current, targetY);

            if (p)
            {
                return false;
            }
        }
    } while (current != target);

    const bool isPremierMouvement = (isWhite() && y() == 2) || (isBlack() && y() == 7);

    const int distanceMax = isPremierMouvement ? 2 : 1;

    return std::abs(targetY - y()) <= distanceMax && !e.getPiece(targetX, targetY);
}

Piece* Pion::promotion(PiecePromotion newPieceType)
{
    Piece* newPiece;
    switch (newPieceType) {
    case PiecePromotion::PromoTour:
        newPiece = new Tour(this->isWhite(), true);
        break;
    case PiecePromotion::PromoFou:
        newPiece = new Fou(this->isWhite(), true);
        break;
    case PiecePromotion::PromoCavalier:
        newPiece = new Cavalier(this->isWhite(), true);
        break;
    case PiecePromotion::PromoReine:
        newPiece = new Reine(this->isWhite());
        break;
    default:
        newPiece = new Pion(this->isWhite(), this->x());
        break;
    }
    newPiece->init(this->x(), this->y(), this->isWhite());
    return newPiece;
}
