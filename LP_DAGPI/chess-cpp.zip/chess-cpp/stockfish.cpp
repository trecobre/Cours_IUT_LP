#include "stockfish.h"
#include "qdebug.h"
#include <QtGlobal>
#include "Utils.h"
#include <QFile>
#include <QDir>

Stockfish::Stockfish(int skillLevel, QObject *parent)
    : QObject{parent}, m_skillLevel(skillLevel)
{
#ifdef Q_OS_WIN
    m_program = "/stockfish.exe";
#elif defined Q_OS_UNIX
    m_program = "/stockfish";
#endif

    connect(&m_process, &QProcess::readyReadStandardOutput, this, &Stockfish::read);
    connect(&m_process, &QProcess::started, this, &Stockfish::started);

    auto path = QDir().currentPath() + m_program;

    if (!QFile(path).exists())
    {
        m_program = "/.." + m_program;
        path = QDir().currentPath() + m_program;
    }

#ifdef Q_OS_UNIX
    auto f = QFile(path);
    f.setPermissions(f.permissions() | QFile::ExeGroup | QFile::ExeOther | QFile::ExeOther | QFile::ExeUser);
#endif

    m_process.start(path);
}

Stockfish::~Stockfish()
{
    m_process.kill();
}

void Stockfish::calcMove(QString fen, int depth)
{
    m_process.write("position fen " + fen.toLatin1() + "\n");
    m_process.write("go depth " + QString::number(depth).toLatin1() + "\n");
}

void Stockfish::read()
{
    auto out = QString(m_process.readAllStandardOutput()).replace("\r", "").split("\n");

    if (out.size() < 2)
    {
        return;
    }

    QString lastLine = out[out.size() - 2];

    if (lastLine == "uciok")
    {
        qInfo() << "Stockfish initialized";
        m_process.write(QString("setoption name Skill Level value " + QString::number(m_skillLevel) + "\n").toLatin1());
        m_process.write("ucinewgame\n");
        initialized = true;
    }
    else if (lastLine.startsWith("bestmove"))
    {
        auto moveArr = lastLine.split(' ');
        QString moveStr = moveArr[1];

        if (moveStr != "(none)")
        {
            QString startStr = QString(moveStr[0]) + moveStr[1];
            QString endStr = QString(moveStr[2]) + moveStr[3];

            //TODO: Gérer la promotion : 5ème caractère = pièce à promouvoir

            const auto& startCoords = Utils::getCoords(startStr);
            const auto& endCoords = Utils::getCoords(endStr);

            if (!startCoords || !endCoords)
            {
                return;
            }

            emit moveFound(std::make_pair(std::make_pair(startCoords.get()[0], startCoords.get()[1]), std::make_pair(endCoords.get()[0], endCoords.get()[1])));
        }
    }
}

void Stockfish::started()
{
    qInfo() << "Stockfish ready";
    m_process.write("uci\n");
}

void Stockfish::setLevel(int lvl){
    m_skillLevel = lvl;
}
