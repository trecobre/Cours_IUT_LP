#include <iostream>
#include <assert.h>
#include "Joueur.h"
#include "Piece.h"
#include <QDebug>

using namespace std;

Joueur::Joueur()
{
    connect(&m_timer, &QTimer::timeout, this, &Joueur::timerTick);
}

Joueur::~Joueur()
{
}

void Joueur::placerPieces( Echiquier &e )
{
    auto p = m_pieces.begin();
    while ( p != m_pieces.end() ) {
        e.placer( p->get() );
        p++;
    }
}

void Joueur::affiche()
{
    vector<unique_ptr<Piece>>::iterator p = m_pieces.begin();
    while ( p != m_pieces.end() ) {
        ( *p )->affiche();
        p++;
    }
}

Roi* Joueur::getRoi()
{
    for (const auto& piece : m_pieces)
    {
        if (auto* roi = dynamic_cast<Roi*>(&*piece))
        {
            return roi;
        }
    }

    return nullptr;
}

void Joueur::timerTick()
{
    if (m_tempsRestant > 0)
    {
        m_tempsRestant--;
    }

    emit tempsRestantChanged(this);

    if (m_tempsRestant == 0)
    {
        emit timerFini(this);
    }
}

bool Joueur::getIsIA() const
{
    return isIA;
}

void Joueur::setIsIA(bool newIsIA)
{
    isIA = newIsIA;
}

void Joueur::changerPiece(Piece* anciennePiece, Piece* nouvellePiece){
    for(auto& piece : this->m_pieces){
        if(piece.get() == anciennePiece){
            piece.reset(nouvellePiece);
        }
    }
}

void Joueur::setTimerDuree(int duree){
    m_tempsRestant = duree*6000;
}

void Joueur::startTimer()
{
    m_timer.start(10);
}

void Joueur::stopTimer()
{
    m_timer.stop();
}

int Joueur::getTempsRestant() const
{
    return m_tempsRestant / 100;
}

int Joueur::getTimeRestantCent() const
{
    return m_tempsRestant;
}

bool Joueur::isEchec(Echiquier& e, Joueur& adversaire)
{
    const Roi* roi = getRoi();
    for (const auto& piece : adversaire.m_pieces)
    {
        if (e.getPiece(piece->x(), piece->y()) == piece.get()) // Vérifier que la pièce est toujours en jeu
        {
            if (piece->mouvementValide(e, roi->x(), roi->y()))
            {
                return true;
            }
        }
    }

    return false;
}

bool Joueur::isEchecEtMat(Echiquier& e,  Joueur& adversaire)
{
    return isEchec(e, adversaire) && getMouvementsValides(e).size() == 0;
}

vector<std::tuple<Piece*, int, int> > Joueur::getMouvementsValides(Echiquier &e)
{
    vector<std::tuple<Piece*, int, int>> mouvementsValides;

    for (const auto& piece : m_pieces)
    {
        if (e.getPiece(piece->x(), piece->y()) == piece.get()) // Vérifier que la pièce est toujours en jeu
        {
            auto mouvementsValidesPiece = piece->getMouvementsValides(e);

            // Ajout des éléments de mouvementsValidesPiece dans mouvementsValides
            for (auto& m : mouvementsValidesPiece)
            {
                mouvementsValides.push_back(std::make_tuple(&*piece, m.first, m.second));
            }
        }
    }

    return mouvementsValides;
}

bool JoueurBlanc::isWhite()
{
    return true;
}

bool JoueurNoir::isWhite()
{
    return false;
}

JoueurBlanc::JoueurBlanc()
{
    m_pieces.push_back( make_unique<Fou>( true, true ) );
    m_pieces.push_back( make_unique<Fou>( true, false ) );
    m_pieces.push_back( make_unique<Tour>( true, true ) );
    m_pieces.push_back( make_unique<Tour>( true, false ) );
    m_pieces.push_back( make_unique<Cavalier>( true, true ) );
    m_pieces.push_back( make_unique<Cavalier>( true, false ) );
    m_pieces.push_back( make_unique<Roi>( true ) );
    m_pieces.push_back( make_unique<Reine>( true ) );
    for ( int x = 1; x <= 8; x++ )
        m_pieces.push_back( make_unique<Pion>( true, x ) );
    assert( m_pieces.size() == 16 );
}

JoueurNoir::JoueurNoir()
{
    m_pieces.push_back( make_unique<Fou>( false, true ) );
    m_pieces.push_back( make_unique<Fou>( false, false ) );
    m_pieces.push_back( make_unique<Tour>( false, true ) );
    m_pieces.push_back( make_unique<Tour>( false, false ) );
    m_pieces.push_back( make_unique<Cavalier>( false, true ) );
    m_pieces.push_back( make_unique<Cavalier>( false, false ) );
    m_pieces.push_back( make_unique<Roi>( false ) );
    m_pieces.push_back( make_unique<Reine>( false ) );
    for ( int x = 1; x <= 8; x++ )
        m_pieces.push_back( make_unique<Pion>( false, x ) );
    assert( m_pieces.size() == 16 );
}
