#!/bin/bash

QTDIR=~/Qt/6.4.0/gcc_64

PATH=$PATH:$QTDIR/bin

mkdir Build-Tests

qmake6 ChessTest/ChessTest.pro -o Build-Tests/
cd Build-Tests
make -j$(nproc)

cd ..

./Build-Tests/ChessTest