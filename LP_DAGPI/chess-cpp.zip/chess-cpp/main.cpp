#include "jeu.h"
#include "Utils.h"

#include "Piece.h"
#include "Joueur.h"
#include "Echiquier.h"

#include <QApplication>
#include "mainwindow.h"
#include "menuwindow.h"

int main(int argc, char *argv[])
{
    int retCode = 0;

    if (argc == 2 && !strcmp(argv[1], "--console")){
         qInfo() << "========== Echecs ==========";

         Jeu jeu;
         Echiquier echiquier = jeu.getEchiquier();

         echiquier.affiche();

         while (jeu.prochainJoueur())
         {
             QString prefix = jeu.getJoueurActif()->isWhite() ? "[Joueur blanc] " : "[Joueur noir] ";

             QString input;
             std::unique_ptr<int> coordsDepart, coordsArrivee;
             int xDepart, yDepart;
             bool pieceDepartValide = false;
             Piece* pieceDepart;

             while (!coordsDepart || !pieceDepartValide)
             {
                 Utils::cout() << prefix << "Choisir la piece a bouger : ";
                 Utils::cin() >> input;

                 coordsDepart = Utils::getCoords(input);

                 if (coordsDepart)
                 {
                     xDepart = coordsDepart.get()[0];
                     yDepart = coordsDepart.get()[1];

                     if ((pieceDepart = echiquier.getPiece(xDepart, yDepart)))
                     {
                         if (pieceDepart->isWhite() == jeu.getJoueurActif()->isWhite())
                         {
                             if (pieceDepart->getMouvementsValides(echiquier).size() > 0)
                             {
                                 pieceDepartValide = true;
                             }
                             else
                             {
                                 qInfo("Cette piece ne peut pas se deplacer");
                             }
                         }
                         else
                         {
                             Utils::cout() << "Cette piece n'appartient pas a " << prefix << Utils::endl();
                         }
                     }
                 }
             }

             bool mouvementValide = false;

             int xArrivee, yArrivee;

             while (!coordsArrivee || !mouvementValide)
             {
                 Utils::cout() << prefix << "Choisir la case de destination : ";
                 Utils::cin() >> input;

                 coordsArrivee = Utils::getCoords(input);

                 if (coordsArrivee)
                 {
                     xArrivee = coordsArrivee.get()[0];
                     yArrivee = coordsArrivee.get()[1];
                     mouvementValide = pieceDepart->mouvementValide(echiquier, xArrivee, yArrivee);
                 }
             }

             echiquier.deplacer(pieceDepart, xArrivee, yArrivee);

             if(echiquier.piecePromotable(pieceDepart)){
                 bool validePromotion = false;
                 QString choixPossible = "1234";
                 int choix = 0;
                 while(!validePromotion){
                     Utils::cout() << prefix << "Choisissez en quel piece le pion doit etre promu : \n1 : Tour\n2 : Fou\n3 : Cavalier\n4 : Reine" << Utils::endl();
                     Utils::cin() >> input;
                     validePromotion = input.length()==1 && choixPossible.contains(input.at(0));
                     if(validePromotion){
                         choix = input.at(0).digitValue();
                     }
                 }
                 jeu.promotionPiece(pieceDepart, (Piece::PiecePromotion)(choix-1));

             }

             qInfo() << Utils::endl();
             echiquier.affiche();
         }

         QString gagnant = jeu.getJoueurActif()->isWhite() ? "[Joueur noir] " : "[Joueur blanc] ";

         Utils::cout() << "Echec et mat ! " << gagnant << " gagne la partie !" << Utils::endl();
     }
    else{
        QApplication a(argc, argv);
        MenuWindow m;
        bool restart = true;

        while (restart)
        {
            m.show();
            a.exec();

            if (m.getIsDemarrer())
            {
                MainWindow w;
                w.gameSettings(&m);
                w.startGame();
                w.show();
                restart = a.exec() == 42;
            }
            else
            {
                restart = false;
            }
        }
    }

    return retCode;
}
