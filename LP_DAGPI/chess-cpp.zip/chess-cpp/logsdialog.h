#ifndef LOGSDIALOG_H
#define LOGSDIALOG_H

#include <QWidget>

namespace Ui {
class LogsDialog;
}

class LogsDialog : public QWidget
{
    Q_OBJECT

public:
    explicit LogsDialog(QWidget *parent = nullptr);
    ~LogsDialog();

    void log(QString message);

private:
    Ui::LogsDialog *ui;

private slots:
    void on_copyButton_clicked();
};

#endif // LOGSDIALOG_H
