#ifndef IA_H
#define IA_H

#include <QObject>
#include "Joueur.h"
#include "stockfish.h"

class IA : public QObject
{
    Q_OBJECT
public:
    IA(Joueur* joueur, int skillLevel);
    void play(Echiquier& e, QString fen = QString());

    int lastStartX, lastStartY, lastEndX, lastEndY;
    Piece* lastPiece;
    int delayMax = 3000;

    void setUseStockfish(bool newUseStockfish, int lvl);

private:
    Joueur* m_joueur;
    Echiquier* m_echiquier;

    Stockfish stockfish;
    int m_depth = 5;
    QString m_fen;

    bool useStockfish = true;

private slots:
    void doPlay();
    void moveFound(std::pair<std::pair<int, int>, std::pair<int, int>> move);

signals:
    void mouvementPlayed();
};

#endif // IA_H
