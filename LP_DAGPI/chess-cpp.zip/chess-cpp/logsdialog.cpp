#include "logsdialog.h"
#include "ui_logsdialog.h"
#include <QMoveEvent>
#include <QClipboard>
#include <QMessageBox>

LogsDialog::LogsDialog(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::LogsDialog)
{
    ui->setupUi(this);
}

LogsDialog::~LogsDialog()
{
    delete ui;
}

void LogsDialog::log(QString message)
{
    ui->logsList->addItem(message);
    ui->logsList->scrollToBottom();

    ui->copyButton->setEnabled(true);
}

void LogsDialog::on_copyButton_clicked()
{
    QString copy = "";

    for (int i=0; i<ui->logsList->count(); i++)
    {
        copy += ui->logsList->item(i)->text();
        copy += "\n";
    }

    QGuiApplication::clipboard()->setText(copy);
    QMessageBox::information(this, "Copié", "L'historique a bien été copié dans le presse-papier.");
}

