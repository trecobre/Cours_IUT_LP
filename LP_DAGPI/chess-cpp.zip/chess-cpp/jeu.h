#ifndef JEU_H
#define JEU_H

#include "Joueur.h"
#include "Echiquier.h"
#include "ia.h"

class Jeu : public QObject
{
    Q_OBJECT
public:
    Jeu();

    Echiquier& getEchiquier();

    JoueurNoir& getJoueurNoir();

    JoueurBlanc& getJoueurBlanc();

    /**
     * @brief Méthode appelée pour changer de joueur actif.
     * La première fois que cette méthode est appelée, le joueur blanc devient le joueur actif.
     * @return true si le joueur peut jouer, false s'il est en échec et mat
     */
    bool prochainJoueur();

    void promotionPiece(Piece * p, Piece::PiecePromotion piecePromo);
    void promotionPiece(Piece * p, Piece::PiecePromotion piecePromo, bool isKonami);

    Joueur *getJoueurActif() const;

    IA* getIA(bool isWhite);

    bool getIsFini() const;

    QString getFEN();

signals:
    void jeuFini(Joueur* gagnant, Joueur* perdant);

private slots:
    void joueurTimeout(Joueur* joueur);

private:
    JoueurBlanc joueurBlanc;
    JoueurNoir joueurNoir;
    IA iaBlanc, iaNoir;
    Echiquier echiquier;

    Joueur* joueurActif = nullptr;

    bool timersEnabled = true;
    bool isFini = false;
};

#endif // JEU_H
