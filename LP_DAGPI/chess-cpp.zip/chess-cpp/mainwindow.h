#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QLayout>
#include "jeu.h"
#include "piecewidget.h"
#include <vector>
#include "logsdialog.h"
#include "menuwindow.h"
#include "timerwidget.h"

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    void updateBoard();
    void gameSettings(MenuWindow* menuwindow);
    void startGame();
    void updateLogsWindow();

private slots:
    void caseClicked(PieceWidget* source);
    void joueurTimeout(Joueur* gagnant, Joueur* perdant);
    void iaBlancPlayed();
    void iaNoirPlayed();

    void on_pushButton_clicked();

private:
    Ui::MainWindow *ui;
    QGridLayout* grid;
    QPixmap image;
    Jeu jeu;

    unique_ptr<LogsDialog> logsDialog;
    unique_ptr<TimerWidget> timerBlanc, timerNoir;

    void resetHighlight();
    void prochainJoueur();
    void log(Piece* piece, int startX, int startY, int endX, int endY);
    void iaPlayed();
    void checkPromotion(int x, int y);

    bool konami = false;

    Piece* selectedPiece = nullptr;

    std::vector<unique_ptr<PieceWidget>> m_cases;
};
#endif // MAINWINDOW_H
