/**
 * Header de Piece.cxx
 *
 * @file Piece.h
 */

#if !defined Piece_h
#define Piece_h

#include <vector>

// #include "Echiquier.h" // inclusion croisee
class Echiquier;

/**
 * Declaration d'une classe modelisant une piece de jeu d'echec.
 */
class Piece
{
public:
    Piece();
    Piece( const Piece &autre );
    Piece( int x, int y, bool white );
    virtual ~Piece();
    Piece       &operator=( const Piece &autre );
    virtual void init( int x, int y, bool white );
    void         move( int targetX, int targetY,  bool incrementMoveCount=true);
    int          x() const;
    int          y() const;
    int          getMove() const;
    bool         isWhite() const;
    bool         isBlack() const;
    void         affiche() const;
    virtual char display() const;
    virtual char FEN() const;
    Piece       &plusforte( Piece &autre );

    /**
     * @brief Vérifie que la case spécifiée est atteignable sans créer d'échec.
     */
    bool mouvementValide( Echiquier &e, int targetX, int targetY );

    /**
     * @brief Retourne un vector de pairs d'entiers correspondants aux coordonnées de tous les mouvements possibles par cete pièce.
     * @return Une liste de paires d'entiers où le premier élément est x, le deuxième est y
     */
    std::vector<std::pair<int, int>> getMouvementsValides(Echiquier& e);

    enum PiecePromotion{
        PromoTour,
        PromoFou,
        PromoCavalier,
        PromoReine,
        Default
    };

protected:
    virtual bool caseAtteignable( Echiquier &e, int targetX, int targetY ) const = 0;

    /**
     * @brief Vérifie si un mouvement mettrait le joueur qui l'effectue en échec.
     * Si le joueur est en situation d'échec, cete méthode permet aussi de vérifier si le mouvement résout l'échec ou non.
     */
    bool mouvementCauseEchec( Echiquier &e, int targetX, int targetY );

    int  m_x;
    int  m_y;
    bool m_white;
    int m_move = 0;
};

class Fou : virtual public Piece
{
public:
    Fou( bool white, bool left );
    char display() const;
    char FEN() const;
    bool caseAtteignable( Echiquier &e, int targetX, int targetY ) const;
};

class Tour : virtual public Piece
{
public:
    Tour( bool white, bool left );
    char display() const;
    char FEN() const;
    bool caseAtteignable( Echiquier &e, int targetX, int targetY ) const;
};

class Cavalier : public Piece
{
public:
    Cavalier( bool white, bool left );
    char display() const;
    char FEN() const;
    bool caseAtteignable( Echiquier &e, int targetX, int targetY ) const;
};

class Reine : public Tour, public Fou
{
public:
    Reine( bool white );
    char display() const;
    char FEN() const;
    bool caseAtteignable( Echiquier &e, int targetX, int targetY ) const;
};

class Roi : public Piece
{
public:
    Roi( bool white );
    char display() const;
    char FEN() const;
    bool caseAtteignable( Echiquier &e, int targetX, int targetY ) const;
    void roque(Echiquier &e , bool isGrand);
};

class Pion : public Piece
{
public:
    Pion( bool white, int x );
    char display() const;
    char FEN() const;
    bool caseAtteignable( Echiquier &e, int targetX, int targetY ) const;
    Piece* promotion(PiecePromotion newPiece);
};

#endif  // !defined Piece_h
