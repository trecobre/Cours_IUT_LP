#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "Echiquier.h"
#include "Piece.h"
#include "Utils.h"
#include "ia.h"

#include <QLayout>
#include <QLabel>
#include <QLayoutItem>
#include <Qt>
#include <QMainWindow>
#include <iostream>
#include <QImageReader>
#include <QMessageBox>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    setWindowTitle("Echecs");
    ui->setupUi(this);

    logsDialog = make_unique<LogsDialog>(ui->logsFrame);
    ui->logsFrame->setLayout(new QGridLayout(ui->logsFrame));
    ui->logsFrame->layout()->addWidget(logsDialog.get());

    connect(&jeu, &Jeu::jeuFini, this, &MainWindow::joueurTimeout);

    logsDialog->setVisible(true);

    for (int x = 1; x <= 8; x++)
    {
        for (int y = 1; y <= 8; y++)
        {
            m_cases.push_back(make_unique<PieceWidget>(x, y, x%2==y%2));
            auto* p = m_cases[m_cases.size() - 1].get();

            connect(p, &PieceWidget::clicked, this, &MainWindow::caseClicked);

            ui->board->addWidget(p, 8 - y, x);
        }
    }
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::gameSettings(MenuWindow* menuwindow){
    jeu.getJoueurBlanc().setIsIA(menuwindow->getJ1isIA());
    jeu.getJoueurNoir().setIsIA(menuwindow->getJ2isIA());

    if(jeu.getJoueurBlanc().getIsIA()){
        jeu.getIA(true)->delayMax = menuwindow->getIAdelay();
        jeu.getIA(true)->setUseStockfish(menuwindow->getJ1isStockfish(), menuwindow->getIABlancLvl());
    }
    if(jeu.getJoueurNoir().getIsIA()){
        jeu.getIA(false)->delayMax = menuwindow->getIAdelay();
        jeu.getIA(false)->setUseStockfish(menuwindow->getJ2isStockfish(), menuwindow->getIANoirLvl());
    }

    if(menuwindow->getIsTimer()){
        jeu.getJoueurBlanc().setTimerDuree(menuwindow->getTimerDuree());
        timerBlanc = make_unique<TimerWidget>(&jeu.getJoueurBlanc(), ui->timerFrameB);
        ui->timerFrameB->setLayout(new QGridLayout(ui->timerFrameB));
        ui->timerFrameB->layout()->addWidget(timerBlanc.get());

        jeu.getJoueurNoir().setTimerDuree(menuwindow->getTimerDuree());
        timerNoir = make_unique<TimerWidget>(&jeu.getJoueurNoir(), ui->timerFrameN);
        ui->timerFrameN->setLayout(new QGridLayout(ui->timerFrameN));
        ui->timerFrameN->layout()->addWidget(timerNoir.get());
    }

    konami = menuwindow->getKonami();
}

void MainWindow::startGame(){
    connect(jeu.getIA(true), &IA::mouvementPlayed, this, &MainWindow::iaBlancPlayed);
    connect(jeu.getIA(false), &IA::mouvementPlayed, this, &MainWindow::iaNoirPlayed);

    if(konami){
        for(int i = 1; i <= 8; i++){
            jeu.promotionPiece(jeu.getEchiquier().getPiece(i, 2), Piece::PromoReine, true);
            jeu.promotionPiece(jeu.getEchiquier().getPiece(i, 7), Piece::PromoReine, true);
        }

    }

    prochainJoueur();

    updateBoard();
}

void MainWindow::updateBoard()
{
    for (int x = 1; x <= 8; x++)
    {
        for (int y = 1; y <= 8; y++)
        {
            auto& c = m_cases[( y - 1 ) + 8 * ( x - 1 )];
            Piece* p = jeu.getEchiquier().getPiece(x, y);

            c->setPiece(p);
            bool isEchec = false;

            if (dynamic_cast<Roi*>(p))
            {
                Joueur& j = p->isWhite() ? dynamic_cast<Joueur&>(jeu.getJoueurBlanc()) : dynamic_cast<Joueur&>(jeu.getJoueurNoir());
                isEchec = j.isEchec(jeu.getEchiquier(), j.isWhite() ? dynamic_cast<Joueur&>(jeu.getJoueurNoir()) : jeu.getJoueurBlanc());
            }

            c->setIsEchec(isEchec);
        }
    }
}

void MainWindow::caseClicked(PieceWidget* source)
{
    resetHighlight();

    if (jeu.getIsFini())
    {
        return;
    }

    if (selectedPiece
        && selectedPiece->isWhite() == jeu.getJoueurActif()->isWhite()
        && selectedPiece->mouvementValide(jeu.getEchiquier(), source->x(), source->y()))
    {
        log(selectedPiece, selectedPiece->x(), selectedPiece->y(), source->x(), source->y());

        jeu.getEchiquier().deplacer(selectedPiece, source->x(), source->y());

        checkPromotion(source->x(), source->y());

        updateBoard();

        selectedPiece = nullptr;

        prochainJoueur();
    }
    else if (!jeu.getJoueurActif()->getIsIA())
    {
        if (selectedPiece && source->getPiece() == selectedPiece)
        {
            resetHighlight();
            selectedPiece = nullptr;
        }
        else
        {
            selectedPiece = source->getPiece();

            if (selectedPiece && selectedPiece->isWhite() == jeu.getJoueurActif()->isWhite())
            {
                auto mValides = selectedPiece->getMouvementsValides(jeu.getEchiquier());

                for (auto& m : mValides)
                {
                    m_cases[( m.second - 1 ) + 8 * ( m.first - 1 )]->setHighlighted(true);
                }
            }
        }
    }
}

void MainWindow::joueurTimeout(Joueur *gagnant, Joueur *perdant)
{
    resetHighlight();

    QString g = gagnant->isWhite() ? "Joueur blanc" : "Joueur noir";
    QString p = perdant->isWhite() ? "Joueur blanc" : "Joueur noir";

    logsDialog->log(g + " gagne la partie au temps");

    QMessageBox::information(this, "Temps écoulé", p + " n'a plus de temps. " + g + " gagne la partie !");
}

void MainWindow::iaBlancPlayed()
{
    auto* ia = jeu.getIA(true);
    log(ia->lastPiece, ia->lastStartX, ia->lastStartY, ia->lastEndX, ia->lastEndY);

    selectedPiece = ia->lastPiece;
    checkPromotion(ia->lastEndX, ia->lastEndY);

    iaPlayed();
}

void MainWindow::iaNoirPlayed()
{
    auto* ia = jeu.getIA(false);
    log(ia->lastPiece, ia->lastStartX, ia->lastStartY, ia->lastEndX, ia->lastEndY);

    selectedPiece = ia->lastPiece;
    checkPromotion(ia->lastEndX, ia->lastEndY);

    iaPlayed();
}

void MainWindow::resetHighlight()
{
    for (auto& c : m_cases)
    {
        c->setHighlighted(false);
    }
}

void MainWindow::prochainJoueur()
{
    if (jeu.getIsFini())
    {
        return;
    }

    if (!jeu.prochainJoueur())
    {
        updateBoard();
        QString joueur = jeu.getJoueurActif()->isWhite() ? "Joueur noir" : "Joueur blanc";
        logsDialog->log(joueur + " gagne la partie");
        QMessageBox::information(this, "Echec et mat", "Echec et mat ! " + joueur + " gagne la partie !");
    }
    else if (jeu.getJoueurActif()->getIsIA())
    {
        jeu.getIA(jeu.getJoueurActif()->isWhite())->play(jeu.getEchiquier(), jeu.getFEN());
    }
}

void MainWindow::log(Piece* piece, int startX, int startY, int endX, int endY)
{
    QString joueur = jeu.getJoueurActif()->isWhite() ? "blanc" : "noir";
    QString startCoords = Utils::getDisplayCoords(std::pair<int, int>(startX, startY));
    QString endCoords = Utils::getDisplayCoords(std::pair<int, int>(endX, endY));

    logsDialog->log(Utils::getPieceDisplayName(piece) + " " + joueur + " " + startCoords + " -> " + endCoords);
}

void MainWindow::iaPlayed()
{
    prochainJoueur();
    updateBoard();
}

void MainWindow::checkPromotion(int x, int y)
{
    if(jeu.getEchiquier().piecePromotable(selectedPiece)){
        Piece::PiecePromotion piecePromo = Piece::Default;
        QString textPromo;
        QString anciennePieceName = Utils::getPieceDisplayName(selectedPiece);

        if (!jeu.getJoueurActif()->getIsIA())
        {
            QMessageBox choixPromo;
            choixPromo.setText("Votre pion peut être promu.");
            choixPromo.setInformativeText("Choisissez en quel piece le pion doit être promu.");

            QPushButton* btnTour = choixPromo.addButton("Tour", QMessageBox::AcceptRole);
            QPushButton* btnCavalier = choixPromo.addButton("Cavalier", QMessageBox::AcceptRole);
            QPushButton* btnFou = choixPromo.addButton("Fou", QMessageBox::AcceptRole);
            QPushButton* btnReine = choixPromo.addButton("Reine", QMessageBox::AcceptRole);

            QPushButton* btnPromo;
            choixPromo.exec();
            btnPromo = (QPushButton*)choixPromo.clickedButton();

            if(btnPromo == btnTour){
                piecePromo = Piece::PromoTour;
                textPromo = "Tour";
            }
            else if(btnPromo == btnCavalier){
                piecePromo = Piece::PromoCavalier;
                textPromo = "Cavalier";
            }
            else if(btnPromo == btnFou){
                piecePromo = Piece::PromoFou;
                textPromo = "Fou";
            }
            else if(btnPromo == btnReine){
                piecePromo = Piece::PromoReine;
                textPromo = "Reine";
            }
        }
        else
        {
            piecePromo = Piece::PromoReine;
            textPromo = "Reine";
        }

        if(piecePromo != Piece::Default){
            jeu.promotionPiece(selectedPiece, piecePromo);

            QString joueur = jeu.getJoueurActif()->isWhite() ? "blanc" : "noir";
            QString endCoords = Utils::getDisplayCoords(std::pair<int, int>(x, y));

            logsDialog->log(anciennePieceName + " " + joueur + " " + endCoords + " promu en " + textPromo);
        }
    }
}

void MainWindow::on_pushButton_clicked()
{
    const auto ret = QMessageBox::question(this, "Quitter", "Voulez-vous vraiment quitter la partie en cours et en commencer une nouvelle ?");

    if (ret == QMessageBox::Yes)
    {
        QApplication::exit(42);
    }
}

