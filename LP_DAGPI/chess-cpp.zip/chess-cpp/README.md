# Projet Chess

## Fonctionnalités
 - Mouvements des pièces
 - Petit/grand roque
 - Détection de mise en échec
 - Détection d'échec et mat
 - Parties joueur contre joueur en mode console (argument de lancement --console)
 - Mode graphique avec Qt6
	 - Parties contre l'IA
	 - IA basique (choix aléatoires)
	 - IA avancée (utilisation du moteur open source Stockfish)
	 - Parties chronométrées
	 - Choix des paramètres de la partie
	 - Possibilité de recommencer une partie en changeant les paramètres

**/!\ WARNING /!\\** : L'IA avancée ne fonctionne pas sous MacOS.

## Compiler et exécuter
Le projet dépend de Qt (version >= 6.0) : il faut avoir installé l'environnement de développement Qt via https://www.qt.io/download-qt-installer

### Windows
Exécuter le script `win-build-and-run.bat` (un simple double-clic dessus devrait suffire). L'argument `--console` peut être ajouté pour lancer le programme en mode console (sans interface graphique).

Il peut être nécessaire d'éditer le chemin d'installation de Qt dans le script :

    set QTDIR=C:\Qt\6.4.0\mingw_64

    set MINGWDIR=C:\Qt\Tools\mingw1120_64\bin
 
Vérifier que le chemin est correct, et changer si besoin `6.4.0` et/ou `mingw1120_64` pour correspondre aux versions installées sur le système.

### Linux
Installer les outils de compilation si nécessaire :

    sudo apt install build-essential

Rendre exécutable le script et lancer le script :

    chmod +x linux-build-and-run.sh
    ./linux-build-and-run.sh

Il peut être nécessaire d'éditer le chemin d'installation de Qt dans le script :

    QTDIR=~/Qt/6.4.0/gcc_64
 
Vérifier que le chemin est correct, et changer si besoin `6.4.0` pour correspondre à la version installée sur le système.

## Tests
Les tests sont exécutés dans un projet séparé `ChessTest`.
La procédure pour compiler et exécuter les tests est la même que pour le programme principal, mais en utilisant les scripts ayant le suffixe `-tests`.
