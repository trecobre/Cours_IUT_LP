#ifndef UTILS_H
#define UTILS_H

#include <QTextStream>
#include <QString>
#include "Piece.h"

class Utils
{
public:
    static QTextStream cout() {return QTextStream(stdout);};
    static QTextStream cin() {return QTextStream(stdin);};
    static char endl() {return '\n';};

    /**
     * @brief Convertir des coordonnées visuelles type 'B3' en coordonnées réelles x et y
     * @param Coordonnées telles que vues sur le plateau
     * @return tableau de 2 entiers {x, y}
     */
    static std::unique_ptr<int> getCoords(QString displayCoords)
    {
        QString lettres = "ABCDEFGH";
        QString nombres = "12345678";
        displayCoords = displayCoords.toUpper();

        if (displayCoords.size() != 2 || !lettres.contains(displayCoords[0]) || !nombres.contains(displayCoords[1]))
        {
            return nullptr;
        }

        std::unique_ptr<int> coords;
        coords.reset(new int[2]);

        coords.get()[0] = displayCoords[0].toLatin1() - 64;

        coords.get()[1] = displayCoords[1].digitValue();

        return coords;
    }

    static QString getDisplayCoords(std::pair<int, int> coords)
    {
        QString ret = "";

        ret += QChar::fromLatin1(coords.first + 64);
        ret += QString::number(coords.second);

        return ret;
    }

    static QString getPieceDisplayName(Piece* piece)
    {
        if (dynamic_cast<Pion*>(piece))
        {
            return "Pion";
        }
        else if (dynamic_cast<Reine*>(piece))
        {
            return "Reine";
        }
        else if (dynamic_cast<Tour*>(piece))
        {
            return "Tour";
        }
        else if (dynamic_cast<Fou*>(piece))
        {
            return "Fou";
        }
        else if (dynamic_cast<Cavalier*>(piece))
        {
            return "Cavalier";
        }
        else if (dynamic_cast<Roi*>(piece))
        {
            return "Roi";
        }

        return "Piece";
    }

    static QString formatNumber(int number)
    {
        QString nStr = QString::number(number);

        if (nStr.size() == 1)
        {
            nStr = "0" + nStr;
        }

        return nStr;
    }
};

#endif // UTILS_H
