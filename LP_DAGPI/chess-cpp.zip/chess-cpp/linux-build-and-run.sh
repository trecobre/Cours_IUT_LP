#!/bin/bash

QTDIR=~/Qt/6.4.0/gcc_64

PATH=$PATH:$QTDIR/bin

mkdir Build

qmake6 Chess.pro -o Build/
cd Build
make -j$(nproc)

./Chess $1

cd ..