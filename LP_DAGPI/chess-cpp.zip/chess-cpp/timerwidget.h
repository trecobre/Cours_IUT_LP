#ifndef TIMERWIDGET_H
#define TIMERWIDGET_H

#include <QWidget>
#include "Joueur.h"

namespace Ui {
class TimerWidget;
}

class TimerWidget : public QWidget
{
    Q_OBJECT

public:
    explicit TimerWidget(Joueur* joueur, QWidget *parent = nullptr);
    ~TimerWidget();

private slots:
    void updateTimer();

private:
    Ui::TimerWidget *ui;
    Joueur* m_joueur;

    bool isRed = false;
};

#endif // TIMERWIDGET_H
