<?php

    //---EXERCICE 1---//
    /*$a = 1;
    $b = 0;
    $c = 0;
    do{
        $a = (rand(0,100))%2;
        $b = (rand(0,100))%2;
        $c = (rand(0,100))%2;
        print("$a $b $c\n");
    }while($a == 1 OR $b == 0 OR $c == 0);*/

    //---EXERCICE 2---//
  /*$d = rand(100, 1000);
    $e = 0;
    $cpt = 0;
    while($d !== $e){
        $cpt++;
        $e = rand(100, 1000);
    }
    print("$d, $e, $cpt");

    $cpt2 = 0;
    for($f = 0; $d != $f; $cpt2++){
        $f = rand(100, 1000);
    }
    print("\n$d, $f, $cpt2");*/

    //---EXERCICE 3---//
    /*for($g=11; $g<=36; $g++){
        $ascii = $g+54;
        $tab[$g] = chr($ascii);
    }
    for($h=11; $h<=36; $h++){
        print($tab[$h]);
    }
    foreach($tab as $i){
        print($i);
    }*/
?>