/**
 * Programme test de Piece
 *
 * @file testPiece.cxx
 */

// Utile pour l'affichage
#include <iostream>
#include "Piece.h"
#include "Joueur.h"
#include "Echiquier.h"

// Pour utiliser les flux de iostream sans mettre "std::" tout le temps.
using namespace std;

bool
comparePiece( const Piece &p, const Piece &q )
{
    bool r = ( p.x() == q.x() ) && ( p.y() == q.y() ) && ( p.isWhite() == q.isWhite() );
    // p.move( 0, 0 ); // protection const du passage par reference
    return r;
}

/**
 * Programme principal
 */
int
main( int argc, char **argv )
{
#if 0
    // instancie un objet p1 de type Piece
    Piece p1;
    // p1 est une piece blanche de coordonnees (3,3)
    p1.init( 3, 3, true );

    Piece p2( 4, 4, false );

    // On l'affiche
    p1.affiche();
    p2.affiche();

    if ( comparePiece( p1, p2 ) )
        cout << "Pieces identiques" << endl;
    else
        cout << "Pieces differentes" << endl;

    Piece p3 = p1;  // construction par copie
    p3.affiche();
    Piece p4( p1 );  // idem
    p4.affiche();
    Piece p5 = Piece( p1 );  // idem
    p5.affiche();

    p5 = p4 = p2;
    // p5      = ( p4 = p2 );
    // p5.operator=( p4.operator=( p2 ) );

    cout << "plusforte:" << endl;
    p5 = p1.plusforte( p2 );
    p5.affiche();

    Piece  tbl[4];
    Piece *ptr = nullptr;      // Pointeur null
    ptr        = &( tbl[0] );  // ptr pointe vers tbl[ 0 ]
    ptr        = tbl;          // Idem
    ptr->init( 1, 1, true );
    ( *ptr ).affiche();        // Affiche la piece tbl[ 0 ]
    ptr->affiche();            // Idem
    tbl->affiche();            // Idem
    ptr++;                     // ptr pointe vers tbl[ 1 ]
#endif

    Echiquier e;
    Joueur jb( true );
    Joueur jn( false );
    jb.placerPieces( e );
    jn.placerPieces( e );
    e.affiche();

    Piece p( 1, 1, true );
    cout << ( p.mouvementValide( e, 2, 2 ) ? "mouvement Valide" : "mouvement Invalide" ) << endl;

    return EXIT_SUCCESS;
    // les objets definis dans cette fonction sont automatiquement detruits.
    // Ex : p1
}
