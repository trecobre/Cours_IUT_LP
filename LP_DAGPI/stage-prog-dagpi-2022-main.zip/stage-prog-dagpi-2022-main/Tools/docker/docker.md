# Install

## Installation on MacOS/VMware
~~~bash
brew install docker docker-machine
docker-machine create --driver vmwarefusion main
eval $(docker-machine env main)
docker-machine status main
docker-machine stop main
docker-machine start main
~~~

## Installation on Debian/Ubuntu
~~~bash
sudo apt-get update && apt-get install -y curl
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo apt-key add -
sudo apt install -y software-properties-common
sudo add-apt-repository "deb [arch=amd64] https://download.docker.com/linux/ubuntu $(lsb_release -cs) stable"
sudo apt-get update
sudo apt install -y docker-ce
sudo usermod -aG docker ${USER}
newgrp docker
~~~

# Commands

## Basic commands
~~~bash
docker run hello-world
docker run gcc
docker images
docker run -it gcc
~~~

## Pull an image
~~~bash
docker pull ubuntu
~~~

## Run processes in isolated containers
~~~bash
docker run -it ubuntu
~~~

## List containers
~~~bash
docker ps -a # all
docker ps -l # last created
~~~

## Commit changes made in the image
~~~bash
docker commit -m "Install standard packages for C/C++ Fortran and Python development" -a "Pierre Ramet" 157ade00bedb ramet/ubuntu-pt4
~~~

## Tag an image
~~~bash
docker tag ramet/ubuntu-pt4 tthor/ubuntu-pt4
~~~

## Push an image on https://hub.docker.com/ (to be available anywhere with a pull)
~~~bash
docker login --username=tthor
docker push tthor/ubuntu-pt4
~~~

## Build an image from a Dockerfile
~~~bash
docker build -t tthor/test .
# the content of the path . will be included in the image
# we suppose here that the Dockerfile is located in ./Dockerfile
~~~

## See Docker disk usage
~~~bash
docker system df
~~~

## Clean Docker containers and images
~~~bash
docker stop $(docker ps -a -q)
docker rm $(docker ps -a -q)
docker rmi $(docker images -a -q)
# see also
docker system prune
~~~

# Docker with X11

# set auth connections and allow network in XQuartz preferences
~~~bash
# IP=$(ifconfig en0 | grep inet | awk '$1=="inet" {print $2}')
# xhost + $IP
export HOSTNAME=`hostname`
xhost + $HOSTNAME
docker run -e DISPLAY=$HOSTNAME:0 -v /tmp/.X11-unix:/tmp/.X11-unix -it tthor/test
# inside docker : sudo apt-get install x11-apps
~~~

# Docker with tightvncserver
~~~bash
# use vncclient with `docker-machine ip`:5901
docker run -p 5901:5901 -it tthor/test
# inside docker :
sudo apt-get install fluxbox tightvncserver
export USER=gitlab
tightvncserver
export DISPLAY=localhost:1
# fluxbox
lxterm
~~~

# Docker with WSL

## WSL1

- native MacOS
  - VMware Windows 10
    - Docker for Windows (can switch between Windows and Linux containers)
      - Hyper-V VM
    - WSL1
      - Docker (as a client on Docker server from upper level)

## WSL2

- native MacOS
  - VMware Windows 10
    - Hyper-V VM
      - WSL2
        - Docker (Linux containers only)
