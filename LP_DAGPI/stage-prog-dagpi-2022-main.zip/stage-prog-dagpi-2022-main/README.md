# Chess
[![pipeline status](https://gitlab-ce.iut.u-bordeaux.fr/poo-lpro-22/stage-prog-sil-2022/badges/master/pipeline.svg)](https://gitlab-ce.iut.u-bordeaux.fr/poo-lpro-22/stage-prog-sil-2022/pipelines) [![coverage report](https://gitlab-ce.iut.u-bordeaux.fr/poo-lpro-22/stage-prog-sil-2022/badges/master/coverage.svg)](http://alee.iut.bx1:9000/dashboard?id=my%3Astage-prog-sil)

Simple Chess in C++ using VSCode

## Ressources

- Serveur `Discord` (discussions, questions, partage d'écran/audio pour demander une aide individuelle) : TODO:
- Dépôt `Gitlab` : https://gitlab-ce.iut.u-bordeaux.fr/poo-lpro-22/stage-prog-sil-2022
- Démo `VSCode + Gitlab` : https://gitlab-ce.iut.u-bordeaux.fr/Pierre/Hello
- Support `VSCode` : https://github.com/ramet/vscode

Vous disposez d'un serveur `Discord`, une fois que vous serez nommés sous le format "GxEy - Prénom Nom" (avec `x` votre groupe et `y` votre numéro d'équipe dans le groupe) vous serez automatiquement affectés dans les canaux texte/audio correspondant à votre équipe.

## Environnements

Plusieurs solutions seront possibles, l'objectif étant de disposer de l'éditeur `VSCode` et d'un compilateur `C/C++` (`clang` ou `gcc/g++`) avec les outils de développement associés.


### Docker

Si vous pouvez installer `Docker` sur votre machine, vous pourrez alors construire votre propre image, ou utiliser l'image [tthor/test](https://hub.docker.com/repository/docker/tthor/test)

```bash
docker pull tthor/test
docker run -it tthor/test
```

Voici les procédures pour installer `Docker` sous :

- [Linux](https://docs.docker.com/engine/install/debian/)
- [Windows](https://docs.docker.com/docker-for-windows/install/)
- [Mac](https://docs.docker.com/docker-for-mac/install/)

Je vous recommande d'utiliser l'éditeur `VSCode` dans votre environnement natif, et d'activer le plugin [remote-docker](https://code.visualstudio.com/docs/remote/containers-tutorial) afin de profiter du conteneur `Docker` pour compiler/exécuter/tester vos programmes. Un fichier de configuration [devcontainer](https://gitlab-ce.iut.u-bordeaux.fr/Pierre/prog_c_etd/-/blob/master/.devcontainer/devcontainer.json).

### Linux natif

Si vous disposez déjà d'un sytème Linux natif ou virtuel, vous pouvez simplement ajouter une liste des paquets avec les commandes suivantes (pour une distribution utilisant les paquets `.deb` comme `Debian` ou `Ubuntu`) :
```bash
sudo apt-get install \
  gcc \
  clang \
  clang-format \
  git \
  doxygen \
  python3-pip \
  cppcheck \
  lcov \
  gcovr \
  make \
  cmake \
  valgrind

sudo update-alternatives --install /usr/bin/python python /usr/bin/python3.7 1
sudo update-alternatives --install /usr/bin/python python /usr/bin/python2.7 2

wget -qO- https://packages.microsoft.com/keys/microsoft.asc | gpg --dearmor > packages.microsoft.gpg

sudo install -o root -g root -m 644 packages.microsoft.gpg /etc/apt/trusted.gpg.d/

sudo sh -c 'echo "deb [arch=amd64 signed-by=/etc/apt/trusted.gpg.d/packages.microsoft.gpg] https://packages.microsoft.com/repos/vscode stable main" > /etc/apt/sources.list.d/vscode.list'

sudo apt-get install apt-transport-https

sudo apt-get update

sudo apt-get install code
```

### VM VirtualBox

Voici les procédures pour installer 'VirtualBox' sous :

- [Linux](https://wiki.debian.org/VirtualBox)
- [Windows](https://www.virtualbox.org/manual/ch02.html#installation_windows)
- [Mac](https://www.virtualbox.org/manual/ch02.html#installation-mac)

Vous pouvez télécharger une image `Debian` avec les principaux outils pour la programmation C et la programmation système [image debian](https://box.iut.u-bordeaux.fr/f/614adb35b7694af2a844/).

Pour l'importer dans `VirtualBox` : Menu "Fichier / Importer un appareil virtuel" et sélectionner le fichier téléchargé avec l'extension `.ova`.

Les comptes disponibles dans cette VM sont :

- root / root
- user / user

### Windows WSL 1 ou 2

Si vous disposez d'une version récente de Windows 10, vous pouvez déployer facilement un environnement de développement `Linux` avec la fonctionnalité `WSL`.
Voici une [procédure](https://korben.info/installer-wsl2-windows-linux.html) d'installation.

Vous pourrez ensuite installer les paquets comme pour la solution `Linux natif` présentée ci-dessus.

Je vous recommande d'utiliser l'éditeur `VSCode` dans votre environnement natif, et d'activer le plugin [remote-wsl](https://code.visualstudio.com/docs/remote/wsl-tutorial) afin de compiler/exécuter/tester vos programmes dans l'environnement `WSL`. Voici un [tutoriel](https://code.visualstudio.com/docs/cpp/config-wsl) complet et une [vidéo](https://www.youtube.com/watch?v=voJlmtoU7Lc) associée.

## Comment dupliquer ce dépôt

Vous pouvez `forker` ce projet (la fourchette en haut à droite sur la page principale du dépôt) dans votre espace pour travailler tranquillement sur une copie privée, ou `commiter` dans ce dépôt si vous avez les droits de `Developer`.
Attention, lors du `fork` d'un projet, l’organisation (`issues`, `milestones`, `labels`) est réinitialisée.

Pour faire une copie intégrale du dépôt, il faut passer par la fonction `export/import` de `Gitlab` :  https://docs.gitlab.com/ee/user/project/settings/import_export.html .
La démarche est alors la suivante :
- depuis `Gitlab` : créer un nouveau projet (le `+` dans le bandeau principal), sélectionner `import project` puis  `from Gitlab export`,
- donner un nom au nouveau projet (par exemple `stage-prog-sil-2022-import`) et choisir le fichier d'export (https://gitlab-ce.iut.u-bordeaux.fr/poo-lpro-22/stage-prog-sil-2022/-/blob/master/stage-prog-sil-2022-export.tar.gz),
- lancer `import project`,
- vous avez votre copie personnelle du dépôt.

## Utilisation de Gitlab pour gérer son projet

Voici les étapes à suivre pour gérer efficacement votre projet.

### Constituer son équipe

Le `maintainer` doit constituer son équipe :
-	inviter les autres membres de l’équipe en tant que `developer`,
-	inviter votre enseignant `P. Ramet` en tant que `reporter`.

### Définir et affecter une `issue` (ou `user-story`)

Lorsque vous vous apprêtez à prendre une nouvelle tâche (une `issue`), rendez-vous dans la section `issues` et assignez-vous une `issue` de la liste `ToDo`. Les `issues` sont en fait des tâches à faire, elles peuvent être attribuées à une ou plusieurs personnes. Par défaut, vous avez les listes : `Open`, `ToDo`, `Doing`, `Closed`.

Vous pouvez aussi regrouper les `issues` par jalons (ou `milestones`), qui peuvent représenter par exemple des sprints dans une méthodologie agile. Le jalon est terminé lorsque toutes ses `issues` sont `Closed`.

***Note*** : Sous la présentation Gitlab `Board`, on peut déplacer facilement les différentes issues en fonction de leur état d’avancement.

### Créer une `merge request` pour débuter votre contribution

Une fois assigné, glissez l’`issue` vers la liste `Doing`. Ouvrez ensuite l’`issue` puis cliquez sur `Create Merge Request`. Cette action va créer automatiquement une `merge-request` avec le statut `WIP` (Work In Progress). La branche de travail associée à cette dernière est également créée.
Dans votre environnement de développement, pensez à faire un `git pull` pour être sûr d’être à jour. La nouvelle branche que vous venez de créer a été synchronisée. Basculez sur cette branche avec un `git switch` (ou `git checkout` si votre `git` n'est pas suffisamment récent).

***Note*** : Vous avez toujours accès au dépôt https://gitlab-ce.iut.u-bordeaux.fr/Pierre/DEMO-GIT-PT2 pour un rappel des commandes `git` basiques.

### Passez en mode relecture (ou `review`)

Une fois l’`issue` traitée, allez voir dans `GitLab` votre `merge-request`. Il se peut que vous ayez des conflits à régler. Vous pouvez tenter de les résoudre automatiquement sur l'interface web de `GitLab`, ou via votre environnement de développement. Une fois résolu, faites un `git commit` pour valider votre `merge`.

On vous recommande de `rebaser` votre branche de travail par rapport à la branche stable (`master` ou `develop`). Des conflits vont probablement apparaître si des contributions ont été intégrées entre temps sur la branche stable. Résolvez-les puis faites un `git rebase -continue` pour valider votre `merge`.

Vérifiez sur `GitLab` que votre problème de `Merge Conflit` a bien disparu.
Puis, cliquez sur `Resolve Wip Status` afin de montrer que le travail est terminé pour cette `merge-request`.

### Attendre les relectures de vos co-équipiers

Prenez en compte les retours proposés par vos relecteurs. Pensez à fermer les discussions pour chaque commentaire lorsque vous avez résolu le problème.
Si tout s’est bien passé, votre relecteur se chargera de faire le `Merge` final de votre branche. L'`issue`sera automatiquement fermée (`Closed`).

***Note*** : Vous pouvez mentionner une `issue` dans le message associé à vos `commit` pour y faire référence. Un message `fix issue #xxx` (avec `xxx` le numéro de l'`issue`) fermera automatiquement cette `issue`. Vous pouvez également faire référence à une autre `merge-request` avec un message contenant `#yyy` (avec `yyy` le numéro de la `merge-request`).

### En tant que relecteur

Une fois un premier `commit` effectué, il est possible de discuter directement sur la contribution (`merge-request`). Il faut alors ouvrir l'onglet `Changes`. Normalement, en tant que `Developer` vous n'avez pas les droits pour `Merger` cette `issue` dans la branche `master` du dépôt principal. Lorsque vous avez fini votre relecture et que vous n'avez plus de remarques, vous pouvez `lever le pouce` pour indiquer que de votre point de vue, cette `issue` peut-être fusionnée.

### Conditions nécessaires pour fusionner une `merge-request`

Comme dit précédemment, vous devez régler les conflits (`Merge Conflit`) et retirer le statut `WIP` de votre `merge-request`.

Dans `Settings/General/Merge Requests/Merge checks`, il est conseillé de définir les règles suivantes :

- [x] `Pipelines must succeed`
- [x] `All discussions must be resolved`

Vous pouvez également imposer que votre contribution soit `rebasée` avant d'être fusionnée en sélectionnant dans `Settings/General/Merge Requests/Merge method` l'une des deux méthodes suivantes :

- [x] `Merge commit with semi-linear history`
- [ ] `Fast-forward merge`

Vous trouverez également deux fichiers cachés à la racine de ce dépôt :

- `.gitignore` : pour définir les règles afin d'ignorer les fichiers temporaires Visual Studio,
- `.gitlab-ci.yml` : pour mettre en place un pipeline d'intégration continue minimal.

### Estimation du temps d'une `issue`

***Ceci est facultatif*** : ceux qui le souhaitent peuvent essayer, vous en tirerez une expérience intéressante !

Il est possible de saisir des estimations du temps passé sur une `issue` en écrivant dans le champs commentaire :
- /estimate \<temps\> : pour ajouter une estimation
- /spend \<temps\> : pour indiquer le temps passé

Le temps se décline en :
- mo : mois
- w : semaines
- d : jours
- h : heures
- m : minutes

La barre de progression du jalon pourra en tenir compte.
