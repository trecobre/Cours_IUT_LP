let isFirstThemeChange = true;

$(document).ready(function () {
  setSticky();
  // Initialisation des variables
  var elem;
  var checkbox = document.getElementById("theme");
  var burger = document.getElementById("btn-burger");

  // Application des attributs aux éléments
  $(".hidden").hide();
  if(window.innerWidth > 980){
    $('#scroll_detector').visibility({
      once: false,
      onBottomPassed: function () {
        $(".ui.header.medium.grid").fadeOut("fast", function () {
          $(".ui.header.medium.grid").addClass('sticky');
          $(".ui.header.medium.grid").show();
          setSticky();
          $(".ui.header.medium.grid").hide();
          $(".ui.header.medium.grid").fadeIn("fast");
        });
      },
      onBottomPassedReverse: function () {
        $(".ui.header.medium.grid").fadeOut("fast", function () {
          $(".ui.header.medium.grid").removeClass('sticky');
          $(".ui.header.medium.grid").fadeIn("fast");
        });
      }
    });
  }

  $('.counter-animation').visibility({
    once: true,
    onTopVisible: function() {
      const target_value = Number($(this).attr('target-value'));
      let speed = Number($(this).attr('counter-speed'));
      if (isNaN(speed)) speed = 1;
      let value = 0;
      let elem = $(this);

      let interval = setInterval(function() {
        value += speed;
        if (value >= target_value) 
        {
          clearInterval(interval);
          value = target_value;
        }
        elem.html(value);
      }, 10);
    }
  })


  if (sessionStorage.getItem("cookie") == null) {
    setCookieMessage();
  }

  if (sessionStorage.getItem("darkmode") == null) {
    sessionStorage.setItem("darkmode", $("#dark-mode").attr("value"))
  }

  if (window.location.origin + "/" == window.location.href) {
    $(".ui.header.medium.grid").removeClass('sticky');
  }

  // event listener
  checkbox.addEventListener('change', function () {
    if (this.checked) {
      sessionStorage.setItem("darkmode", "true");
    } else {
      sessionStorage.setItem("darkmode", "false");
    }
    change_theme();
  });

  burger.addEventListener('click', function(){
    $("#header-sidebar").addClass("visible");
    $("#header-sidebar").fadeIn("fast");
  });

  document.getElementById("body").addEventListener('click', function(){
    $("#header-sidebar").fadeOut("fast", function(){
      $("#header-sidebar").removeClass("visible");
    });
  });
  if(document.getElementsByClassName("masthead").item(0) != null){
    document.getElementsByClassName("masthead").item(0).addEventListener('click', function(){
      $("#header-sidebar").fadeOut("fast", function(){
        $("#header-sidebar").removeClass("visible");
      });
    });
  }
  

  // fonctions
  function change_theme() {
    let isDark = sessionStorage.getItem("darkmode") == "true";
    let label = document.getElementById("label-theme");
    if (isDark) {
      document.getElementById("semantic-dark").setAttribute("href", '/semantic/semantic.dark.min.css');
      document.getElementById("dark-mode").setAttribute("href", '/stylesheets/style.dark.css');
      $("#header .ui, #header-mobile .ui, footer .ui, .info-segment, .message").addClass("inverted");
      $("footer button").removeClass("inverted");
      $(".header-logo>img").attr("src", "/resources/EvetechDarker.png")
      $(".connected_students_profile_pic_icon").attr("src", "/resources/profile_pic_icon_white.png");
      label.innerHTML = "Thème sombre";
      document.getElementById("theme").checked = true;
    }
    else {
      document.getElementById("semantic-dark").setAttribute("href", '');
      document.getElementById("dark-mode").setAttribute("href", '');
      $("#header .ui, #header-mobile .ui, footer .ui, .info-segment, .message").removeClass("inverted");
      $(".header-logo>img").attr("src", "/resources/EvetechLighter.png");
      $(".connected_students_profile_pic_icon").attr("src", "/resources/profile_pic_icon.png");
      label.innerHTML = "Thème clair";
      document.getElementById("theme").checked = false;
    }

    if (isFirstThemeChange) {
      isFirstThemeChange = false;

      setTimeout(() => $("#theme-transition").html("* {transition: background-color 100ms linear;}"), 1000);
    }

    $.get(`/api/theme?theme=${isDark ? 'dark' : 'light'}`);
  }

  function setSticky() {
    $('.ui.sticky').sticky({
      context: '#body'
    });
  }

  function setCookieMessage() {
    var buttonYes = document.createElement('div');
    var buttonNo = document.createElement('div');
    if(window.innerWidth > 980){
      buttonYes.className = "ui tiny right attached positive ok button";
      buttonNo.className = "ui tiny left attached negative no button";
    }
    else{
      buttonYes.className = "ui mini bottom attached positive ok button";
      buttonNo.className = "ui mini top attached negative no button" ;
    }
    
    buttonYes.innerHTML = '<i class="checkmark icon"></i>Accepter';
    buttonNo.innerHTML = '<i class="remove icon"></i>Refuser';

    buttonYes.addEventListener("click", function () {
      sessionStorage.setItem("cookie", "oui");
      document.body.removeChild(elem);
    })
    buttonNo.addEventListener("click", function () {
      sessionStorage.setItem("cookie", "non");
      document.body.removeChild(elem);
    })
    elem = document.createElement("div");
    elem.className = "ui message";
    elem.id = "cookie-popup";
    var cookie_text = "Ce site web utilise les cookies (non) acceptez vous les cookies ?";
    elem.innerHTML = '<div class="ui content"><p>' + cookie_text + '</p><div class="item actions"></div></div>';
    elem.getElementsByClassName("actions").item(0).appendChild(buttonNo);
    elem.getElementsByClassName("actions").item(0).appendChild(buttonYes);
    document.body.appendChild(elem);
  }

  change_theme();
});