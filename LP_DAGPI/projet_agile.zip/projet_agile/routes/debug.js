var express = require('express');
var router = express.Router();
const mongoose = require('mongoose');
const User = mongoose.model('User');
const Item = mongoose.model('Item');
const bcrypt = require('bcrypt');

router.get('/', async function(req, res, next) {
  res.send(req.session.loggedin ? req.session.username : "Not logged in.");
});

router.get('/user', async function(req, res, next) {
  await User.deleteOne({username: "roger"});
  let pass = "mdproger";
  let hash = await bcrypt.hash(pass, 10);
  const all_items = await Item.find({});

  let items = [];
  let index = 0;
  for (const i of all_items) {
    items.push({
      item_id: i._id,
      slot: index
    });

    index++;
  }
  const testUser = new User({username: "roger", prenom: "Roger", nom: "Dupont", password: hash, items: items});
  await testUser.save();
  res.send(testUser.username);
});

router.get('/password', async function(req, res, next) {
  const testUser = await User.findOne({username: "Roger"});
  res.send('Password: ' + testUser.password);
});

module.exports = router;
