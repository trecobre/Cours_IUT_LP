var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function (req, res, next) {
    if (res.user)
    {
        return res.render('inventaire', { title: 'Inventaire', user: res.user });
    }

    res.redirect('/');
});

module.exports = router;