var express = require('express');
var router = express.Router();
const mongoose = require('mongoose');
const User = mongoose.model('User');
const Item = mongoose.model('Item');
const Matiere = mongoose.model('Matiere');
const bcrypt = require('bcrypt');

router.get('/theme', async function(req, res) {
    if (req.query.theme) req.session.theme = req.query.theme;

    res.status(200).send(req.session.theme);
});

/* Login */
router.post('/auth', async function (req, res, next) {
    const in_username = req.body.username;
    const in_password = req.body.password;

    if (!in_username || !in_password)
    {
        return res.sendStatus(400);
    }

    const user = await User.findOne({username: in_username});

    if (!user)
    {
        return res.sendStatus(400);
    }

    const password_valid = await bcrypt.compare(in_password, user.password);

    if (!password_valid)
    {
        return res.sendStatus(403);
    }

    req.session.loggedin = true;
	req.session.username = in_username;

    res.sendStatus(200);
});

/* Logout */
router.delete('/auth', async function (req, res, next) {
    req.session.loggedin = false;
	req.session.username = "";

    res.sendStatus(200);
});

/* Get items list */
router.get('/items', async function(req, res) {
    res.send(await Item.find({}));
});

/* Get a specific item */
router.get('/items/:id', async function(req, res) {
    let item = await Item.findById(req.params.id);

    if (!item) return res.sendStatus(404);

    res.send(item);
});

/* Get items of a specific user. If the user is logged, get also items and stats. */
router.get('/user/:username', async function(req, res) {
    const user = await User.findOne({username: req.params.username});

    if (!user) return res.sendStatus(404);

    const isLoggedUser = user.username == req.session.username;

    let user_stats = {};

    if (isLoggedUser)
    {
        const stats = await Matiere.find();

        let getStat = (code) => {
            for (const stat of stats) {
                if (stat.code == code) return stat;
            }
        }

        for (const i of user.items) {
            const item = await Item.findById(i.item_id);

            for (const s of item.matieres) {
                const stat = getStat(s.code);
                
                if(!user_stats[stat.code]) user_stats[stat.code] = { name: stat.name, tag: stat.tag, amount: 0 };

                user_stats[stat.code].amount += s.amount;
            }
        }
    }

    res.status(200).send({username: user.username, items: isLoggedUser ? user.items : [], stats: user_stats});
});

/* Move an item from sourceSlot to targetSlot */
router.post('/moveitem', async function(req, res) {
    if (!req.session.username) return res.sendStatus(403);

    let user = await User.findOne({username: req.session.username});

    if (!user) return res.sendStatus(404);

    req.body.sourceSlot = Number(req.body.sourceSlot);
    req.body.targetSlot = Number(req.body.targetSlot);

    if (isNaN(req.body.sourceSlot) || isNaN(req.body.targetSlot) || req.body.sourceSlot == req.body.targetSlot || req.body.targetSlot > 99) return res.sendStatus(400);

    let itemSlot;
    let targetSlotEmpty = true;
    let index = 0;

    for (const i of user.items)
    {
        if (i.slot == req.body.sourceSlot)
        {
            itemSlot = index;
        }

        if (i.slot == req.body.targetSlot) targetSlotEmpty = false;

        index++;
    }

    if (itemSlot == undefined || !targetSlotEmpty) return res.sendStatus(400);

    user.items[itemSlot].slot = req.body.targetSlot;

    await user.save();

    res.sendStatus(200);
});

router.get('/stats', async function(req, res) {
    res.send(await Matiere.find({}));
});

module.exports = router;
