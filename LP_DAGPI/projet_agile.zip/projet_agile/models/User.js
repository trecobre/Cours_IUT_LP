const mongoose = require('mongoose');

const userSchema = mongoose.Schema({
    username: String,
    password: String,
    prenom: String,
    nom: String,
    items: [{item_id: mongoose.Schema.Types.ObjectId, slot: Number}],
    main_item: mongoose.Schema.Types.ObjectId,
    matieres: [{code: Number, amount: Number}]
});

mongoose.model('User', userSchema);