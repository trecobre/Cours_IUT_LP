const mongoose = require('mongoose');

const itemSchema = mongoose.Schema({
    name: String,
    description: String,
    image: String,
    matieres: [{code: Number, amount: Number}]
});

mongoose.model('Item', itemSchema);