const mongoose = require('mongoose');

const statSchema = mongoose.Schema({
    name: String,
    tag: String,
    code: Number
});

mongoose.model('Matiere', statSchema);