# API Documentation

* [Error handling](errors.md)
* [Versioning](version.md)
* [Common](context.md)
* [Getting and setting chunk data](chunk.md)
* [Decoder API](decode.md)
* [Encoder API](encode.md)
