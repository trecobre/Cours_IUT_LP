
ENCODE="test encode image"

echo ">> "$ENCODE 

./main -encode otter.bmp "$ENCODE" encoded.bmp
if [ $? -eq 0 ]; then 
    echo ">> image encoded" 
else
    echo ">> image not encoded"
fi

echo ">> test decode image"

DECODE="$(./main -decode encoded.bmp)"
if [ $? -eq 0 ]; then 
    echo ">> image decoded" 
else
    echo ">> image not decoded"
fi


if [ "$ENCODE" = "$DECODE" ]; then 
    echo "Same text at encode and decode, program runs succesfully"
else
    echo "Different text at encode and decode, program occures an error"
fi

python3 wrapper.py &
sleep 5

ENCODE="test-encode-image-with-cURL"

echo ">> "$ENCODE 

TEXT="text="$ENCODE

curl -F "input=@otter.bmp" -F "$TEXT" localhost:5000/encode --output output.bmp
if [ $? -eq 0 ]; then 
    DATA="$(cat output.bmp)"
    if [ "$DATA" = "NO" ]; then
        echo ">> image not encoded with cURL. Output = $(cat output.bmp)" 
    elif [ "$DATA" = *"<!doctype html>"* ]; then
        echo ">> image not encoded with cURL. Output = $(cat output.bmp)" 
    else
        echo ">> image encoded with cURL." 
    fi
else
    echo ">> image not encoded with cURL"
fi

echo ">> test decode image"

DECODE="$(curl -F "input=@output.bmp" localhost:5000/decode)"
echo ">> "$DECODE
if [ $? -eq 0 ]; then 
    echo ">> image decoded" 
else
    echo ">> image not decoded"
fi


if [ "$ENCODE" = "$DECODE" ]; then 
    echo "Same text at encode and decode, program runs succesfully"
else
    echo "Different text at encode and decode, program occures an error"
fi

SERVER="$(pgrep python3)"
kill $SERVER