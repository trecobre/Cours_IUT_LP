from cgitb import text
from flask import Flask, request, send_file
import os

app = Flask(__name__)

UPLOAD_FOLDER = '.'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/encode', methods=['GET', 'POST'])
def encodeIndex():
    file = request.files['input']
    file_path = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
    file.save(file_path)
    text = request.form.get('tex')
    output_img = "/tmp/test.bmp"
    if not ("ubf-steganography" in os.getcwd()):
        done = os.chdir("ubf-steganography")
    os.system("make")
    done = os.system("./main -encode " + file_path + " " + text + " " + output_img)
    file.close()
    if(done==0):
        return send_file(output_img)
    return "NO"

@app.route('/decode', methods=['GET', 'POST'])
def decodeIndex():
    file = request.files['input']
    file_path = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
    file.save(file_path)
    if not ("ubf-steganography" in os.getcwd()):
        os.chdir("ubf-steganography")
    os.system("make")
    text = os.popen("./main -decode "+file_path).read()
    if(text!=None):
        return "" + text 
    return "NO"

app.run(host='0.0.0.0', port=5000)