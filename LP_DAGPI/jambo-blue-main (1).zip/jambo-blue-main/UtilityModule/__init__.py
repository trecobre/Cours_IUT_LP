from enum import Enum

class LanguageEnum(Enum):
    EN = 1
    FR = 2
    DE = 3

class SlotEnum(Enum):
    EVENT_SLOT = -1
    DISCARD = 0
    CARD_DRAW = 1
    DECK_P1 = 2
    UTILITY1_P1 = 3
    UTILITY2_P1 = 4
    UTILITY3_P1 = 5
    MARKETPLACE_P1 = 6
    MARKET_EXTENSION1_P1 = 7
    MARKET_EXTENSION2_P1 = 8
    MARKET_EXTENSION3_P1 = 9
    MARKET_EXTENSION4_P1 = 10
    MARKET_EXTENSION5_P1 = 11
    DECK_P2 = 12
    UTILITY1_P2 = 13
    UTILITY2_P2 = 14
    UTILITY3_P2 = 15
    MARKETPLACE_P2 = 16
    MARKET_EXTENSION1_P2 = 17
    MARKET_EXTENSION2_P2 = 18
    MARKET_EXTENSION3_P2 = 19
    MARKET_EXTENSION4_P2 = 20
    MARKET_EXTENSION5_P2 = 21

class LanguageManager():
    @staticmethod
    def get_buy_sell_text():
        from GameModule.GameManager import SingletonFactory
        current_language = SingletonFactory.get_instance().current_langage
        choice_sell_sentence: str
        choice_buy_sentence: str
        if current_language == LanguageEnum.EN:
            choice_sell_sentence = "Sell wares"
            choice_buy_sentence = "Buy wares"
        elif current_language == LanguageEnum.FR:
            choice_sell_sentence = "Vendre marchandises"
            choice_buy_sentence ="Acheter marchandises"
        elif current_language == LanguageEnum.DE:
            choice_sell_sentence = "Waren verkaufen"  
            choice_buy_sentence = "Waren kaufen"           
        return (choice_buy_sentence, choice_sell_sentence)
    
    @staticmethod
    def get_guard_choice_texts():
        from GameModule.GameManager import SingletonFactory
        current_language = SingletonFactory.get_instance().current_langage
        cancel_text: str
        dont_cancel_text: str
        if current_language == LanguageEnum.EN:
            cancel_text = "Cancel this animal card"
            dont_cancel_text = "Don't cancel this animal card"
        elif current_language == LanguageEnum.FR:
            cancel_text = "Annuler cette carte animal"
            dont_cancel_text ="Ne pas annuler cette carte animal"
        elif current_language == LanguageEnum.DE:
            cancel_text = "Stornieren Sie diese Tierkarte"  
            dont_cancel_text = "Kündigen Sie diese Tierkarte nicht"
        return (cancel_text, dont_cancel_text)

    @staticmethod
    def get_rain_maker_choice_texts():
        from GameModule.GameManager import SingletonFactory
        current_language = SingletonFactory.get_instance().current_langage
        take_ware_text: str
        dont_take_ware_text: str
        if current_language == LanguageEnum.EN:
            take_ware_text = "Take this ware card"
            dont_take_ware_text = "Don't take this ware card"
        elif current_language == LanguageEnum.FR:
            take_ware_text = "Prendre cette carte marchandise"
            dont_take_ware_text ="Ne pas prendre cette carte marchandise"
        elif current_language == LanguageEnum.DE:
            take_ware_text = "Nimm diese Warenkarte"  
            dont_take_ware_text = "Nimm diese Warenkarte nicht"
        return (take_ware_text, dont_take_ware_text)
    
    @staticmethod
    def get_kettles_choice_text():
        from GameModule.GameManager import SingletonFactory
        current_language = SingletonFactory.get_instance().current_langage
        one_card: str
        two_card: str
        if current_language == LanguageEnum.EN:
            one_card = "Discard and draw a card"
            two_card = "Discard and draw two cards"
        elif current_language == LanguageEnum.FR:
            one_card = "Défaussez et piochez une carte"
            two_card = "Défaussez et piochez deux cartes"
        elif current_language == LanguageEnum.DE:
            one_card = "Wirf ab und ziehe eine Karte"  
            two_card = "Wirf ab und ziehe zwei Karten"
        return (one_card, two_card)

    @staticmethod
    def get_use_card_choice_text(card, language:LanguageEnum):
        from CardsModule import Card, MarketCard, WareCard
        string_builder: str = ""
        if type(card) == WareCard:
            if language == LanguageEnum.EN:
                string_builder = "Do you want to use Ware card?" + LanguageManager.get_ware_card_desc(card, language)
            elif language == LanguageEnum.FR:
                string_builder = "Voulez vous utiliser la carte marchandise ?" + LanguageManager.get_ware_card_desc(card, language)
            elif language == LanguageEnum.DE:
                string_builder = "Möchten Sie die Warenkarte verwenden?" + LanguageManager.get_ware_card_desc(card, language)
        elif type(card) == MarketCard:
            from GameModule.GameManager import SingletonFactory
            current_cost = SingletonFactory.get_instance().current_small_market_stand_price
            if language == LanguageEnum.EN:
                string_builder = "Do you want to use market card?\n Cost : " + str(current_cost)
            elif language == LanguageEnum.FR:
                string_builder = "Voulez vous utiliser la carte marché ?\n Coût : " + str(current_cost)
            elif language == LanguageEnum.DE:
                string_builder = "Möchtest du die Marktkarte verwenden?\n Kosten:" + str(current_cost)
        else:
            if language == LanguageEnum.EN:
                string_builder = "Do you want to use " + card.name.get(LanguageEnum.EN) +"?\nDescription: " + card.desc.get(LanguageEnum.EN)
            elif language == LanguageEnum.FR:
                string_builder = "Voulez vous utiliser la carte " + card.name.get(LanguageEnum.FR) +"?\nDescription : " + card.desc.get(LanguageEnum.FR)
            elif language == LanguageEnum.DE:
                string_builder = "Möchten Sie die Karte verwenden" + card.name.get(LanguageEnum.DE) + "?"
        return string_builder

    @staticmethod
    def get_draw_choice_text(card_name:str, language:LanguageEnum, card=...):
        string_builder = ""
        desc = ""
        from CardsModule import MarketCard, WareCard
        if type(card)==WareCard:
            desc = LanguageManager.get_ware_card_desc(card, language)
        elif not type(card) == MarketCard:
            if language == LanguageEnum.EN:
                desc = "\nDescription : {}".format(card.desc.get(language))
            elif language == LanguageEnum.FR:
                desc = "\nDescription : {}".format(card.desc.get(language))
            elif language == LanguageEnum.DE:
                desc = "\nBeschreibung : {}".format(card.desc.get(language))
        if language == LanguageEnum.EN:
            string_builder = "Do you want to take {} or not ?{}".format(card_name, desc)
        elif language == LanguageEnum.FR:
            string_builder = "Voulez vous prendre {} ou pas ?{}".format(card_name, desc)
        elif language == LanguageEnum.DE:
            string_builder = "Willst du nehmen {} oder nicht ?{}".format(card_name, desc)
        return string_builder
    
    @staticmethod
    def get_ware_card_desc(card, language:LanguageEnum):
        from CardsModule import Card, MarketCard, WareCard
        from GameModule.GameManager import SingletonFactory

        if type(card)==WareCard:
            player = SingletonFactory.get_instance().get_owning_player(card)

            buy_price = card.buy_price - player.ware_buy_reduction
            sell_price = card.sell_price + player.ware_sell_buff

            if buy_price < 0:
                buy_price = 0

            ware_string = ""
            string_builder = ""
            for i in card.wares:
                ware_string += i.name.get(language) + "/"
            if language == LanguageEnum.EN:
                string_builder += "\nDescription : {}\nBuy : {} | Sell : {}".format(ware_string, buy_price, sell_price)
            elif language == LanguageEnum.FR:
                string_builder += "\nDescription : {}\nAcheter : {} | Vendre : {}".format(ware_string, buy_price, sell_price)
            elif language == LanguageEnum.DE:
                string_builder += "\nBeschreibung : {}\nKaufen: {} | Verkauf : {}".format(ware_string, buy_price, sell_price)
            return string_builder
        else:
            return ""

    @staticmethod
    def get_type_card_text(card):
        from CardsModule import Card, MarketCard, WareCard
        from GameModule.GameManager import SingletonFactory
        current_language = SingletonFactory.get_instance().current_langage
        text_to_return = ""
        if current_language == LanguageEnum.EN:
            if type(card)==WareCard:
                text_to_return = "ware card"
            elif type(card)==(MarketCard):
                text_to_return = "market card"
        elif current_language == LanguageEnum.FR:
            if type(card)==(WareCard):
                text_to_return = "carte marchandise"
            elif type(card)==(MarketCard):
                text_to_return = "carte marché"
        elif current_language == LanguageEnum.DE:
            if type(card)==(WareCard):
                text_to_return = "warenkarte"
            elif type(card)==(MarketCard):
                text_to_return = "Marktkarte"
        return text_to_return
    
    @staticmethod
    def get_wares_name(): 
        from GameModule.GameManager import SingletonFactory
        gm = SingletonFactory.get_instance()
        list_ware = gm.base_wares
        language = gm.current_langage
        list_name = []
        for ware in list_ware:
            list_name.append(ware.get_name(language))
        return list_name

    @staticmethod
    def get_gold_text():
        from GameModule.GameManager import SingletonFactory
        current_language = SingletonFactory.get_instance().current_langage
        text = ""
        if current_language == LanguageEnum.EN:
            text = "Gold"
        elif current_language == LanguageEnum.FR:
            text = "Pépite d'or"
        elif current_language == LanguageEnum.DE:
            text = "Gold"
        return text

    @staticmethod
    def get_action_point_text():
        from GameModule.GameManager import SingletonFactory
        current_language = SingletonFactory.get_instance().current_langage
        text = ""
        if current_language == LanguageEnum.EN:
            text = "Action point"
        elif current_language == LanguageEnum.FR:
            text = "Point d'action"
        elif current_language == LanguageEnum.DE:
            text = "Aktionspunkt"
        return text
    
    @staticmethod
    def get_btn_skip_phase_text():
        from GameModule.GameManager import SingletonFactory
        gm = SingletonFactory.get_instance()
        current_language = gm.current_langage
        text = ""
        if gm.active_phase == 2:
            if current_language == LanguageEnum.EN:
                text = "End turn"
            elif current_language == LanguageEnum.FR:
                text = "Finir le tour"
            elif current_language == LanguageEnum.DE:
                text = "Beenden Sie die Runde"
        else:
            if current_language == LanguageEnum.EN:
                text = "Skip phase"
            elif current_language == LanguageEnum.FR:
                text = "Passer la phase"
            elif current_language == LanguageEnum.DE:
                text = "Phase überspringen"
        return text
    
    @staticmethod
    def get_ware_toolbar_text():
        from GameModule.GameManager import SingletonFactory
        current_language = SingletonFactory.get_instance().current_langage
        text = ""
        if current_language == LanguageEnum.EN:
            text = "Wares"
        elif current_language == LanguageEnum.FR:
            text = "Marchandises"
        elif current_language == LanguageEnum.DE:
            text = "Waren"
        return text
    
    @staticmethod
    def get_TribalElder_Draw_Discard_text():
        from GameModule.GameManager import SingletonFactory
        current_language = SingletonFactory.get_instance().current_langage
        choice_TribalElder_Draw_sentence: str
        choice_TribalElder_Discard_sentence: str
        if current_language == LanguageEnum.EN:
            choice_TribalElder_Draw_sentence = "You draw cards from the card supply until you have 5 cards in yourhands"
            choice_TribalElder_Discard_sentence = "ennemy discard cards from his hand until he have 3 left"
        elif current_language == LanguageEnum.FR:
            choice_TribalElder_Draw_sentence = "Vous piochez des cartes de la réserve de cartes jusqu'à ce que vous ayez 5 cartes en main"
            choice_TribalElder_Discard_sentence = "l'ennemi défausse les cartes de sa main jusqu'à ce qu'il en reste 3"
        elif current_language == LanguageEnum.DE:
            choice_TribalElder_Draw_sentence = "Man zieht Karten aus dem Kartenvorrat, bis man 5 Karten auf der Hand hat"
            choice_TribalElder_Discard_sentence = "Gegner wirft Karten aus seiner Hand ab, bis er noch 3 übrig hat"            
        return (choice_TribalElder_Draw_sentence, choice_TribalElder_Discard_sentence)

    @staticmethod
    def get_cheetah_choice_texts():
        from GameModule.GameManager import SingletonFactory
        current_language = SingletonFactory.get_instance().current_langage
        give_two_gold_text: str
        draw_two_card_text: str
        if current_language == LanguageEnum.EN:
            give_two_gold_text = "Give 2 gold"
            draw_two_card_text = "Ennemy draw 2 card"
        elif current_language == LanguageEnum.FR:
            give_two_gold_text = "Donner 2 pépites d’or"
            draw_two_card_text ="L'ennemy pioche 2 cartes"
        elif current_language == LanguageEnum.DE:
            give_two_gold_text = "Gib 2 Gold"  
            draw_two_card_text = "Der Feind zieht 2 Karten"
        return (give_two_gold_text, draw_two_card_text)

    def get_carrier_choice_texts():
        from GameModule.GameManager import SingletonFactory
        current_language = SingletonFactory.get_instance().current_langage
        take_2_same_ware: str
        draw_2_card: str
        if current_language == LanguageEnum.EN:
            take_2_same_ware = "take 2 same wares"
            draw_2_card = "draw 2 cards"
        elif current_language == LanguageEnum.FR:
            take_2_same_ware = "prendre 2 mêmes marchandises"
            draw_2_card ="tirer 2 cartes"
        elif current_language == LanguageEnum.DE:
            take_2_same_ware = "Nimm 2 gleiche Waren"  
            draw_2_card = "Ziehe 2 Karten"
        return (take_2_same_ware, draw_2_card)
    
    @staticmethod
    def get_supplies_choice_texts():
        from GameModule.GameManager import SingletonFactory
        current_language = SingletonFactory.get_instance().current_langage
        pay_one_gold: str
        discard_one_card: str
        if current_language == LanguageEnum.EN:
            pay_one_gold = "Pay one gold"
            discard_one_card = "Discard one card"
        elif current_language == LanguageEnum.FR:
            pay_one_gold = "Payer une pièce d'or"
            discard_one_card ="Défausser une carte"
        elif current_language == LanguageEnum.DE:
            pay_one_gold = "Zahle eine Goldmünze"  
            discard_one_card = "Wirf eine Karte ab"
        return (pay_one_gold, discard_one_card)

    def get_MaskOfTransformation_choice_texts():
        from GameModule.GameManager import SingletonFactory
        current_language = SingletonFactory.get_instance().current_langage
        use_mask: str
        dont_use_mask: str
        if current_language == LanguageEnum.EN:
            use_mask = "Use Mask of Transformation"
            dont_use_mask = "Dont use Mask of Transformation"
        elif current_language == LanguageEnum.FR:
            use_mask = "Utiliser le masque de transformation "
            dont_use_mask ="Ne pas utiliser Masque de transformation"
        elif current_language == LanguageEnum.DE:
            use_mask = "Verwenden Sie Maske der Transformation"  
            dont_use_mask = "Verwenden Sie keine Maske der Transformation"
        return (use_mask, dont_use_mask)
    
    @staticmethod
    def get_player_color_text():
        from GameModule.GameManager import SingletonFactory
        current_language = SingletonFactory.get_instance().current_langage
        text = ["", ""]
        if current_language == LanguageEnum.EN:
            text = ["Blue", "Green"]
        elif current_language == LanguageEnum.FR:
            text = ["Bleu", "Vert"]
        elif current_language == LanguageEnum.DE:
            text = ["Blau", "Grün"]
        return text

    @staticmethod
    def get_window_name_text():
        from GameModule.GameManager import SingletonFactory
        current_language = SingletonFactory.get_instance().current_langage
        text = ""
        if current_language == LanguageEnum.EN:
            text = "Jambo-Blue - Game"
        elif current_language == LanguageEnum.FR:
            text = "Jambo-Bleu - Jeu"
        elif current_language == LanguageEnum.DE:
            text = "Jambo-Blau - Spiel"
        return text

    @staticmethod
    def get_actual_turn_text():
        from GameModule.GameManager import SingletonFactory
        gm = SingletonFactory.get_instance()
        current_language = gm.current_langage
        text = ""
        if gm.active_player == gm.board.player1:
            if current_language == LanguageEnum.EN:
                text = "It's your turn !"
            elif current_language == LanguageEnum.FR:
                text = "A votre tour !"
            elif current_language == LanguageEnum.DE:
                text = "Du bist dran !"
        else:
            if current_language == LanguageEnum.EN:
                text = "It's AI's turn"
            elif current_language == LanguageEnum.FR:
                text = "Au tour de l'IA"
            elif current_language == LanguageEnum.DE:
                text = "Rund um die KI"
        return text

    @staticmethod
    def get_draw_window_text():
        from GameModule.GameManager import SingletonFactory
        current_language = SingletonFactory.get_instance().current_langage
        text = ""
        if current_language == LanguageEnum.EN:
            text = "Drawing"
        elif current_language == LanguageEnum.FR:
            text = "En pioche"
        elif current_language == LanguageEnum.DE:
            text = "in Spitzhacke"
        return text

    @staticmethod
    def get_auction_title():
        from GameModule.GameManager import SingletonFactory
        current_language = SingletonFactory.get_instance().current_langage
        text = ""
        if current_language == LanguageEnum.EN:
            text = "Auction"
        elif current_language == LanguageEnum.FR:
            text = "Enchère"
        elif current_language == LanguageEnum.DE:
            text = "Gebot"
        return text

    @staticmethod
    def get_auction_desc():
        from GameModule.GameManager import SingletonFactory
        current_language = SingletonFactory.get_instance().current_langage
        text = ""
        if current_language == LanguageEnum.EN:
            text = "Winner will get : "
        elif current_language == LanguageEnum.FR:
            text = "Le gagnant obtiendra : "
        elif current_language == LanguageEnum.DE:
            text = "Der Gewinner bekommt : "
        return text

    @staticmethod
    def get_auction_current_golds():
        from GameModule.GameManager import SingletonFactory
        current_language = SingletonFactory.get_instance().current_langage
        text = ""
        if current_language == LanguageEnum.EN:
            text = "Previous auction : "
        elif current_language == LanguageEnum.FR:
            text = "Enchère précédente : "
        elif current_language == LanguageEnum.DE:
            text = "Vorherige Auktion : "
        return text

    @staticmethod
    def get_auction_texts():
        from GameModule.GameManager import SingletonFactory
        current_language = SingletonFactory.get_instance().current_langage
        (add_text, give_up_text) = ("", "")
        if current_language == LanguageEnum.EN:
            (add_text, give_up_text) = ("Bid", "Give up")
        elif current_language == LanguageEnum.FR:
            (add_text, give_up_text) = ("Enchérir", "Abandonner")
        elif current_language == LanguageEnum.DE:
            (add_text, give_up_text) = ("Gebot", "Aufgeben")
        return (add_text, give_up_text)

    @staticmethod
    def get_end_text():
        from GameModule.GameManager import SingletonFactory
        current_language = SingletonFactory.get_instance().current_langage
        text = ""
        if current_language == LanguageEnum.EN:
            text = "Do you want to restart a game ?"
        elif current_language == LanguageEnum.FR:
            text = "Voulez-vous rejouer ?"
        elif current_language == LanguageEnum.DE:
            text = "Möchten Sie ein Spiel neu starten?"
        return text

    @staticmethod
    def get_end_title():
        from GameModule.GameManager import SingletonFactory
        gm = SingletonFactory.get_instance()
        current_language = gm.current_langage
        text = ""
        if gm.winner == gm.board.player1:
            if current_language == LanguageEnum.EN:
                text = "You win ! 🎆"
            elif current_language == LanguageEnum.FR:
                text = "Vous avez gagné ! 🎆"
            elif current_language == LanguageEnum.DE:
                text = "Du hast gewonnen! 🎆"
        else:
            if current_language == LanguageEnum.EN:
                text = "You loose ! 💀"
            elif current_language == LanguageEnum.FR:
                text = "Vous avez perdu ! 💀"
            elif current_language == LanguageEnum.DE:
                text = "Du hast verloren ! 💀"
        return text

    def get_keep_card_text():
        from GameModule.GameManager import SingletonFactory
        gm = SingletonFactory.get_instance()
        current_language = gm.current_langage
        text = ""

        if current_language == LanguageEnum.EN:
            text = "Choose a card to keep"
        elif current_language == LanguageEnum.FR:
            text = "Choisissez une carte à garder"
        elif current_language == LanguageEnum.DE:
            text = "Wähle eine Karte, die du behalten möchtest"

        return text

    def get_discard_card_text():
        from GameModule.GameManager import SingletonFactory
        gm = SingletonFactory.get_instance()
        current_language = gm.current_langage
        text = ""

        if current_language == LanguageEnum.EN:
            text = "Choose a card to discard"
        elif current_language == LanguageEnum.FR:
            text = "Choisissez une carte à défausser"
        elif current_language == LanguageEnum.DE:
            text = "Wähle eine Karte zum Ablegen"

        return text

    def get_give_card_text():
        from GameModule.GameManager import SingletonFactory
        gm = SingletonFactory.get_instance()
        current_language = gm.current_langage
        text = ""

        if current_language == LanguageEnum.EN:
            text = "Choose a card to give"
        elif current_language == LanguageEnum.FR:
            text = "Choisissez une carte à donner"
        elif current_language == LanguageEnum.DE:
            text = "Wähle eine Karte zum Verschenken"

        return text

    def get_take_ware_text():
        from GameModule.GameManager import SingletonFactory
        gm = SingletonFactory.get_instance()
        current_language = gm.current_langage
        text = ""

        if current_language == LanguageEnum.EN:
            text = "Choose a ware to take"
        elif current_language == LanguageEnum.FR:
            text = "Choisissez une marchandise à prendre"
        elif current_language == LanguageEnum.DE:
            text = "Wähle eine Ware zum Mitnehmen"

        return text

    def get_give_ware_text():
        from GameModule.GameManager import SingletonFactory
        gm = SingletonFactory.get_instance()
        current_language = gm.current_langage
        text = ""

        if current_language == LanguageEnum.EN:
            text = "Choose a ware to give"
        elif current_language == LanguageEnum.FR:
            text = "Choisissez une marchandise à donner"
        elif current_language == LanguageEnum.DE:
            text = "Wähle eine Ware zum Verschenken aus"

        return text