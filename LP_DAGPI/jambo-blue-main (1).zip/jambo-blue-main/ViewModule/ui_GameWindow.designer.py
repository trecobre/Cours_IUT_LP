# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'GameWindow.designer.ui'
##
## Created by: Qt User Interface Compiler version 6.3.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################
"""CODE AUTO GENERATED"""

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QFrame, QHBoxLayout, QMainWindow,
    QSizePolicy, QSpacerItem, QVBoxLayout, QWidget)

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        if not MainWindow.objectName():
            MainWindow.setObjectName(u"MainWindow")
        MainWindow.resize(1024, 768)
        MainWindow.setCursor(QCursor(Qt.ArrowCursor))
        icon = QIcon()
        icon.addFile(u":/leafcursor/Downloads/Leaf Normal Select.cur", QSize(), QIcon.Normal, QIcon.Off)
        MainWindow.setWindowIcon(icon)
        MainWindow.setStyleSheet(u"QHBoxLayout{\n"
"	bg-color:red;\n"
"}")
        self.centralwidget = QWidget(MainWindow)
        self.centralwidget.setObjectName(u"centralwidget")
        self.horizontalLayout_2 = QHBoxLayout(self.centralwidget)
        self.horizontalLayout_2.setObjectName(u"horizontalLayout_2")
        self.board = QVBoxLayout()
        self.board.setObjectName(u"board")
        self.p2_zone = QHBoxLayout()
        self.p2_zone.setObjectName(u"p2_zone")
        self.verticalSpacer_4 = QSpacerItem(20, 40, QSizePolicy.Minimum, QSizePolicy.Expanding)

        self.p2_zone.addItem(self.verticalSpacer_4)

        self.card_zone_p2 = QVBoxLayout()
        self.card_zone_p2.setObjectName(u"card_zone_p2")
        self.deck_p2 = QHBoxLayout()
        self.deck_p2.setObjectName(u"deck_p2")

        self.card_zone_p2.addLayout(self.deck_p2)

        self.utility_p2 = QHBoxLayout()
        self.utility_p2.setObjectName(u"utility_p2")

        self.card_zone_p2.addLayout(self.utility_p2)

        self.market_place_p2_zone = QHBoxLayout()
        self.market_place_p2_zone.setObjectName(u"market_place_p2_zone")

        self.card_zone_p2.addLayout(self.market_place_p2_zone)


        self.p2_zone.addLayout(self.card_zone_p2)

        self.verticalSpacer = QSpacerItem(20, 40, QSizePolicy.Minimum, QSizePolicy.Expanding)

        self.p2_zone.addItem(self.verticalSpacer)


        self.board.addLayout(self.p2_zone)

        self.separator_p2_neutral = QFrame(self.centralwidget)
        self.separator_p2_neutral.setObjectName(u"separator_p2_neutral")
        self.separator_p2_neutral.setFrameShape(QFrame.HLine)
        self.separator_p2_neutral.setFrameShadow(QFrame.Sunken)

        self.board.addWidget(self.separator_p2_neutral)

        self.neutral_zone = QHBoxLayout()
        self.neutral_zone.setSpacing(7)
        self.neutral_zone.setObjectName(u"neutral_zone")

        self.board.addLayout(self.neutral_zone)

        self.separator_p1_neutral = QFrame(self.centralwidget)
        self.separator_p1_neutral.setObjectName(u"separator_p1_neutral")
        self.separator_p1_neutral.setFrameShape(QFrame.HLine)
        self.separator_p1_neutral.setFrameShadow(QFrame.Sunken)

        self.board.addWidget(self.separator_p1_neutral)

        self.p1_zone = QHBoxLayout()
        self.p1_zone.setObjectName(u"p1_zone")
        self.verticalSpacer_3 = QSpacerItem(20, 40, QSizePolicy.Minimum, QSizePolicy.Expanding)

        self.p1_zone.addItem(self.verticalSpacer_3)

        self.card_zone_p1 = QVBoxLayout()
        self.card_zone_p1.setObjectName(u"card_zone_p1")
        self.market_place_p1_zone = QHBoxLayout()
        self.market_place_p1_zone.setObjectName(u"market_place_p1_zone")

        self.card_zone_p1.addLayout(self.market_place_p1_zone)

        self.utility_p1 = QHBoxLayout()
        self.utility_p1.setObjectName(u"utility_p1")

        self.card_zone_p1.addLayout(self.utility_p1)

        self.deck_p1 = QHBoxLayout()
        self.deck_p1.setObjectName(u"deck_p1")

        self.card_zone_p1.addLayout(self.deck_p1)


        self.p1_zone.addLayout(self.card_zone_p1)

        self.verticalSpacer_2 = QSpacerItem(20, 40, QSizePolicy.Minimum, QSizePolicy.Expanding)

        self.p1_zone.addItem(self.verticalSpacer_2)


        self.board.addLayout(self.p1_zone)


        self.horizontalLayout_2.addLayout(self.board)

        MainWindow.setCentralWidget(self.centralwidget)

        self.retranslateUi(MainWindow)

        QMetaObject.connectSlotsByName(MainWindow)
    # setupUi

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(QCoreApplication.translate("MainWindow", u"MainWindow", None))
    # retranslateUi

