from PyQt6.QtWidgets import QMainWindow, QWidget
from PyQt6 import QtCore, QtWidgets, QtGui
from UtilityModule import LanguageEnum, LanguageManager
import ViewModule
from ViewModule import GameWindow
from ViewModule.SettingsWindowDesigner import Ui_Dialog
from ViewModule import CustomWidget

datas = {}
class SettingsWindow(QMainWindow):
    """Settings windows which is launch a the beginning

    Heritance : QMainWindow
    """
    def __init__(self) -> None:
        super().__init__()
        self.setWindowTitle(LanguageManager.get_window_name_text())
        self.setWindowIcon(QtGui.QIcon("Resources/templates/icon_app.png"))
        self.game_start = False
        self.settings = {}
        self.ui = Ui_Dialog()
        self.setStyleSheet("QMainWindow{border-image: url(Resources/templates/light-wood.jpg);}QPushButton{border-image: url(Resources/templates/dark_wood2.jpg);}QPushButton:hover{border-image: url(Resources/templates/dark_wood3.jpg);}")
        self.ui.setupUi(self)
        self.is_active = True

        title_font = QtGui.QFont("Lucida Handwriting", 72)
        self.ui.title_label.setFont(title_font)
        self.ui.title_label.setStyleSheet("color:mediumslateblue")

        self.ui.language_combo_box.addItems(["English","Français","Deutsch"])

        self.ui.nb_ia_combo_box.addItems(["1","2"])

        self.ui.start_button.clicked.connect(self.collect_setting)

        difficulty = ["Basic", "Advanced"]

        self.ui.difficulty_ia1_combo_box.addItems(difficulty)
        self.ui.difficulty_ia2_combo_box.addItems(difficulty)

        self.ui.language_combo_box.currentTextChanged.connect(self.change_language)

        self.ui.nb_ia_combo_box.currentTextChanged.connect(self.change_nb_ia)

        self.ui.difficulty_ia2_combo_box.setDisabled(True)

        if not len(datas.keys()) == 0:
            self.ui.language_combo_box.setCurrentIndex(datas.get("language"))
            self.ui.nb_ia_combo_box.setCurrentText(datas.get("nb_ia"))
            self.ui.difficulty_ia1_combo_box.setCurrentText(datas.get("ia_1"))
            self.ui.difficulty_ia2_combo_box.setCurrentText(datas.get("ia_2"))

    def retranslateUiEn(self):
        """translate the text in the settings windows in english
        """
        _translate = QtCore.QCoreApplication.translate
        self.setWindowTitle(_translate("Dialog", "Jambo-Blue - Settings"))
        self.ui.title_label.setText(_translate("Dialog", "Jambo-Blue"))
        self.ui.language_label.setText(_translate("Dialog", "Select the language"))
        self.ui.start_button.setText(_translate("Dialog", "Start Game"))
        self.ui.label_nb_ia.setText(_translate("Dialog", "How Many AI will play ?"))
        self.ui.label_ia_1.setText(_translate("Dialog", "Difficulty of AI n°1"))
        self.ui.difficulty_ia1_combo_box.setItemText(0, _translate("Dialog", "Basic"))
        self.ui.difficulty_ia1_combo_box.setItemText(1, _translate("Dialog", "Advanced"))
        self.ui.label_ia_2.setText(_translate("Dialog", "Difficulty of AI n°2"))
        self.ui.difficulty_ia2_combo_box.setItemText(0, _translate("Dialog", "Basic"))
        self.ui.difficulty_ia2_combo_box.setItemText(1, _translate("Dialog", "Advanced"))
        self.ui.color_choice_label.setText(_translate("Dialog", "Player color"))

    def retranslateUiFr(self):
        """translate the text in the settings windows in french
        """
        _translate = QtCore.QCoreApplication.translate
        self.setWindowTitle(_translate("Dialog", "Jambo-Bleu - Paramètres"))
        self.ui.title_label.setText(_translate("Dialog", "Jambo-Bleu"))
        self.ui.language_label.setText(_translate("Dialog", "Choisir le langage"))
        self.ui.start_button.setText(_translate("Dialog", "Démarrer le jeu"))
        self.ui.label_nb_ia.setText(_translate("Dialog", "Combien d'IA joueront ?"))
        self.ui.label_ia_1.setText(_translate("Dialog", "Difficulté de la première IA "))
        self.ui.difficulty_ia1_combo_box.setItemText(0, _translate("Dialog", "Basique"))
        self.ui.difficulty_ia1_combo_box.setItemText(1, _translate("Dialog", "Avancée"))
        self.ui.label_ia_2.setText(_translate("Dialog", "Difficulté de la seconde IA"))
        self.ui.difficulty_ia2_combo_box.setItemText(0, _translate("Dialog", "Basique"))
        self.ui.difficulty_ia2_combo_box.setItemText(1, _translate("Dialog", "Avancée"))
        self.ui.color_choice_label.setText(_translate("Dialog", "Couleur du joueur"))

    def retranslateUiDe(self):
        """translate the text in the settings windows in deutch
        """
        _translate = QtCore.QCoreApplication.translate
        self.setWindowTitle(_translate("Dialog", "Jambo-Blau - Einstellungen"))
        self.ui.title_label.setText(_translate("Dialog", "Jambo-Blau"))
        self.ui.language_label.setText(_translate("Dialog", "Wählen Sie die Sprache"))
        self.ui.start_button.setText(_translate("Dialog", "Starte das Spiel"))
        self.ui.label_nb_ia.setText(_translate("Dialog", "Wie viele KIs werden spielen?"))
        self.ui.label_ia_1.setText(_translate("Dialog", "Erste KI-Schwierigkeit"))
        self.ui.difficulty_ia1_combo_box.setItemText(0, _translate("Dialog", "Basic"))
        self.ui.difficulty_ia1_combo_box.setItemText(1, _translate("Dialog", "Fortschrittlich"))
        self.ui.label_ia_2.setText(_translate("Dialog", "Zweite KI-Schwierigkeit"))
        self.ui.difficulty_ia2_combo_box.setItemText(0, _translate("Dialog", "Basic"))
        self.ui.difficulty_ia2_combo_box.setItemText(1, _translate("Dialog", "Fortschrittlich"))
        self.ui.color_choice_label.setText(_translate("Dialog", "Spielerfarbe"))

    def change_language(self):
        """change the language of hte settings window"""
        if self.ui.language_combo_box.currentText() == "English":
            self.retranslateUiEn()
        elif self.ui.language_combo_box.currentText() == "Français":
            self.retranslateUiFr()
        elif self.ui.language_combo_box.currentText() == "Deutsch":
            self.retranslateUiDe()

    def change_nb_ia(self):
        """enable/disable the difficulty of the 2nd AI when the value of the combo box of the nb of AI is changed
        """
        if self.ui.nb_ia_combo_box.currentText() == "1":
            self.ui.difficulty_ia2_combo_box.setDisabled(True)
        else:
            self.ui.difficulty_ia2_combo_box.setDisabled(False)

    def collect_setting(self):
        """appends when the start game button is pressed, launches the game
        """
        index:int = self.ui.language_combo_box.currentIndex()+1
        from GameModule.GameManager import SingletonFactory
        gm = SingletonFactory.get_instance()
        gm.current_langage = LanguageEnum(index)
        gm.number_of_ai = int(self.ui.nb_ia_combo_box.currentText())
        gm.difficulty_ai_1 = self.ui.difficulty_ia1_combo_box.currentIndex()
        gm.difficulty_ai_2 = self.ui.difficulty_ia2_combo_box.currentIndex()
        if self.ui.color_choice.isChecked():
            gm.player_color = "dodgerblue"
        else:
            gm.player_color = "lawngreen"
        self.setHidden(True)
        gm.game_window.show()
        gm.start_game()