# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'SettingsWindow.designer.ui'
##
## Created by: Qt User Interface Compiler version 6.3.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################
"""CODE AUTO GENERATED"""

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QComboBox, QDialog, QFrame,
    QHBoxLayout, QLabel, QPushButton, QSizePolicy,
    QSpacerItem, QVBoxLayout, QWidget)

class Ui_Dialog(object):
    def setupUi(self, Dialog):
        if not Dialog.objectName():
            Dialog.setObjectName(u"Dialog")
        Dialog.resize(1280, 720)
        Dialog.setStyleSheet(u"QDialog{\n"
"    background-color: teal;\n"
"}")
        self.horizontalLayoutWidget = QWidget(Dialog)
        self.horizontalLayoutWidget.setObjectName(u"horizontalLayoutWidget")
        self.horizontalLayoutWidget.setGeometry(QRect(-1, -1, 1281, 221))
        self.layout_title = QHBoxLayout(self.horizontalLayoutWidget)
        self.layout_title.setObjectName(u"layout_title")
        self.layout_title.setContentsMargins(0, 0, 0, 0)
        self.space_title_left = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.layout_title.addItem(self.space_title_left)

        self.title_label = QLabel(self.horizontalLayoutWidget)
        self.title_label.setObjectName(u"title_label")

        self.layout_title.addWidget(self.title_label)

        self.space_title_right = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.layout_title.addItem(self.space_title_right)

        self.horizontalLayoutWidget_2 = QWidget(Dialog)
        self.horizontalLayoutWidget_2.setObjectName(u"horizontalLayoutWidget_2")
        self.horizontalLayoutWidget_2.setGeometry(QRect(0, 220, 1281, 501))
        self.menu_layout = QHBoxLayout(self.horizontalLayoutWidget_2)
        self.menu_layout.setObjectName(u"menu_layout")
        self.menu_layout.setContentsMargins(0, 0, 0, 0)
        self.laguage_frame = QFrame(self.horizontalLayoutWidget_2)
        self.laguage_frame.setObjectName(u"laguage_frame")
        self.laguage_frame.setStyleSheet(u"QComboBox{\n"
"    margin-left: 50px;\n"
"	margin-right: 50px;\n"
"	margin-bottom:50px;\n"
"    font-size: 30px;\n"
"	border-radius: 10px;\n"
"}\n"
"\n"
"QLabel{\n"
"    margin-left: 45px;\n"
"    font-size: 15px;\n"
"	color:white;\n"
"}")
        self.LayoutLanguageSetting = QVBoxLayout(self.laguage_frame)
        self.LayoutLanguageSetting.setObjectName(u"LayoutLanguageSetting")
        self.verticalSpacer_2 = QSpacerItem(20, 40, QSizePolicy.Minimum, QSizePolicy.Expanding)

        self.LayoutLanguageSetting.addItem(self.verticalSpacer_2)

        self.horizontalSpacer_4 = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.LayoutLanguageSetting.addItem(self.horizontalSpacer_4)

        self.language_label = QLabel(self.laguage_frame)
        self.language_label.setObjectName(u"language_label")

        self.LayoutLanguageSetting.addWidget(self.language_label)

        self.language_combo_box = QComboBox(self.laguage_frame)
        self.language_combo_box.setObjectName(u"language_combo_box")

        self.LayoutLanguageSetting.addWidget(self.language_combo_box)

        self.horizontalSpacer_5 = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.LayoutLanguageSetting.addItem(self.horizontalSpacer_5)

        self.verticalSpacer_4 = QSpacerItem(20, 40, QSizePolicy.Minimum, QSizePolicy.Expanding)

        self.LayoutLanguageSetting.addItem(self.verticalSpacer_4)


        self.menu_layout.addWidget(self.laguage_frame)

        self.button_layout = QFrame(self.horizontalLayoutWidget_2)
        self.button_layout.setObjectName(u"button_layout")
        self.button_layout.setStyleSheet(u"")
        self.horizontalLayout_3 = QHBoxLayout(self.button_layout)
        self.horizontalLayout_3.setObjectName(u"horizontalLayout_3")
        self.start_button = QPushButton(self.button_layout)
        self.start_button.setObjectName(u"start_button")
        self.start_button.setMinimumSize(QSize(419, 0))
        self.start_button.setStyleSheet(u"QPushButton{background-color: deeppink;color: white;border: 1px;border-radius: 40px;font-size: 50px;padding: 10px;margin: 10px;}QPushButton:hover{background-color : black;}QPushButton:active{background-color : blue;}")

        self.horizontalLayout_3.addWidget(self.start_button)


        self.menu_layout.addWidget(self.button_layout)

        self.ia_settings_layout = QFrame(self.horizontalLayoutWidget_2)
        self.ia_settings_layout.setObjectName(u"ia_settings_layout")
        self.ia_settings_layout.setStyleSheet(u"QComboBox{\n"
"    margin: 50px;\n"
"    margin-top: 0px;\n"
"    font-size: 30px;\n"
"	border-radius: 10px;\n"
"}\n"
"\n"
"QLabel{\n"
"    margin-left: 45px;\n"
"    font-size: 15px;\n"
"	color:white;\n"
"}")
        self.LayoutPlayerSettings = QVBoxLayout(self.ia_settings_layout)
        self.LayoutPlayerSettings.setObjectName(u"LayoutPlayerSettings")
        self.vspace_ia_top = QSpacerItem(20, 40, QSizePolicy.Minimum, QSizePolicy.Expanding)

        self.LayoutPlayerSettings.addItem(self.vspace_ia_top)

        self.hspace_ia_top = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.LayoutPlayerSettings.addItem(self.hspace_ia_top)

        self.label_nb_ia = QLabel(self.ia_settings_layout)
        self.label_nb_ia.setObjectName(u"label_nb_ia")

        self.LayoutPlayerSettings.addWidget(self.label_nb_ia)

        self.nb_ia_combo_box = QComboBox(self.ia_settings_layout)
        self.nb_ia_combo_box.setObjectName(u"nb_ia_combo_box")
        self.nb_ia_combo_box.setStyleSheet(u"")

        self.LayoutPlayerSettings.addWidget(self.nb_ia_combo_box)

        self.label_ia_1 = QLabel(self.ia_settings_layout)
        self.label_ia_1.setObjectName(u"label_ia_1")

        self.LayoutPlayerSettings.addWidget(self.label_ia_1)

        self.difficulty_ia1_combo_box = QComboBox(self.ia_settings_layout)
        self.difficulty_ia1_combo_box.setObjectName(u"difficulty_ia1_combo_box")

        self.LayoutPlayerSettings.addWidget(self.difficulty_ia1_combo_box)

        self.label_ia_2 = QLabel(self.ia_settings_layout)
        self.label_ia_2.setObjectName(u"label_ia_2")

        self.LayoutPlayerSettings.addWidget(self.label_ia_2)

        self.difficulty_ia2_combo_box = QComboBox(self.ia_settings_layout)
        self.difficulty_ia2_combo_box.setObjectName(u"difficulty_ia2_combo_box")

        self.LayoutPlayerSettings.addWidget(self.difficulty_ia2_combo_box)

        self.hspace_ia_bottom = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.LayoutPlayerSettings.addItem(self.hspace_ia_bottom)

        self.vspace_ia_bottom = QSpacerItem(20, 40, QSizePolicy.Minimum, QSizePolicy.Expanding)

        self.LayoutPlayerSettings.addItem(self.vspace_ia_bottom)

        self.nb_ia_combo_box.raise_()
        self.label_ia_1.raise_()
        self.difficulty_ia1_combo_box.raise_()
        self.label_ia_2.raise_()
        self.label_nb_ia.raise_()
        self.difficulty_ia2_combo_box.raise_()

        self.menu_layout.addWidget(self.ia_settings_layout)


        self.retranslateUi(Dialog)

        QMetaObject.connectSlotsByName(Dialog)
    # setupUi

    def retranslateUi(self, Dialog):
        Dialog.setWindowTitle(QCoreApplication.translate("Dialog", u"Dialog", None))
        self.title_label.setText(QCoreApplication.translate("Dialog", u"<html><head/><body><p><span style=\" font-size:72pt; color:#55aaff;\">Jambo-Blue</span></p></body></html>", None))
        self.language_label.setText(QCoreApplication.translate("Dialog", u"Select the language", None))
        self.start_button.setText(QCoreApplication.translate("Dialog", u"Start Game", None))
        self.label_nb_ia.setText(QCoreApplication.translate("Dialog", u"How Many IA will play ?", None))
        self.label_ia_1.setText(QCoreApplication.translate("Dialog", u"Difficulty of IA n\u00b01", None))
        self.label_ia_2.setText(QCoreApplication.translate("Dialog", u"Difficulty of IA n\u00b02", None))
    # retranslateUi

