from PyQt6.QtWidgets import QMainWindow, QWidget, QMessageBox
from PyQt6 import QtWidgets, QtCore, QtGui
from CardsModule import Card, MarketCard, WareCard
from CardsModule.UtilityCards import UtilityCard
from GameModule.CardSlot import CardSlot
from GameModule.Ware import Ware
from UtilityModule import LanguageEnum, LanguageManager, SlotEnum
from ViewModule.GameWindowDesigner import Ui_MainWindow
from typing import *
from ViewModule.CustomWidget import VisualSlot, MessageBox, AuctionDialog

class GameWindow(QMainWindow):
    """This is the game window 
    """
    def __init__(self, screen_size=...) -> None:
        super().__init__()
        self.setWindowState(QtCore.Qt.WindowState.WindowFullScreen)
        self.setWindowTitle(LanguageManager.get_window_name_text())
        self.setWindowIcon(QtGui.QIcon("Resources/templates/icon_app.png"))
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)
        self.slots: List[VisualSlot] = list[VisualSlot]()
        self.player1_cards: List[VisualSlot] = list[VisualSlot]()
        self.player2_cards: List[VisualSlot] = list[VisualSlot]()
        self.create_neutral_area(self.ui.neutral_zone)
        self.set_up_player_zone()
        pixmap = QtGui.QPixmap("Resources/templates/cursor3.png")
        cursor = QtGui.QCursor(pixmap, 0, 0)
        self.setCursor(cursor)
        bgimg = QtGui.QImage("Resources/templates/dark_wood.jpg")
        bgimg.scaled(self.size())
        brush = QtGui.QBrush()
        brush.setTextureImage(bgimg)
        palette = QtGui.QPalette()
        palette.setBrush(QtGui.QPalette.ColorRole.Window, brush)
        self.setPalette(palette)
        self.set_up_menu_bar()
        self.setHidden(True)
        self.setFixedSize(screen_size)
        self.is_full_screen = True

    def closeEvent(self, a0: QtGui.QCloseEvent) -> None:
        from GameModule.GameManager import SingletonFactory

        SingletonFactory.get_instance().log_window.close()

        return super().closeEvent(a0)

    def keyPressEvent(self, a0: QtGui.QKeyEvent) -> None:
        """appends when F11 key is pressed, set the window in fullscreen or maximized

        Args:
            a0 (QtGui.QKeyEvent): key pressed

        Returns:
            _type_: _description_
        """
        if a0.key() == QtCore.Qt.Key.Key_F11:
            if self.is_full_screen:
                self.setWindowState(QtCore.Qt.WindowState.WindowMaximized)
                self.is_full_screen = False
            else:
                self.setWindowState(QtCore.Qt.WindowState.WindowFullScreen)
                self.is_full_screen = True
        return super().keyPressEvent(a0)
    
    def set_up_menu_bar(self):
        """place the border of the board
        """
        toolbar_p1 = QtWidgets.QToolBar()
        self.gold_label_p1 = QtWidgets.QLabel()
        self.action_point_label_p1 = QtWidgets.QLabel()
        self.wares_label_p1 = QtWidgets.QLabel()

        silk_img = QtWidgets.QLabel()
        hides_img = QtWidgets.QLabel()
        fruit_img = QtWidgets.QLabel()
        tea_img = QtWidgets.QLabel()
        salt_img = QtWidgets.QLabel()
        trinket_img = QtWidgets.QLabel()
        gold_img = QtWidgets.QLabel()
        action_point_img = QtWidgets.QLabel()
        silk_img2 = QtWidgets.QLabel()
        hides_img2 = QtWidgets.QLabel()
        fruit_img2 = QtWidgets.QLabel()
        tea_img2 = QtWidgets.QLabel()
        salt_img2 = QtWidgets.QLabel()
        trinket_img2 = QtWidgets.QLabel()
        action_point_img2 = QtWidgets.QLabel()
        gold_img2 = QtWidgets.QLabel()
        silk_img_board = QtWidgets.QLabel()
        hides_img_board = QtWidgets.QLabel()
        fruit_img_board = QtWidgets.QLabel()
        tea_img_board = QtWidgets.QLabel()
        salt_img_board = QtWidgets.QLabel()
        trinket_img_board = QtWidgets.QLabel()
        gold_img_board = QtWidgets.QLabel()

        generic_path = "Resources/templates/wares/"

        list_path = ["trinkets.png", "hides.png", "tea.png", "fruits.png", "salt.png", "silk.png"]
        list_img = [trinket_img, hides_img, tea_img, fruit_img, salt_img, silk_img]
        list_img2 = [trinket_img2, hides_img2, tea_img2, fruit_img2, salt_img2, silk_img2]
        list_img_board = [trinket_img_board, hides_img_board, tea_img_board, fruit_img_board, salt_img_board, silk_img_board]


        gold_img.setPixmap(QtGui.QPixmap("Resources/templates/gold.png").scaled(25, 25))
        gold_img2.setPixmap(QtGui.QPixmap("Resources/templates/gold.png").scaled(25, 25))
        gold_img_board.setPixmap(QtGui.QPixmap("Resources/templates/gold.png").scaled(25, 25))

        action_point_img.setPixmap(QtGui.QPixmap("Resources/templates/action_point.png").scaled(31, 25))
        action_point_img.setToolTip(LanguageManager.get_action_point_text().capitalize())
        action_point_img2.setPixmap(QtGui.QPixmap("Resources/templates/action_point.png").scaled(31, 25))
        action_point_img2.setToolTip(LanguageManager.get_action_point_text().capitalize())

        for img, img2,img_board, path, name in zip(list_img,list_img2,list_img_board, list_path, LanguageManager.get_wares_name()):
            img.setPixmap(QtGui.QPixmap(generic_path+path).scaled(25, 25))
            img.setToolTip(name.capitalize())
            img2.setPixmap(QtGui.QPixmap(generic_path+path).scaled(25, 25))
            img2.setToolTip(name.capitalize())
            img_board.setPixmap(QtGui.QPixmap(generic_path+path).scaled(25, 25))
            img_board.setToolTip(name.capitalize())

        silk_label = QtWidgets.QLabel()
        hides_label = QtWidgets.QLabel()
        fruit_label = QtWidgets.QLabel()
        tea_label = QtWidgets.QLabel()
        salt_label = QtWidgets.QLabel()
        trinket_label = QtWidgets.QLabel()
        self.turn_label = QtWidgets.QLabel()
        self.list_label_p1 = [trinket_label, hides_label, tea_label, fruit_label, salt_label, silk_label]
        toolbar_p1.addWidget(self.turn_label)
        toolbar_p1.addWidget(self.create_expanding_widget())
        toolbar_p1.addWidget(gold_img)
        toolbar_p1.addWidget(self.gold_label_p1)
        for img, label in zip(list_img, self.list_label_p1):
            toolbar_p1.addWidget(img)
            toolbar_p1.addWidget(label)
        toolbar_p1.addWidget(self.wares_label_p1)
        toolbar_p1.addWidget(action_point_img)
        toolbar_p1.addWidget(self.action_point_label_p1)
        self.addToolBar(QtCore.Qt.ToolBarArea.BottomToolBarArea, toolbar_p1)
        toolbar_p1.addWidget(self.create_expanding_widget())
        self.button_skip_phase = QtWidgets.QToolButton()
        toolbar_p1.addWidget(self.button_skip_phase)
        self.button_skip_phase.clicked.connect(self.action_btn)
        toolbar_p1.setMovable(False)
        toolbar_p1.setStyleSheet("QToolBar{border-image: url(Resources/templates/wood.jpg)}QLabel{font-weight:bold;font-size:15px;}")

        self.gold_label_p2 = QtWidgets.QLabel()
        self.action_point_label_p2 = QtWidgets.QLabel()
        self.wares_label_p2 = QtWidgets.QLabel()
        toolbar_p2 = QtWidgets.QToolBar()
        silk_label2 = QtWidgets.QLabel()
        hides_label2 = QtWidgets.QLabel()
        fruit_label2 = QtWidgets.QLabel()
        tea_label2 = QtWidgets.QLabel()
        salt_label2 = QtWidgets.QLabel()
        trinket_label2 = QtWidgets.QLabel()
        self.list_label_p2 = [trinket_label2, hides_label2, tea_label2, fruit_label2, salt_label2, silk_label2]
        toolbar_p2.addWidget(self.create_expanding_widget())
        toolbar_p2.addWidget(gold_img2)
        toolbar_p2.addWidget(self.gold_label_p2)
        for img, label in zip(list_img2, self.list_label_p2):
            toolbar_p2.addWidget(img)
            toolbar_p2.addWidget(label)
        toolbar_p2.addWidget(self.wares_label_p2)
        toolbar_p2.addWidget(action_point_img2)
        toolbar_p2.addWidget(self.action_point_label_p2)
        self.addToolBar(QtCore.Qt.ToolBarArea.TopToolBarArea, toolbar_p2)
        toolbar_p2.setMovable(False)
        toolbar_p2.setStyleSheet("QToolBar{border-image: url(Resources/templates/wood.jpg)}QLabel{font-weight:bold;font-size:15px;}")
        toolbar_p2.addWidget(self.create_expanding_widget())

        self.gold_label_board = QtWidgets.QLabel()
        toolbar_board = QtWidgets.QToolBar()
        silk_label_board = QtWidgets.QLabel()
        hides_label_board = QtWidgets.QLabel()
        fruit_label_board = QtWidgets.QLabel()
        tea_label_board = QtWidgets.QLabel()
        salt_label_board = QtWidgets.QLabel()
        trinket_label_board = QtWidgets.QLabel()
        self.list_label_board = [trinket_label_board, hides_label_board, tea_label_board, fruit_label_board, salt_label_board, silk_label_board]
        toolbar_board.addWidget(self.create_expanding_widget())
        toolbar_board.addWidget(gold_img_board)
        toolbar_board.addWidget(self.gold_label_board)
        for img, label in zip(list_img_board, self.list_label_board):
            toolbar_board.addWidget(img)
            label.setAlignment(QtCore.Qt.AlignmentFlag.AlignCenter)
            toolbar_board.addWidget(label)
        self.addToolBar(QtCore.Qt.ToolBarArea.LeftToolBarArea, toolbar_board)
        toolbar_board.setMovable(False)
        toolbar_board.setStyleSheet("QToolBar{border-image: url(Resources/templates/wood.jpg)}QLabel{font-weight:bold;font-size:15px;}")
        toolbar_board.addWidget(self.create_expanding_widget())

        toolbar_right = QtWidgets.QToolBar()
        toolbar_right.setFixedWidth(25)
        self.addToolBar(QtCore.Qt.ToolBarArea.RightToolBarArea, toolbar_right)
        toolbar_right.setMovable(False)
        toolbar_right.setStyleSheet("QToolBar{border-image: url(Resources/templates/wood.jpg)}")
        self.update_resources()

    def action_btn(self):
        from GameModule.GameManager import SingletonFactory 
        gm = SingletonFactory.get_instance()
        gm.run_game()

    def set_up_player_zone(self):
        """place the zone for the players
        """
        self.create_player_areas(6, self.ui.market_place_p1_zone, self.ui.market_place_p2_zone, SlotEnum.MARKETPLACE_P1)
        self.create_player_areas(3, self.ui.utility_p1, self.ui.utility_p2, SlotEnum.UTILITY1_P1)

    def create_expanding_widget(self):
        """create the expanding widget to center others widget in the window

        Returns:
            QWidget : the expanding widget
        """
        spacer = QWidget()
        spacer.setSizePolicy(QtWidgets.QSizePolicy.Policy.Expanding, QtWidgets.QSizePolicy.Policy.Expanding)
        return spacer

    def create_player_areas(self, nb_slot:int, place_1: QtWidgets.QHBoxLayout ,place_2: QtWidgets.QHBoxLayout, id_start:SlotEnum)->None:
        """create the players area on the board

        Args:
            nb_slot (int): number of slot to add in players areas 
            place_1 (QtWidgets.QHBoxLayout): areas of player 1
            place_2 (QtWidgets.QHBoxLayout): areas of player 2
            id_start (SlotEnum): the slot enum to start
        """
        place_1.addSpacerItem(self.create_hspace_item())
        place_2.addSpacerItem(self.create_hspace_item())
        for i in range(0, nb_slot):
            place_1.addWidget(self.generate_card_widget(SlotEnum(id_start.value+i), None))
            place_2.addWidget(self.generate_card_widget(SlotEnum(id_start.value+i+10), None))
        place_1.addSpacerItem(self.create_hspace_item())
        place_2.addSpacerItem(self.create_hspace_item())

    def create_neutral_area(self, neutral_zone:QtWidgets.QHBoxLayout)->None:
        """create the area which doesn't belong to a player

        Args:
            neutral_zone (QtWidgets.QHBoxLayout): the area to fill
        """
        neutral_zone.addSpacerItem(self.create_hspace_item())
        neutral_zone.addSpacerItem(self.create_hspace_item())
        event_slot = VisualSlot(SlotEnum.EVENT_SLOT)
        neutral_zone.addWidget(event_slot)
        self.slots.append(event_slot)
        neutral_zone.addSpacerItem(self.create_hspace_item())
        neutral_zone.addSpacerItem(self.create_hspace_item())
        draw_widget = VisualSlot(SlotEnum.CARD_DRAW)
        self.slots.append(draw_widget)
        draw_widget.clicked.connect(lambda state, x=draw_widget.id: self.event_draw(x))
        neutral_zone.addWidget(draw_widget)
        discard_slot = VisualSlot(SlotEnum.DISCARD)
        neutral_zone.addWidget(discard_slot)
        self.slots.append(discard_slot)
        neutral_zone.addSpacerItem(self.create_hspace_item())
        neutral_zone.addSpacerItem(self.create_hspace_item())
        neutral_zone.addSpacerItem(self.create_hspace_item())
        neutral_zone.addSpacerItem(self.create_hspace_item())

    def create_hspace_item(self)->QtWidgets.QSpacerItem:
        """create spacer item

        Returns:
            QtWidgets.QSpacerItem: the spacer item created
        """
        space = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Policy.Expanding, QtWidgets.QSizePolicy.Policy.Minimum)
        return space

    def set_deck(self, deck_p1:CardSlot, deck_p2:CardSlot, deck_zone_1: QtWidgets.QHBoxLayout, deck_zone_2: QtWidgets.QHBoxLayout, language:LanguageEnum):
        """set the players deck

        Args:
            deck_p1 (CardSlot): player 1's deck
            deck_p2 (CardSlot): player 2's deck
            deck_zone_1 (QtWidgets.QHBoxLayout): player 1 zone deck
            deck_zone_2 (QtWidgets.QHBoxLayout): player 2 zone deck
            language (LanguageEnum): language of the game
        """
        while deck_zone_1.count() > 0:
            widget = deck_zone_1.takeAt(0).widget()
            if widget:
                widget.deleteLater()
                widget = None
        while deck_zone_2.count() > 0:
            widget = deck_zone_2.takeAt(0).widget()
            if widget:
                widget.deleteLater()
                widget = None

        self.player1_cards.clear()
        self.player2_cards.clear()
        deck_zone_1.addSpacerItem(self.create_hspace_item())
        deck_zone_2.addSpacerItem(self.create_hspace_item())
        for i in deck_p1.cards:
            deck_zone_1.addWidget(self.generate_card_widget(SlotEnum.DECK_P1, i))
            
        for i in deck_p2.cards:
            deck_zone_2.addWidget(self.generate_card_widget(SlotEnum.DECK_P2, i))
        deck_zone_1.addItem(self.create_hspace_item())
        deck_zone_2.addItem(self.create_hspace_item())

    def generate_card_widget(self,slot_enum: SlotEnum, card:Card)->VisualSlot:
        """card widget visual

        Args:
            slot_enum (SlotEnum): slot of the card
            card (Card): the card

        Returns:
            VisualSlot: the slot 
        """
        card_widget = VisualSlot(slot_enum, card)
        card_widget.clicked.connect(lambda state, x=card_widget.id, y=card_widget.card, z=card_widget: self.event_draw(x, y,z))
        if slot_enum == SlotEnum.DECK_P1:
            self.player1_cards.append(card_widget)
        elif slot_enum == SlotEnum.DECK_P2:
            self.player2_cards.append(card_widget)
        else:
            self.slots.append(card_widget)
        return card_widget

    def event_draw(self, id:SlotEnum, card:Card = ..., clicked_widget:VisualSlot=...):
        """appends when phe player draws a card

        Args:
            id (SlotEnum): the draw slot
            card (Card, optional): card drawed. Defaults to ....
            clicked_widget (VisualSlot, optional): the widget of the slot draw. Defaults to ....
        """
        from GameModule.GameManager import SingletonFactory 
        gm = SingletonFactory.get_instance()
        if card is None:
            card = clicked_widget.card
        if id == SlotEnum.CARD_DRAW:
            draw = gm.board.slots.get(SlotEnum.CARD_DRAW)
            card_to_draw = draw.cards[-1]

            msg = QMessageBox()
            msg.setWindowTitle(LanguageManager.get_draw_window_text())
            msg.setStandardButtons(QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
            text = card_to_draw.name.get(self.language)
            if text is None:
                text = LanguageManager.get_type_card_text(card_to_draw)
            msg.setText(LanguageManager.get_draw_choice_text(text, self.language, card_to_draw))
            ret = msg.exec()
            wants_card = True
            if ret == QMessageBox.StandardButton.No:
                wants_card = False

            gm.phase1_resolve_draw_choice(card_to_draw, wants_card)
            if wants_card:
                gm.run_game()

        elif id == SlotEnum.DECK_P1:
            deck = gm.board.slots.get(SlotEnum.DECK_P1)
            msg = QMessageBox()
            msg.setWindowTitle("")
            msg.setStandardButtons(QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
            msg.setText(LanguageManager.get_use_card_choice_text(card, gm.current_langage))
            ret = msg.exec()
            if ret == QMessageBox.StandardButton.Yes:
                gm.phase2_play_card(card)
        elif id == SlotEnum.UTILITY1_P1 or id == SlotEnum.UTILITY2_P1 or id == SlotEnum.UTILITY3_P1:
            gm.phase2_use_utility_card(card)

    def update(self):
        """Gather all informations from the board and update the UI.
        Call this everytime something happened on the board
        """
        from GameModule.GameManager import SingletonFactory
        gm = SingletonFactory.get_instance()

        if gm.number_of_ai == 2 and not gm.game_finished:
            return

        self.language = gm.current_langage

        self.button_skip_phase.setText(LanguageManager.get_btn_skip_phase_text())
        if gm.active_phase == 2:
            self.button_skip_phase.setStyleSheet("QToolButton{font-weight:bold;font-size:13px;background-color:red}")
        else:
            self.button_skip_phase.setStyleSheet("QToolButton{font-size:15px;}")

        self.update_resources()
        

        deck_p1 = gm.board.slots.get(SlotEnum.DECK_P1)
        deck_p2 = gm.board.slots.get(SlotEnum.DECK_P2)

        self.set_deck(deck_p1, deck_p2, self.ui.deck_p1, self.ui.deck_p2, self.language)
        self.disable_all_slots()

        for visual_slot in self.slots:
            if visual_slot.id is not SlotEnum.CARD_DRAW:
                cards = gm.board.slots[visual_slot.id].cards
                if len(cards) > 0:
                    if visual_slot.id is SlotEnum.DISCARD:
                        visual_slot.set_card(cards[-1])
                    else:
                        visual_slot.set_card(cards[0])
                        if isinstance(cards[0], UtilityCard) and gm.get_owning_player(cards[0]) == gm.board.player1:
                            visual_slot.setEnabled(gm.active_player.action_points > 0 and cards[0].can_be_played() and not cards[0].used)
                else:
                    visual_slot.set_card(None)
            else:
                visual_slot.set_card(None)
        phase = gm.active_phase

        if gm.active_player == gm.board.player1:
            # only player1 can be a human
            if phase == 1:
                if gm.active_player.action_points > 0:
                    self.get_visual_slot(SlotEnum.CARD_DRAW).setEnabled(True)
            elif phase == 2:
                for card_slot in self.player1_cards:
                    if isinstance(card_slot.card, UtilityCard):
                        card_slot.setEnabled(gm.active_player.action_points > 0)
                    else:
                        card_slot.setEnabled((not card_slot.card.action_used or gm.active_player.action_points > 0) and card_slot.card.can_be_played())

    def get_visual_slot(self, slot_enum: SlotEnum):
        for slot in self.slots:
            if slot.id == slot_enum:
                return slot

    def disable_all_slots(self):
        list_slot = [SlotEnum.MARKETPLACE_P1,SlotEnum.MARKET_EXTENSION1_P1,SlotEnum.MARKET_EXTENSION2_P1,SlotEnum.MARKET_EXTENSION3_P1,SlotEnum.MARKET_EXTENSION4_P1,SlotEnum.MARKET_EXTENSION5_P1,SlotEnum.MARKETPLACE_P2,SlotEnum.MARKET_EXTENSION1_P2,SlotEnum.MARKET_EXTENSION2_P2,SlotEnum.MARKET_EXTENSION3_P2,SlotEnum.MARKET_EXTENSION4_P2,SlotEnum.MARKET_EXTENSION5_P2]
        for slot in self.slots:
            if slot.id in list_slot:
                slot.setEnabled(True)
            else: 
                slot.setEnabled(False)
        for slot in self.player1_cards:
            slot.setEnabled(False)
        for slot in self.player2_cards:
            slot.setEnabled(True)

    def start_phase(self, phase: int):
        from GameModule.GameManager import SingletonFactory
        game_manager = SingletonFactory.get_instance()

    def show_string_choice(self, strings: List[str], title: str = None, desc: str = None):
        """show the message box for when the player have to do a choice between 2 action

        Args:
            strings (List[str]): list of choices
            title (str, optional): title of the window. Defaults to None.
            desc (str, optional): text of the window. Defaults to None.

        Returns:
            _type_: the player choice
        """
        msg = MessageBox()
        window_title = "Please choose what to do"
        if title is not None:
            window_title = title
        if desc is not None:
            msg.setText(desc)
        msg.setWindowTitle(window_title)
        for i in range(len(strings)):
            button = QtWidgets.QToolButton()
            button.setText(strings[i])
            button.setMinimumHeight(50)
            button.setMaximumHeight(50)
            msg.addButton(button, QtWidgets.QMessageBox.ButtonRole.AcceptRole)
        msg.setWindowFlags(QtCore.Qt.WindowType.CustomizeWindowHint | QtCore.Qt.WindowType.WindowTitleHint)
        return strings[msg.exec()]

    def show_card_choice(self, cards: List[Card], title: str = None, desc: str = None):
        """show the message box for when the player have to do a choice between multiple cards

        Args:
            cards (List[Card]): list of card
            title (str, optional): title of the window. Defaults to None.
            desc (str, optional): desc of the window. Defaults to None.

        Returns:
            _type_: the player choice
        """
        msg = MessageBox()
        window_title = "Please choose what to do"
        if title is not None:
            window_title = title
        if desc is not None:
            msg.setText(desc)
        msg.setWindowTitle(window_title)
        for c in cards:
            button = VisualSlot(None, c)
            button.setEnabled(True)
            msg.addButton(button, QtWidgets.QMessageBox.ButtonRole.AcceptRole)
        msg.setWindowFlags(QtCore.Qt.WindowType.CustomizeWindowHint | QtCore.Qt.WindowType.WindowTitleHint)
        return cards[msg.exec()]

    def show_auction(self, current_cost: int, cards: Set[Card] = None, wares: Set[Ware] = None, player_has_gold = True):
        diag = AuctionDialog()
        diag.cards = cards
        diag.wares = wares
        diag.golds = current_cost
        diag.can_add = player_has_gold
        return diag.exec()

    def update_resources(self):
        """update the resources displayed
        """
        from GameModule.GameManager import SingletonFactory
        gm = SingletonFactory.get_instance()
        nb_ware_p1 = 0

        self.turn_label.setText(LanguageManager.get_actual_turn_text())

        for label, name in zip(self.list_label_p1, LanguageManager.get_wares_name()):
            nb_ware_p1 += gm.board.player1.get_num_ware_by_name(name)
            label.setText(" : "+ str(gm.board.player1.get_num_ware_by_name(name)) +"      ")
        self.gold_label_p1.setText(" : "+ str(gm.board.player1.gold) +"      ")
        self.action_point_label_p1.setText(" : "+ str(gm.board.player1.action_points) +"      ")
        self.wares_label_p1.setText(LanguageManager.get_ware_toolbar_text() + " : " + str(nb_ware_p1) + "/" + str(gm.board.player1.market_size)+"      ")

        nb_ware_p2 = 0
        for label, name in zip(self.list_label_p2, LanguageManager.get_wares_name()):
            nb_ware_p2 += gm.board.player2.get_num_ware_by_name(name)
            label.setText(" : "+ str(gm.board.player2.get_num_ware_by_name(name)) +"      ")
        self.gold_label_p2.setText(" : "+ str(gm.board.player2.gold) +"      ")
        self.action_point_label_p2.setText(" : "+ str(gm.board.player2.action_points) +"      ")
        self.wares_label_p2.setText(LanguageManager.get_ware_toolbar_text() +" : " + str(nb_ware_p2) + "/" + str(gm.board.player2.market_size)+"      ")

        for label, name in zip(self.list_label_board, LanguageManager.get_wares_name()):
            label.setText(str(gm.board.get_num_ware_by_name(name)))
        self.gold_label_board.setText(str(gm.board.gold))

    def endGame(self):
        """the end of the game but visual
        """
        msg = QMessageBox()
        from GameModule.GameManager import SingletonFactory 
        gm = SingletonFactory.get_instance()
        msg.setWindowTitle(LanguageManager.get_end_title())
        if gm.winner == gm.board.player1:
            msg.setIcon(QMessageBox.Icon.Information)
        else:
            msg.setIcon(QMessageBox.Icon.Critical)
        msg.setText(LanguageManager.get_end_text())
        msg.setStandardButtons(QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        ret = msg.exec()
        if ret == QMessageBox.StandardButton.Yes:
            gm.log_window.setVisible(False)
            while gm.log_window.layout_log.count() > 0:
                widget = gm.log_window.layout_log.takeAt(0).widget()
                if widget:
                    widget.deleteLater()
                    widget = None
            self.setHidden(True)
            self.button_skip_phase.setEnabled(True)
            gm.reset_game()
            gm.game_finished=False
            gm.setting_window.setHidden(False)
            