from PyQt6 import QtWidgets, QtCore, QtGui
from CardsModule import Card, MarketCard, WareCard
from UtilityModule import LanguageManager, SlotEnum
from PyQt6 import QtCore, QtGui, QtWidgets
from PyQt6.QtCore import Qt, QRect
from typing import *
from GameModule.Ware import Ware

class MySwitch(QtWidgets.QPushButton):
    """Class MySwitch

    Heritance : QtWidgets.QPushButton

    Generate Switch Button 

    Code find on StackOverFlow
    """
    def __init__(self, parent = None):
        super().__init__(parent)
        self.setCheckable(True)
        self.setMinimumWidth(150)
        self.setMinimumHeight(100)

    def paintEvent(self, event):
        """paint_event

        Args:
            event (_type_): change color when status button change
        """
        text = LanguageManager.get_player_color_text()
        label = text[0] if self.isChecked() else text[1]
        bg_color = Qt.GlobalColor.blue if self.isChecked() else Qt.GlobalColor.green

        radius = 10
        width = 75
        center = self.rect().center()

        painter = QtGui.QPainter(self)
        painter.translate(center)
        painter.setBrush(QtGui.QColor(0,0,0))

        pen = QtGui.QPen(Qt.GlobalColor.black)
        pen.setWidth(2)
        painter.setPen(pen)

        painter.drawRoundedRect(QRect(-width, -radius, 2*width, 2*radius), radius, radius)
        painter.setBrush(QtGui.QBrush(bg_color))
        sw_rect = QRect(-radius, -radius, width + radius, 2*radius)
        if not self.isChecked():
            sw_rect.moveLeft(-width)
        painter.drawRoundedRect(sw_rect, radius, radius)
        painter.drawText(sw_rect, Qt.AlignmentFlag.AlignCenter, label)


class VisualSlot(QtWidgets.QToolButton):
    """Class VisualSlot

    Heritance : QToolButton

    This class is the visual widget for cards on the board
    """
    def __init__(self, id_slot:SlotEnum, card:Card=None):
        super().__init__()
        self.setEnabled(False)
        list_slot = [SlotEnum.MARKETPLACE_P1,SlotEnum.MARKET_EXTENSION1_P1,SlotEnum.MARKET_EXTENSION2_P1,SlotEnum.MARKET_EXTENSION3_P1,SlotEnum.MARKET_EXTENSION4_P1,SlotEnum.MARKET_EXTENSION5_P1,SlotEnum.MARKETPLACE_P2,SlotEnum.MARKET_EXTENSION1_P2,SlotEnum.MARKET_EXTENSION2_P2,SlotEnum.MARKET_EXTENSION3_P2,SlotEnum.MARKET_EXTENSION4_P2,SlotEnum.MARKET_EXTENSION5_P2]
        if id_slot in list_slot:
            self.size_btn = QtCore.QSize(96, 62)
        else:
            self.size_btn = QtCore.QSize(62, 96)
        self.setMinimumSize(self.size_btn)
        self.setMaximumSize(self.size_btn)
        self.id = id_slot
        self.card: Card = None
        self.label = QtWidgets.QLabel()
        self.label.setWordWrap(True)
        self.label.setAlignment(QtCore.Qt.AlignmentFlag.AlignCenter)
        self.set_card(card)
        self.layout = QtWidgets.QHBoxLayout(self)
        self.layout.addWidget(self.label)
        from GameModule.GameManager import SingletonFactory
        color = SingletonFactory.get_instance().player_color
        if color == "dodgerblue":
            color2 = "lawngreen"
        else:
            color2 = "dodgerblue"
        if self.id == SlotEnum.DECK_P1:
            self.setStyleSheet("QToolButton{background-color: "+ color +"; border:2px solid;border-color:"+ color +";border-radius:5px;}")

        elif self.id == SlotEnum.DECK_P2:
            self.setStyleSheet("QToolButton{background-color: "+ color2 +";border:2px solid;border-color:"+ color2 +";border-radius:5px;}") 
        else:
            self.setStyleSheet("QToolButton{background-color: rgba(255, 255, 255, 0);}")

    def mousePressEvent(self, a0: QtGui.QMouseEvent) -> None:
        """appends when mouse press this visual widget

        Args:
            a0 (QtGui.QMouseEvent): Mouse Event

        Returns:
            None: return none
        """
        print(self.id)
        print(self.card)
        return super().mousePressEvent(a0)

    def set_card(self, card: Card):
        """set card on the widget 

        Args:
            card (Card): the card to display/remove
        """
        from GameModule.GameManager import SingletonFactory
        gm = SingletonFactory.get_instance()
        self.card = card
        if card is not None:
            if self.id is not SlotEnum.DECK_P2:
                tooltip = "<html><div style=\"max-width: 600px;\">"
                name = card.name.get(gm.current_langage)
                if name is None:
                    name = LanguageManager.get_type_card_text(card)
                if card.img is not None:
                    icon = QtGui.QIcon(card.img)
                    icon.pixmap(self.size_btn)
                    self.setIcon(icon)
                    self.setIconSize(self.size_btn)
                else:
                    self.label.setText(name)
                tooltip += "<b>{}</b><br><br>".format(name)
                desc = ""
                if isinstance(card, WareCard):
                    desc = LanguageManager.get_ware_card_desc(card, gm.current_langage)
                elif not isinstance(card, MarketCard):
                    desc = card.desc[gm.current_langage]
                tooltip += desc + "<br><br>In " + gm.get_card_slot(card).id.name
                tooltip += "</div></html>"
                self.setToolTip(QtCore.QCoreApplication.translate("MainWindow", tooltip))
            else:
                icon = QtGui.QIcon("Resources/templates/back_card.png")
                icon.pixmap(self.size_btn)
                self.setIcon(icon)
                self.setIconSize(self.size_btn)
        elif self.id is SlotEnum.CARD_DRAW:
            self.label.setText(str(len(gm.board.slots[SlotEnum.CARD_DRAW].cards)))
            self.setToolTip("")
            icon = QtGui.QIcon("Resources/templates/back_card.png")
            icon.pixmap(self.size_btn)
            self.setIcon(icon)
            self.setIconSize(self.size_btn)
        else:
            self.setIcon(QtGui.QIcon())
            self.setEnabled(False)
            self.label.setText("")
            self.setToolTip("")
            self.setToolTipDuration(-1)
        # Update card image

class MessageBox(QtWidgets.QMessageBox):
    """A custom QMessageBox which makes the buttons centered
    """
    def __init__(self, parent=None):
        super().__init__(parent)
        grid_layout = self.layout()

        qt_msgboxex_icon_label = self.findChild(QtWidgets.QLabel, "qt_msgboxex_icon_label")
        qt_msgboxex_icon_label.deleteLater()

        qt_msgbox_label = self.findChild(QtWidgets.QLabel, "qt_msgbox_label")
        qt_msgbox_label.setAlignment(QtCore.Qt.AlignmentFlag.AlignCenter)
        grid_layout.removeWidget(qt_msgbox_label)

        qt_msgbox_buttonbox = self.findChild(QtWidgets.QDialogButtonBox, "qt_msgbox_buttonbox")
        grid_layout.removeWidget(qt_msgbox_buttonbox)

        grid_layout.addWidget(qt_msgbox_label, 0, 0, alignment=QtCore.Qt.AlignmentFlag.AlignCenter)
        grid_layout.addWidget(qt_msgbox_buttonbox, 1, 0, alignment=QtCore.Qt.AlignmentFlag.AlignCenter)

class AuctionDialog(QtWidgets.QDialog):
    """The auction window for auction
    """
    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setWindowFlags(QtCore.Qt.WindowType.CustomizeWindowHint | QtCore.Qt.WindowType.WindowTitleHint)
        self.wares: Set[Ware] = None
        self.cards: Set[Card] = None
        self.golds: int = 0
        self.can_add = True
        self.setFixedSize(QtCore.QSize(350, 250))
    
    def exec(self) -> int:
        self.setWindowTitle(LanguageManager.get_auction_title())
        self.setLayout(QtWidgets.QVBoxLayout())

        desc_label = QtWidgets.QLabel(LanguageManager.get_auction_desc())
        desc_label.setAlignment(QtCore.Qt.AlignmentFlag.AlignCenter)
        self.layout().addWidget(desc_label)

        if self.cards:
            cards_rewards_layout = QtWidgets.QHBoxLayout()
            cards_rewards_frame = QtWidgets.QFrame()
            cards_rewards_frame.setLayout(cards_rewards_layout)
            for card in self.cards:
                cards_rewards_layout.addWidget(VisualSlot(SlotEnum.EVENT_SLOT, card))
            self.layout().addWidget(cards_rewards_frame)

        if self.wares:
            from GameModule.GameManager import SingletonFactory
            wares_rewards_layout = QtWidgets.QHBoxLayout()
            wares_rewards_frame = QtWidgets.QFrame()
            wares_rewards_frame.setLayout(wares_rewards_layout)
            for ware in self.wares:
                label = QtWidgets.QLabel()
                label.setText(ware.name[SingletonFactory.get_instance().current_langage])
                label.setAlignment(QtCore.Qt.AlignmentFlag.AlignCenter)
                wares_rewards_layout.addWidget(label)
            self.layout().addWidget(wares_rewards_frame)
        
        golds_label = QtWidgets.QLabel(LanguageManager.get_auction_current_golds() + str(self.golds))
        golds_label.setAlignment(QtCore.Qt.AlignmentFlag.AlignCenter)
        self.layout().addWidget(golds_label)

        buttons_layout = QtWidgets.QHBoxLayout()
        buttons_frame = QtWidgets.QFrame()
        buttons_frame.setLayout(buttons_layout)
        (add_text, pass_text) = LanguageManager.get_auction_texts()
        button_add = QtWidgets.QToolButton()
        button_add.setText(add_text)
        button_add.clicked.connect(self.accept)
        button_add.setMinimumHeight(50)
        button_add.setMaximumHeight(50)
        button_add.setMaximumWidth(150)
        button_add.setMinimumWidth(150)
        button_add.setEnabled(self.can_add)
        button_pass = QtWidgets.QToolButton()
        button_pass.setText(pass_text)
        button_pass.clicked.connect(self.reject)
        button_pass.setMinimumHeight(50)
        button_pass.setMaximumHeight(50)
        button_pass.setMaximumWidth(150)
        button_pass.setMinimumWidth(150)
        buttons_layout.addWidget(button_add)
        buttons_layout.addWidget(button_pass)
        self.layout().addWidget(buttons_frame)

        return super().exec()

class logs_move_played(QtWidgets.QMainWindow):
    """Logs windows that display players moves
    """
    def __init__(self, parent=None):
        super().__init__(parent)
        self.scroll_area = QtWidgets.QScrollArea()
        self.widget = QtWidgets.QWidget()
        self.layout_log = QtWidgets.QVBoxLayout()
        self.setFixedSize(QtCore.QSize(200, 700))
        geom = self.geometry()
        geom.setX(50)
        geom.setY(50)
        self.setGeometry(geom)
        self.widget.setLayout(self.layout_log)
        self.scroll_area.setWidget(self.widget)

        self.setWindowTitle("Logs")

        self.setCentralWidget(self.scroll_area)

        self.scroll_area.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOn)
        self.scroll_area.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        self.scroll_area.setWidgetResizable(True)
        self.scroll_area.verticalScrollBar().rangeChanged.connect(self.ranged_changed)
        self.layout_log.setAlignment(Qt.AlignmentFlag.AlignTop)
        self.setLayout(self.layout_log)
        self.setHidden(True)
        self.setWindowFlag(QtCore.Qt.WindowType.WindowStaysOnTopHint)
    
    def add_line(self, line:str):
        """add a new line to the logs window

        Args:
            line (str): the text to add to the logs
        """
        label = QtWidgets.QLabel(line)
        self.layout_log.addWidget(label)
    
    def ranged_changed(self, min, max):
        """Called when the vertical scroll bar's range changes

        Args:
            min (_type_): new min value
            max (_type_): new max value
        """
        self.scroll_area.verticalScrollBar().setValue(max)
