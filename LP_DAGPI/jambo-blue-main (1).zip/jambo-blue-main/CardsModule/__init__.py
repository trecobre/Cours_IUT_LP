from abc import ABCMeta, abstractmethod
from typing import *
from xml.dom.domreg import well_known_implementations 
from GameModule.Ware import Ware
from GameModule.PlayerInventory import PlayerInventory
from UtilityModule import *


class Card(metaclass=ABCMeta):
    def __init__(self) -> None:
        self.name: Dict[LanguageEnum, str] = dict[LanguageEnum, str]()
        self.desc: Dict[LanguageEnum, str] = dict[LanguageEnum, str]()
        self.img: str = ""
        self.action_used: bool = True
        self.used_by_croco = False
    
    #@abstractmethod
    def use(self):
        pass
    
    #@abstractmethod
    def can_be_played(self) -> bool:
        return True
    
    #@abstractmethod
    def on_phase_start(self, phase: int):
        pass

    #@abstractmethod
    def on_phase_end(self, phase: int):
        pass

    def get_ennemy_player(self) -> PlayerInventory:
        from GameModule.GameManager import SingletonFactory
        game_manager = SingletonFactory.get_instance()
        player = game_manager.get_owning_player(self)
        ennemy_player = None
        if player == game_manager.board.player1:
            ennemy_player = game_manager.board.player2
        else: 
            ennemy_player= game_manager.board.player1 
        return ennemy_player
                 
class MarketCard(Card):
    def __init__(self, size: int) -> None:
        super().__init__()
        self.size: int = size
        if size == 6:
            self.img = "Resources/templates/large_market_stand.png"
        else:
            self.img = "Resources/templates/small_market_stand.png"
        
    
    def use(self):
        from GameModule.GameManager import SingletonFactory
        gm = SingletonFactory.get_instance()
        player = gm.get_owning_player(self)
        player.market_size += self.size
        player.give_gold(gm.board, gm.current_small_market_stand_price)
        gm.current_small_market_stand_price = gm.BUILD_OTHER_SMALL_MARKET_STAND_PRICE
    
    def can_be_played(self) -> bool:
        from GameModule.GameManager import SingletonFactory
        game_manager = SingletonFactory.get_instance()
        player = game_manager.get_owning_player(self)
        confirmation = False
        if player.gold >= game_manager.current_small_market_stand_price:
            if player == game_manager.board.player1:
                confirmation = len(game_manager.board.slots[SlotEnum.MARKET_EXTENSION5_P1].cards) == 0
            else:
                confirmation = len(game_manager.board.slots[SlotEnum.MARKET_EXTENSION5_P2].cards) == 0
        else:
            confirmation = False

        return confirmation

class WareCard(Card):
    def __init__(self):
        super().__init__()
        self.buy_price : int = 0
        self.sell_price : int = 0
        self.wares : Set[Ware] = set[Ware]()
        self.img = "Resources/templates/ware_card.png"
    
    def use(self):
        from GameModule.GameManager import SingletonFactory
        game_manager = SingletonFactory.get_instance()
        (choice_buy_sentence, choice_sell_sentence)= LanguageManager.get_buy_sell_text()
        player = game_manager.get_owning_player(self)
        count = 0
        player_has_wares = True
        for ware in self.wares:
            if player.get_num_ware_by_name(ware.name[game_manager.current_langage]) >= self.get_num_ware_by_name(ware.name[game_manager.current_langage]) :
                count += 1
            else:
                player_has_wares = False

        board_has_wares = True

        for ware in self.wares:
            name = ware.name[game_manager.current_langage]
            if game_manager.board.get_num_ware_by_name(name) < self.get_num_ware_by_name(name):
                board_has_wares = False
                break

        if not board_has_wares and not player_has_wares:
            return False

        buy_price = self.buy_price - player.ware_buy_reduction
        sell_price = self.sell_price + player.ware_sell_buff

        if buy_price < 0:
            buy_price = 0

        can_buy = board_has_wares and player.gold >= buy_price and len(player.wares) + len(self.wares) <= player.market_size
        can_sell = player_has_wares and game_manager.board.gold >= sell_price

        choices = []

        wares_name = []
        for ware in self.wares:
            wares_name.append(ware.get_name())

        if can_buy:
            choices.append(choice_buy_sentence)
            game_manager.log_window.add_line(game_manager.get_active_player_text() + " buy wares : " + str(wares_name) + " (-" + str(self.buy_price) + "Golds)")
        if can_sell:
            choices.append(choice_sell_sentence)
            game_manager.log_window.add_line(game_manager.get_active_player_text() + " sell wares : " + str(wares_name) + " (+" + str(self.sell_price) + "Golds)")
        choice_result = game_manager.start_string_choice(choices)

        player = game_manager.get_owning_player(self)
        if choice_result == choice_buy_sentence:
            player.give_gold(game_manager.board,buy_price)
            game_manager.board.give_Wares(player,self.wares)
        elif choice_result == choice_sell_sentence:
            game_manager.board.give_gold(player,sell_price)
            player.give_Wares(game_manager.board,self.wares)       

    def can_be_played(self) -> bool:
        from GameModule.GameManager import SingletonFactory
        game_manager = SingletonFactory.get_instance()

        player = game_manager.get_owning_player(self)
        count = 0
        player_has_wares = True
        for ware in self.wares:
            if player.get_num_ware_by_name(ware.name[game_manager.current_langage]) >= self.get_num_ware_by_name(ware.name[game_manager.current_langage]) :
                count += 1
            else:
                player_has_wares = False

        board_has_wares = True

        for ware in self.wares:
            name = ware.name[game_manager.current_langage]
            if game_manager.board.get_num_ware_by_name(name) < self.get_num_ware_by_name(name):
                board_has_wares = False
                break

        if not board_has_wares and not player_has_wares:
            return False

        buy_price = self.buy_price - player.ware_buy_reduction
        sell_price = self.sell_price + player.ware_sell_buff

        if buy_price < 0:
            buy_price = 0

        player_has_gold_to_fill = True
        if len(player.wares) + len(self.wares) == player.market_size:
            if player.gold < buy_price + game_manager.FILL_LARGE_MARKET_STAND_PRICE:
                player_has_gold_to_fill = False

        can_buy = board_has_wares and player.gold >= buy_price and len(player.wares) + len(self.wares) <= player.market_size and player_has_gold_to_fill
        can_sell = player_has_wares and game_manager.board.gold >= sell_price

        if can_buy or can_sell:
            return True
        else:
            return False    


    def on_phase_end(self, phase: int):
        return super().on_phase_end(phase)

    def on_phase_start(self, phase: int):
        return super().on_phase_start(phase)     

    def get_num_ware_by_name(self, name: str) -> int:
        """Get the number of the specified ware

        Args:
            name (str): Ware name in current language

        Returns:
            int: Quantity
        """
        from GameModule.GameManager import SingletonFactory

        count = 0

        for ware in self.wares:
            if name == ware.name[SingletonFactory.get_instance().current_langage]:
                count += 1
        
        return count       
