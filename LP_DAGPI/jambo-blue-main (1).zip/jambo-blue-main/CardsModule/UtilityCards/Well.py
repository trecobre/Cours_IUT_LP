from CardsModule.UtilityCards import UtilityCard
import GameModule
from GameModule.Board import Board
from GameModule.GoldHolder import GoldHolder
from GameModule.CardSlot import CardSlot
from GameModule.PlayerInventory import PlayerInventory
from UtilityModule import *

class Well(UtilityCard):
    def __init__(self) -> None:
        super().__init__()
        self.img = "Resources/templates/utilitycard/well.png"

        
    def on_phase_start(self, phase: int):
        pass

    def on_phase_end(self, phase: int):
        pass
    
    def can_be_played(self) -> bool:
        from GameModule.GameManager import SingletonFactory
        game_manager = SingletonFactory.get_instance()
        player = game_manager.get_owning_player(self)
        is_not_empty = False
        if player.gold >= 1:
                is_not_empty = True

        return is_not_empty
        
    def use(self):
        from GameModule.GameManager import SingletonFactory
        
        game_manager = SingletonFactory.get_instance()
        player = game_manager.get_owning_player(self)
        game_manager.active_player.give_gold(game_manager.board, 1)
        if player == game_manager.board.player1:
            game_manager.board.slots[SlotEnum.CARD_DRAW].give_card(game_manager.board.slots[SlotEnum.CARD_DRAW].cards[-1], SlotEnum.DECK_P1)
        elif player == game_manager.board.player2:
            game_manager.board.slots[SlotEnum.CARD_DRAW].give_card(game_manager.board.slots[SlotEnum.CARD_DRAW].cards[-1], SlotEnum.DECK_P2)