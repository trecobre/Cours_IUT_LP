from CardsModule.UtilityCards import UtilityCard
from UtilityModule import SlotEnum

class Drums(UtilityCard):
    def __init__(self) -> None:
        super().__init__()
        self.img = "Resources/templates/utilitycard/drums.png"
    
    def use(self):
        from GameModule.GameManager import SingletonFactory
        game_manager = SingletonFactory.get_instance()
        player = game_manager.get_owning_player(self)
        ware_available = []
        for ware in game_manager.base_wares:
            if player.get_num_ware_by_name(ware.name[game_manager.current_langage]) >= 1:
                ware_available.append(ware.name[game_manager.current_langage])
        choice_result = game_manager.start_string_choice(ware_available,player)
        player.give_Ware(game_manager.board,choice_result,1)
        if player == game_manager.board.player1:
            game_manager.board.slots[SlotEnum.CARD_DRAW].give_card_at(-1,SlotEnum.DECK_P1)
        else:
            game_manager.board.slots[SlotEnum.CARD_DRAW].give_card_at(-1,SlotEnum.DECK_P1)


    
    def can_be_played(self) -> bool:
        from GameModule.GameManager import SingletonFactory
        game_manager = SingletonFactory.get_instance()
        player = game_manager.get_owning_player(self)
        player_have_ware = False
        for ware in game_manager.base_wares:
            if player.get_num_ware_by_name(ware.name[game_manager.current_langage]) >= 1:
                player_have_ware = True
                break
        return player_have_ware