
from CardsModule.UtilityCards import UtilityCard

class LeopardStatue(UtilityCard):
    def __init__(self) -> None:
        super().__init__()
        self.img = "Resources/templates/utilitycard/leopardstatue.png"
    
    def use(self):
        from GameModule.GameManager import SingletonFactory
        game_manager = SingletonFactory.get_instance()
        player = game_manager.get_owning_player(self)
        ware_available = []
        for ware in game_manager.base_wares:
            if game_manager.board.get_num_ware_by_name(ware.name[game_manager.current_langage]) >= 1:
                ware_available.append(ware.name[game_manager.current_langage])
        choice_result = game_manager.start_string_choice(ware_available,player)
        game_manager.board.give_Ware(player,choice_result,1)
        player.give_gold(game_manager.board,2)

    def can_be_played(self) -> bool:
        from GameModule.GameManager import SingletonFactory
        game_manager = SingletonFactory.get_instance()
        player = game_manager.get_owning_player(self)
        board_have_wares = False
        player_have_place = False
        if player.market_size - len(player.wares) >= 1:
            player_have_place = True
        for ware in game_manager.base_wares:
            if game_manager.board.get_num_ware_by_name(ware.name[game_manager.current_langage]) >= 1:
                board_have_wares = True
                break
        if player.gold >= 2 and board_have_wares and player_have_place:
            return True
        else:
            return False