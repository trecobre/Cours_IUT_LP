from CardsModule.UtilityCards import UtilityCard
from UtilityModule import LanguageEnum, LanguageManager

class Throne(UtilityCard):
    def __init__(self) -> None:
        super().__init__()
        self.img = "Resources/templates/utilitycard/throne.png"

    def use(self):
        from GameModule.GameManager import SingletonFactory
        game_manager = SingletonFactory.get_instance()
        player =game_manager.get_owning_player(self)
        ennemy_player = self.get_ennemy_player()
        ware_available = []
        choice_result = None
        for ware in ennemy_player.wares:
            ware_available.append(ware.name[game_manager.current_langage])
        choice_result = game_manager.start_string_choice(ware_available,player,LanguageManager.get_take_ware_text())
        ennemy_player.give_Ware(player,choice_result,1)
        ware_available = []
        for ware in player.wares:
            ware_available.append(ware.name[game_manager.current_langage])
        choice_result = game_manager.start_string_choice(ware_available,player,LanguageManager.get_give_ware_text())
        player.give_Ware(ennemy_player,choice_result,1)
    
    def can_be_played(self) -> bool:
        from GameModule.GameManager import SingletonFactory
        game_manager = SingletonFactory.get_instance()
        player = game_manager.get_owning_player(self)
        ennemy_player = self.get_ennemy_player()
        if len(player.wares) >0 and len(ennemy_player.wares) >0:
            return True
        else:
            return False