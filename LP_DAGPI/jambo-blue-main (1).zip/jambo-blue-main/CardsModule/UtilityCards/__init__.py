from CardsModule import Card

class UtilityCard(Card):
    def __init__(self) -> None:
        super().__init__()
        self.used: bool = False