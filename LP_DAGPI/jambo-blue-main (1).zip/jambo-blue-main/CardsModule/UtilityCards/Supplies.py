from CardsModule.UtilityCards import UtilityCard
from UtilityModule import SlotEnum
from CardsModule import WareCard
from UtilityModule import *

class Supplies(UtilityCard):
    def __init__(self) -> None:
        super().__init__()
        self.img = "Resources/templates/utilitycard/supplies.png"
        
        
    def use(self):
        from GameModule.GameManager import SingletonFactory
        
        game_manager = SingletonFactory.get_instance()
        player = game_manager.get_owning_player(self)
        
        (pay_one_gold, discard_one_card)= LanguageManager.get_supplies_choice_texts()
        choice_result = None
        
        if player == game_manager.board.player1:
            if len(game_manager.board.slots[SlotEnum.DECK_P1].cards) >= 1 and player.gold >= 1:
                choice_result = game_manager.start_string_choice([pay_one_gold, discard_one_card],player)
            elif len(game_manager.board.slots[SlotEnum.DECK_P1].cards) >= 1 and player.gold == 0:
                choice_result = game_manager.start_string_choice([discard_one_card],player)
            elif len(game_manager.board.slots[SlotEnum.DECK_P1].cards) == 0 and player.gold >= 1:
                choice_result = game_manager.start_string_choice([pay_one_gold],player)
        elif player == game_manager.board.player2:
            if len(game_manager.board.slots[SlotEnum.DECK_P2].cards) >= 1 and player.gold >= 1:
                choice_result = game_manager.start_string_choice([pay_one_gold, discard_one_card],player)
            elif len(game_manager.board.slots[SlotEnum.DECK_P2].cards) >= 1 and player.gold == 0:
                choice_result = game_manager.start_string_choice([discard_one_card],player)
            elif len(game_manager.board.slots[SlotEnum.DECK_P2].cards) == 0 and player.gold >= 1:
                choice_result = game_manager.start_string_choice([pay_one_gold],player)
                
        if choice_result == pay_one_gold:
            game_manager.active_player.give_gold(game_manager.board, 1)
        elif choice_result == discard_one_card:
            card_available = []
            if player == game_manager.board.player1:
                for card in game_manager.board.slots[SlotEnum.DECK_P1].cards:
                    card_available.append(card)

            elif player == game_manager.board.player2:
                for card in game_manager.board.slots[SlotEnum.DECK_P2].cards:
                    card_available.append(card)
        
            choice_card_result = game_manager.start_card_choice(card_available)
            
            choice_slot = game_manager.get_card_slot(choice_card_result)
            choice_slot.give_card(choice_card_result, SlotEnum.DISCARD)
                
        while isinstance(game_manager.board.slots[SlotEnum.CARD_DRAW].cards[-1],WareCard) == False:
            game_manager.board.slots[SlotEnum.CARD_DRAW].give_card(game_manager.board.slots[SlotEnum.CARD_DRAW].cards[-1], SlotEnum.DISCARD)
        if player == game_manager.board.player1:
            
            game_manager.board.slots[SlotEnum.CARD_DRAW].give_card(game_manager.board.slots[SlotEnum.CARD_DRAW].cards[-1], SlotEnum.DECK_P1)
        elif player == game_manager.board.player2:
            game_manager.board.slots[SlotEnum.CARD_DRAW].give_card(game_manager.board.slots[SlotEnum.CARD_DRAW].cards[-1], SlotEnum.DECK_P2)
    
    def on_phase_end(self, phase: int):
        pass
    
    def on_phase_start(self, phase: int):
        pass
    
    def can_be_played(self) -> bool:
        from GameModule.GameManager import SingletonFactory
        
        game_manager = SingletonFactory.get_instance()

        # This card needs at least 1 ware card in draw or discard

        ware_card_found = False

        for card in game_manager.board.slots[SlotEnum.CARD_DRAW].cards:
            if isinstance(card, WareCard):
                ware_card_found = True
                break

        for card in game_manager.board.slots[SlotEnum.DISCARD].cards:
            if isinstance(card, WareCard):
                ware_card_found = True
                break

        if not ware_card_found:
            return False

        player = game_manager.get_owning_player(self)
        player_have_cards = False
        card_available = []
        if player == game_manager.board.player1:
            for i in range(game_manager.N_MAX_UTILITY_CARDS_AREA):
                    card_available.append(game_manager.board.slots[SlotEnum(SlotEnum.UTILITY1_P1.value + i)].cards)
                    card_available.append(game_manager.board.slots[SlotEnum.DECK_P1].cards)
        else : 
            for i in range(game_manager.N_MAX_UTILITY_CARDS_AREA):
                    card_available.append(game_manager.board.slots[SlotEnum(SlotEnum.UTILITY1_P1.value + i)].cards)
                    card_available.append(game_manager.board.slots[SlotEnum.DECK_P1].cards)
        if len(card_available) >= 2:
            player_have_cards = True
        if player.gold >= 1 or player_have_cards:
            return True
        else : 
            return False
        
