from CardsModule.UtilityCards import UtilityCard
from UtilityModule import LanguageManager, SlotEnum

class MaskOfTransformation(UtilityCard):
    def __init__(self) -> None:
        super().__init__()
        self.img = "Resources/templates/utilitycard/maskoftransformation.png"

    def on_phase_start(self, phase: int):
        from GameModule.GameManager import SingletonFactory
        game_manager = SingletonFactory.get_instance()
        player = game_manager.get_owning_player(self)
        card_available = []
        if phase == 0 and player == game_manager.active_player:
            game_manager.game_window.update()
            (use_mask,dont_use_mask) = LanguageManager.get_MaskOfTransformation_choice_texts()
            choice_result = game_manager.start_string_choice([use_mask,dont_use_mask],player)
            if choice_result == use_mask:            
                if player == game_manager.board.player1:
                    for card in game_manager.board.slots[SlotEnum.DECK_P1].cards:
                        card_available.append(card)
                else:
                    for card in game_manager.board.slots[SlotEnum.DECK_P2].cards:
                        card_available.append(card)
                choice_card_result = game_manager.start_card_choice(card_available,player)
                if player == game_manager.board.player1:
                    game_manager.board.slots[SlotEnum.DISCARD].give_card_at(-1,SlotEnum.DECK_P1)
                    game_manager.board.slots[SlotEnum.DECK_P1].give_card(choice_card_result,SlotEnum.DISCARD)
                else:
                    game_manager.board.slots[SlotEnum.DISCARD].give_card_at(-1,SlotEnum.DECK_P2)
                    game_manager.board.slots[SlotEnum.DECK_P2].give_card(choice_card_result,SlotEnum.DISCARD)

                player.action_points -= 1
            else:
                return
            
    def can_be_played(self) -> bool:
        from GameModule.GameManager import SingletonFactory
        game_manager = SingletonFactory.get_instance()
        if game_manager.active_phase == 0:
            player = game_manager.get_owning_player(self)
            if player.action_points == 0:
                return False
            player_have_card = False
            discard_have_card = False
            if player == game_manager.board.player1:
                for card in game_manager.board.slots[SlotEnum.DECK_P1].cards:
                    player_have_card = True
                    break
            else:
                for card in game_manager.board.slots[SlotEnum.DECK_P2].cards:
                    player_have_card = True
                    break
            for card in game_manager.board.slots[SlotEnum.DISCARD].cards:
                discard_have_card = True
            if discard_have_card and player_have_card:
                return True
            else:
                return False
        else:
            return False
            
            
