from CardsModule.UtilityCards import UtilityCard
from UtilityModule import SlotEnum, LanguageManager

class Scale(UtilityCard):
    def __init__(self) -> None:
        super().__init__()
        self.img = "Resources/templates/utilitycard/scale.png"

    def use(self):
        from GameModule.GameManager import SingletonFactory
        game_manager = SingletonFactory.get_instance()
        player = game_manager.get_owning_player(self)
        card_available =[] 
        for i in range (len(game_manager.board.slots[SlotEnum.CARD_DRAW].cards)-2,len(game_manager.board.slots[SlotEnum.CARD_DRAW].cards)):
            card_available.append(game_manager.board.slots[SlotEnum.CARD_DRAW].cards[i])
        choice_result = game_manager.start_card_choice(card_available,player, LanguageManager.get_keep_card_text())
        card_available.remove(choice_result)
        if player == game_manager.board.player1:
            game_manager.board.slots[SlotEnum.CARD_DRAW].give_card(choice_result,SlotEnum.DECK_P1)
            game_manager.board.slots[SlotEnum.CARD_DRAW].give_card(card_available[0],SlotEnum.DECK_P2)
        else :
            game_manager.board.slots[SlotEnum.CARD_DRAW].give_card(choice_result,SlotEnum.DECK_P2)
            game_manager.board.slots[SlotEnum.CARD_DRAW].give_card(card_available[0],SlotEnum.DECK_P1)


    def can_be_played(self) -> bool:
        from GameModule.GameManager import SingletonFactory
        game_manager = SingletonFactory.get_instance()
        if len(game_manager.board.slots[SlotEnum.CARD_DRAW].cards)>=2:
            return True
        else:
            return False