from CardsModule.UtilityCards import UtilityCard
from GameModule.Board import Board
from GameModule.CardSlot import CardSlot
from GameModule.GoldHolder import GoldHolder
from UtilityModule import *

class Weapons(UtilityCard):
    def __init__(self) -> None:
        super().__init__()
        self.img = "Resources/templates/utilitycard/weapons.png"

        
    def can_be_played(self) -> bool:
        return True
        
    def use(self):
        """Discard 1 card from hand or play area and add 2 gold for the player

        Args:
            Slot (CardSlot.id): Slot to discard the card
            CardIndex : Card to discard.
            receiver : Player's deck
    """
        from GameModule.GameManager import SingletonFactory
        
        game_manager = SingletonFactory.get_instance()
        player = game_manager.get_owning_player(self)
        slots = []
        if player == game_manager.board.player1:
            slots = [SlotEnum.DECK_P1, SlotEnum.UTILITY1_P1, SlotEnum.UTILITY2_P1, SlotEnum.UTILITY3_P1]
        elif player == game_manager.board.player2:
            slots = [SlotEnum.DECK_P2, SlotEnum.UTILITY1_P2, SlotEnum.UTILITY2_P2, SlotEnum.UTILITY3_P2]
        cards = []

        for slot in slots:
            for card in game_manager.board.slots[slot].cards:
                cards.append(card)
        
        choice_result = game_manager.start_card_choice(cards)

        player = game_manager.get_owning_player(self)
        choice_slot = game_manager.get_card_slot(choice_result)
        choice_slot.give_card(choice_result, SlotEnum.DISCARD)
        game_manager.board.give_gold(player, 2)