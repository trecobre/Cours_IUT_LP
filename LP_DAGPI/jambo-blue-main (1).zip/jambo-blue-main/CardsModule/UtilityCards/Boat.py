from CardsModule.UtilityCards import UtilityCard
from UtilityModule import *

class Boat(UtilityCard):
    def __init__(self) -> None:
        super().__init__()
        self.img = "Resources/templates/utilitycard/boat.png"
        
    def use(self):
        """discard 1 card, take 1 ware of your choice

        Args:
            
    """
        from GameModule.GameManager import SingletonFactory
        
        game_manager = SingletonFactory.get_instance()
        player = game_manager.get_owning_player(self)
        card_available = []
        if player == game_manager.board.player1:
            for card in game_manager.board.slots[SlotEnum.DECK_P1].cards:
                card_available.append(card)
            for card in game_manager.board.slots[SlotEnum.UTILITY1_P1].cards:
                card_available.append(card)
            for card in game_manager.board.slots[SlotEnum.UTILITY2_P1].cards:
                card_available.append(card)
            for card in game_manager.board.slots[SlotEnum.UTILITY3_P1].cards:
                card_available.append(card)
        else:
            for card in game_manager.board.slots[SlotEnum.DECK_P2].cards:
                card_available.append(card)
            for card in game_manager.board.slots[SlotEnum.UTILITY1_P2].cards:
                card_available.append(card)
            for card in game_manager.board.slots[SlotEnum.UTILITY2_P2].cards:
                card_available.append(card)
            for card in game_manager.board.slots[SlotEnum.UTILITY3_P2].cards:
                card_available.append(card)   
        ware_available = []
        for ware in game_manager.base_wares:
           if game_manager.board.get_num_ware_by_name(ware.name[game_manager.current_langage]) >= 1:
                ware_available.append(ware.get_name(game_manager.current_langage))
        
        choice_result = game_manager.start_card_choice(card_available,player,LanguageManager.get_discard_card_text())
        if player == game_manager.board.player1:
            game_manager.get_card_slot(choice_result).give_card(choice_result,SlotEnum.DISCARD)
        else:
            game_manager.get_card_slot(choice_result).give_card(choice_result,SlotEnum.DISCARD)

        self.current_choice = True
        choice_result = game_manager.start_string_choice(ware_available,player)
        game_manager.board.give_Ware(player,choice_result, 1) 

    def can_be_played(self) -> bool:
        from GameModule.GameManager import SingletonFactory
        game_manager = SingletonFactory.get_instance()
        player = game_manager.get_owning_player(self)
        board_have_ware = False
        for ware in game_manager.base_wares:
           if game_manager.board.get_num_ware_by_name(ware.name[game_manager.current_langage]) >= 1:
                board_have_ware = True
                break

        if len(player.wares) + 1 <= player.market_size and board_have_ware:
            return True
        else:
            return False
        
    def on_phase_start(self, phase: int):
        pass

    def on_phase_end(self, phase: int):
        pass
        
 

        
