from CardsModule.UtilityCards import UtilityCard
from GameModule.PlayerInventory import PlayerInventory
from UtilityModule import *


class Kettle(UtilityCard):
    def __init__(self) -> None:
        super().__init__()
        self.img = "Resources/templates/utilitycard/kettle.png"
        
    def use(self):
        from GameModule.GameManager import SingletonFactory
        game_manager = SingletonFactory.get_instance()
        (one_card, two_card) = LanguageManager.get_kettles_choice_text()
        player = game_manager.get_owning_player(self)
        cards = []
        choice_result = None
        if player == game_manager.board.player1:
            if len(game_manager.board.slots[SlotEnum.DECK_P1].cards) < 2:
                choice_result = game_manager.start_string_choice([one_card])
            else:        
                choice_result = game_manager.start_string_choice([one_card, two_card])
            for card in game_manager.board.slots[SlotEnum.DECK_P1].cards:
                cards.append(card)
        else:
            if len(game_manager.board.slots[SlotEnum.DECK_P2].cards) < 2:
                choice_result = game_manager.start_string_choice([one_card])
            else:        
                choice_result = game_manager.start_string_choice([one_card, two_card])
            for card in game_manager.board.slots[SlotEnum.DECK_P2].cards:
                cards.append(card)
        
        count = 1
        if choice_result == two_card:
            count = 2

        for i in range(count):
            choice_result = game_manager.start_card_choice(cards, player)
            cards.remove(choice_result)
                
            player = game_manager.get_owning_player(self)
            if player == game_manager.board.player1:
                card_slot = game_manager.get_card_slot(choice_result)
                card_slot.give_card(choice_result, SlotEnum.DISCARD)
                game_manager.board.slots[SlotEnum.CARD_DRAW].give_card(game_manager.board.slots[SlotEnum.CARD_DRAW].cards[-1], SlotEnum.DECK_P1)
            else:
                card_slot = game_manager.get_card_slot(choice_result)
                card_slot.give_card(choice_result,SlotEnum.DISCARD)
                game_manager.board.slots[SlotEnum.CARD_DRAW].give_card(game_manager.board.slots[SlotEnum.CARD_DRAW].cards[-1], SlotEnum.DECK_P1)
    
    def can_be_played(self) -> bool:
        from GameModule.GameManager import SingletonFactory
        game_manager = SingletonFactory.get_instance()
        player = game_manager.get_owning_player(self)
        is_not_empty = False
        if player == game_manager.board.player1:
            if len(game_manager.board.slots[SlotEnum.DECK_P1].cards) > 1:
                    is_not_empty = True
        else:
            if len(game_manager.board.slots[SlotEnum.DECK_P2].cards) > 1:
                    is_not_empty = True

        return is_not_empty
    
    def on_phase_start(self, phase: int):
        return super().on_phase_start(phase)
    
    def on_phase_end(self, phase: int):
        return super().on_phase_end(phase)
    
    def get_ennemy_player(self) -> PlayerInventory:
        return super().get_ennemy_player()
    
    