from CardsModule.AnimalCards import AnimalCard
from CardsModule.UtilityCards import UtilityCard
from UtilityModule import LanguageEnum, SlotEnum

class Lion(AnimalCard):
    def __init__(self) -> None:
        super().__init__()
        self.img = "Resources/templates/animalcard/lion.png"

    def use(self):
        from GameModule.GameManager import SingletonFactory
        game_manager = SingletonFactory.get_instance()
        player_choosing = game_manager.get_owning_player(self)
        for card in game_manager.board.slots[SlotEnum.UTILITY1_P1].cards:
            game_manager.board.slots[SlotEnum.UTILITY1_P1].give_card(card,SlotEnum.EVENT_SLOT)
        for card in game_manager.board.slots[SlotEnum.UTILITY2_P1].cards:
            game_manager.board.slots[SlotEnum.UTILITY2_P1].give_card(card,SlotEnum.EVENT_SLOT)
        for card in game_manager.board.slots[SlotEnum.UTILITY3_P1].cards:
            game_manager.board.slots[SlotEnum.UTILITY3_P1].give_card(card,SlotEnum.EVENT_SLOT)
        for card in game_manager.board.slots[SlotEnum.UTILITY1_P2].cards:
            game_manager.board.slots[SlotEnum.UTILITY1_P2].give_card(card,SlotEnum.EVENT_SLOT)
        for card in game_manager.board.slots[SlotEnum.UTILITY2_P2].cards:
            game_manager.board.slots[SlotEnum.UTILITY2_P2].give_card(card,SlotEnum.EVENT_SLOT)
        for card in game_manager.board.slots[SlotEnum.UTILITY3_P2].cards:
            game_manager.board.slots[SlotEnum.UTILITY3_P2].give_card(card,SlotEnum.EVENT_SLOT)
        p1_i = 0
        p2_i = 0
        while len(game_manager.board.slots[SlotEnum.EVENT_SLOT].cards) > 0:
            choice_result = game_manager.start_card_choice(game_manager.board.slots[SlotEnum.EVENT_SLOT].cards,player_choosing)
            if player_choosing == game_manager.board.player1:
                game_manager.board.slots[SlotEnum.EVENT_SLOT].give_card(choice_result,SlotEnum(SlotEnum.UTILITY1_P1.value + p1_i))
                player_choosing = game_manager.board.player2
                p1_i += 1
            else:
                game_manager.board.slots[SlotEnum.EVENT_SLOT].give_card(choice_result,SlotEnum(SlotEnum.UTILITY1_P2.value + p2_i))
                player_choosing = game_manager.board.player1
                p2_i += 1
                

    def can_be_played(self) -> bool:
        from GameModule.GameManager import SingletonFactory
        game_manager = SingletonFactory.get_instance()
        for i in range(game_manager.N_MAX_UTILITY_CARDS_AREA):
            slot_p1 = game_manager.board.slots[SlotEnum(SlotEnum.UTILITY1_P1.value + i)]
            slot_p2 = game_manager.board.slots[SlotEnum(SlotEnum.UTILITY1_P2.value + i)]
            if (len(slot_p1.cards) == 0 and len(slot_p2.cards) == 0):
                return False
            else:
                return True
                 

    def on_phase_end(self, phase: int):
        pass

    def on_phase_start(self, phase: int):
        pass    