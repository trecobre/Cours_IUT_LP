from CardsModule import Card

class AnimalCard(Card):
    def __init__(self) -> None:
        super().__init__()