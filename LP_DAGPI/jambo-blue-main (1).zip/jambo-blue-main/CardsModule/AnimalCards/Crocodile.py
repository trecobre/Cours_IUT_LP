from random import choices
from CardsModule.UtilityCards import UtilityCard
from GameModule.CardSlot import CardSlot
from CardsModule.AnimalCards import AnimalCard
from UtilityModule import LanguageEnum, SlotEnum

class Crocodile(AnimalCard):
    def __init__(self) -> None:
        super().__init__()
        self.img = "Resources/templates/animalcard/crocodile.png"
    
    def use(self):
        from GameModule.GameManager import SingletonFactory
        game_manager = SingletonFactory.get_instance()
        if game_manager.get_owning_player(self) == game_manager.board.player1:
            slots = [game_manager.board.slots[SlotEnum.UTILITY1_P2]]
            slots.append(game_manager.board.slots[SlotEnum.UTILITY2_P2])
            slots.append(game_manager.board.slots[SlotEnum.UTILITY3_P2])
            cards_available = []
            for slot in slots :
                if len(slot.cards) > 0:
                    cards_available.append(slot.cards[0])    
        else:   
            slots = [game_manager.board.slots[SlotEnum.UTILITY1_P1]]
            slots.append(game_manager.board.slots[SlotEnum.UTILITY2_P1])
            slots.append(game_manager.board.slots[SlotEnum.UTILITY3_P1])
            cards_available = []
            for slot in slots : 
                if len(slot.cards) > 0:
                    cards_available.append(slot.cards[0])

        choice_result = game_manager.start_card_choice(cards_available)

        if choice_result.name[LanguageEnum.EN] != "Mask of transformation":
            choice_result.used_by_croco = True
            if choice_result.can_be_played():
                choice_result.use()
            choice_result.used_by_croco = False
        choice_slot = game_manager.get_card_slot(choice_result)
        choice_slot.give_card(choice_result,SlotEnum.DISCARD)
    
    def can_be_played(self) -> bool:
        from GameModule.GameManager import SingletonFactory
        game_manager = SingletonFactory.get_instance()
        player = game_manager.get_owning_player(self)
        if player == game_manager.board.player1:
            if len(game_manager.board.slots[SlotEnum.UTILITY1_P2].cards)  == 0 and len(game_manager.board.slots[SlotEnum.UTILITY2_P2].cards) == 0 and len(game_manager.board.slots[SlotEnum.UTILITY3_P2].cards) == 0:
                return False
            else:
                return True
        else:
            if len(game_manager.board.slots[SlotEnum.UTILITY1_P1].cards)  == 0 and len(game_manager.board.slots[SlotEnum.UTILITY2_P1].cards) == 0 and len(game_manager.board.slots[SlotEnum.UTILITY3_P1].cards) == 0:
                return False
            else:
                return True

    def on_phase_end(self, phase: int):
        pass

    def on_phase_start(self, phase: int):
        pass
        