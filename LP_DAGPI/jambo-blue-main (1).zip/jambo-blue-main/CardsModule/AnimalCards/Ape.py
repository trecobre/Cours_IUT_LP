from CardsModule.AnimalCards import AnimalCard
from UtilityModule import LanguageEnum, SlotEnum

class Ape(AnimalCard):
    def __init__(self) -> None:
        super().__init__()
        self.img ="Resources/templates/animalcard/ape.png"

    def use(self):
        from GameModule.GameManager import SingletonFactory
        game_manager = SingletonFactory.get_instance()
        player_choosing = game_manager.get_owning_player(self)
        while len(game_manager.board.slots[SlotEnum.DECK_P1].cards) > 0:
            game_manager.board.slots[SlotEnum.DECK_P1].give_card_at(0,SlotEnum.EVENT_SLOT)
        while len(game_manager.board.slots[SlotEnum.DECK_P2].cards) > 0:
            game_manager.board.slots[SlotEnum.DECK_P2].give_card_at(0,SlotEnum.EVENT_SLOT)
        
        player_slot = SlotEnum.DECK_P1
        if game_manager.get_owning_player(self) is game_manager.board.player2:
            player_slot = SlotEnum.DECK_P2

        if self in game_manager.board.slots[SlotEnum.EVENT_SLOT].cards:
            game_manager.board.slots[SlotEnum.EVENT_SLOT].give_card(self, player_slot)
        while len(game_manager.board.slots[SlotEnum.EVENT_SLOT].cards) > 0:
            choice_result = game_manager.start_card_choice(game_manager.board.slots[SlotEnum.EVENT_SLOT].cards,player_choosing)
            if player_choosing == game_manager.board.player1:
                game_manager.board.slots[SlotEnum.EVENT_SLOT].give_card(choice_result,SlotEnum.DECK_P1)
                player_choosing = game_manager.board.player2
            else:
                game_manager.board.slots[SlotEnum.EVENT_SLOT].give_card(choice_result,SlotEnum.DECK_P2)
                player_choosing = game_manager.board.player1
                
    def can_be_played(self) -> bool:
        from GameModule.GameManager import SingletonFactory
        game_manager = SingletonFactory.get_instance()
        if len(game_manager.board.slots[SlotEnum.DECK_P1].cards) <= 0 and len(game_manager.board.slots[SlotEnum.DECK_P2].cards) <=0:
            return False
        else:
            return True                   

    def on_phase_end(self, phase: int):
        pass

    def on_phase_start(self, phase: int):
        pass    