from CardsModule.AnimalCards import AnimalCard
from UtilityModule import LanguageEnum, LanguageManager, SlotEnum

class Hyena(AnimalCard):
    def __init__(self) -> None:
        super().__init__()
        self.img = "Resources/templates/animalcard/hyena.png"
        self.current_choice: bool = False

    def use(self):
        from GameModule.GameManager import SingletonFactory
        game_manager = SingletonFactory.get_instance()
        card_available = []
        player = game_manager.get_owning_player(self)
        if player == game_manager.board.player1:
            for card in game_manager.board.slots[SlotEnum.DECK_P2].cards:
                card_available.append(card)
        else:
            for card in game_manager.board.slots[SlotEnum.DECK_P1].cards:
                card_available.append(card)

        choice_result = game_manager.start_card_choice(card_available, None, LanguageManager.get_keep_card_text())

        player = game_manager.get_owning_player(self)
        card_available = []
        choice_slot = game_manager.get_card_slot(choice_result)

        if player == game_manager.board.player1:
            choice_slot.give_card(choice_result,SlotEnum.DECK_P1)
            for card in game_manager.board.slots[SlotEnum.DECK_P1].cards:
                card_available.append(card)
        else:
            choice_slot.give_card(choice_result,SlotEnum.DECK_P2)
            for card in game_manager.board.slots[SlotEnum.DECK_P2].cards:
                card_available.append(card)
        card_available.remove(self)
        game_manager.game_window.update()
        choice_result = game_manager.start_card_choice(card_available, None, LanguageManager.get_give_card_text())
        choice_slot = game_manager.get_card_slot(choice_result)

        if player == game_manager.board.player1:
            choice_slot.give_card(choice_result,SlotEnum.DECK_P2)
        else:
            choice_slot.give_card(choice_result,SlotEnum.DECK_P1)
        
    def can_be_played(self) -> bool:
        from GameModule.GameManager import SingletonFactory
        game_manager = SingletonFactory.get_instance()
        player = game_manager.get_owning_player(self)
        if player == game_manager.board.player1:
            if len(game_manager.board.slots[SlotEnum.DECK_P2].cards)  == 0:
                return False
            else:
                return True
        else:
            if len(game_manager.board.slots[SlotEnum.DECK_P1].cards)  == 0:
                return False
            else:
                return True
        

    def on_phase_end(self, phase: int):
        pass

    def on_phase_start(self, phase: int):
        pass
            
        
            