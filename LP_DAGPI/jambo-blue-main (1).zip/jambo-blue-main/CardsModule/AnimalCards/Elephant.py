from CardsModule.AnimalCards import AnimalCard
from UtilityModule import SlotEnum
from GameModule.Ware import Ware
from GameModule.CardSlot import EventSlot

class Elephant(AnimalCard):
    def __init__(self) -> None:
        super().__init__()
        self.img = "Resources/templates/animalcard/elephant.png"

    def use(self):
        from GameModule.GameManager import SingletonFactory
        game_manager = SingletonFactory.get_instance()
        player = game_manager.get_owning_player(self)
        ennemy_player = self.get_ennemy_player()
        player_choosing =player
        player.give_Wares(game_manager.board.slots[SlotEnum.EVENT_SLOT],player.wares)
        ennemy_player.give_Wares(game_manager.board.slots[SlotEnum.EVENT_SLOT],ennemy_player.wares)
        wares_choice = []
        for ware in game_manager.board.slots[SlotEnum.EVENT_SLOT].wares:
            wares_choice.append(ware.get_name(game_manager.current_langage))
        while len(game_manager.board.slots[SlotEnum.EVENT_SLOT].wares) > 0:
            choice_result = game_manager.start_string_choice(wares_choice,player_choosing)
            wares_choice.remove(choice_result)
            event_slot: EventSlot = game_manager.board.slots[SlotEnum.EVENT_SLOT]
            if player_choosing == game_manager.board.player1:
                event_slot.give_Ware(player_choosing, choice_result, 1)
                player_choosing = game_manager.board.player2
            else:
                event_slot.give_Ware(player_choosing, choice_result, 1)
                player_choosing = game_manager.board.player1

    def can_be_played(self) -> bool:
        from GameModule.GameManager import SingletonFactory
        game_manager = SingletonFactory.get_instance()
        player = game_manager.get_owning_player(self)
        ennemy_player = self.get_ennemy_player()
        player_have_ware_place = False
        ennemy_have_ware_place = False
        if player.market_size >=round((len(player.wares)+len(ennemy_player.wares))/2):
            player_have_ware_place = True
        if ennemy_player.market_size >=round((len(player.wares)+len(ennemy_player.wares))/2):
            ennemy_have_ware_place = True
        if len(player.wares) > 0 and len(ennemy_player.wares) > 0 and player_have_ware_place and ennemy_have_ware_place:
            return True
        else:
            return False                      

    def on_phase_end(self, phase: int):
        pass

    def on_phase_start(self, phase: int):
        pass    