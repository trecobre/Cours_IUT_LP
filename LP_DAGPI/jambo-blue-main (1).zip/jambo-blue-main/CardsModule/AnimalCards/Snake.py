import imp
from CardsModule.AnimalCards import AnimalCard
from UtilityModule import *
from PyQt6.QtGui import QIcon

class Snake(AnimalCard):
    def __init__(self) -> None:
        super().__init__()
        self.img = "Resources/templates/animalcard/snake.png"

    def use(self):
        """Your opponent and you must discard all but 1 
            of your utility card in play. (Not in your hand)
            
            use fonc start 2 choice too both player sending their utility card


        """
        from GameModule.GameManager import SingletonFactory
        game_manager = SingletonFactory.get_instance()
        player_card_available = []
        player = game_manager.get_owning_player(self)
        ennemy_player = self.get_ennemy_player()
        ennemy_card_available = []
        if player == game_manager.board.player1:
            slots = [game_manager.board.slots[SlotEnum.UTILITY1_P1], game_manager.board.slots[SlotEnum.UTILITY2_P1], game_manager.board.slots[SlotEnum.UTILITY3_P1]]
            for slot in slots:
                for card in slot.cards:
                    player_card_available.append(card)
            slots = [game_manager.board.slots[SlotEnum.UTILITY1_P2], game_manager.board.slots[SlotEnum.UTILITY2_P2], game_manager.board.slots[SlotEnum.UTILITY3_P2]]
            for slot in slots:
                for card in slot.cards:
                    ennemy_card_available.append(card)
        else:
            slots = [game_manager.board.slots[SlotEnum.UTILITY1_P1], game_manager.board.slots[SlotEnum.UTILITY2_P1], game_manager.board.slots[SlotEnum.UTILITY3_P1]]
            for slot in slots:
                for card in slot.cards:
                    ennemy_card_available.append(card)
            slots = [game_manager.board.slots[SlotEnum.UTILITY1_P2], game_manager.board.slots[SlotEnum.UTILITY2_P2], game_manager.board.slots[SlotEnum.UTILITY3_P2]]
            for slot in slots:
                for card in slot.cards:
                    player_card_available.append(card)
        
        if len(player_card_available) > 0:
            choice_result = game_manager.start_card_choice(player_card_available, player)

            card_slot = game_manager.get_card_slot(choice_result)
            card_slot.give_card(choice_result,SlotEnum.DISCARD)  

        if len(ennemy_card_available) > 0:
            choice_result = game_manager.start_card_choice(ennemy_card_available, ennemy_player)

            card_slot = game_manager.get_card_slot(choice_result)
            card_slot.give_card(choice_result,SlotEnum.DISCARD)      

    def can_be_played(self) -> bool:
        from GameModule.GameManager import SingletonFactory
        game_manager = SingletonFactory.get_instance()   
        return True       
                                

    def on_phase_end(self, phase: int):
        pass

    def on_phase_start(self, phase: int):
        pass    