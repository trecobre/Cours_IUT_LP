from CardsModule.AnimalCards import AnimalCard
from GameModule.WareHolder import WareHolder
from PyQt6.QtGui import QIcon

class Parrot(AnimalCard):
    def __init__(self) -> None:
        super().__init__()
        self.img = "Resources/templates/animalcard/parrot.png"
    
    def use(self):
        from GameModule.GameManager import SingletonFactory
        game_manager = SingletonFactory.get_instance()
        player_ennemy = self.get_ennemy_player()
        ware_names = []
        for ware in player_ennemy.wares:
            ware_names.append(ware.get_name(game_manager.current_langage))

        choice_result = game_manager.start_string_choice(ware_names)

        player = game_manager.get_owning_player(self)
        player_ennemy = None
        if player == game_manager.board.player1:
            player_ennemy = game_manager.board.player2
        else:
            player_ennemy = game_manager.board.player1
        player_ennemy.give_Ware(player,choice_result,1)
        
    def can_be_played(self) -> bool:
        from GameModule.GameManager import SingletonFactory
        game_manager = SingletonFactory.get_instance()
        player = game_manager.get_owning_player(self)
        player_ennemy = self.get_ennemy_player()
        ennemy_have_ware = False
        player_have_ware_place = False
        if player.market_size - len(player.wares) >= 1:
            player_have_ware_place = True
        for ware in player_ennemy.wares:
            if ware != None:
                ennemy_have_ware = True
        if ennemy_have_ware and player_have_ware_place:
            return True
        else:
            return False 

    def on_phase_end(self, phase: int):
        pass

    def on_phase_start(self, phase: int):
        pass