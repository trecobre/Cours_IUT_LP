from CardsModule.AnimalCards import AnimalCard
from UtilityModule import LanguageManager, SlotEnum

class Cheetah(AnimalCard):
    def __init__(self) -> None:
        super().__init__()
        self.img = "Resources/templates/animalcard/cheetah.png"

    def use(self):
        from GameModule.GameManager import SingletonFactory
        game_manager = SingletonFactory.get_instance()
        player = game_manager.get_owning_player(self)
        ennemy_player = self.get_ennemy_player()
        (give_two_gold_text,draw_two_card_text) = LanguageManager.get_cheetah_choice_texts()
        if ennemy_player.gold >= 2:
            choice_result = game_manager.start_string_choice([draw_two_card_text],ennemy_player)
        else:
            choice_result = game_manager.start_string_choice([give_two_gold_text,draw_two_card_text],ennemy_player)
        if choice_result == give_two_gold_text:
            ennemy_player.give_gold(player,2)
        if choice_result == draw_two_card_text:
                game_manager.board.slots[SlotEnum.CARD_DRAW].give_card_at(-1,SlotEnum.DECK_P1)
                game_manager.board.slots[SlotEnum.CARD_DRAW].give_card_at(-1,SlotEnum.DECK_P1)

    def can_be_played(self) -> bool:
        return True                    

    def on_phase_end(self, phase: int):
        pass

    def on_phase_start(self, phase: int):
        pass    