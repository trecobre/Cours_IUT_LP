from CardsModule.PeopleCards import PeopleCard
from GameModule.CardSlot import EventSlot
from UtilityModule import SlotEnum

class ArabianMerchant(PeopleCard):
    def __init__(self) -> None:
        super().__init__()
        self.img = "Resources/templates/peoplecard/arabianmerchant.png"

    def can_be_played(self) -> bool:
        from GameModule.GameManager import SingletonFactory
        gm = SingletonFactory.get_instance()

        return gm.get_owning_player(self).gold > 0

    def use(self):
        from GameModule.GameManager import SingletonFactory
        gm = SingletonFactory.get_instance()

        for i in range(3):
            gm.board.slots[SlotEnum.CARD_DRAW].give_card_at(-1, SlotEnum.EVENT_SLOT)

        player = gm.get_owning_player(self)
        opponent = self.get_ennemy_player()

        event_slot: EventSlot = gm.board.slots[SlotEnum.EVENT_SLOT]

        player.give_gold(event_slot, 1)

        player_golds = 1
        opponent_golds = 0

        player_choosing = opponent

        gm.game_window.update()

        # Player must add 2 golds to be 1 gold over its opponent total
        while gm.start_auction_choice(max([player_golds, opponent_golds]), gm.board.slots[SlotEnum.EVENT_SLOT].cards, None, player_choosing, player_choosing.gold >= 2):
            gm.game_window.update()
            player_choosing.give_gold(event_slot, 2)

            if player_choosing == player:
                player_golds += 2
                player_choosing = opponent
            else:
                opponent_golds += 2
                player_choosing = player

        # player_choosing lost auction
        
        if player_choosing == player:
            # opponent won

            event_slot.give_gold(player, player_golds)
            event_slot.give_gold(gm.board, opponent_golds)

            receiver = SlotEnum.DECK_P1
            if opponent == gm.board.player2:
                receiver = SlotEnum.DECK_P2
            while len(event_slot.cards) > 0:
                event_slot.give_card_at(0, receiver)
        else:
            # player won

            event_slot.give_gold(opponent, opponent_golds)
            event_slot.give_gold(gm.board, player_golds)

            receiver = SlotEnum.DECK_P1
            if player == gm.board.player2:
                receiver = SlotEnum.DECK_P2
            while len(event_slot.cards) > 0:
                event_slot.give_card_at(0, receiver)
