from CardsModule.PeopleCards import PeopleCard

class Guard(PeopleCard):
    def __init__(self) -> None:
        super().__init__()
        self.img = "Resources/templates/peoplecard/guard.png"

    def use(self):
        """Usage of this card is handled by GameManager.
        """
        pass

    def can_be_played(self) -> bool:
        return False
