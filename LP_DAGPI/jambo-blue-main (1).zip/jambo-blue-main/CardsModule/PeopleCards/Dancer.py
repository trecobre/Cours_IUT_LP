from CardsModule import WareCard
from CardsModule.PeopleCards import PeopleCard
from UtilityModule import LanguageEnum, SlotEnum

class Dancer(PeopleCard):
    def __init__(self) -> None:
        super().__init__()
        self.img = "Resources/templates/peoplecard/dancer.png"
    
    def use(self):
        from GameModule.GameManager import SingletonFactory
        game_manager = SingletonFactory.get_instance()
        player = game_manager.get_owning_player(self)
        card_available = []
        ware_available = []
        if player == game_manager.board.player1:
            for card in game_manager.board.slots[SlotEnum.DECK_P1].cards:
                if isinstance(card, WareCard):
                    if len(card.wares) == 3:
                        card_available.append(card)
        else:
            for card in game_manager.board.slots[SlotEnum.DECK_P2].cards:
                if isinstance(card,WareCard):
                    if len(card.wares) == 3:
                        card_available.append(card)
        card_result = game_manager.start_card_choice(card_available,player)
        price = card_result.sell_price
        for i in range (0,3):
            for ware in player.wares:
                ware_available.append(ware.name[game_manager.current_langage])
            ware_result = game_manager.start_string_choice(ware_available,player)
            ware_available.clear()
            player.give_Ware(game_manager.board.slots[SlotEnum.EVENT_SLOT],ware_result,1)
            card_result_slot = game_manager.get_card_slot(card_result)
            card_result_slot.give_card(card_result,SlotEnum.DISCARD)
        game_manager.board.give_gold(player,price)


    
    def can_be_played(self) -> bool:
        from GameModule.GameManager import SingletonFactory
        game_manager = SingletonFactory.get_instance()
        player = game_manager.get_owning_player(self)
        count = 0
        if player == game_manager.board.player1:
            for card in game_manager.board.slots[SlotEnum.DECK_P1].cards:
                if isinstance(card, WareCard):
                    if len(card.wares) == 3:
                        count += 1
        else:
            for card in game_manager.board.slots[SlotEnum.DECK_P2].cards:
                if isinstance(card,WareCard):
                    if len(card.wares) == 3:
                        count += 1
        if len(player.wares) >= 3 and count >=1:
            return True
        else:
            return False
    
    def on_phase_end(self, phase: int):
        return super().on_phase_end(phase)
    
    def on_phase_start(self, phase: int):
        return super().on_phase_start(phase)
