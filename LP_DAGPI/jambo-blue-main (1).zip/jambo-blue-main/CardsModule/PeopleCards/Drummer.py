from CardsModule.PeopleCards import PeopleCard
from CardsModule.UtilityCards import UtilityCard
from UtilityModule import SlotEnum

class Drummer(PeopleCard):
    def __init__(self) -> None:
        super().__init__()
        self.img = "Resources/templates/peoplecard/drummer.png"
    
    def use(self):
        from GameModule.GameManager import SingletonFactory
        game_manager = SingletonFactory.get_instance()
        player = game_manager.get_owning_player(self)
        card_available = []
        for card in game_manager.board.slots[SlotEnum.DISCARD].cards:
            if isinstance(card,UtilityCard):
                card_available.append(card)
        choice_result = game_manager.start_card_choice(card_available,player)
        if player == game_manager.board.player1:
            game_manager.board.slots[SlotEnum.DISCARD].give_card(choice_result,SlotEnum.DECK_P1)
        else:
            game_manager.board.slots[SlotEnum.DISCARD].give_card(choice_result,SlotEnum.DECK_P2)

    def can_be_played(self) -> bool:
        from GameModule.GameManager import SingletonFactory
        game_manager = SingletonFactory.get_instance()
        count = 0
        for card in game_manager.board.slots[SlotEnum.DISCARD].cards:
            if isinstance(card,UtilityCard):
                count += 1
        if count >= 1:
            return True
        else:
            return False

    def on_phase_end(self, phase: int):
        return super().on_phase_end(phase)
    
    def on_phase_start(self, phase: int):
        return super().on_phase_start(phase)
    
