from CardsModule.PeopleCards import PeopleCard
from UtilityModule import LanguageEnum, LanguageManager, SlotEnum

class Carrier(PeopleCard):
    def __init__(self) -> None:
        super().__init__()
        self.img = "Resources/templates/peoplecard/carrier.png"
    
    def use(self):
        from GameModule.GameManager import SingletonFactory
        game_manager = SingletonFactory.get_instance()
        player = game_manager.get_owning_player(self)
        ennemy_player = self.get_ennemy_player()
        choice_result = None
        (take_2_same_ware,draw_2_card) = LanguageManager.get_carrier_choice_texts()
        card_available =[] 
        for i in range (len(game_manager.board.slots[SlotEnum.CARD_DRAW].cards)-2,len(game_manager.board.slots[SlotEnum.CARD_DRAW].cards)):
            card_available.append(game_manager.board.slots[SlotEnum.CARD_DRAW].cards[i])
        choice_result = game_manager.start_string_choice([take_2_same_ware,draw_2_card],player)
        if choice_result == take_2_same_ware:
            ware_available = []
            for ware in game_manager.base_wares:
                if game_manager.board.get_num_ware_by_name(ware.name[game_manager.current_langage]) >= 2:
                    ware_available.append(ware.name[game_manager.current_langage])
            choice_result = game_manager.start_string_choice(ware_available,player)
            game_manager.board.give_Ware(player,choice_result,2)
            if player == game_manager.board.player1:
                game_manager.board.slots[SlotEnum.CARD_DRAW].give_card(card_available[0],SlotEnum.DECK_P2)
                game_manager.board.slots[SlotEnum.CARD_DRAW].give_card(card_available[1],SlotEnum.DECK_P2)
            else:
                game_manager.board.slots[SlotEnum.CARD_DRAW].give_card(card_available[0],SlotEnum.DECK_P1)
                game_manager.board.slots[SlotEnum.CARD_DRAW].give_card(card_available[1],SlotEnum.DECK_P1)
        elif choice_result == draw_2_card:
            ware_available = []
            for ware in game_manager.base_wares:
                if game_manager.board.get_num_ware_by_name(ware.name[game_manager.current_langage]) >= 2:
                    ware_available.append(ware.name[game_manager.current_langage])
            choice_result = game_manager.start_string_choice(ware_available,ennemy_player)
            game_manager.board.give_Ware(ennemy_player,choice_result,2)
            if player == game_manager.board.player1:
                game_manager.board.slots[SlotEnum.CARD_DRAW].give_card(card_available[0],SlotEnum.DECK_P1)
                game_manager.board.slots[SlotEnum.CARD_DRAW].give_card(card_available[1],SlotEnum.DECK_P1)
            else:
                game_manager.board.slots[SlotEnum.CARD_DRAW].give_card(card_available[0],SlotEnum.DECK_P1)
                game_manager.board.slots[SlotEnum.CARD_DRAW].give_card(card_available[1],SlotEnum.DECK_P1)
    
    def can_be_played(self) -> bool:
        from GameModule.GameManager import SingletonFactory
        game_manager = SingletonFactory.get_instance()
        player = game_manager.get_owning_player(self)
        ennemy_player = self.get_ennemy_player()
        board_have_wares = False
        card_draw_have_card= False
        player_have_places = False
        ennemy_have_places = False
        if player.market_size - len(player.wares) >= 2:
            player_have_places = True
        
        if ennemy_player.market_size - len(ennemy_player.wares) >= 2:
            ennemy_have_places = True

        for ware in game_manager.base_wares:
            if game_manager.board.get_num_ware_by_name(ware.name[game_manager.current_langage]) >= 2:
                board_have_wares = True
                break
        if len(game_manager.board.slots[SlotEnum.CARD_DRAW].cards)>=2:
            card_draw_have_card = True
            
        if card_draw_have_card and board_have_wares and player_have_places and ennemy_have_places:
            return True
        else:
            return False