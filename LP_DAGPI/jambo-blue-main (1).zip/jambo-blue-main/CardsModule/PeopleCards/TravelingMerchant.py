from CardsModule.PeopleCards import PeopleCard
from UtilityModule import SlotEnum
from GameModule.CardSlot import EventSlot

class TravelingMerchant(PeopleCard):
    def __init__(self) -> None:
        super().__init__()
        self.img = "Resources/templates/peoplecard/travelingmerchant.png"

    def can_be_played(self) -> bool:
        from GameModule.GameManager import SingletonFactory
        gm = SingletonFactory.get_instance()

        available_wares_count = 0

        for ware in gm.base_wares:
            if gm.board.get_num_ware_by_name(ware.name[gm.current_langage]) > 0:
                available_wares_count += 1

        player = gm.get_owning_player(self)

        return available_wares_count >= 2 and player.gold > 0 and player.market_size >= len(player.wares) + 2
    
    def use(self):
        from GameModule.GameManager import SingletonFactory
        gm = SingletonFactory.get_instance()

        # Ask which wares to auction

        wares_available = []

        for ware in gm.board.wares:
            name = ware.name[gm.current_langage]
            if name not in wares_available:
                wares_available.append(name)

        event_slot: EventSlot = gm.board.slots[SlotEnum.EVENT_SLOT]

        for i in range(2):
            result = gm.start_string_choice(wares_available)
            gm.board.give_Ware(event_slot, result, 1)
            if gm.board.get_num_ware_by_name(result) == 0:
                wares_available.remove(result)
            gm.game_window.update()

        player = gm.get_owning_player(self)
        opponent = self.get_ennemy_player()

        if opponent.market_size < len(opponent.wares) + 2:
            # If opponent can't take the wares, player pays 1 gold and takes them
            player.give_gold(gm.board, 1)
            while len(event_slot.wares) > 0:
                event_slot.give_Ware(player, next(iter(event_slot.wares)).name[gm.current_langage], 1)
        else:
            player.give_gold(event_slot, 1)
            player_choosing = opponent

            player_golds = 1
            opponent_golds = 0

            while gm.start_auction_choice(max([player_golds, opponent_golds]), None, event_slot.wares, player_choosing, player_choosing.gold >= 2):
                gm.game_window.update()
                player_choosing.give_gold(event_slot, 2)

                if player_choosing == player:
                    player_golds += 2
                    player_choosing = opponent
                else:
                    opponent_golds += 2
                    player_choosing = player

            # player_choosing lost auction
            
            if player_choosing == player:
                # opponent won

                event_slot.give_gold(player, player_golds)
                event_slot.give_gold(gm.board, opponent_golds)

                while len(event_slot.wares) > 0:
                    event_slot.give_Ware(opponent, next(iter(event_slot.wares)).name[gm.current_langage], 1)
            else:
                # player won

                event_slot.give_gold(opponent, opponent_golds)
                event_slot.give_gold(gm.board, player_golds)

                while len(event_slot.wares) > 0:
                    event_slot.give_Ware(player, next(iter(event_slot.wares)).name[gm.current_langage], 1)