from CardsModule.PeopleCards import PeopleCard
from UtilityModule import LanguageManager, SlotEnum

class RainMaker(PeopleCard):
    def __init__(self) -> None:
        super().__init__()
        self.img = "Resources/templates/peoplecard/rainmaker.png"

    def use(self):
        from GameModule.GameManager import SingletonFactory
        gm = SingletonFactory.get_instance()

        (take_ware_text, dont_take_ware_text) = LanguageManager.get_rain_maker_choice_texts()

        ware_card_slot = gm.board.slots[SlotEnum.DISCARD]
        player = gm.get_owning_player(self)
        result = gm.start_string_choice([take_ware_text, dont_take_ware_text], player, None, LanguageManager.get_ware_card_desc(ware_card_slot.cards[-1], gm.current_langage))
        
        if result == take_ware_text:
            receiver = SlotEnum.DECK_P1
            if player is gm.board.player2:
                receiver = SlotEnum.DECK_P2
            ware_card_slot.give_card(ware_card_slot.cards[-1], receiver)
            gm.get_card_slot(self).give_card(self, SlotEnum.DISCARD)

    def can_be_played(self) -> bool:
        return False