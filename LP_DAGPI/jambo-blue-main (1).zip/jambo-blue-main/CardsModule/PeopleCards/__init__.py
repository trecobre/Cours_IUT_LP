from CardsModule import Card

class PeopleCard(Card):
    def __init__(self) -> None:
        super().__init__()