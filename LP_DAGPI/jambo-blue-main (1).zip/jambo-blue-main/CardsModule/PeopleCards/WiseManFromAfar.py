from CardsModule.PeopleCards import PeopleCard

class WiseManFromAfar(PeopleCard):
    def __init__(self) -> None:
        super().__init__()
        self.img = "Resources/templates/peoplecard/wisemanfromafar.png"

    def can_be_played(self) -> bool:
        return True

    def use(self):
        from GameModule.GameManager import SingletonFactory

        player = SingletonFactory.get_instance().get_owning_player(self)

        player.ware_buy_reduction += 2
        player.ware_sell_buff += 2