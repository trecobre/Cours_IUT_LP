from CardsModule.PeopleCards import PeopleCard

class BasketMaker(PeopleCard):
    def __init__(self) -> None:
        super().__init__()
        self.img = "Resources/templates/peoplecard/basketmaker.png"
    
    def use(self):
        from GameModule.GameManager import SingletonFactory
        game_manager = SingletonFactory.get_instance()
        player = game_manager.get_owning_player(self)
        ware_available = []

        for ware in game_manager.base_wares:
            if game_manager.board.get_num_ware_by_name(ware.name[game_manager.current_langage]) >= 2:
                ware_available.append(ware.name[game_manager.current_langage])
        choice_result = game_manager.start_string_choice(ware_available,player)
        game_manager.board.give_Ware(player,choice_result,2)
        player.give_gold(game_manager.board,2)

    
    def can_be_played(self) -> bool:
        from GameModule.GameManager import SingletonFactory
        game_manager = SingletonFactory.get_instance()
        player = game_manager.get_owning_player(self)
        board_have_wares = False
        player_have_places = False
        if player.market_size - len(player.wares) >=2:
            player_have_places = True
        for ware in game_manager.base_wares:
            if game_manager.board.get_num_ware_by_name(ware.name[game_manager.current_langage]) >= 2:
                board_have_wares = True
        if player.gold >= 2 and board_have_wares and player_have_places:
            return True
        else:
            return False
    
    def on_phase_end(self, phase: int):
        return super().on_phase_end(phase)
    
    def on_phase_start(self, phase: int):
        return super().on_phase_start(phase)