from CardsModule.PeopleCards import PeopleCard
from UtilityModule import LanguageManager

class Shaman(PeopleCard):
    def __init__(self) -> None:
        super().__init__()
        self.img = "Resources/templates/peoplecard/shaman.png"
    
    def use(self):
        from GameModule.GameManager import SingletonFactory
        game_manager = SingletonFactory.get_instance()
        player = game_manager.get_owning_player(self)
        ware_available = []
        for ware in game_manager.base_wares:
            if player.get_num_ware_by_name(ware.name[game_manager.current_langage]) >= 1:
                ware_available.append(ware.name[game_manager.current_langage])
        choice_result = game_manager.start_string_choice(ware_available,player,LanguageManager.get_give_ware_text())
        quantity = player.get_num_ware_by_name(choice_result)
        player.give_Ware(game_manager.board,choice_result,quantity)
        ware_available = []
        for ware in game_manager.base_wares:
            if game_manager.board.get_num_ware_by_name(ware.name[game_manager.current_langage]) >= quantity:
                ware_available.append(ware.name[game_manager.current_langage])
        choice_result = game_manager.start_string_choice(ware_available,player,LanguageManager.get_take_ware_text())
        game_manager.board.give_Ware(player,choice_result,quantity)
                
    def can_be_played(self) -> bool:
        from GameModule.GameManager import SingletonFactory
        game_manager = SingletonFactory.get_instance()
        player = game_manager.get_owning_player(self)
        count = 0
        for ware in player.wares:
            if player.get_num_ware_by_name(ware.name[game_manager.current_langage]) <= game_manager.board.get_num_ware_by_name(ware.name[game_manager.current_langage]) :
                count += 1
        if count >= 1:
            return True
        else:
            return False


    def on_phase_end(self, phase: int):
        pass
    def on_phase_start(self, phase: int):
        pass
