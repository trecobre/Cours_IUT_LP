from CardsModule.PeopleCards import PeopleCard

class Portuguese(PeopleCard):
    def __init__(self) -> None:
        super().__init__()
        self.img = "Resources/templates/peoplecard/portuguese.png"
    
    def use(self):
        from GameModule.GameManager import SingletonFactory
        game_manager = SingletonFactory.get_instance()
        player = game_manager.get_owning_player(self)
        while len(player.wares) >0 :
            game_manager.game_window.update()
            ware_available = ["Stop"]
            for ware in player.wares:
                ware_available.append(ware.name[game_manager.current_langage])
            choice_result = game_manager.start_string_choice(ware_available, player)
            if choice_result !=  "Stop":
                player.give_Ware(game_manager.board,choice_result,1)
                game_manager.board.give_gold(player,2)
            else: 
                break

    def can_be_played(self) -> bool:
        from GameModule.GameManager import SingletonFactory
        game_manager = SingletonFactory.get_instance()
        player = game_manager.get_owning_player(self)
        if len(player.wares) == 0:
            return False
        else:
            return True


    def on_phase_end(self, phase: int):
        pass

    def on_phase_start(self, phase: int):
        pass

