from xmlrpc.client import boolean
from CardsModule.PeopleCards import PeopleCard
from UtilityModule import *

class TribalElder(PeopleCard):
    def __init__(self) -> None:
        super().__init__()
        self.img = "Resources/templates/peoplecard/tribalelder.png"
    
    def can_be_played(self) -> bool:
        from GameModule.GameManager import SingletonFactory
        game_manager = SingletonFactory.get_instance()
        player = game_manager.get_owning_player(self)
        is_not_empty = False
        if player == game_manager.board.player1:
            if len(game_manager.board.slots[SlotEnum.DECK_P1].cards) < 5 or len(game_manager.board.slots[SlotEnum.DECK_P2].cards) > 3:
                    is_not_empty = True
        else:
            if len(game_manager.board.slots[SlotEnum.DECK_P2].cards) < 5 or len(game_manager.board.slots[SlotEnum.DECK_P1].cards) > 3:
                    is_not_empty = True

        return is_not_empty
        
    def use(self):
        from GameModule.GameManager import SingletonFactory
        game_manager = SingletonFactory.get_instance()
        player = game_manager.get_owning_player(self)
        ennemy_player = self.get_ennemy_player()
        (choice_TribalElder_Draw_sentence, choice_TribalElder_Discard_sentence)= LanguageManager.get_TribalElder_Draw_Discard_text()
        choice_result = None
        if player == game_manager.board.player1:
            if len(game_manager.board.slots[SlotEnum.DECK_P2].cards) > 3 and len(game_manager.board.slots[SlotEnum.DECK_P1].cards) < 5:
                choice_result = game_manager.start_string_choice([choice_TribalElder_Draw_sentence, choice_TribalElder_Discard_sentence],player)
            elif len(game_manager.board.slots[SlotEnum.DECK_P2].cards) > 3 and len(game_manager.board.slots[SlotEnum.DECK_P1].cards) > 5:
                choice_result = game_manager.start_string_choice([choice_TribalElder_Discard_sentence],player)
            elif len(game_manager.board.slots[SlotEnum.DECK_P2].cards) < 3 and len(game_manager.board.slots[SlotEnum.DECK_P1].cards) < 5 :
                choice_result = game_manager.start_string_choice([choice_TribalElder_Draw_sentence],player)
        elif player == game_manager.board.player2:
            if len(game_manager.board.slots[SlotEnum.DECK_P1].cards) > 3 and len(game_manager.board.slots[SlotEnum.DECK_P2].cards) < 5:
                choice_result = game_manager.start_string_choice([choice_TribalElder_Draw_sentence, choice_TribalElder_Discard_sentence],player)
            elif len(game_manager.board.slots[SlotEnum.DECK_P1].cards) > 3 and len(game_manager.board.slots[SlotEnum.DECK_P2].cards) > 5:
                choice_result = game_manager.start_string_choice([choice_TribalElder_Discard_sentence],player)
            elif len(game_manager.board.slots[SlotEnum.DECK_P1].cards) < 3 and len(game_manager.board.slots[SlotEnum.DECK_P2].cards) < 5 :
                choice_result = game_manager.start_string_choice([choice_TribalElder_Draw_sentence],player)
                
        if choice_result == choice_TribalElder_Draw_sentence:
            if player == game_manager.board.player1:
                while len(game_manager.board.slots[SlotEnum.DECK_P1].cards) <= 5:
                    game_manager.board.slots[SlotEnum.CARD_DRAW].give_card_at(-1, SlotEnum.DECK_P1)
            else: 
                while len(game_manager.board.slots[SlotEnum.DECK_P2].cards) <= 5:
                    game_manager.board.slots[SlotEnum.CARD_DRAW].give_card_at(-1, SlotEnum.DECK_P2)
        else:
            if ennemy_player == game_manager.board.player1:    
               while len(game_manager.board.slots[SlotEnum.DECK_P1].cards) > 3:
                    choice_result = game_manager.start_card_choice(game_manager.board.slots[SlotEnum.DECK_P1].cards,ennemy_player)
                    game_manager.board.slots[SlotEnum.DECK_P1].give_card(choice_result,SlotEnum.DISCARD)
            else:
                while len(game_manager.board.slots[SlotEnum.DECK_P2].cards) > 3:
                    choice_result = game_manager.start_card_choice(game_manager.board.slots[SlotEnum.DECK_P2].cards,ennemy_player)
                    game_manager.board.slots[SlotEnum.DECK_P2].give_card(choice_result,SlotEnum.DISCARD)