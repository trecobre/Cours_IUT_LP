import unittest
from CardsModule import Card
from CardsModule.UtilityCards import Well
from GameModule.GameManager import SingletonFactory
import xml.etree.ElementTree as ET
from UtilityModule import SlotEnum
from GameModule.CardSlot import CardSlot, EventSlot

class TestWell(unittest.TestCase):
    def setUp(self):
        game_elements = ET.parse('Resources/game_elements-Jambo.xml').getroot()
        game_manager = SingletonFactory.get_instance()

        for i in range(-1, len(SlotEnum) - 1):
            slot_enum = SlotEnum(i)
            if slot_enum == SlotEnum.EVENT_SLOT:
                game_manager.board.slots[slot_enum] = EventSlot(slot_enum)
            else:
                game_manager.board.slots[slot_enum] = CardSlot(slot_enum)
        
        draw_slot = game_manager.board.slots[SlotEnum.CARD_DRAW]
        
        # Load cards

        for card in game_elements.find("cards"):
            kind = card.findtext("kind")

            if kind == "UTILITY":
                for i in range(int(card.findtext("n_copies"))):
                    utility_card: Card = None
                    name_en = card.find("name").findtext("english")

                    if name_en == "Well":
                        utility_card = Well.Well()

                    game_manager.board.slots[SlotEnum.CARD_DRAW].cards.append(utility_card)
                    
        game_manager.board.give_gold(game_manager.board.player1, 1)
        
        game_manager.board.slots[SlotEnum.CARD_DRAW].give_card(game_manager.board.slots[SlotEnum.CARD_DRAW].cards[0], SlotEnum.UTILITY1_P1, 0)
                    
    def test_Well(self):
        game_manager = SingletonFactory.get_instance()
        player = game_manager.board.player1
        game_manager.active_player = player
        if game_manager.board.slots[SlotEnum.UTILITY1_P1].cards[0].can_be_played() == True:
            game_manager.board.slots[SlotEnum.UTILITY1_P1].cards[0].use()
        self.assertEqual(player.gold, 0)
        self.assertEqual(len(game_manager.board.slots[SlotEnum.DECK_P1].cards), 1)
        
        
    if __name__ == '__main__':
        unittest.main()