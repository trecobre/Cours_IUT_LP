from PyQt6 import QtCore, QtGui, QtWidgets
from ViewModule.SettingsWindow import SettingsWindow, Ui_Dialog
from GameModule.GameManager import SingletonFactory
from ViewModule.GameWindow import GameWindow
from ViewModule.CustomWidget import logs_move_played
import sys

running = 1

if __name__ == "__main__":
    game_manager = SingletonFactory.get_instance()
    game_manager.init_game()
    app = QtWidgets.QApplication(sys.argv)
    setting_window = SettingsWindow()
    main_window = GameWindow(app.primaryScreen().size())
    game_manager.game_window = main_window
    game_manager.setting_window = setting_window
    game_manager.log_window = logs_move_played()
    setting_window.show()
    app.exec()