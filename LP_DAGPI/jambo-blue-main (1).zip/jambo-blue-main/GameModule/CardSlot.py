from __future__ import annotations
from CardsModule import Card
from typing import *
from GameModule.GoldHolder import GoldHolder
from GameModule.WareHolder import WareHolder
from UtilityModule import *
from random import shuffle as shuffle_list

class CardSlot:
    def __init__(self, id: SlotEnum) -> None:
        self.id: SlotEnum = id
        self.cards: List[Card] = list[Card]()
    
    def give_card(self, card: Card, receiver: SlotEnum, destination_index: int = -1) -> None:
        """Give a card from this CardSlot to another CardSlot

        Args:
            card (Card): Card to give
            receiver (SlotEnum): CardSlot ID to give card
            destination_index (int, optional): Let to -1 to add at the end.
        """
        
        from GameModule.GameManager import SingletonFactory
        gm = SingletonFactory.get_instance()

        dest_slot = gm.board.slots[receiver]

        if destination_index == -1:
            destination_index = len(dest_slot.cards)
        
        dest_slot.cards.insert(destination_index, card)
        self.cards.remove(card)

        if self.id == SlotEnum.CARD_DRAW and len(self.cards) == 0:
            # Card draw is empty, shuffle the discard in the draw
            while len(gm.board.slots[SlotEnum.DISCARD].cards) > 0:
                gm.board.slots[SlotEnum.DISCARD].give_card_at(0, SlotEnum.CARD_DRAW)
            gm.board.slots[SlotEnum.CARD_DRAW].shuffle()

    def give_card_at(self, index, receiver: SlotEnum, destination_index: int = -1):
        """Give a card from a specified index of this CardSlot to another CardSlot

        Args:
            card_index (int): Index of the card to give
            receiver (SlotEnum): CardSlot ID to give card
            destination_index (int, optional): Let to -1 to add at the end.
        """
        
        from GameModule.GameManager import SingletonFactory
        gm = SingletonFactory.get_instance()

        dest_slot = gm.board.slots[receiver]

        if destination_index == -1:
            destination_index = len(dest_slot.cards)
        
        dest_slot.cards.insert(destination_index, self.cards[index])
        self.cards.pop(index)

        if self.id == SlotEnum.CARD_DRAW and len(self.cards) == 0:
            # Card draw is empty, shuffle the discard in the draw
            while len(gm.board.slots[SlotEnum.DISCARD].cards) > 0:
                gm.board.slots[SlotEnum.DISCARD].give_card_at(0, SlotEnum.CARD_DRAW)
            gm.board.slots[SlotEnum.CARD_DRAW].shuffle()

    def shuffle(self) -> None:
        shuffle_list(self.cards)

class EventSlot(CardSlot,GoldHolder,WareHolder):
        def __init__(self, id) -> None:
            CardSlot.__init__(self, id)
            GoldHolder.__init__(self)
            WareHolder.__init__(self)
        
