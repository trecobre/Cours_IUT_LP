from __future__ import annotations
import imp
from typing import *
from unicodedata import name
from GameModule.Ware import *
from UtilityModule import *

class WareHolder:
    def __init__(self) -> None:
        super(WareHolder, self).__init__()
        self.wares: Set[Ware] = set[Ware]()

    def get_ware_by_name(self, name: str) -> Ware:
        from GameModule.GameManager import SingletonFactory
        for ware in self.wares:
            if ware.get_name(SingletonFactory.get_instance().current_langage) == name:
                return ware
    
    def get_num_ware_by_name(self, name: str) -> int:
        """Get the number of the specified ware

        Args:
            name (str): Ware name in current language

        Returns:
            int: Quantity
        """
        from GameModule.GameManager import SingletonFactory

        count = 0

        for ware in self.wares:
            if name == ware.name[SingletonFactory.get_instance().current_langage]:
                count += 1
        
        return count
        
    def give_Ware(self, receiver: WareHolder, name: str, quantity: int) :
            """give ware too the receiver (player or board) and remove ware of sender(self)

            Args:
                receiver (WareHolder): 
                name (str): name of ware
                quantity (int): quantity of wares
            """

            for i in range(quantity):
                ware = self.get_ware_by_name(name)
                receiver.wares.add(ware)
                self.wares.remove(ware)

            from GameModule.PlayerInventory import PlayerInventory
            from GameModule.GameManager import SingletonFactory
            gm = SingletonFactory.get_instance()

            if isinstance(receiver, PlayerInventory) and len(receiver.wares) == receiver.market_size:
                receiver.give_gold(gm.board, gm.FILL_LARGE_MARKET_STAND_PRICE)

                
    def give_Wares(self, receiver: WareHolder, wares_given: Set[Ware]):
            """Give a set of wares to the receiver

            Args:
                receiver (WareHolder): _description_
                wares_given (Set[Ware]): Wares to give
            """
            from GameModule.GameManager import SingletonFactory
            gm = SingletonFactory.get_instance()
            wares: List[str] = []

            for ware in wares_given:
                wares.append(ware.name[gm.current_langage])

            for ware in wares:
                self.give_Ware(receiver, ware, 1)
                