from __future__ import annotations
import typing
from abc import ABC

class GoldHolder(ABC):    
    def __init__(self) -> None:
        super(GoldHolder, self).__init__()
        self.gold: int = 0
        
    def give_gold(self, receiver: GoldHolder, quantity: int) :
        """Give gold from an GoldHolder to another GoldHolder

        Args:
            receiver (GoldHolder): GoldHolder to give gold
            duantity : number of gold to give.
        """
        from GameModule.PlayerInventory import PlayerInventory
        from GameModule.GameManager import SingletonFactory
        gm = SingletonFactory.get_instance()

        self.gold = self.gold - quantity
        receiver.gold = receiver.gold + quantity

        if isinstance(receiver, PlayerInventory) and receiver.gold >= gm.N_MONEY_TRIGGERING_END_GAME:
            gm.player_who_triggered_end_game = receiver