from GameModule.CardSlot import CardSlot
from GameModule.GoldHolder import GoldHolder
from GameModule.PlayerInventory import PlayerInventory
from GameModule.WareHolder import WareHolder
from UtilityModule import *
from typing import *

class Board(WareHolder , GoldHolder):
    def __init__(self) -> None:
        super(Board, self).__init__()
        self.slots: Dict[SlotEnum, CardSlot] = dict[SlotEnum, CardSlot]()
        self.player1: PlayerInventory = PlayerInventory()
        self.player2: PlayerInventory = PlayerInventory()
