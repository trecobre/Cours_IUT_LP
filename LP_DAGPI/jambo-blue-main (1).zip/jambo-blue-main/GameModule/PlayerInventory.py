from concurrent.futures.process import _global_shutdown
from GameModule.WareHolder import WareHolder
from GameModule.GoldHolder import GoldHolder

class PlayerInventory(WareHolder, GoldHolder):
    def __init__(self) -> None:
        super().__init__()
        self.action_points: int = 0
        self.market_size: int = 0
        self.ware_buy_reduction: int = 0
        self.ware_sell_buff: int = 0