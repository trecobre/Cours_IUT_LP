from random import shuffle, randint
from time import sleep
from typing import *
from UtilityModule import SlotEnum
from GameModule.PlayerInventory import PlayerInventory
from CardsModule.UtilityCards import UtilityCard, Card

class BasicAI:
    def __init__(self, player_to_control: PlayerInventory) -> None:
        self.player_to_control = player_to_control

    def resolve_choice(self, choices_available: List[Any]):
        return choices_available[randint(0, len(choices_available) - 1)]

    def start_phase(self, phase: int):
        from GameModule.GameManager import SingletonFactory
        gm = SingletonFactory.get_instance()

        if gm.active_player is not self.player_to_control:
            return

        if phase == 1:
            while gm.active_phase == 1 and self.player_to_control.action_points > 0:
                # 33% chance of keeping card, 33% chance of keeping it, 33% chance of skipping
                r = randint(0, 2)
                if r == 0:
                    gm.phase1_resolve_draw_choice(gm.board.slots[SlotEnum.CARD_DRAW].cards[-1], True)
                    return True
                elif r == 1:
                    gm.phase1_resolve_draw_choice(gm.board.slots[SlotEnum.CARD_DRAW].cards[-1], False)
                else:
                    return True
            if gm.active_phase == 1:
                return True
        elif phase == 2:
            while gm.active_phase == 2 and self.player_to_control.action_points > 0:
                r = randint(0, 1) # Use a card on board or play a card from hand
                # Get placed and usable utility cards
                usable_utility_cards: List[UtilityCard] = []

                slot_val = SlotEnum.UTILITY1_P1.value
                if self.player_to_control == gm.board.player2:
                    slot_val = SlotEnum.UTILITY1_P2.value
                for i in range(gm.N_MAX_UTILITY_CARDS_AREA):
                    cards: List[UtilityCard] = gm.board.slots[SlotEnum(slot_val + i)].cards
                    if len(cards) > 0 and not cards[0].used and cards[0].can_be_played():
                        usable_utility_cards.append(cards[0])

                playable_cards_in_hand: List[Card] = []
                hand_slot = SlotEnum.DECK_P1
                if self.player_to_control == gm.board.player2:
                    hand_slot = SlotEnum.DECK_P2
                
                for card in gm.board.slots[hand_slot].cards:
                    if card.can_be_played():
                        playable_cards_in_hand.append(card)

                skip = randint(0, 9) # 10% chance to skip to next turn

                if (len(playable_cards_in_hand) == 0 and len(usable_utility_cards) == 0) or skip == 0:
                    # We can't do anything, end the turn
                    return True
                elif len(usable_utility_cards) == 0:
                    r = 0
                elif len(playable_cards_in_hand) == 0:
                    r = 1

                if r == 0:
                    # Play a card from hand
                    gm.phase2_play_card(self.resolve_choice(playable_cards_in_hand))
                else:
                    # Use an utility card
                    gm.phase2_use_utility_card(self.resolve_choice(usable_utility_cards))
            if gm.active_phase == 2:
                return True
