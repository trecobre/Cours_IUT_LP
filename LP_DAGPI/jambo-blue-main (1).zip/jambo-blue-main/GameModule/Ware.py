from typing  import *
from UtilityModule import LanguageEnum

class Ware:
    def __init__(self) -> None:
        self.name: Dict[LanguageEnum,str] = dict[LanguageEnum, str]()
        
    def get_name(self,lang: LanguageEnum = LanguageEnum.EN ):
            return  self.name[lang]
    