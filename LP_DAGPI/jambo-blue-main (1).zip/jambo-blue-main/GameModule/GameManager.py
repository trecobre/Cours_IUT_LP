import xml.etree.ElementTree as ET
import CardsModule
from typing import *
from CardsModule.UtilityCards import Boat, Drums, Kettle, LeopardStatue, MaskOfTransformation, Scale, Supplies, Throne, UtilityCard, Weapons, Well
from CardsModule.PeopleCards import ArabianMerchant, BasketMaker, Carrier, Dancer, Drummer, Guard, PeopleCard, Portuguese, Psychic, RainMaker, Shaman, TravelingMerchant, TribalElder, WiseManFromAfar
from CardsModule.AnimalCards import AnimalCard, Ape, Cheetah, Crocodile, Elephant, Hyena, Lion, Parrot, Snake
from GameModule.CardSlot import CardSlot, EventSlot
from GameModule.Board import Board
from GameModule.PlayerInventory import PlayerInventory
from GameModule.Ware import Ware
from UtilityModule import LanguageEnum, SlotEnum
import UtilityModule
from ViewModule.GameWindow import GameWindow
from GameModule.ArtificialIntelligence import BasicAI
from ViewModule.SettingsWindow import SettingsWindow
from ViewModule.CustomWidget import logs_move_played

class GameManager:
    """This class handles all the game logic
    """
    def __init__(self) -> None:
        self.game_window: GameWindow = None
        self.board: Board = Board()
        self.active_phase: int = -1
        self.active_player: PlayerInventory = None
        self.current_langage: LanguageEnum = LanguageEnum.EN
        self.number_of_ai: int = 1
        self.difficulty_ai_1: int = 0
        self.difficulty_ai_2: int = 0
        self.current_small_market_stand_price: int = 0
        self.base_wares: List[Ware] = []
        self.player_who_triggered_end_game: PlayerInventory = None
        self.player1_basic_AI = BasicAI(self.board.player1)
        self.player2_basic_AI = BasicAI(self.board.player2)
        self.player_color: str = "dodgerblue"
        self.game_finished = False
        self.running = 1
        self.setting_window: SettingsWindow
        self.winner: PlayerInventory
        self.log_window: logs_move_played
        # Constants

        self.N_ROOMS_LARGE_MARKET_STAND = -1
        self.N_ROOMS_SMALL_MARKET_STAND = -1
        self.STARTING_HAND = -1
        self.STARTING_CAPITAL = -1
        self.N_ACTIONS = -1
        self.N_MAX_UTILITY_CARDS_AREA = -1
        self.N_MIN_ACTIONS_LEFT_EVENT = -1
        self.N_MIN_ACTIONS_LEFT_MONEY = -1
        self.BUILD_FIRST_SMALL_MARKET_STAND_PRICE = -1
        self.BUILD_OTHER_SMALL_MARKET_STAND_PRICE = -1
        self.N_GOLD_IN_BANK = 168
        self.FILL_LARGE_MARKET_STAND_PRICE = -1
        self.N_MONEY_TRIGGERING_END_GAME = -1
        self.N_SMALL_MARKET_STANDS = 0

    def __get_language_enum(self, lang: str) -> LanguageEnum:
        """Get a LanguageEnum from a string found in the XML file

        Args:
            lang (str): string to parse

        Returns:
            LanguageEnum: The LanguageEnum corresponding to the string
        """
        if lang == "english":
            return LanguageEnum.EN
        elif lang == "french":
            return LanguageEnum.FR
        elif lang == "german":
            return LanguageEnum.DE

    def start_card_choice(self, cards: List[CardsModule.Card], player: PlayerInventory = None, title: str = None, desc: str = None) -> CardsModule.Card:
        """Begin a choice between a list of cards.
        The choice will be resolved either by the GameWindow (aka the human player) or by an AI

        Args:
            cards (List[CardsModule.Card]): The cards to choose betwwen
            player (PlayerInventory, optional): Optionally specify which player makes the choice. Defaults to None, which takes the active player
            title (str, optional): Optional title for the choice window. Defaults to None.
            desc (str, optional): Optional description for the choice window. Defaults to None.

        Returns:
            CardsModule.Card: The card choosen in cards
        """
        if player is None:
            player = self.active_player

        if player is self.board.player1:
            if self.number_of_ai == 1:
                return self.game_window.show_card_choice(cards, title, desc)
            else:
                return self.player1_basic_AI.resolve_choice(cards)
        else:
            # AI to choose
            return self.player2_basic_AI.resolve_choice(cards)

    def start_auction_choice(self, current_cost: int, cards: List[CardsModule.Card], wares: Set[Ware], player: PlayerInventory, player_has_gold: bool) -> int:
        """Begin a choice between adding more to an auction, or pass it

        Args:
            current_cost (int): Current cost of the auction (golds)
            cards (List[CardsModule.Card]): Cards which may be won by this auction, to show them in the window. Can be None.
            wares (Set[Ware]): Wares which may be won by this auction, to show them in the window. Can be None.
            player (PlayerInventory): Specify which player makes the choice. Can be None, which takes the active player
            player_has_gold (bool): Boolean to determine if the player has enough golds to add to the auction

        Returns:
            int: 0 if player chose to pass, 1 if he added golds
        """
        if player is None:
            player = self.active_player

        if player is self.board.player1:
            if self.number_of_ai == 1:
                return self.game_window.show_auction(current_cost, cards, wares, player_has_gold)
            else:
                choices = []
                if player_has_gold:
                    choices = [0, 1]
                else:
                    choices = [0]
                return self.player1_basic_AI.resolve_choice(choices)
        else:
            choices = []
            if player_has_gold:
                choices = [0, 1]
            else:
                choices = [0]
            return self.player2_basic_AI.resolve_choice(choices)

    def start_string_choice(self, strings: List[str], player: PlayerInventory = None, title: str = None, desc: str = None) -> str:
        """Begin a choice between a list of strings

        Args:
            strings (List[str]): The strings to choose between
            player (PlayerInventory, optional): Optionally specify which player makes the choice. Defaults to None, which takes the active player
            title (str, optional): Optional title for the choice window. Defaults to None.
            desc (str, optional): Optional description for the choice window. Defaults to None.

        Returns:
            str: The string chosen in strings
        """
        if player is None:
            player = self.active_player

        if player is self.board.player1:
            if self.number_of_ai == 1:
                return self.game_window.show_string_choice(strings, title, desc)
            else:
                return self.player1_basic_AI.resolve_choice(strings)
        else:
            # AI to choose
            return self.player2_basic_AI.resolve_choice(strings)

    def get_owning_player(self, card: CardsModule.Card) -> PlayerInventory:
        """Returns the PlayerInventory who owns the specified card

        Args:
            card (CardsModule.Card): The card to check

        Returns:
            PlayerInventory: Player who owns the card
        """
        for slot_enum in self.board.slots:
            if card in self.board.slots[slot_enum].cards:
                if slot_enum.value >= 2 and slot_enum.value <= 11:
                    if card.used_by_croco:
                        return self.board.player2
                    else:
                        return self.board.player1
                else:
                    if card.used_by_croco:
                        return self.board.player1
                    else:
                        return self.board.player2

    def get_card_slot(self, card: CardsModule.Card) -> CardSlot:
        """Returns the slot containing the specified card

        Args:
            card (CardsModule.Card): The card to find

        Returns:
            CardSlot: The slot containing the card
        """
        for slot in self.board.slots.values():
            if card in slot.cards:
                return slot
        return None

    def init_game(self) -> None:
        """Load all values from the XML file and instanciate all the cards, wares, and constants values
        This needs to be called only once, when the game starts
        """
        game_elements = ET.parse('Resources/game_elements-Jambo.xml').getroot()

        # Constants

        self.N_ROOMS_LARGE_MARKET_STAND = int(game_elements.findtext("n_rooms_large_market_stand"))
        self.N_ROOMS_SMALL_MARKET_STAND = int(game_elements.findtext("n_rooms_small_market_stand"))
        self.STARTING_HAND = int(game_elements.findtext("starting_hand"))
        self.STARTING_CAPITAL = int(game_elements.findtext("starting_capital"))
        self.N_ACTIONS = int(game_elements.findtext("n_actions"))
        self.N_MAX_UTILITY_CARDS_AREA = int(game_elements.findtext("n_max_utility_cards_area"))
        self.N_MIN_ACTIONS_LEFT_EVENT = int(game_elements.findtext("n_min_actions_left_event"))
        self.N_MIN_ACTIONS_LEFT_MONEY = int(game_elements.findtext("n_min_actions_left_money"))
        self.BUILD_FIRST_SMALL_MARKET_STAND_PRICE = int(game_elements.findtext("build_first_small_market_stand_price"))
        self.BUILD_OTHER_SMALL_MARKET_STAND_PRICE = int(game_elements.findtext("build_other_small_market_stand_price"))
        self.FILL_LARGE_MARKET_STAND_PRICE = int(game_elements.findtext("fill_large_market_stand_price"))
        self.N_MONEY_TRIGGERING_END_GAME = int(game_elements.findtext("n_money_triggering_end_game"))

        # Create card slots

        for i in range(-1, len(SlotEnum) - 1):
            slot_enum = SlotEnum(i)
            if slot_enum == SlotEnum.EVENT_SLOT:
                self.board.slots[slot_enum] = EventSlot(slot_enum)
            else:
                self.board.slots[slot_enum] = CardSlot(slot_enum)
        
        draw_slot = self.board.slots[SlotEnum.CARD_DRAW]

        # Load Wares

        for ware_element in game_elements.find("wares"):
            ware_added = False
            for i in range(int(ware_element.findtext("nbr"))):
                ware = Ware()

                for lang in ware_element.find("name"):
                    lang_enum = self.__get_language_enum(lang.tag)
                    ware.name[lang_enum] = lang.text

                self.board.wares.add(ware)

                if not ware_added:
                    ware_added = True
                    self.base_wares.append(ware)

        # Load cards

        large_market_slot_id = SlotEnum.MARKETPLACE_P1
        for card in game_elements.find("cards"):
            kind = card.findtext("kind")

            if kind == "LARGE MARKET STAND":
                self.board.slots[large_market_slot_id].cards.append(CardsModule.MarketCard(self.N_ROOMS_LARGE_MARKET_STAND))
                large_market_slot_id = SlotEnum.MARKETPLACE_P2
            elif kind == "SMALL MARKET STAND":
                for i in range(int(card.findtext("n_copies"))):
                    draw_slot.cards.append(CardsModule.MarketCard(self.N_ROOMS_SMALL_MARKET_STAND))
                    self.N_SMALL_MARKET_STANDS += 1
            elif kind == "WARE":
                for i in range(int(card.findtext("n_copies"))):
                    ware_card = CardsModule.WareCard()
                    ware_card.buy_price = int(card.findtext("buy_price"))
                    ware_card.sell_price = int(card.findtext("sell_price"))

                    for ware_component in card.find("wares"):
                        for i in range(int(ware_component.findtext("nbr"))):
                            ware = Ware()
                            for lang in ware_component.find("name"):
                                ware.name[self.__get_language_enum(lang.tag)] = lang.text
                            ware_card.wares.add(ware)
                    
                    self.board.slots[SlotEnum.CARD_DRAW].cards.append(ware_card)
            elif kind == "UTILITY":
                for i in range(int(card.findtext("n_copies"))):
                    utility_card: CardsModule.Card = None
                    name_en = card.find("name").findtext("english")

                    if name_en == "Boat":
                        utility_card = Boat.Boat()
                    elif name_en == "Drums":
                        utility_card = Drums.Drums()
                    elif name_en == "Kettle":
                        utility_card = Kettle.Kettle()
                    elif name_en == "Leopard statue":
                        utility_card = LeopardStatue.LeopardStatue()
                    elif name_en == "Mask of transformation":
                        utility_card = MaskOfTransformation.MaskOfTransformation()
                    elif name_en == "Scale":
                        utility_card = Scale.Scale()
                    elif name_en == "Supplies":
                        utility_card = Supplies.Supplies()
                    elif name_en == "Weapons":
                        utility_card = Weapons.Weapons()
                    elif name_en == "Well":
                        utility_card = Well.Well()
                    elif name_en == "Throne":
                        utility_card = Throne.Throne()

                    for lang in card.find("name"):
                        utility_card.name[self.__get_language_enum(lang.tag)] = lang.text
                    for lang in card.find("text"):
                        utility_card.desc[self.__get_language_enum(lang.tag)] = lang.text
                    
                    if LanguageEnum.DE not in utility_card.desc.keys():
                        utility_card.desc[LanguageEnum.DE] = utility_card.desc[LanguageEnum.EN]

                    self.board.slots[SlotEnum.CARD_DRAW].cards.append(utility_card)
            elif kind == "PEOPLE":
                for i in range(int(card.findtext("n_copies"))):
                    people_card: CardsModule.Card = None
                    name_en = card.find("name").findtext("english")

                    if name_en == "Arabian merchant":
                        people_card = ArabianMerchant.ArabianMerchant()
                    elif name_en == "Basket maker":
                        people_card = BasketMaker.BasketMaker()
                    elif name_en == "Carrier":
                        people_card = Carrier.Carrier()
                    elif name_en == "Dancer":
                        people_card = Dancer.Dancer()
                    elif name_en == "Drummer":
                        people_card = Drummer.Drummer()
                    elif name_en == "Guard":
                        people_card = Guard.Guard()
                    elif name_en == "Portuguese":
                        people_card = Portuguese.Portuguese()
                    elif name_en == "Psychic":
                        people_card = Psychic.Psychic()
                    elif name_en == "Rain maker":
                        people_card = RainMaker.RainMaker()
                    elif name_en == "Shaman":
                        people_card = Shaman.Shaman()
                    elif name_en == "Traveling merchant":
                        people_card = TravelingMerchant.TravelingMerchant()
                    elif name_en == "Tribal elder":
                        people_card = TribalElder.TribalElder()
                    elif name_en == "Wise man from afar":
                        people_card = WiseManFromAfar.WiseManFromAfar()

                    for lang in card.find("name"):
                        people_card.name[self.__get_language_enum(lang.tag)] = lang.text
                    for lang in card.find("text"):
                        people_card.desc[self.__get_language_enum(lang.tag)] = lang.text

                    if LanguageEnum.DE not in people_card.desc.keys():
                        people_card.desc[LanguageEnum.DE] = people_card.desc[LanguageEnum.EN]
                    
                    self.board.slots[SlotEnum.CARD_DRAW].cards.append(people_card)
            elif kind == "ANIMAL":
                for i in range(int(card.findtext("n_copies"))):
                    animal_card: CardsModule.Card = None
                    name_en = card.find("name").findtext("english")

                    if name_en == "Ape":
                        animal_card = Ape.Ape()
                    elif name_en == "Cheetah":
                        animal_card = Cheetah.Cheetah()
                    elif name_en == "Crocodile":
                        animal_card = Crocodile.Crocodile()
                    elif name_en == "Elephant":
                        animal_card = Elephant.Elephant()
                    elif name_en == "Hyena":
                        animal_card = Hyena.Hyena()
                    elif name_en == "Lion":
                        animal_card = Lion.Lion()
                    elif name_en == "Parrot":
                        animal_card = Parrot.Parrot()
                    elif name_en == "Snake":
                        animal_card = Snake.Snake()

                    for lang in card.find("name"):
                        animal_card.name[self.__get_language_enum(lang.tag)] = lang.text
                    for lang in card.find("text"):
                        animal_card.desc[self.__get_language_enum(lang.tag)] = lang.text

                    if LanguageEnum.DE not in animal_card.desc.keys():
                        animal_card.desc[LanguageEnum.DE] = animal_card.desc[LanguageEnum.EN]
                    
                    self.board.slots[SlotEnum.CARD_DRAW].cards.append(animal_card)

    def reset_game(self) -> None:
        """Setup the board to be ready for a new game
        """
        for i in range(-1, len(SlotEnum) - 1):
            slot_enum = SlotEnum(i)
            if not(slot_enum == SlotEnum.MARKETPLACE_P1 or slot_enum == SlotEnum.MARKETPLACE_P2 or slot_enum == SlotEnum.CARD_DRAW):
                while len(self.board.slots.get(slot_enum).cards)>0:
                    self.board.slots.get(slot_enum).give_card_at(0, SlotEnum.CARD_DRAW)
        self.board.player1.gold = 0
        self.board.player2.gold = 0

        self.board.player1.wares.clear()
        self.board.player2.wares.clear()

        self.player_who_triggered_end_game = None


    def start_game(self):
        """Begin a new game, assuming init_game or reset_game have been called
        """
        self.log_window.setHidden(False)

        self.board.slots[SlotEnum.CARD_DRAW].shuffle()

        self.board.gold = self.N_GOLD_IN_BANK

        self.board.give_gold(self.board.player1, self.STARTING_CAPITAL)
        self.board.give_gold(self.board.player2, self.STARTING_CAPITAL)

        self.active_player = self.board.player1
        self.active_phase = -1

        self.board.player1.action_points = self.N_ACTIONS
        self.board.player2.action_points = self.N_ACTIONS

        self.current_small_market_stand_price = self.BUILD_FIRST_SMALL_MARKET_STAND_PRICE

        self.board.player1.market_size = self.N_ROOMS_LARGE_MARKET_STAND
        self.board.player2.market_size = self.N_ROOMS_LARGE_MARKET_STAND

        for i in range(self.STARTING_HAND):
            self.board.slots[SlotEnum.CARD_DRAW].give_card_at(-1, SlotEnum.DECK_P1)
            self.board.slots[SlotEnum.CARD_DRAW].give_card_at(-1, SlotEnum.DECK_P2)
        
        self.game_window.update()
        self.run_game()

    def run_game(self):
        """Enter a loop which will be exited when the human player has to interact with the board, or when the game is finished
        """
        while self.next_phase():
            if self.game_finished:
                return

    def next_phase(self) -> bool:
        """Go into the next game phase (0, 1 or 2), or to the next turn if the active phase is 2

        Returns:
            bool: True if we need to immediately go to the next phase, False or None to exit the run_game loop and wait for a player interaction 
        """
        previous_phase = self.active_phase
        if self.active_phase == 0:
            self.log_window.add_line(self.get_active_player_text() + " turn.")

        if self.active_phase == 1:
            pass
        if self.active_phase == 2:
            if self.player_who_triggered_end_game is not None and self.player_who_triggered_end_game is not self.active_player:
                self.log_window.add_line("Game Finished")
                print("game is finished!")
                self.active_phase = -1
                self.game_finished = True
                self.game_window.update()
                if self.board.player1.gold > self.board.player2.gold:
                    self.winner = self.board.player1
                else:
                    self.winner = self.board.player2
                self.game_window.button_skip_phase.setEnabled(False)
                self.game_window.endGame()
                self.game_window.disable_all_slots()
                return
            if self.active_player.action_points >= self.N_MIN_ACTIONS_LEFT_EVENT:
                self.log_window.add_line(self.get_active_player_text() + " didn't use all action point, " + self.get_active_player_text() + " recieve 1 Gold")
                self.board.give_gold(self.active_player, self.N_MIN_ACTIONS_LEFT_MONEY)
            self.active_phase = 0
            self.board.player1.ware_buy_reduction = 0
            self.board.player1.ware_sell_buff = 0
            self.board.player2.ware_buy_reduction = 0
            self.board.player2.ware_sell_buff = 0
            if self.active_player == self.board.player1:
                self.active_player = self.board.player2
                self.board.player2.action_points = self.N_ACTIONS
            else:
                self.active_player = self.board.player1
                self.board.player1.action_points = self.N_ACTIONS
        else:
            self.active_phase += 1

        if self.active_phase == 0:
            pass
        elif self.active_phase == 1:
            pass
        elif self.active_phase == 2:
            if self.active_player.action_points > 0:
                # Enable utility cards placed on board
                utility_slot = SlotEnum.UTILITY1_P1
                if self.active_player == self.board.player2:
                    utility_slot = SlotEnum.UTILITY1_P2
                for i in range(self.N_MAX_UTILITY_CARDS_AREA):
                    slot = self.board.slots[SlotEnum(utility_slot.value + i)]
                    if len(slot.cards) > 0:
                        utility_card: UtilityCard = slot.cards[0]
                        utility_card.used = False

        cards_in_game: Set[CardsModule.Card] = set[CardsModule.Card]()

        for i in range(self.N_MAX_UTILITY_CARDS_AREA):
            slot_p1 = self.board.slots[SlotEnum(SlotEnum.UTILITY1_P1.value + i)]
            slot_p2 = self.board.slots[SlotEnum(SlotEnum.UTILITY1_P2.value + i)]
            if len(slot_p1.cards) > 0:
                cards_in_game.add(slot_p1.cards[0])
            if len(slot_p2.cards) > 0:
                cards_in_game.add(slot_p2.cards[0])

        for card in cards_in_game:
            if card.can_be_played():
                card.on_phase_end(previous_phase)
        for card in cards_in_game:
            if card.can_be_played():
                card.on_phase_start(self.active_phase)
        
        self.game_window.update()

        if self.active_phase == 0:
            return True

        if self.active_player == self.board.player1:
            if self.number_of_ai == 1:
                self.game_window.start_phase(self.active_phase)
            else:
                return self.player1_basic_AI.start_phase(self.active_phase)
        else:
            # Start AI phase
            return self.player2_basic_AI.start_phase(self.active_phase)

    def get_active_player_text(self) -> str:
        """Return a string representing the active player

        Returns:
            str: "Player 1" or "Player 2"
        """
        if self.active_player == self.board.player1:
            return "Player 1"
        else:
            return "Player 2"

    def phase1_resolve_draw_choice(self, card: CardsModule.Card, wants_card: bool):
        """Resolve a choice made by the player during the phase 1

        Args:
            card (CardsModule.Card): The card drawn
            wants_card (bool): True to keep the card, False to discard it.
            It's the responsibility of the caller to go to the next phase if wants_card is True
        """
        if self.active_player.action_points > 0:
            if wants_card:
                receiver = SlotEnum.DECK_P1
                if self.active_player == self.board.player2:
                    receiver = SlotEnum.DECK_P2
                self.log_window.add_line(self.get_active_player_text() + " draw a card and keep it.")
                self.board.slots[SlotEnum.CARD_DRAW].give_card(card, receiver)
            else:
                self.board.slots[SlotEnum.CARD_DRAW].give_card(card, SlotEnum.DISCARD)
                self.log_window.add_line(self.get_active_player_text() + " draw a card and discard it.")
            self.active_player.action_points -= 1

        self.game_window.update()

    def phase2_play_card(self, card_to_play: CardsModule.Card):
        """Play a card from a player's hand to the board (discard, utility slot, market extension slot) during phase 2.

        Args:
            card_to_play (CardsModule.Card): The card to play.
            It's the responsability of the caller to check if the card can be played.
        """
        if self.active_player.action_points > 0 or not card_to_play.action_used:
            owning_player = self.get_owning_player(card_to_play)
            if isinstance(card_to_play, UtilityCard):
                self.log_window.add_line(self.get_active_player_text() + " places " + type(card_to_play).__name__ + " card.")
                slot_value = SlotEnum.UTILITY1_P1.value
                if owning_player == self.board.player2:
                    slot_value = SlotEnum.UTILITY1_P2.value
                utility_cards = []
                for i in range(self.N_MAX_UTILITY_CARDS_AREA):
                    cards = self.board.slots[SlotEnum(slot_value + i)].cards
                    if len(cards) == 0:
                        self.get_card_slot(card_to_play).give_card(card_to_play, SlotEnum(slot_value + i))
                        break
                    else:
                        utility_cards.append(cards[0])
                if len(utility_cards) == self.N_MAX_UTILITY_CARDS_AREA:
                    card_to_discard = self.start_card_choice(utility_cards)
                    slot = self.get_card_slot(card_to_discard)
                    slot.give_card(card_to_discard, SlotEnum.DISCARD)
                    self.get_card_slot(card_to_play).give_card(card_to_play, slot.id)
                self.active_player.action_points -= 1

            elif isinstance(card_to_play, AnimalCard):
                # Animal cards can be cancelled by the Guard
                self.log_window.add_line(self.get_active_player_text() + " uses " + type(card_to_play).__name__ + " card.")
                guard_found: Guard.Guard = None
                choice_result = None
                (cancel_text, dont_cancel_text) = UtilityModule.LanguageManager.get_guard_choice_texts()
                if owning_player is self.board.player1:
                    for card in self.board.slots[SlotEnum.DECK_P2].cards:
                        if isinstance(card, Guard.Guard):
                            guard_found = card
                            choice_result = self.start_string_choice([cancel_text, dont_cancel_text], self.board.player2, card_to_play.name[self.current_langage], card_to_play.desc[self.current_langage])
                            break
                else:
                    for card in self.board.slots[SlotEnum.DECK_P1].cards:
                        if isinstance(card, Guard.Guard):
                            guard_found = card
                            choice_result = self.start_string_choice([cancel_text, dont_cancel_text], self.board.player1, card_to_play.name[self.current_langage], card_to_play.desc[self.current_langage])
                            break

                animal_canceled = choice_result == cancel_text
                
                if not animal_canceled:
                    self.active_player.action_points -= 1
                    card_to_play.use()
                else:
                    self.log_window.add_line(type(card_to_play).__name__ + " card has been canceled by guard.")
                    self.get_card_slot(guard_found).give_card_at(0, SlotEnum.DISCARD)
                self.get_card_slot(card_to_play).give_card(card_to_play, SlotEnum.DISCARD)
            elif isinstance(card_to_play, CardsModule.MarketCard):
                self.log_window.add_line(self.get_active_player_text() + " uses " + type(card_to_play).__name__ + " card.")
                self.active_player.action_points -= 1
                market_slot_id = SlotEnum.MARKET_EXTENSION1_P1.value
                if owning_player == self.board.player2:
                    market_slot_id = SlotEnum.MARKET_EXTENSION1_P2.value
                for i in range(self.N_SMALL_MARKET_STANDS):
                    slot = SlotEnum(market_slot_id + i)
                    if len(self.board.slots[slot].cards) == 0:
                        self.get_card_slot(card_to_play).give_card(card_to_play, slot)
                        card_to_play.use()
                        break
            else:
                self.log_window.add_line(self.get_active_player_text() + " uses " + type(card_to_play).__name__ + " card.")
                self.active_player.action_points -= 1
                card_to_play.use()
                self.get_card_slot(card_to_play).give_card(card_to_play, SlotEnum.DISCARD)

            if isinstance(card_to_play, CardsModule.WareCard):
                # Ware cards can be taken by the Rain Maker
                if owning_player is self.board.player1:
                    for card in self.board.slots[SlotEnum.DECK_P2].cards:
                        if isinstance(card, RainMaker.RainMaker):
                            card.use()
                            break
                else:
                    for card in self.board.slots[SlotEnum.DECK_P1].cards:
                        if isinstance(card, RainMaker.RainMaker):
                            card.use()
                            break

        self.game_window.update()

    def phase2_use_utility_card(self, utility_card_to_use: UtilityCard):
        """Use an utility card which was already placed on the board.

        Args:
            utility_card_to_use (UtilityCard): The utility card to use.
            It's the responsability of the caller to check if the card can be played
        """
        self.active_player.action_points -= 1
        self.log_window.add_line(self.get_active_player_text() + " uses " + type(utility_card_to_use).__name__ + " card.")
        utility_card_to_use.use()
        utility_card_to_use.used = True

        self.game_window.update()


class SingletonFactory:
    __instance = None
    @staticmethod
    def get_instance() -> GameManager:
        if SingletonFactory.__instance is None :
            SingletonFactory.__instance = GameManager()
        return SingletonFactory.__instance