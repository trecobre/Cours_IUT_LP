#!/bin/bash

# ----- Change these variables to fit the project -----
FRONT_FOLDER="musicreviewer-front"
USE_DB=1 # Set this to something else than 0 to disable remote DB
EMPTY_DB="./empty_database.sqlite"
DB_FILE="./MusicReviewerDB"
# -----------------------------------------------------

RED='\033[0;31m'
GREEN='\033[0;32m'
ORANGE='\033[0;33m'
BLUE='\033[0;36m'
NC='\033[0m' # No Color
ENV_TYPE=""
ROOT_FOLDER=$(pwd)

check_error () {
    if [ $? -ne 0 ]; then
        printf "\n${RED}Error: Something went wrong with the last command, exiting.\n"
        exit -1
    fi
}

if [ "$1" = "dev" ]; then
    ENV_TYPE="dev"
elif [ "$1" = "prod" ]; then
    ENV_TYPE="prod"
elif [ "$1" = "" ]; then
    ENV_TYPE="dev"
else
    printf "\n${RED}Error: Unknown environment type '${1}'\n"
    exit -1
fi

printf "\nUsing ${ORANGE}${ENV_TYPE}${NC} environment\n\n"

if [ ! -s "$DB_FILE" ]; then
    printf "\nInvalid DB file, creating a new one with the template ...\n"
    cp "$EMPTY_DB" "$DB_FILE"
    check_error
    printf "${GREEN}DB created${NC}\n\n"
fi

if [ -z "$(ls -A $FRONT_FOLDER)" ]; then
    printf "${BLUE}Initializing submodule...${NC}\n\n"
    git submodule update --init
fi

if [ "$ENV_TYPE" = "prod" ]; then
    git checkout main
    check_error
    git pull
    check_error
    git submodule update
    check_error
    npm i
    check_error
    cd "$FRONT_FOLDER"
    check_error
    npm i
    check_error
    npm run build
    check_error
    cd "$ROOT_FOLDER"
    npm run build
    check_error
else
    npm i
    check_error
    cd "$FRONT_FOLDER"
    check_error
    npm i
    check_error
    cd "$ROOT_FOLDER"
fi

ENV_FILE=./.env
DB_ENV_CREATED=0

if [ ! -f "$ENV_FILE" ]; then
    echo "ENV=$ENV_TYPE" > "$ENV_FILE"
    check_error
    if [ $USE_DB -eq 0 ]; then
        echo "DB_URL=PUT_DB_URL_HERE" >> "$ENV_FILE"
        check_error
        DB_ENV_CREATED=1
    fi
    echo ""
    echo ".env file created"
else
    if ! grep -q "ENV=" "$ENV_FILE"; then
        echo "ENV=$ENV_TYPE" >> .env
        check_error
    else
        sed -i "s/ENV=dev/ENV=$ENV_TYPE/" "$ENV_FILE"
        sed -i "s/ENV=prod/ENV=$ENV_TYPE/" "$ENV_FILE"
    fi
    if [ $USE_DB -eq 0 ] && ! grep -q "DB_URL=" "$ENV_FILE"; then
        echo "DB_URL=PUT_DB_URL_HERE" >> "$ENV_FILE"
        check_error
        DB_ENV_CREATED=1
    fi
    echo ""
    echo ".env file updated to $ENV_TYPE"
fi

if [ $USE_DB -eq 0 ] && grep -q "DB_URL=PUT_DB_URL_HERE" "$ENV_FILE"; then
    DB_ENV_CREATED=1
fi

if [ $DB_ENV_CREATED -ne 0 ]; then
    printf "\n${ORANGE}DON'T FORGET TO UPDATE DB_URL in .env\n${NC}"
fi

printf "\n${GREEN}Done.\n\n"

if [ "$ENV_TYPE" = "prod" ]; then
    printf "${NC}Server is ready for production and can be started with ${BLUE}npm run start:prod\n"
else
    printf "${NC}Server is ready for development and can be started with ${BLUE}npm run start:dev\n"
    printf "${NC}To start the front server, run ${BLUE}npm run start${NC} in the ${ORANGE}${FRONT_FOLDER}${NC} folder\n"
fi

exit 0