import { HttpClient } from "@angular/common/http";
import { Injectable, isDevMode } from "@angular/core";
import { Tracks } from "../models/Tracks";
import { Ranking } from "../models/Ranking";
import { Location } from '@angular/common';

@Injectable({
  providedIn: 'root'
})
export class TrackService {
  private BASE_URL: string;

  constructor(private http: HttpClient, private loc: Location) {
    const angularRoute = this.loc.path();
    const url = window.location.href;
    this.BASE_URL = (isDevMode() ? "http://localhost:3000" : url.replace(angularRoute, '')) + "/api";
  }

  public searchTrack(searchText:string){
    return this.http.get<Tracks[]>(this.BASE_URL + '/music/search?q='+searchText); 
  }

  public getListTracksByIds(list:number[]){
    return this.http.get<Tracks[]>(this.BASE_URL + '/music/track?trackIds='+list.join(',')); 
  }
}
