export class Ranking{
    public rating?:number;
    public trackId?:number;
    public reviewId?:number;
    public userId?:number;
    public average?:number;
    public count?:number;
    constructor(rating?:number, trackId?:number, reviewId?:number, userId?:number, average?:number, count?:number){
        this.rating = rating;
        this.trackId = trackId;
        this.reviewId = reviewId;
        this.userId = userId;
        this.average = average;
        this.count = count;
    }
}