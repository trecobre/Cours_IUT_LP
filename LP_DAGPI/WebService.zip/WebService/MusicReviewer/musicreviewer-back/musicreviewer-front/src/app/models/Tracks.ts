interface IArtist{
    name:string;
    picture:string;
}
interface IAlbum{
    title:string;
    cover:string;
}

export class Tracks{
    public id?:number;
    public title?:string;
    public duration?:number;
    public artist?:IArtist;
    public album?:IAlbum;
    public ranking?:number;
}