
import { HttpClient } from "@angular/common/http";
import { Injectable, isDevMode } from "@angular/core";
import { Tracks } from "../models/Tracks";
import { Ranking } from "../models/Ranking";
import { Location } from '@angular/common';

@Injectable({
    providedIn: 'root'
})
export class RankingService {
    private BASE_URL: string;

    constructor(private http: HttpClient, private loc: Location) {
        const angularRoute = this.loc.path();
        const url = window.location.href;
        this.BASE_URL = (isDevMode() ? "http://localhost:3000" : url.replace(angularRoute, '')) + "/api";
    }

    public getTopTracks(){
        return this.http.get<Ranking[]>(this.BASE_URL + '/ranking');
    }

    public rateTrack(rating:Ranking){
        return this.http.post<Ranking>(this.BASE_URL + '/ranking', rating, {withCredentials: isDevMode()});
    }
    ///api/ranking/track/{trackId}
    public getTrackRating(id:number){
        return this.http.get<Ranking>(this.BASE_URL + '/ranking/track/'+id);
    }
}
