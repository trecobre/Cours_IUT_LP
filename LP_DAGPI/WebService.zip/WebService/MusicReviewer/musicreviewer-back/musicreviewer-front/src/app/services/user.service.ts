import { HttpClient } from "@angular/common/http";
import { Injectable, isDevMode } from "@angular/core";
import { User } from '../models/User';
import { Location } from '@angular/common';
import { AuthResponse } from "../models/AuthResponse";

@Injectable({
  providedIn: 'root'
})
export class UserService {
  private BASE_URL: string;

  constructor(private http: HttpClient, private loc: Location) {
    const angularRoute = this.loc.path();
    const url = window.location.href;
    this.BASE_URL = (isDevMode() ? "http://localhost:3000" : url.replace(angularRoute, '')) + "/api";
  }

  public authenticateUser(user:User){
    return this.http.post<AuthResponse>(this.BASE_URL + '/auth', user, {withCredentials: isDevMode()}); 
  }

  public isConnected(){
    return this.http.get<AuthResponse>(this.BASE_URL + '/users/me', {withCredentials: isDevMode()}); 
  }

  public createUser(user:User){
    return this.http.post(this.BASE_URL + '/users', user); 
  }
}
