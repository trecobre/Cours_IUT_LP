import { Component, Input, OnInit } from '@angular/core';
import { ModalSize } from '@mantic-ui/angular';
import { Tracks } from 'src/app/models/Tracks';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { User } from 'src/app/models/User';
import { Ranking } from 'src/app/models/Ranking';
import { RankingService } from 'src/app/services/ranking.service';

@Component({
  selector: 'app-track-component',
  templateUrl: './track-component.component.html',
  styleUrls: ['./track-component.component.css'],
})
export class TrackComponentComponent implements OnInit{
  @Input() track?: Tracks;
  @Input() isConnected?: boolean;
  public showModal= false;
  public size: ModalSize = 'large';
  public max = 10;
  public rate = 0;
  public isReadonly = false;
  constructor(private rankingService: RankingService , private modalService: NgbModal) {}
  ariaValueText() {
		return `${this.rate} sur ${this.max}`;
	}
  
  ngOnInit(): void {
    if(this.track?.ranking){
      this.rate = this.track?.ranking;
    }
  }

  getCover(){
    return this.track?.album?.cover;
  }

  getTrackName(){
    return this.track?.title;
  }

  getArtistName(){
    return this.track?.artist?.name;
  }

  getAlbumName(){
    return this.track?.album?.title;
  }

  getArtistCover(){
    return this.track?.artist?.picture;
  }

  getDuration(){
    if(this.track?.duration){
      let minutes = Math.trunc(Number(this.track?.duration) / 60);
      let secondes = Number(this.track?.duration) - (minutes*60);
      return minutes + ":" + String(secondes).padStart(2, '0');
    }
    else{
      return "";
    }
  }

  openModal(content:any) {
		this.modalService.open(content, { size: 'xl', scrollable: true });
	}

  rateTrack(){
    console.log(this.rate)
    if(this.isConnected && this.track?.id){
      let ranking = new Ranking(this.rate, this.track.id);
      this.rankingService.rateTrack(ranking).subscribe(val => {
        if(val.trackId){
          this.rankingService.getTrackRating(val.trackId).subscribe(rank => {
            if(this.track){
              this.track.ranking = rank.average;
            }
          })
        }

      })
    }
  }
}
