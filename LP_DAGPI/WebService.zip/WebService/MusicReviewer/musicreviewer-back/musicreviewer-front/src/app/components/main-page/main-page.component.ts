import { Component, OnInit } from '@angular/core';
import { NotificationService } from '@mantic-ui/angular';
import { UserService } from '../../services/user.service';
import { User } from '../../models/User';
import { TrackService } from '../../services/track.service';
import { Tracks } from '../../models/Tracks';
import { NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { RankingService } from 'src/app/services/ranking.service';

@Component({
  selector: 'app-main-page',
  templateUrl: './main-page.component.html',
  styleUrls: ['./main-page.component.css']
})
export class MainPageComponent implements OnInit {
  public showModal = false;
  public isLoginModal = true;
  public isPasswordInvalid = false;
  public isAccountCreated = false;
  public isFieldMissing = false;
  public creationFailed = false;
  public username?: string;
  public password?: string;
  public user?: User;
  public passwordConfirmation?: string;
  public searchText?: string;
  public listTracks: Tracks[] = [];
  public modalOpen?: NgbModalRef;

  public constructor(private userService: UserService, private trackService: TrackService,private rankingService: RankingService ,private modalService: NgbModal) { }

  ngOnInit(): void {
    this.userService.isConnected().subscribe({
      next: (value) => {
        if(value.username){
          this.user = new User(value.username);
        }
        else {
          this.user = undefined;
        }
      },
      error: (e) => {
        this.user = undefined;
      }
    });
    this.resetTrackList();
  }

  openModal(content: any) {
    this.modalOpen = this.modalService.open(content, { centered: true });
  }

  connect() {
    if (this.username && this.password) {
      let user = new User(this.username, this.password);
      this.userService.authenticateUser(user).subscribe({
        next: (value) => {
          if (value.success) {
            this.user = user;
            this.modalOpen?.close()
          }
          else {
            this.isPasswordInvalid = true;
          }
        },
        error: (e) => {
          this.isPasswordInvalid = true;
        }
      });
    }
  }

  isConnected() {
    return (this.user != undefined);
  }

  createAccount() {
    if (this.username && this.password && this.passwordConfirmation && this.password === this.passwordConfirmation) {
      let user = new User(this.username, this.password);
      this.userService.createUser(user).subscribe({
        next: (value) => {
          console.log(value)
          this.isLoginModal = true;
          this.isAccountCreated = true;
        },
        error: (error) => {
          this.creationFailed = true;
        }
      });
    }
    else {
      this.isFieldMissing = true;
    }
  }

  searchTrack() {
    if (this.searchText) {
      this.trackService.searchTrack(this.searchText).subscribe((val) => {
        this.listTracks = val;
      })
    }
  }

  onUsernameChange(event: any) {
    this.username = event.target.value;
  }

  onPwdChange(event: any) {
    this.password = event.target.value;
  }

  onPwdConfChange(event: any) {
    this.passwordConfirmation = event.target.value;
  }

  getUsername() {
    return this.user?.getUsername();
  }

  resetTrackList(){
    let listId:number[]=[];
    this.rankingService.getTopTracks().subscribe({
      next: (rankingArray) => {
        rankingArray.forEach(ranking => {
          if(ranking.trackId){
            listId.push(ranking.trackId);
          }
        });
        this.trackService.getListTracksByIds(listId).subscribe(listTracks => {
          this.listTracks = listTracks;
          this.listTracks.forEach(track => {
            rankingArray.forEach(ranking => {
              if(track.id === ranking.trackId) {
                track.ranking = ranking.rating;
              }
            });
          })
        })
      }
    })
  }
}
