export class AuthResponse{
    public success?:boolean;
    public userId?:number;
    public username?: string;
    constructor(succes?:boolean, userId?:number, username?:string){
        this.success = succes;
        this.userId = userId;
        this.username = username;
    }
}