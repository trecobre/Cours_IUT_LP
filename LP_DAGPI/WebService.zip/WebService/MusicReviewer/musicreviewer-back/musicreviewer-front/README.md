# front

## Installation

1- install angular : npm install -g @angular/cli
2- git clone
3- npm i
4- 
