![Logo](https://cdn.discordapp.com/attachments/1031825765345538089/1101077773654687774/MusicReviewerPurpleWhiteLOGOSmaller.png)


# LoudR

Louder est un projet réalisé dans le cadre d'un cours sur les services web. L'objectif de ce projet est de démontrer comment les technologies web peuvent être utilisées pour créer un service web. Pour atteindre cet objectif.

Louder utilise Angular pour la partie front-end et Node.js pour la partie back-end, avec l'utilisation de plusieurs frameworks back-end tels que Nest.js et Sequelize. La communication entre la partie back-end et la partie front-end est assurée par l'utilisation d'un service REST.



## Features d'API

- Recherche de musique
- Creations/modification de playlist personnel
- Noter les musiques
- Creations d'utilisateur


## Installation

Install Louder sur linux en dev

```bash
  git clone git@gitlab-ce.iut.u-bordeaux.fr:musicreviewer/musicreviewer-back.git Louder
  cd Louder/
  ./install.sh dev
  npm run start:dev
  cd musicreviewer-front/
  npm run start
```
Install Louder sur linux en prod

```bash
  git clone git@gitlab-ce.iut.u-bordeaux.fr:musicreviewer/musicreviewer-back.git Louder
  cd Louder
  ./install.sh prod
  npm run start:prod
```

## Documentation
 - [Louder](http://tonarie.xyz/doc)
 - [Nest.JS](https://docs.nestjs.com/)
 - [Sequelize](https://docs.nestjs.com/)
 - [SQLite](https://www.sqlite.org/docs.html)


## Authors

- [@lecarricart](https://gitlab-ce.iut.u-bordeaux.fr/lecarricart)
- [@allafaye](https://gitlab-ce.iut.u-bordeaux.fr/allafaye)
- [@trecobre](https://gitlab-ce.iut.u-bordeaux.fr/trecobre)
