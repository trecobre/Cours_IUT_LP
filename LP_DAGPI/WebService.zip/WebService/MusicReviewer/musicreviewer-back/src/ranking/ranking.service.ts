import { Injectable } from '@nestjs/common';
import { ApiProperty } from '@nestjs/swagger';
import { dbInterface } from 'src/DB/dbInterface';

export class TrackRankingDto {
  @ApiProperty()
  average: number;

  @ApiProperty()
  count: number;
}

@Injectable()
export class RankingService {
  
  async getTrackRanking(trackId: number): Promise<TrackRankingDto> {
    const db = dbInterface.getInstance();
    const average = await db.getReviewRatingAverageFromTrack(trackId);
    const count = (await db.getReviewRatingListFromTrack(trackId)).length;

    return {
      average,
      count
    };
  }

  async getTopTracks(nbTracks: Number) {
    return await dbInterface.getInstance().getTopTrackRanking(nbTracks);
  }

  async postRanking(userId: Number, trackId: Number, ranking: Number) {
    const db = dbInterface.getInstance();

    let review = await db.getReviewFromTrackAndUser(trackId, userId);

    if (review) {
      review.rating = ranking;
      await db.updateReview(review.reviewId, review.rating, review.comment);
      return review;
    }

    return await db.newReview(userId, trackId, ranking);
  }
}
