import { Body, Controller, Get, Param, Post, Query, Req, UnauthorizedException, UseGuards } from '@nestjs/common';
import { ApiBody, ApiCookieAuth, ApiCreatedResponse, ApiOperation, ApiProperty, ApiQuery, ApiTags } from '@nestjs/swagger';
import { AuthGuard } from 'src/auth/auth.guard';
import { ReviewDTO } from 'src/DB/dbInterface';
import { RankingService, TrackRankingDto } from './ranking.service';

export class PostRankingDto {
  @ApiProperty()
  trackId: Number;

  @ApiProperty()
  rating: Number;
}

@Controller()
export class RankingController {
  constructor(private readonly rankingService: RankingService) {}

  @Get()
  @ApiTags('Ranking')
  @ApiQuery({
    name: 'count',
    required: false,
    description: 'Le nombre de tracks à retourner. 10 par défaut'
  })
  @ApiOperation({
    description: "Obtenir les tracks ayant les meilleures notes"
  })
  @ApiCreatedResponse({
    description: "Liste des tracks classées",
    type: [PostRankingDto]
  })
  async getTop(@Query('count') count = 10) {
    const obj = await this.rankingService.getTopTracks(count);
    let out = [];

    for (const item of obj) {
      out.push({
        trackId: item['TRACK_ID'],
        rating: item['AVG']
      })
    }

    return out;
  }

  @Get('/track/:trackId')
  @ApiTags('Ranking')
  @ApiOperation({
    description: "Obtenir la moyenne des notes d'une track"
  })
  @ApiCreatedResponse({
    description: "Moyenne des notes et nombre de notes",
    type: TrackRankingDto
  })
  async getTrackRanking(@Param('trackId') trackId: number) {
    return await this.rankingService.getTrackRanking(trackId);
  }

  @ApiTags('Ranking')
  @ApiOperation({
      description: "Noter une track"
  })
  @ApiBody({
      description: "Infos sur la track à noter",
      type: PostRankingDto
  })
  @ApiCreatedResponse({
      description: "La review créée",
      type: ReviewDTO
  })
  @ApiCookieAuth()
  @UseGuards(AuthGuard)
  @Post()
  async postRanking(@Req() req, @Body() postRankingDto: PostRankingDto) {
      return await this.rankingService.postRanking(req.user.userId, postRankingDto.trackId, postRankingDto.rating);
  }
}
