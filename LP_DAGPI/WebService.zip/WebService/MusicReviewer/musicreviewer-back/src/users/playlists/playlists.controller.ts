import { BadRequestException, Body, Controller, Delete, Get, NotFoundException, Param, Post, Put, Query, UnauthorizedException, UseGuards } from '@nestjs/common';
import { ApiBody, ApiCookieAuth, ApiCreatedResponse, ApiOperation, ApiProperty, ApiTags } from '@nestjs/swagger';
import { AuthGuard } from 'src/auth/auth.guard';
import { PlaylistDTO } from 'src/DB/dbInterface';
import { PlaylistsService } from './playlists.service';

export class CreatePlaylistDto {
    @ApiProperty()
    playlistName: string;
}

@Controller('playlists')
export class PlaylistsController {
    constructor(private playlistsSerice: PlaylistsService) {}

    @ApiTags('Playlists')
    @ApiOperation({
        description: "Obtenir les playlists d'un utilisateur"
    })
    @ApiCreatedResponse({
        description: "Les playlists que l'utilisateur a créées",
        type: [PlaylistDTO]
    })
    @Get()
    async getUserPlaylists(@Param('userId') userId: Number) {
        return await this.playlistsSerice.getPlaylistsOfUser(userId);
    }

    @ApiTags('Playlists')
    @ApiOperation({
        description: "Créer une nouvelle playlists"
    })
    @ApiBody({
        description: "Infos sur la playlist à créer",
        type: CreatePlaylistDto
    })
    @ApiCreatedResponse({
        description: "La playlist créée",
        type: PlaylistDTO
    })
    @ApiCookieAuth()
    @UseGuards(AuthGuard)
    @Post()
    async createPlaylist(@Param('userId') userId: Number, @Body() createPlaylistDto: CreatePlaylistDto) {
        if (!createPlaylistDto.playlistName) throw new BadRequestException();

        return await this.playlistsSerice.createPlaylist(createPlaylistDto.playlistName, userId)
    }

    @ApiTags('Playlists')
    @ApiOperation({
        description: "Supprimer une playlist."
    })
    @ApiCookieAuth()
    @UseGuards(AuthGuard)
    @Delete(':playlistId')
    async deletePlaylist(@Param('userId') userId: Number,@Param('playlistId') playlistId: Number) {
        this.authorize(userId, playlistId);

        return await this.playlistsSerice.deletePlaylist(playlistId);
    }

    @ApiTags('Playlists')
    @ApiOperation({
        description: "Obtenir les tracks d'une playlist."
    })
    @Get(':playlistId/tracks')
    async getTracks(@Param('playlistId') playlistId: Number) {
        return await this.playlistsSerice.getPlaylistTracks(playlistId);
    }

    @ApiTags('Playlists')
    @ApiOperation({
        description: "Ajouter une track à une playlist."
    })
    @ApiCookieAuth()
    @UseGuards(AuthGuard)
    @Put(':playlistId/tracks')
    async addTrack(@Param('userId') userId: Number,@Param('playlistId') playlistId: Number, @Query('trackId') trackId: Number) {
        this.authorize(userId, playlistId);

        return await this.playlistsSerice.addTrackToPlaylist(playlistId, trackId);
    }

    @ApiTags('Playlists')
    @ApiOperation({
        description: "Supprimer une track d'une playlist."
    })
    @ApiCookieAuth()
    @UseGuards(AuthGuard)
    @Delete(':playlistId/tracks')
    async removeTrack(@Param('userId') userId: Number,@Param('playlistId') playlistId: Number, @Query('trackId') trackId: Number) {
        this.authorize(userId, playlistId);

        return await this.playlistsSerice.removeTrackFromPlaylist(playlistId, trackId);
    }

    private async authorize(userId: Number, playlistId: Number) {
        const playlist = await this.playlistsSerice.getPlaylist(playlistId);

        if (!playlist) throw new NotFoundException();

        const ownerId = playlist.userId;

        if (ownerId != userId) throw new UnauthorizedException();
    }
}
