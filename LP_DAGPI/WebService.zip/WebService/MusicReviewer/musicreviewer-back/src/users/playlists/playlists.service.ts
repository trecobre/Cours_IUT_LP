import { Injectable } from '@nestjs/common';
import { ApiProperty } from '@nestjs/swagger';
import { dbInterface } from 'src/DB/dbInterface';

@Injectable()
export class PlaylistsService {
    async getPlaylistsOfUser(userId: Number) {
        return await dbInterface.getInstance().getAllPlaylistByUserId(userId);
    }

    async getPlaylist(playlistId: Number) {
        return await dbInterface.getInstance().getPlaylistById(playlistId);
    }

    async createPlaylist(playlistName: string, userId: Number) {
        return await dbInterface.getInstance().newPlaylist(playlistName, userId);
    }

    async deletePlaylist(playlistId: Number) {
        await dbInterface.getInstance().deletePlaylist(playlistId);
    }

    async addTrackToPlaylist(playlistId: Number, trackId: Number) {
        await dbInterface.getInstance().addTrackToPlaylist(playlistId, trackId);
    }

    async getPlaylistTracks(playlistId: Number) {
        return await dbInterface.getInstance().getallPlaylistTrack(playlistId);
    }

    async removeTrackFromPlaylist(playlistId: Number, trackId: Number) {
        await dbInterface.getInstance().removeTrackFromPlaylist(playlistId, trackId);
    }
}
