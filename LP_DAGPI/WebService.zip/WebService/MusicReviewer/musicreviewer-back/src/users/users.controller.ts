import { Body, Controller, Get, HttpException, HttpStatus, Post, Query, UseGuards, Request, Param } from '@nestjs/common';
import { ApiBody, ApiCookieAuth, ApiCreatedResponse, ApiOperation, ApiProperty, ApiTags } from '@nestjs/swagger';
import { UserDTO } from 'src/DB/dbInterface';
import { UsersService } from './users.service';
import { AuthGuard } from 'src/auth/auth.guard';

class MinimalUserDto {
  @ApiProperty()
  userId: number;

  @ApiProperty()
  username: string;
}

class AddUserDto {
  @ApiProperty()
  username: string;

  @ApiProperty()
  password: string;
}

@Controller()
export class UsersController {
  constructor(private readonly usersService: UsersService) { }

  @Get('/byId/:userId')
  @ApiTags('Users')
  @ApiOperation({
    description: "Obtenir les informations basiques sur un utilisateurs à partir de son ID"
  })
  @ApiCreatedResponse({
    description: "Infos sur l'utilisateur demandé",
    type: MinimalUserDto
  })
  async getUser(@Param('userId') userId: number): Promise<UserDTO> {
    if (!userId) throw new HttpException("Missing user id", HttpStatus.BAD_REQUEST);

    let user = await this.usersService.getUser(userId);
    return user;
  }

  @Post()
  @ApiTags('Users')
  @ApiOperation({
    description: "Ajouter un nouvel utilisateur"
  })
  @ApiBody({
    description: "L'utilisateur à ajouter",
    type: AddUserDto
  })
  @ApiCreatedResponse({
    description: "L'utilisateur ajouté",
    type: MinimalUserDto
  })
  async addUser(@Body() userDto: UserDTO): Promise<UserDTO> {
    if (!userDto || !userDto.username || !userDto.password) throw new HttpException("Invalid user", HttpStatus.BAD_REQUEST);

    return await this.usersService.addUser(userDto);
  }

  @Get('me')
  @ApiTags('Users')
  @ApiOperation({
    description: "Obtenir l'utilisateur actuellement connecté"
  })
  @ApiCreatedResponse({
    description: "L'utilisateur connecté",
    type: MinimalUserDto
  })
  @ApiCookieAuth()
  @UseGuards(AuthGuard)
  async getMe(@Request() req) {
    return {...req.user.dataValues, sessionId: undefined, password: undefined};;
  }
}
