import { HttpException, HttpStatus, Injectable, NotFoundException } from '@nestjs/common';
import { dbInterface, UserDTO } from 'src/DB/dbInterface';
import { checkHash, getHash } from 'src/utils/utils';

@Injectable()
export class UsersService {
  async getUser(id: number): Promise<UserDTO> {
    const user = await dbInterface.getInstance().getMinimalUserById(id);

    if (!user)
    {
      throw new NotFoundException();
    }

    return user;
  }

  async findOne(filter: {id?: number, username?: string}): Promise<UserDTO> {

    let user: UserDTO = null;

    if (filter.id)
    {
      user = await dbInterface.getInstance().getUserById(filter.id);
    }

    if (filter.username)
    {
      user = await dbInterface.getInstance().getUserByName(filter.username);
    }

    if (!user)
    {
      throw new NotFoundException();
    }

    return user;
  }

  async addUser(user: UserDTO): Promise<UserDTO> {
    const db = dbInterface.getInstance();
    const findUser = await db.getUserByName(user.username);

    if (findUser) throw new HttpException("User already exists", HttpStatus.BAD_REQUEST)

    return await db.newUser(user.username, await getHash(user.password));
  }
}
