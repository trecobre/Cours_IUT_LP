import { Injectable } from '@nestjs/common';

@Injectable()
export class ReviewsService {
  getReview(): string {
    return 'Hello Review!';
  }
}
