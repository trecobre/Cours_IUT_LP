export const Cookies = {
    sessionId: 'sessionId'
}