import * as bcrypt from 'bcrypt';
import * as dotenv from "dotenv";
import * as crypto from 'crypto';
import { PlaylistDTO , UserDTO , dbInterface , ReviewDTO , PlaylistTracksDTO} from '../DB/dbInterface';

dotenv.config()

const SESSION_ID_SIZE = 64;

export function createSessionId() {
    return crypto.randomBytes(SESSION_ID_SIZE).toString('base64');
}

export function validateSessionId(sessionId: string) {
    return Buffer.from(sessionId, 'base64').length == SESSION_ID_SIZE;
}

export async function getHash(textToHash: string)
{
    const saltOrRounds = 10;
    return await bcrypt.hash(textToHash, saltOrRounds);
}

export async function checkHash(clearText: string, hash: string)
{
    return await bcrypt.compare(clearText, hash);
}

export async function feedDevDatabase(){
    const db = dbInterface.getInstance();
    let roger = null;
    roger = await db.getMinimalUserByName("Roger");
    if (roger == null || roger == undefined){
        //create users
        await db.newUser('Roger', (await getHash('mdproger')).toString());
        await db.newUser('Pierre', (await getHash('mdppierre')).toString());
        await db.newUser('Albert', (await getHash('mdpalbert')).toString());
        await db.newUser('Matthew', (await getHash('mdpmuse')).toString());
        await db.newUser('Thibault', (await getHash('mdpthibault')).toString());

        const rogerId = (await db.getUserByName('Roger')).userId;
        const pierreId = (await db.getUserByName('Pierre')).userId;
        const albertId = (await db.getUserByName('Albert')).userId;
        const matthewId = (await db.getUserByName('Matthew')).userId;
        const thibaultId = (await db.getUserByName('Thibault')).userId;
        //create reviews
        await db.newReview(rogerId,13636688,9.0);
        await db.newReview(pierreId,13636688,8.5);
        await db.newReview(albertId,13636688,10);
        await db.newReview(matthewId,13636688,9);
        await db.newReview(thibaultId,13636688,4);

        await db.newReview(rogerId,138539157,5);
        await db.newReview(pierreId,138539157,7);
        await db.newReview(albertId,138539157,9.3);
        await db.newReview(matthewId,138539157,10);
        await db.newReview(thibaultId,138539157,1);

        await db.newReview(rogerId,62082829,6);
        await db.newReview(pierreId,62082829,7);
        await db.newReview(albertId,62082829,8);
        await db.newReview(matthewId,62082829,10);
        await db.newReview(thibaultId,62082829,6);

        await db.newReview(rogerId,138539973,10);
        await db.newReview(pierreId,138539973,9);
        await db.newReview(albertId,138539973,8);
        await db.newReview(matthewId,138539973,10);
        await db.newReview(thibaultId,138539973,2);

        await db.newReview(rogerId,3599714,1);
        await db.newReview(pierreId,3599714,7);
        await db.newReview(albertId,3599714,5);
        await db.newReview(matthewId,3599714,4);
        await db.newReview(thibaultId,3599714,2);

        //create playlist
        await db.newPlaylist("MattBestRockSong",matthewId);
        const playlistId = (await db.getPlaylist("MattBestRockSong",matthewId)).playlistId;
        await db.addTrackToPlaylist(playlistId,13636688);
        await db.addTrackToPlaylist(playlistId,3824093);
        await db.addTrackToPlaylist(playlistId,3599714);
        await db.addTrackToPlaylist(playlistId,3590186);
        await db.addTrackToPlaylist(playlistId,138539157);
        await db.addTrackToPlaylist(playlistId,138544263);
        await db.addTrackToPlaylist(playlistId,138539973);
        await db.addTrackToPlaylist(playlistId,62082829);
        await db.addTrackToPlaylist(playlistId,7675196);
        await db.addTrackToPlaylist(playlistId,15178643);
    }
}

export class Config {
    private static loaded: boolean = false;

    public static env: string;
    public static jwtSecret: string;

    public static load() {
        if (!Config.loaded)
        {
            dotenv.config()

            Config.env = process.env.ENV;
            Config.jwtSecret = process.env.JWT_SECRET;

            Config.loaded = true;
        }
    }

    public static isDev() {
        return Config.env == 'dev';
    }
}

Config.load();