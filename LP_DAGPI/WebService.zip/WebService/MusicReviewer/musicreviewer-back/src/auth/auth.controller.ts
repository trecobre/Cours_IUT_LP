import { BadRequestException, Body, Controller, Delete, HttpCode, Post, Res } from '@nestjs/common';
import { ApiBody, ApiCreatedResponse, ApiOperation, ApiProperty, ApiTags } from '@nestjs/swagger';
import { UserDTO } from 'src/DB/dbInterface';
import { AuthService } from './auth.service';
import { Response } from 'express';
import { Cookies } from 'src/utils/cookies';

class LoginDto
{
  @ApiProperty()
  username: string;

  @ApiProperty()
  password: string;
}

class SuccessDto
{
  @ApiProperty()
  success: boolean;
}

@Controller()
export class AuthController {
    constructor(private authService: AuthService) {}

    @Post()
    @HttpCode(200)
    @ApiTags('Auth')
    @ApiOperation({
        description: "Connecter un utilisateur à la session active"
    })
    @ApiBody({
        description: "Identifiants de l'utilisateur",
        type: LoginDto
    })
    @ApiCreatedResponse({
        description: "Le cookie sessionId prend la valeur de l'ID de session de l'utilisateur.",
        type: SuccessDto
    })
    async login(@Body() userDto: UserDTO, @Res({ passthrough: true }) res: Response): Promise<SuccessDto> {
        if (!userDto || !userDto.username || !userDto.password) throw new BadRequestException();

        const sid = await this.authService.login(userDto);
        res.cookie(Cookies.sessionId, sid, { maxAge: 999999999999999, expires: new Date(8640000000000000) });

        return {success: true};
    }

    @Delete()
    @HttpCode(200)
    @ApiTags('Auth')
    @ApiOperation({
        description: "Déconnecter l'utilisateur de la session active."
    })
    @ApiCreatedResponse({
        description: "Supprime le cookie sessionId",
        type: SuccessDto
    })
    async logout(@Res({ passthrough: true }) res: Response): Promise<SuccessDto> {
        res.cookie('sessionId', null);
        return {success: true};
    }
}
