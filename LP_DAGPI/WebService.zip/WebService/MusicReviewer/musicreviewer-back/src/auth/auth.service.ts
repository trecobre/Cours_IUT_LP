import { Injectable, UnauthorizedException } from '@nestjs/common';
import { UserDTO } from 'src/DB/dbInterface';
import { checkHash, createSessionId } from 'src/utils/utils';
import { UsersService } from 'src/users/users.service';

@Injectable()
export class AuthService {
    constructor(
        private usersService: UsersService,
    ) { }

    async login(user: UserDTO) {
        let findUser = await this.usersService.findOne({username: user.username});

        const ex = new UnauthorizedException();

        if (!findUser) throw ex;

        const success = await checkHash(user.password, findUser.password);

        if (!success) throw ex;

        if (!findUser.sessionId)
        {
            findUser.sessionId = createSessionId();
            await findUser.save();
        }

        return findUser.sessionId;
    }
}
