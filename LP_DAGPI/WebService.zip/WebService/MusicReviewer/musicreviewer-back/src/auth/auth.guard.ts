import { CanActivate, ExecutionContext, Injectable, UnauthorizedException } from '@nestjs/common';
import { Request } from 'express';
import { dbInterface } from 'src/DB/dbInterface';
import { Cookies } from 'src/utils/cookies';

@Injectable()
export class AuthGuard implements CanActivate {
    constructor() { }

    async canActivate(context: ExecutionContext): Promise<boolean> {
        const request: Request = context.switchToHttp().getRequest();

        try {
            const user = await dbInterface.getInstance().getUserBySessionId(request.cookies[Cookies.sessionId]);

            if (!user) throw new UnauthorizedException();

            request['user'] = user;
        } catch {
            throw new UnauthorizedException();
        }
        return true;
    }
}