import { Config, feedDevDatabase } from './utils/utils';
import { NestFactory } from '@nestjs/core';
import { SwaggerModule, DocumentBuilder } from '@nestjs/swagger';
import { AppModule } from './app.module';
import { dbInterface } from './DB/dbInterface';
import { Logger } from '@nestjs/common';
import * as cookieParser from 'cookie-parser';

async function bootstrap() {
  const app = await NestFactory.create(AppModule);
  
  if (Config.isDev())
  {
    app.enableCors({
      credentials: true,
      origin: 'http://localhost:4200'
    });
    Logger.log("CORS Enabled");
  }

  app.use(cookieParser());

  const swaggerConfig = new DocumentBuilder()
    .setTitle('LoudR')
    .setDescription('The LoudR REST API description')
    .setVersion('1.0')
    .addTag('Users')
    .addTag('Music')
    .addTag('Reviews')
    .addTag('Ranking')
    .build();
  const document = SwaggerModule.createDocument(app, swaggerConfig);
  SwaggerModule.setup('doc', app, document);
  await dbInterface.getInstance().authenticate();
  await feedDevDatabase();
  await app.listen(3000);
}
bootstrap();
