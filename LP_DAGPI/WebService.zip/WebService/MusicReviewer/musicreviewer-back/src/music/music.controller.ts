import { BadRequestException, Controller, Get, HttpException, HttpStatus, Query, Res } from '@nestjs/common';
import { ApiCreatedResponse, ApiQuery, ApiTags } from '@nestjs/swagger';
import { MusicService, Track } from './music.service';

const SEPARATOR = ',';

@Controller()
export class MusicController {
  constructor(private readonly musicService: MusicService) {}

  @Get('track')
  @ApiTags('Music')
  @ApiQuery({
    name: 'trackId',
    required: false
  })
  @ApiQuery({
    name: 'trackIds',
    required: false,
    description: 'Une liste de track IDs, séparés par des virgules'
  })
  @ApiCreatedResponse({
    description: 'Les tracks demandées. Si trackId est utilisé, ne retourne pas un tableau mais directement la track.',
    type: [Track],
  })
  async getTrack(@Query('trackId') trackId?: Number, @Query('trackIds') trackIds?: String ) {
    if (trackId && trackIds) throw new BadRequestException('Please only provide trackId or trackIds, not both');
    if (trackId) {
      const track = await this.musicService.getTrack(trackId);

      if (!track) throw new HttpException("Track not found", HttpStatus.NOT_FOUND);

      return track;
    }
    else if (trackIds) {
      const trackIdsNumber = trackIds.split(SEPARATOR).map(Number).filter(n => !isNaN(n));

      const ex = new HttpException("Tracks not found", HttpStatus.NOT_FOUND);
      
      if (trackIdsNumber.length == 0) throw ex;

      const tracks = await this.musicService.getTracks(trackIdsNumber);

      if (!tracks) throw ex;

      const filteredTracks = tracks.filter(t => t);

      if (filteredTracks.length == 0) throw ex;

      return filteredTracks;
    }
    else throw new HttpException("Invalid track ID", HttpStatus.BAD_REQUEST);
  }

  @Get('search')
  @ApiTags('Music')
  @ApiCreatedResponse({
    description: 'Une liste de tracks correspondant à la recherche.',
    type: [Track],
  })
  async search(@Query('q') q: string): Promise<Track[]>
  {
    const results = await this.musicService.search(q);

    if (!results) throw new HttpException("Invalid query", HttpStatus.BAD_REQUEST);
    
    return results;
  }
}
