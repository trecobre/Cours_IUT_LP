import { Injectable } from '@nestjs/common';
import { ApiProperty } from '@nestjs/swagger';
import axios from 'axios';

const DEEZER_BASE_URL = "https://api.deezer.com"
const DEEZER_API = {
  Track: DEEZER_BASE_URL + "/track/",
  Search: DEEZER_BASE_URL + "/search"
}

export class Artist
{
  @ApiProperty()
  name: string;

  @ApiProperty()
  picture: string; // picture_xl
}

export class Album
{
  @ApiProperty()
  title: string;

  @ApiProperty()
  cover: string; // cover_xl

  @ApiProperty()
  release_date: string;
}

export class Track
{
  @ApiProperty()
  id: number;

  @ApiProperty()
  title: string;

  @ApiProperty()
  duration: number;

  @ApiProperty()
  artist: Artist;

  @ApiProperty()
  album: Album;
}

function formatTrack(track: any): Track
{
  return {
    id: track.id,
    title: track.title,
    duration: track.duration,
    artist: {
      name: track.artist.name,
      picture: track.artist.picture_xl
    },
    album: {
      title: track.album.title,
      cover: track.album.cover_xl,
      release_date: track.album.release_date
    }
  };
}

@Injectable()
export class MusicService {
  async getTrack(trackId: Number): Promise<Track> {
    const resp = await axios.get(DEEZER_API.Track + trackId);
    const track = resp.data;

    if (track.error) return null; // Error while getting this track
    
    return formatTrack(track);
  }

  async getTracks(trackIds: Number[]) {
    let outTracks: Track[] = [];

    for (const trackId of trackIds) {
      outTracks.push(await this.getTrack(trackId));
    }

    return outTracks;
  }

  async search(q: string): Promise<Track[]> {
    const resp = await axios.get(DEEZER_API.Search, {params: {q}});
    const results = resp.data;

    if (results.error) return null; // Error
    
    return results.data.map(t => formatTrack(t));
  }
}
