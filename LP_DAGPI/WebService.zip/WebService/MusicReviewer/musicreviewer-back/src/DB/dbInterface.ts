import { ApiProperty } from '@nestjs/swagger';
import { Sequelize , QueryTypes} from 'sequelize';
import {DataTypes, Model } from 'sequelize';

export class dbInterface {
  private static instance: dbInterface;

  static getInstance()
  {
    if (!this.instance)
    {
      this.instance = new dbInterface();
    }

    return this.instance;
  }

  constructor()
  {
    this.db = new Sequelize({
      dialect: 'sqlite',
      storage: './MusicReviewerDB'
    });
  }

  db: Sequelize;

  async authenticate() {
    try {
      await this.db.authenticate();
      console.log('Connection has been established successfully.');
    } catch (error) {
      console.error('Unable to connect to the database:', error);
    }
  }

  async  newUser(p_user: string, p_password: string) {
    const newUser = await UserDTO.create({
      username: p_user,
      password: p_password
    });
    return newUser;
  }


  async updateUser(p_id: Number, p_password: string , p_username:string){
    const updatedUser = await UserDTO.update({password : p_password, username:p_username },{
      where:{
        userId: p_id
      }
    });
    return updatedUser;
  }

  async updateUserSession(p_id: Number, p_sessionId: string){
    const updatedUser = await UserDTO.update({sessionId:p_sessionId},{
      where:{
        userId: p_id
      }
    });
    return updatedUser;
  }

  async deleteUser(p_id: Number){
    await UserDTO.destroy({where: { userId: p_id}});
  }

  async getMinimalUsersList(){
    const users = await UserDTO.findAll({attributes: [['USER_ID', 'userId'], ['USERNAME', 'username']]});
    return users;
  }

  async getUserById(p_id: Number) {
    return await UserDTO.findOne({where: {userId: p_id}});
  }

  async getUserBySessionId(p_sid: string) {
    return await UserDTO.findOne({where: {sessionId: p_sid}});
  }

  async getUserByName(p_username: string) {
    return await UserDTO.findOne({where: {username: p_username}});
  }

  async getMinimalUserById(p_id: Number) {
    return await UserDTO.findOne({where: {userId: p_id} ,attributes: [['USER_ID', 'userId'], ['USERNAME', 'username']]});
  }

  async getMinimalUserByName(p_username: string) {
    return await UserDTO.findOne({where: {username: p_username} , attributes: [['USER_ID', 'userId'], ['USERNAME', 'username']]});
  }

  //create playlist
  async newPlaylist(p_playlistName: string, p_userId: Number){
    const newPlaylist = await PlaylistDTO.create({
      userId: p_userId,
      playlistName: p_playlistName
    });
    return newPlaylist;
  }

  async updatePlaylist(p_playlistName: string, p_id: Number ){
    const updatedPlaylist = await PlaylistDTO.update({playlistName : p_playlistName},{
      where:{
        playlistId: p_id
      }
    })
    return updatedPlaylist;
  }

  async deletePlaylist(p_id: Number){
    await PlaylistDTO.destroy({where:{playlistId: p_id}});
  }

  async getAllPlaylistByUserId(p_userId: Number){
    return await PlaylistDTO.findAll({where: {userId: p_userId}});
  }

  async getAllPlaylistByName(p_playlistName: string){
    return await PlaylistDTO.findAll({where: {playlistName: p_playlistName}});
  }

  async getPlaylist(p_playlistName: string, p_userId: Number){
    return await PlaylistDTO.findOne({where: {playlistName: p_playlistName , userId: p_userId}});
  }

  async getPlaylistById(p_playlistId: Number) {
    return await PlaylistDTO.findOne({where: {playlistId: p_playlistId}});
  }

  async addTrackToPlaylist(p_playlistId:Number, p_trackId:Number){
    await PlaylistTracksDTO.create({
      playlistId : p_playlistId,
      trackId: p_trackId
    })
  }

  async removeTrackFromPlaylist(p_playlistId:Number , p_trackId:Number){
    await PlaylistTracksDTO.destroy({where:{playlistId : p_playlistId , trackId : p_trackId}})
  }

  async getallPlaylistTrack(p_playlistId:Number){
    return PlaylistTracksDTO.findAll({where:{playlistId : p_playlistId}})
  }

  async newReview(p_userId: Number,p_trackId: Number,p_rating: Number,p_comment: string = null){
      const newReview = await ReviewDTO.create({
        userId: p_userId,
        trackId: p_trackId,
        rating: p_rating,
        comment: p_comment,
      });
      return newReview;
  }

  async updateReview(p_reviewId: Number,p_rating: Number,p_comment: string = null){
    const updatedReview = await ReviewDTO.update({
      rating: p_rating,
      comment: p_comment,
    },
    {
      where : {reviewId: p_reviewId}
    });
    return updatedReview;
  }

  async getReviewRatingListFromUser(p_userId : Number){
    return ReviewDTO.findAll({where: {userId: p_userId} ,attributes: [['RATING', 'rating'],['TRACK_ID','trackId']]})
  }

  async getReviewRatingListFromTrack(p_trackId : Number){
    return ReviewDTO.findAll({where: {trackId: p_trackId} ,attributes: [['RATING', 'rating'],['USER_ID','userId']]})
  }

  async getReviewFromTrackAndUser(p_trackId : Number, p_userId : Number) {
    return ReviewDTO.findOne({where: {trackId: p_trackId, userId: p_userId} ,attributes: [['REVIEW_ID', 'reviewId'],['RATING', 'rating'],['USER_ID','userId']]})
  }

  async getReviewRatingAverageFromUser(p_userId : Number) {
    return (await db.query('SELECT AVG(RATING) as AVG FROM REVIEW WHERE USER_ID = ?',
    {
      replacements: [p_userId],
      type: QueryTypes.SELECT
    }))[0]['AVG'] as number;
  }

  async getReviewRatingAverageFromTrack(p_trackId : Number){
    return (await db.query('SELECT AVG(RATING) as AVG FROM REVIEW WHERE TRACK_ID = ?',
    {
      replacements: [p_trackId],
      type: QueryTypes.SELECT
    }))[0]['AVG'] as number;
  }

  async getTopTrackRanking(p_Topcmb : Number){
    return (await db.query('SELECT AVG(RATING) as AVG , TRACK_ID FROM REVIEW ' +
            'WHERE RATING IS NOT NULL '+
            'GROUP BY TRACK_ID ORDER BY AVG DESC '+
            'LIMIT ?',
    {
      replacements: [p_Topcmb],
      type: QueryTypes.SELECT
    }));
  }

}

const db =  dbInterface.getInstance().db;
export class UserDTO extends Model{
    declare userId: Number;
    declare password: string;
    declare username: string;
    declare sessionId: string;
}

UserDTO.init({
    userId:{
        type: DataTypes.NUMBER,
        field:'USER_ID',
        autoIncrement: true,
        primaryKey: true,
        allowNull: false
        },
    password:{
        type: DataTypes.TEXT,
        field:'PASSWORD',
        allowNull: false
    },
    username:{
        type:DataTypes.TEXT,
        field:'USERNAME',
        allowNull: false
    },
    sessionId:{
      type:DataTypes.TEXT,
      field:'SESSION_ID',
      allowNull: true,
    }
},
    {
    sequelize: db,
    modelName:'User',
    tableName:'USER',
    timestamps:false,
    }
);

//Model pour Playlist
export class PlaylistDTO extends Model{
  @ApiProperty()
  declare playlistId: Number;

  @ApiProperty()
  declare userId: Number;
  
  @ApiProperty()
  declare playlistName: string;
}
PlaylistDTO.init({
    playlistId:{
        type: DataTypes.NUMBER,
        field:'PLAYLIST_ID',
        primaryKey: true,
        allowNull: false,
        autoIncrement: true
    },
    userId:{
        type: DataTypes.NUMBER,
        field:'USER_ID',
        allowNull: false,
    },
    playlistName:{
        type: DataTypes.TEXT,
        field:'PLAYLIST_NAME',
        allowNull:false
    }
},
    {
      sequelize: db,
      modelName:'Playlist',
      tableName:'PLAYLIST',
      timestamps:false,
    });

//PlaylistTracks Model 
export class PlaylistTracksDTO extends Model{
    declare playlistTrackId: Number;
    declare playlistId: Number;
    declare trackId: Number;
}
PlaylistTracksDTO.init({
    playlistTrackId:{
      type: DataTypes.NUMBER,
      field:'PLAYLIST_TRACK_ID',
      primaryKey: true,
      allowNull: false,
      autoIncrement: true
    },
    playlistId:{
        type: DataTypes.NUMBER,
        field:'PLAYLIST_ID',
        allowNull:false
    },
    trackId:{
        type: DataTypes.NUMBER,
        field:'TRACK_ID',
        allowNull:false
    }
},
    {
        sequelize: db,
        modelName:'PlaylistTracks',
        tableName:'PLAYLIST_TRACK',
        timestamps:false,
    }
);

// model of Review
export class ReviewDTO extends Model{
    @ApiProperty()
    declare reviewId: Number;
    @ApiProperty()
    declare userId: Number;
    @ApiProperty()
    declare trackId: Number;
    @ApiProperty()
    declare rating: Number;
    declare comment: string;
    declare creationDate: Date;
}
ReviewDTO.init({
    reviewId:{
        type:DataTypes.NUMBER,
        field:'REVIEW_ID',
        primaryKey: true,
        allowNull: false,
        autoIncrement: true
    },
    userId:{
        type: DataTypes.NUMBER,
        field:'USER_ID',
        allowNull:false
    },
    trackId:{
        type:DataTypes.NUMBER,
        field:'TRACK_ID',
        allowNull:false,
    },
    rating:{
        type:DataTypes.NUMBER,
        field:'RATING',
        allowNull: false,
    },
    comment:{
        type:DataTypes.TEXT,
        field:'COMMENT',
        allowNull:true
    },
},
    {
        sequelize: db,
        modelName:'Review',
        tableName:'REVIEW',
        timestamps:false,
    }
);

//Relation entre base
UserDTO.hasMany(PlaylistDTO,{foreignKey : 'USER_ID'});
PlaylistDTO.belongsTo(UserDTO,{foreignKey:'USER_ID'});

UserDTO.hasMany(ReviewDTO,{foreignKey:'USER_ID'});
ReviewDTO.belongsTo(UserDTO,{foreignKey:'USER_ID'});

PlaylistDTO.hasMany(PlaylistTracksDTO,{foreignKey:'PLAYLIST_ID'});
PlaylistTracksDTO.hasOne(PlaylistDTO,{foreignKey:'PLAYLIST_ID'});
