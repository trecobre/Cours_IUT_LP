import { Module } from '@nestjs/common';
import { RouterModule } from '@nestjs/core';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { MusicModule } from './music/music.module';
import { RankingModule } from './ranking/ranking.module';
import { ReviewsModule } from './reviews/reviews.module';
import { UsersModule } from './users/users.module';
import { AuthModule } from './auth/auth.module';
import { ServeStaticModule } from '@nestjs/serve-static';
import { join } from 'path';
import { Config } from './utils/utils';
import { PlaylistsModule } from './users/playlists/playlists.module';

@Module({
  imports: [],
})
export class ApiModule {}

let appImports = [
  PlaylistsModule,
  UsersModule,
  AuthModule,
  MusicModule,
  ReviewsModule,
  RankingModule,
  RouterModule.register([
    {
      path: 'api',
      module: ApiModule,
      children: [
        {
          path: 'users',
          module: UsersModule,
          children: [
            {
              path: ':userId',
              module: PlaylistsModule
            }
          ]
        },
        {
          path: 'auth',
          module: AuthModule
        },
        {
          path: 'music',
          module: MusicModule,
        },
        {
          path: 'reviews',
          module: ReviewsModule,
        },
        {
          path: 'ranking',
          module: RankingModule,
        },
      ]
    },
  ]),
]

if (!Config.isDev())
{
  appImports.push(ServeStaticModule.forRoot({
    rootPath: join(__dirname, '..', 'musicreviewer-front/dist/musicreviewer-front')
  }));
}

@Module({
  imports: appImports,
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}
