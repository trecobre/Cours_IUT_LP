package fr.iut.designpattern.td.servlet;

import java.io.FileReader;
import java.io.IOException;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Quid extends HttpServlet {
  private static final long serialVersionUID = 1L;
  private String dbDriver;
  private String dbLogin;
  private String dbPassword;
  private String dbUrl;

  record ServletIO(HttpServletRequest req, HttpServletResponse resp) {
    String getParameter(String name) {
      return req.getParameter(name);
    }

    String getParameter(String name, String defaultValue) {
      var s = req.getParameter(name);
      return s == null ? defaultValue : s;
    }

    String getParameterString(String name, String defaultValue) {
      return getParameter(name, defaultValue);
    }

    boolean getParameterBoolean(String name, boolean defaultValue) {
      var value = req.getParameter(name);
      if (value == null)
        return defaultValue;
      try {
        return Boolean.valueOf(value);
      } catch (Exception e) {
        return defaultValue;
      }
    }

    int getParameterInt(String name, int defaultValue) {
      var value = req.getParameter(name);
      if (value == null)
        return defaultValue;
      try {
        return Integer.valueOf(value);
      } catch (Exception e) {
        return defaultValue;
      }
    }

    double getParameterDouble(String name, double defaultValue) {
      var value = req.getParameter(name);
      if (value == null)
        return defaultValue;
      try {
        return Double.valueOf(value);
      } catch (Exception e) {
        return defaultValue;
      }
    }

    float getParameterFloat(String name, float defaultValue) {
      var value = req.getParameter(name);
      if (value == null)
        return defaultValue;
      try {
        return Float.valueOf(value);
      } catch (Exception e) {
        return defaultValue;
      }
    }

  };

  @Override
  public void init(ServletConfig config) throws ServletException {
    super.init(config);

    var propertiesFileName = config.getInitParameter("PropertiesFileName");
    var propertiesPath = config.getServletContext().getRealPath(propertiesFileName);
    var prop = new Properties();
    try (
        var reader = new FileReader(propertiesPath, StandardCharsets.UTF_8)) {
      prop.load(reader);

      dbDriver = prop.getProperty("db.driver", "");
      dbUrl = prop.getProperty("db.url", "");
      dbLogin = prop.getProperty("db.login", "");
      dbPassword = prop.getProperty("db.password", "");

      initDB();
    } catch (Exception e) {
      throw new ServletException(e);
    }
  }

  private void initDB() throws SQLException, ClassNotFoundException {
    Class.forName(dbDriver);

    try (
        var con = DriverManager.getConnection(dbUrl, dbLogin, dbPassword);) {

      try (
          var userStmt = con.prepareStatement("SELECT idUser FROM wuser");
          var users = userStmt.executeQuery();) {

        if (users != null && users.next())
          return;
      } catch (Exception e) {
        /* la table user n'existe pas */ }

      try (
          var createUserStmt = con.prepareStatement("""
               CREATE TABLE IF NOT EXISTS wuser(
               idUser INT AUTO_INCREMENT PRIMARY KEY,
               created DATETIME,
               isDead BOOLEAN,
               birthDate DATE ,
               size FLOAT,
               firstname VARCHAR(80) NOT NULL,
               lastname VARCHAR(80) NOT NULL,
               login VARCHAR(80) NOT NULL,
               pwd VARCHAR(80) NOT NULL
              );
              """);) {
        createUserStmt.executeUpdate();
      }
      try (
          var addUserStmt = con.prepareStatement("""
              INSERT INTO wuser(
                  created,
                  isDead,birthDate,size,
                  firstname,lastname,
                  login,pwd
                ) VALUES (
                    now(),
                    ?,?,?,
                    ?,?,
                    ?,?);
              """);) {

        int index;

        // ajout utilisateur 1
        index = 0;
        addUserStmt.setBoolean(++index, false);
        addUserStmt.setDate(++index, Date.valueOf("2000-02-06"));
        addUserStmt.setFloat(++index, 1.80f);
        addUserStmt.setString(++index, "Charlotte");
        addUserStmt.setString(++index, "Molière");
        addUserStmt.setString(++index, "cm");
        addUserStmt.setString(++index, "cm");
        addUserStmt.executeUpdate();

        // ajout utilisateur 1
        index = 0;
        addUserStmt.setBoolean(++index, false);
        addUserStmt.setDate(++index, Date.valueOf("2004-02-06"));
        addUserStmt.setFloat(++index, 1.60f);
        addUserStmt.setString(++index, "Denise");
        addUserStmt.setString(++index, "dupont");
        addUserStmt.setString(++index, "dd");
        addUserStmt.setString(++index, "dd");
        addUserStmt.executeUpdate();
      }

    }

  }

  @Override
  protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
    doSend(req, resp);
  }

  @Override
  protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
    doSend(req, resp);
  }

  private void doSend(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
    var servletIO = new ServletIO(req, resp);
    var cmd = servletIO.getParameter("Order", "");

    try {
      switch (cmd) {
        case "ListUser":
          sendListUser(servletIO);
          break;
        case "AddUser":
          sendAddUser(servletIO);
          break;
        case "SetUser":
          sendSetUser(servletIO);
          break;
        case "DelUser":
          sendDelUser(servletIO);
          break;
        default:
          sendBadCmd(servletIO);
      }
    } catch (ServletException | IOException e) {
      throw e;
    } catch (Exception e) {
      throw new ServletException(e);
    }
  }

  private void sendBadCmd(ServletIO servletIO) throws Exception {
    servletIO.resp().setHeader("content-type", "text/plain");
    try (
        Writer out = servletIO.resp().getWriter();) {
      out.append("Commande inconnue !");
    }
  }

  private void sendListUser(ServletIO servletIO) throws Exception {
    servletIO.resp().setHeader("content-type", "application/json; charset=utf-8");
    try (
        var con = DriverManager.getConnection(dbUrl, dbLogin, dbPassword);
        var usersStmt = con.prepareStatement("SELECT * FROM wuser ORDER BY login ");
        var usersRs = usersStmt.executeQuery();

        Writer out = servletIO.resp().getWriter();) {
      out
          .append("{")
          .append("\"code\": 0,")
          .append("\"msg\": \"OK\",")
          .append("\"users\":")
          .append("[");
      var isFirst = true;
      while (usersRs.next()) {
        if (isFirst) {
          isFirst = false;
        } else {
          out.append(",");
        }
        out
            .append("{")
            .append("\"idUser\":\"").append(usersRs.getString("idUser")).append("\",")
            .append("\"created\":\"").append(usersRs.getString("created")).append("\",")
            .append("\"firstname\":\"").append(usersRs.getString("firstname")).append("\",")
            .append("\"lastname\":\"").append(usersRs.getString("lastname")).append("\",")
            .append("\"login\":\"").append(usersRs.getString("login")).append("\",")
            .append("\"size\":\"").append(usersRs.getString("size")).append("\",")
            .append("\"isDead\":\"").append(usersRs.getString("isDead")).append("\",")
            .append("\"birthDate\":\"").append(usersRs.getString("birthDate")).append("\"")
            .append("}");
      }
      out
          .append("]")
          .append("}");
    }
  }

  private void sendAddUser(ServletIO servletIO) throws Exception {
    servletIO.resp().setHeader("content-type", "application/json; charset=utf-8");
    try (
        var con = DriverManager.getConnection(dbUrl, dbLogin, dbPassword);
        var addUserStmt = con
            .prepareStatement(
                """
                    INSERT INTO
                      wuser(
                        created,
                        isDead, birthDate, size,
                        firstname, lastname,
                        login, pwd
                      ) VALUES(
                        now(),
                        ?,?, ?,
                        ?,?,
                        ?,?
                      )
                    """,
                java.sql.Statement.RETURN_GENERATED_KEYS);
        Writer out = servletIO.resp().getWriter();) {
      int index = 0;
      addUserStmt.setBoolean(++index, servletIO.getParameterBoolean("isDead", false));
      addUserStmt.setString(++index, servletIO.getParameterString("birthDate", ""));
      addUserStmt.setDouble(++index, servletIO.getParameterDouble("size", 0.0));
      addUserStmt.setString(++index, servletIO.getParameterString("firstname", ""));
      addUserStmt.setString(++index, servletIO.getParameterString("lastname", ""));
      addUserStmt.setString(++index, servletIO.getParameterString("login", ""));
      addUserStmt.setString(++index, servletIO.getParameterString("pwd", ""));
      addUserStmt.executeUpdate();

      var idUser = 0;
      try (
          var resultRS = addUserStmt.getGeneratedKeys()) {
        resultRS.next();
        idUser = resultRS.getInt(1);
      }

      out
          .append("{")
          .append("\"code\": 0,")
          .append("\"msg\": \"OK\",")
          .append("\"idUser\":" + idUser)
          .append("}");
    }
  }

  private void sendSetUser(ServletIO servletIO) throws Exception {
    servletIO.resp().setHeader("content-type", "application/json; charset=utf-8");
    try (
        var con = DriverManager.getConnection(dbUrl, dbLogin, dbPassword);
        var usersStmt = con
            .prepareStatement(
                """
                    UPDATE wuser SET
                        isDead=?, birthDate=?, size=?,
                        firstname=?, lastname=?,
                        login=?, pwd=?
                      WHERE idUser=?
                    """,
                java.sql.Statement.RETURN_GENERATED_KEYS);
        Writer out = servletIO.resp().getWriter();) {

      int index = 0;
      usersStmt.setBoolean(++index, servletIO.getParameterBoolean("isDead", false));
      usersStmt.setString(++index, servletIO.getParameterString("birthDate", ""));
      usersStmt.setDouble(++index, servletIO.getParameterDouble("size", 0.0));

      usersStmt.setString(++index, servletIO.getParameterString("firstname", ""));
      usersStmt.setString(++index, servletIO.getParameterString("lastname", ""));

      usersStmt.setString(++index, servletIO.getParameterString("login", ""));
      usersStmt.setString(++index, servletIO.getParameterString("pwd", ""));

      usersStmt.setInt(++index, servletIO.getParameterInt("idUser", 0));
      usersStmt.executeUpdate();

      out
          .append("{")
          .append("\"code\": 0,")
          .append("\"msg\": \"OK\"")
          .append("}");
    }
  }

  private void sendDelUser(ServletIO servletIO) throws Exception {
    var idUser = servletIO.getParameterInt("idUser", 0);

    servletIO.resp().setHeader("content-type", "application/json; charset=utf-8");
    try (
        var con = DriverManager.getConnection(dbUrl, dbLogin, dbPassword);
        var delUserStmt = con.prepareStatement("DELETE FROM wuser WHERE idUser=?");
        var out = servletIO.resp().getWriter();) {

      delUserStmt.setInt(1, idUser);
      if (delUserStmt.executeUpdate() > 0) {
        out
            .append("{")
            .append("\"code\": 0,")
            .append("\"msg\": \"OK\"")
            .append("}");
      } else {
        out
            .append("{")
            .append("\"code\": 1,")
            .append("\"msg\": \"User not found idUser=" + idUser + "\"")
            .append("}");
      }

    }
  }

}
