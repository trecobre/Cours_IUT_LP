

export class UsersList {
    loading = false;
    users = [];
    serverURI = "http://localhost:8080/gof/quid?";
    newUser = {
        isDead: false,
        birthDate: "",
        size: 1.60,
        firstname: "",
        lastname: "",
        login: "",
        pwd: ""
    };

    constructor() { }

    activate() {
        this.newUser = this.createUser();
        this.loadUsers();
    }

    createUser() {
        return {
            isDead: false,
            birthDate: "",
            size: 1.60,
            firstname: "",
            lastname: "",
            login: "",
            pwd: ""
        };
    }

    loadUsers() {
        this.loading = true;
        fetch(this.serverURI, {
            "method": "POST",
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/x-www-form-urlencoded'
            },
            body: 'Order=ListUser'
        }).then(response => {
            if (!response.ok)
                throw "Server returned " + response.status + " : " + response.statusText;
            return response.json();
        }).then(response => {
            for (let user of response.users) {
                //user.created = new Date(user.created);
                user.size = Math.round(user.size * 100) / 100;
            }
            this.users = response.users;
        }).catch(err => {
            console.log(err);
        }).finally(() => {
            this.loading = false;
        });
    }

    delUsers(idUser) {
        this.loading = true;
        fetch(this.serverURI, {
            "method": "POST",
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/x-www-form-urlencoded'
            },
            body: 'Order=DelUser&idUser=' + idUser
        }).then(response => {
            if (!response.ok)
                throw "Server returned " + response.status + " : " + response.statusText;
            return response.json()
        }).then(response => {
            if (response.code != 0)
                throw "Utilisateur introuvable !";
            let iUser = this.users.findIndex((a) => a.idUser == idUser);
            if (iUser >= 0)
                this.users.splice(iUser, 1);
        }).catch(err => {
            console.log(err);
        }).finally(() => {
            this.loading = false;
        });
    }

    addUsers(newUser) {
        this.loading = true;

        let params = "Order=AddUser";
        for (let key in newUser) {
            let value = newUser[key];
            params += "&" + encodeURIComponent(key) + "=" + encodeURIComponent(value);
        }

        fetch(this.serverURI, {
            "method": "POST",
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/x-www-form-urlencoded'
            },
            body: params
        }).then(response => {
            if (!response.ok)
                throw "Server returned " + response.status + " : " + response.statusText;
            return response.json()
        }).then(response => {
            if (response.code != 0)
                throw "Impossible d'ajouter l'utilisateur";
            let iUser = response.idUser;
            if (iUser >= 0) {
                this.loadUsers();
                this.newUser = this.createUser();
            } else {
                throw "Erreur lors de l'ajout";
            }



        }).catch(err => {
            console.log(err);
        }).finally(() => {
            this.loading = false;
        });
    }
}