import './App.css';
import Welcome from './components/Welcome/Welcome';

function App() {
  return (
    <div className="App">
      <Welcome name="dude" age="20"></Welcome>
    </div>
  );
}

export default App;
